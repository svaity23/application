﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos
{
    public class MetadataFieldDto
    {
        public Guid? AccountId { get; set; }
        public Guid? Id { get; set; }
        public string Label { get; set; }
        public bool Active { get; set; }
        public bool Default { get; set; }
        public int MetadataFieldTypeId { get; set; }
        public Guid MetadataProfileId { get; set; }
        public Guid Previous { get; set; }
        public bool Required { get; set; }
    }
}
