﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text.Json;
using WebApi.Authorization;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class AzureAdB2cController : ControllerBase
    {
        private readonly ILogger<AzureAdB2cController> _logger;
        private readonly IConfiguration _configuration;
        private readonly AzureAdB2cService _azureAdB2cService;

        public AzureAdB2cController(ILogger<AzureAdB2cController> logger, IConfiguration configuration, AzureAdB2cService azureAdB2cService)
        {
            _logger = logger;
            _configuration = configuration;
            _azureAdB2cService = azureAdB2cService;
        }
        
        [HttpPost("idtoken")]
        public IActionResult BuildIdToken([FromBody] JsonElement claimList)
        {
            _logger.LogDebug("WebApi AzureAdB2c: Build Id Token");

            try
            {
                string issuer = _configuration.GetSection("AzureAdB2C:IdToken:Issuer")?.Value;

                // All parameters send to Azure AD B2C needs to be sent as claims
                IList<System.Security.Claims.Claim> claims = new List<System.Security.Claims.Claim>();
                foreach (var element in claimList.EnumerateObject())
                {
                    if (element.Value.ValueKind == JsonValueKind.String)
                    {
                        claims.Add(new System.Security.Claims.Claim(element.Name, element.Value.GetString(), System.Security.Claims.ClaimValueTypes.String, issuer));
                    }
                }

                var token = _azureAdB2cService.BuildIdToken(claims);

                return Ok(new { token });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "WebApi AzureAdB2c: Exception occurred building token");
                //_telemetryClient.TrackException(ex);
                return null;
            }
        }

    }
}
