﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos
{
    public class MetadataFieldResponseDto
    {
        public MetadataFieldDto[] MetadataFields { get; set; }
        public MetadataFieldValueDto[] MetadataFieldValues { get; set; }
    }
}
