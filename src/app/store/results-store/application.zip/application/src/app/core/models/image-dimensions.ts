export interface ImageDimensions {
    clientHeight?: number;
    clientWidth?: number;
    naturalHeight?: number;
    naturalWidth?: number;
    offsetLeft?: number;
    offsetTop?: number;
    windowHeight?: number;
}