
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { BaseDataService } from './base-data.service';

import { LegalDocument } from '../models/legal-document';

export interface LegalDocumentDataServiceInterface {
    accept(legal: LegalDocument, userId: string, accountId: string): Observable<LegalDocument>;
}

@Injectable({ providedIn: 'root' })
export class LegalDocumentDataService extends BaseDataService implements LegalDocumentDataServiceInterface {
    accept(legal: LegalDocument, userId: string, accountId: string): Observable<LegalDocument> {
        const dto = {
            UserId: userId,
            AccountId: accountId,
            LegalId: legal.legalId
        };
        const url = `${this.webApiUrl}/legal`;
        return this.createApiPut({ url, data: dto });
    }
}
