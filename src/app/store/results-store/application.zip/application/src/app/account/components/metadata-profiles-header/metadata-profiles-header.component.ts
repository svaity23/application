import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-metadata-profiles-header',
  templateUrl: './metadata-profiles-header.component.html',
  styleUrls: ['./metadata-profiles-header.component.scss']
})
export class MetadataProfilesHeaderComponent  {
  @Input() className = '';

  constructor() { }
}
