﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos
{
    public class UpsertLightboxAssetsResponse
    {
        public Guid[] Ids { get; set; }
        public Guid LightboxId { get; set; }
        public int AssetCount { get; set; }
    }
}
