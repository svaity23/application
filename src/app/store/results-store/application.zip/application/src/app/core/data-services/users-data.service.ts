import { Injectable } from '@angular/core';

import { map } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

import { AccountLite } from '../models/account-lite.model';
import { BaseDataService } from './base-data.service';
import { HttpParams } from '@angular/common/http';
import { UpsertEntityResponse } from '../models/api-responses/upsert-entity-response.model';
import { User } from '../models/entities/user.model';
import { ValidateEmailResponse } from '../models/api-responses/validate-email-response.model';
import { ValidateUsersResponse } from '../models/api-responses/validate-users-response.model';

export interface UsersDataServiceInterface {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  add(user: User): Observable<any>;
  addFederated(): Observable<UpsertEntityResponse<User>>;
  assignGroup(users: User[], groupId: string): Observable<User[]>;
  bulkInactivate(users: User[]): Observable<string[]>;
  delete(id: string): Observable<User>;
  downloadAllUsers(includeInactiveUsers: boolean): Observable<Blob>;
  filterUsers(searchText: string): Observable<User[]>;
  getAll(): Observable<User[]>;
  getUserAccounts(): Observable<AccountLite[]>;
  sendEmailVerificationRequest(): Observable<boolean>;
  updateUser(user: User): Observable<User>;
  validateUploadUsersFile(usersFile: File): Observable<ValidateUsersResponse>;
  validateUserEmail(user: User): Observable<ValidateEmailResponse>;
  verifyUserEmail(): Observable<boolean>;
}

@Injectable({ providedIn: 'root' })
export class UsersDataService extends BaseDataService implements UsersDataServiceInterface {
  add(user: User): Observable<User> {
    const dto = {
      ExternalId: user.externalId,
      Active: true,
      FirstName: user.firstName,
      LastName: user.lastName,
      Email: user.email,
      RoleId: user.roleId,
      GroupId: user.groupId
    };
    const url = `${this.webApiUrl}/users`;
    return this.createApiPost({ url, data: dto });
  }

  addFederated(): Observable<UpsertEntityResponse<User>> {
    const url = `${this.webApiUrl}/users/createFederated`;
    return this.createApiPost({ url });
  }

  assignGroup(users: User[], groupId: string): Observable<User[]> {
    const userIds: string[] = users.map(u => u.id);
    const assignGroupRequest = { userIds, groupId };
    const url = `${this.webApiUrl}/users/bulk/assignGroup`;
    return this.createApiPut({ url, data: assignGroupRequest });
  }

  bulkInactivate(users: User[]): Observable<string[]> {
    const ids: string[] = users.map(u => u.id);
    const deleteUsersRequest = {
      ids
    };
    // TODO: rename webapi to inactivate
    const url = `${this.webApiUrl}/users/bulk/deletes`;
    return this.createApiPost({ url, data: deleteUsersRequest });
  }

  delete(id: string): Observable<User> {
    const url = `${this.webApiUrl}/users/${id}`;
    return this.createApiDelete({ url, options: { observe: 'response' } }).pipe(
      // eslint-disable-next-line @typescript-eslint/dot-notation
      map((data) => data['body'] as User)
    );
  }

  downloadAllUsers(includeInactiveUsers: boolean): Observable<Blob> {
    const params = new HttpParams()
      .set('includeInactive', includeInactiveUsers);
    const url = `${this.webApiUrl}/users/bulk/download`;
    return this.createApiGet({ url: url, options: { observe: 'body', responseType: 'blob' }, params });
  }

  filterUsers(searchText: string): Observable<User[]> {

    // TODO - rewrite this so the search is in the stored proc instead of
    // filtering the get all. Heavy operation here.

    // Also the subscribe is not correct, this could have been done
    // from the original observable and mappings.

    return new Observable(observer => {
      const temp: User[] = [];
      this.getAll().subscribe(data => {
        data.forEach((item) => {
          temp.push(item);
        });
        temp.slice();
        const items =
          temp.filter(u => {
            return u.lastName.toString().toLocaleLowerCase().includes(searchText.toLocaleLowerCase())
              || u.firstName.toString().toLocaleLowerCase().includes(searchText.toLocaleLowerCase())
              || u.email.toString().toLocaleLowerCase().includes(searchText.toLocaleLowerCase());
          });

        // Yield a single value and complete
        const clone = JSON.parse(JSON.stringify(items));
        observer.next(clone);
        observer.complete();
      });
    });
  }

  getAll(): Observable<User[]> {
    const url = `${this.webApiUrl}/users`;
    return this.createApiGet({ url });
  }

  getUserAccounts(): Observable<AccountLite[]> {
    const url = `${this.webApiUrl}/context/accounts`;
    return this.createApiGet({ url });
  }

  resendWelcomeEmail(user: User): Observable<boolean> {
    const dto = {
      Id: user.id,
      AccountId: user.accountId,
      ExternalId: user.externalId,
      Active: user.active,
      FirstName: user.firstName,
      LastName: user.lastName,
      Email: user.email,
      RoleId: user.roleId,
      RoleKey: user.roleKey,
      GroupId: user.groupId
    };
    const url = `${this.webApiUrl}/users/resendWelcomeEmailRequest`;

    return this.createApiPost({ url, data: dto }).pipe(
        map(() => true)
      );
  }

  sendEmailVerificationRequest(): Observable<boolean> {
    const url = `${this.webApiUrl}/users/emailVerificationRequest`;
    return this.createApiPost({ url }).pipe(
      map(() => true)
    );
  }

  signoutActivity(userId: string, accessToken: string): void {
    if (userId) {
      const url = `${this.webApiUrl}/userActivity/logout/${userId}`;

      const formData = new FormData();
      formData.append('authorization', accessToken);
      navigator.sendBeacon(url, formData);
    }
  }

  signoutActivityWaitForResponse(userId: string): Observable<number> {
    if (userId) {
      const url = `${this.webApiUrl}/userActivity/logout/${userId}`;
      return this.createApiPost({ url });
    }

    return of(0);
  }

  updateUser(user: User): Observable<User> {
    const id = user.id;
    const dto = {
      Id: user.id,
      AccountId: user.accountId,
      ExternalId: user.externalId,
      Active: user.active,
      FirstName: user.firstName,
      LastName: user.lastName,
      Email: user.email,
      RoleId: user.roleId,
      RoleKey: user.roleKey,
      GroupId: user.groupId,
      Federated: user.federated === true
    };
    const url = `${this.webApiUrl}/users/${id}`;
    return this.createApiPut({ url, data: dto });
  }

  uploadUsers(users: User[]): Observable<User[]> {
    const uploadUsersRequest = users;
    const url = `${this.webApiUrl}/users/bulk/create`;
    return this.createApiPost({ url, data: uploadUsersRequest });
  }

  validateUploadUsersFile(usersFile: File): Observable<ValidateUsersResponse> {
    const data = new FormData();
    data.append('file', usersFile, usersFile.name);
    const url = `${this.webApiUrl}/users/bulk/validateUsersFile`;

    return this.createApiPost({ url, data });
  }

  validateUserEmail(user: User): Observable<ValidateEmailResponse> {
    const dto = {
      Id: user.id,
      AccountId: user.accountId,
      ExternalId: user.externalId,
      Active: user.active,
      FirstName: user.firstName,
      LastName: user.lastName,
      Email: user.email,
      RoleId: user.roleId,
      RoleKey: user.roleKey,
      GroupId: user.groupId,
      Federated: user.federated === true
    };
    const url = `${this.webApiUrl}/users/validateEmail`;

    return this.createApiPost({ url, data: dto });
  }

  verifyUserEmail(): Observable<boolean> {
    const url = `${this.webApiUrl}/users/emailVerification`;
    return this.createApiPost({ url }).pipe(
      map(() => true)
    );
  }

}
