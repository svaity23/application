﻿namespace WebApi.Common.Constants
{
    public class IntegrationSettingKeys
    {
        public const string Slack = "integration-slack-enabled";
        public const string Hubspot = "integration-hubspot-enabled";
        public const string Marcom = "integration-marcomcentral-enabled";
        public const string MicrosoftLogin = "integration-microsoft-login-enabled";
        public const string WordPress = "integration-wordpress-enabled";
    }
}
