import { ChangeDetectionStrategy, Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Observable } from 'rxjs';

import { AccountDetail } from '@app/core/models/entities/account-detail.model';
import { AdminAccountStoreFacade } from '@app/store/admin-store/admin-account-store.facade';
import { AppStoreFacade } from '@app/store/app-store/app-store.facade';

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountsComponent implements OnInit {
  accounts$: Observable<AccountDetail[]>;
  activeAccounts$: Observable<AccountDetail[]>;
  includeInactiveAccounts  = false;

  constructor(private appStoreFacade: AppStoreFacade, private adminAccountStoreFacade: AdminAccountStoreFacade) { }

  addAccount(): void {
    this.appStoreFacade.navigate('admin/accounts/new');
  }

  editAccount(account: AccountDetail): void {
    this.appStoreFacade.navigate(`admin/accounts/${account.id}`);
  }

  filterAccounts(searchText: string): void {
    if (searchText !== null) {
      // this.usersStoreFacade.filterUsers(searchText);
      console.warn('Search Not implemented');
    }
  }

  navigateToUtilities(): void {
    this.appStoreFacade.navigate('/admin/utilities');
  }

  ngOnInit(): void {
    this.activeAccounts$ = this.adminAccountStoreFacade.activeAccounts$;
    this.accounts$ = this.adminAccountStoreFacade.accounts$;
  }

  setIncludeInactiveAccounts(isIncludeInActiveChecked: boolean): void {
      this.includeInactiveAccounts  = isIncludeInActiveChecked;
  }

}
