import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { filter, map, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AppStoreFacade } from '@app/store/app-store/app-store.facade';

@Injectable({
  providedIn: 'root'
})
export class SwitchAccountGuard implements CanActivate {

  constructor(private appStoreFacade: AppStoreFacade, private router: Router) { }

  canActivate(
    // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
    _route: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
    _state: RouterStateSnapshot): Observable<boolean | UrlTree> {

    return this.hasMultipleAccounts();
  }

  private hasMultipleAccounts(): Observable<boolean| UrlTree> {
    return this.appStoreFacade.userAccounts$.pipe(
      tap(userAccounts => {
        if (userAccounts.length === 0) {
          this.appStoreFacade.loadUserAccounts();
        }
      }),
      filter(userAccounts => userAccounts.length > 0),
      map(userAccounts => {
        const accountsCount = userAccounts.length;
        if (accountsCount === 1) {
          return this.router.parseUrl('/page-not-found'); // TODO: check where to navigate
        } else {
          return true;
        }
      })
    );
  }
}
