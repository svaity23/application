﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos.Zapier
{
    public class ZapAssetDto
    {
        public string Name { get; set; }
        public string ShareLink { get; set; }
        public string FileExt { get; set; }
        public long FileSize { get; set; }
        public string CollectionId { get; set; }
    }
}
