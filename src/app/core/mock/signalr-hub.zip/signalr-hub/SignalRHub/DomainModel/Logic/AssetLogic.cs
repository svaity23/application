﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using SignalRHub.DomainModel.Context;
using SignalRHub.DomainModel.Finders;
using SignalRHub.Messages;
using System;
using System.Threading.Tasks;

namespace ApplicationLogic.Logic
{
    public class AssetLogic
    {
        public ILogger<AssetLogic> Logger { get; set; }

        private readonly AssetFinder _finder;

        public AssetLogic(damContext context)
        {
            _finder = new AssetFinder(context);
            Logger = NullLogger<AssetLogic>.Instance;
        }

        public async Task<string> StoreAttachmentsAsync(ThumbReadyDTO payload)
        {
            return await _finder.StoreAttachmentsAsync(payload);
        }

        public async Task<string> StoreAiAndOcrTextAsync(TagsReadyDTO payload)
        {
            return await _finder.StoreAiAndOcrTextAsync(payload);
        }
    }
}
