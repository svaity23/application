﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text.Json;
using System.Text.Json.Serialization;
using WebApi.Dtos;
using WebApi.Dtos.Asset.Comment;
using WebApi.Dtos.Notification;
using WebApi.Services;
using WebApiTests.Shared;

namespace WebApiTests.Services
{
    [TestClass]
    public class DBNotificationServiceTest
    {

        #region [Click to open] Test initialization and configuration...
        private static damContext dbContext;
        private static UserDetailDto adminUser;
        private static UserDetailDto contributorUser;
        private static UserDetailDto viewerUser;
        private static readonly Random _rnd = new Random();
        private static readonly JsonSerializerOptions options = new JsonSerializerOptions()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            ReferenceHandler = ReferenceHandler.Preserve
        };
        private static List<Asset> _assets;
        private static readonly Guid TEST_ACCOUNT = Guid.Parse("5189526F-642F-449F-B018-5F5027A7191B"); // marcel@saguaro.ro
        private const string COMMENT_PREFIX = "~MSTest~ ";
        private static AssetService _as;


        [ClassInitialize]
        public static void BeforeClass(TestContext context)
        {
            Debug.WriteLine("Before all tests");
            dbContext = AzureSQLTools.InitializeDamContext();

            var loggerFactory = (ILoggerFactory)new LoggerFactory();
            sut = new NotificationService(loggerFactory.CreateLogger<NotificationService>(), dbContext);


            adminUser = AzureSQLTools.GetTestUser(dbContext, "admin", TEST_ACCOUNT);
            contributorUser = AzureSQLTools.GetTestUser(dbContext, "contributor", TEST_ACCOUNT);
            viewerUser = AzureSQLTools.GetTestUser(dbContext, "viewer", TEST_ACCOUNT);

            _as = new AssetService(null, null, null, null, dbContext, null);
            _assets = _as.GetActiveAssets(TEST_ACCOUNT).Result;
            // Prepare some notifications
            AddAssetComments();
        }

        private static void AddAssetComments()
        {
            AssetCommentDto commentDto = new()
            {
                Comment = COMMENT_PREFIX + "Admin::Can somebody check this message?",
                TaggedUserIds = new Guid[] { adminUser.Id }
            };
            UpsertResponse<AssetCommentDto> ret = _as.AddCommentAsync(TEST_ACCOUNT, adminUser.Id, _assets[0].Id, commentDto).Result;

            commentDto = new AssetCommentDto()
            {
                Comment = COMMENT_PREFIX + "Contributor::Can somebody check this message?",
                TaggedUserIds = new Guid[] { contributorUser.Id }
            };
            ret = _as.AddCommentAsync(TEST_ACCOUNT, contributorUser.Id, _assets[0].Id, commentDto).Result;
        }

        [ClassCleanup]
        public static void AfterClass()
        {
            CleanUp();
            dbContext.Dispose();
        }
        private static void CleanUp()
        {
            Debug.WriteLine("Clean up after all tests");
            try
            {
                dbContext.Database.ExecuteSqlRaw("delete from [dbo].[notification] " +
                    "where [mentionedUserId] = {0} ", adminUser.Id);
                dbContext.Database.ExecuteSqlRaw("delete from [dbo].[notification] " +
                    "where [mentionedUserId] = {0} ", contributorUser.Id);

                dbContext.Database.ExecuteSqlRaw("delete from [dbo].[assetComment] " +
                    "where [accountId] = {0} " +
                    "and comment like '" + COMMENT_PREFIX + "%'", TEST_ACCOUNT);

            }
            catch (Exception e) 
            {
                Debug.WriteLine(e.Message);
            }
        }

        [TestInitialize]
        public void BeforeTest()
        {
            Debug.WriteLine("...Prepare test");
        }

        [TestCleanup]
        public void AfterTest()
        {
            Debug.WriteLine("...Clear test\n");
        }
        #endregion

        // sut - Service Under Test
        private static NotificationService sut;

        [TestMethod]
        public void GetAllNotifications_Viewer()
        {
            Assert.IsNotNull(viewerUser); // Make sure we have a such user first ;-)
            GetEntitiesResponse<NotificationDto> result =
                sut.GetAllNotificationsAsync((Guid)viewerUser.AccountId, viewerUser.Id).Result;
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Error.Code == 3);
        }

        [TestMethod]
        public void GetAllNotifications_NonViewer()
        {
            Assert.IsNotNull(adminUser); // Make sure we have a such user first ;-)

            // Make sure the get notification returns content for admin like users
            GetEntitiesResponse<NotificationDto> result =
                sut.GetAllNotificationsAsync((Guid)adminUser.AccountId, adminUser.Id).Result;
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Error);
            Assert.AreEqual<int>(0, result.Error.Code);

            Assert.IsNotNull(result.Entities);
            Assert.IsTrue(result.Entities.Count > 0);

            Assert.IsNotNull(contributorUser);
            result = 
                sut.GetAllNotificationsAsync((Guid)contributorUser.AccountId, contributorUser.Id).Result;
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Error);
            Assert.AreEqual<int>(0, result.Error.Code);

            Assert.IsNotNull(result.Entities);
            Assert.IsTrue(result.Entities.Count > 0);
        }

        [TestMethod]
        public void MarkNotifications()
        {
            Assert.IsNotNull(adminUser); // Make sure we have a such user first ;-)

            // Make sure the get notification returns content for admin like users
            GetEntitiesResponse<NotificationDto> result =
                sut.GetAllNotificationsAsync((Guid)adminUser.AccountId, adminUser.Id).Result;
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Error);
            Assert.AreEqual<int>(0, result.Error.Code);

            if (result.Entities.Count > 0)
            {
                MarkNotificationDTO mark = new MarkNotificationDTO()
                {
                    MarkAsRead = true,
                    Ids = new List<Guid> { result.Entities[0].Id }
                };
                GetEntitiesResponse<Guid> ret = sut.MarkNotificationAsync(TEST_ACCOUNT, adminUser.Id, mark).Result;
                Assert.IsNotNull(ret);
                Assert.IsNotNull(ret.Error);
                Assert.AreEqual<int>(0, ret.Error.Code);
                Assert.AreEqual<int>(1, ret.Entities.Count);

                result =
                sut.GetAllNotificationsAsync((Guid)adminUser.AccountId, adminUser.Id).Result;
                foreach(NotificationDto notification in result.Entities)
                {
                    if (notification.Id.Equals(mark.Ids[0]))
                    {
                        Assert.IsTrue(notification.Read);
                        break;
                    }
                }
            }

        }

        [TestMethod]
        public void DeleteAsync()
        {
            Assert.IsNotNull(adminUser); // Make sure we have a such user first ;-)

            GetEntitiesResponse<NotificationDto> result =
                sut.GetAllNotificationsAsync((Guid)adminUser.AccountId, adminUser.Id).Result;
            Assert.IsNotNull(result);

            Assert.IsNotNull(result.Entities);
            Assert.IsTrue(result.Entities.Count > 0);

            var initialNotificationCount = result.Entities.Count;

            GetEntitiesResponse<Guid> deleteResult = sut.DeleteAsync((Guid)adminUser.AccountId, adminUser.Id, result.Entities[0].Id).Result;
            Assert.IsNotNull(deleteResult);
            Assert.IsTrue(deleteResult.Entities.Count == 1);

            result =
                sut.GetAllNotificationsAsync((Guid)adminUser.AccountId, adminUser.Id).Result;
            Assert.IsNotNull(result);
            if (initialNotificationCount == 1)
            {
                Assert.IsNull(result.Entities);
            }
            else
            {
                Assert.AreEqual<int>(result.Entities.Count, initialNotificationCount - 1);
            }
        }

    }
}