﻿namespace WebApi.Enums
{
    public static class ServiceBusMessageType
    {
        public const string ASSETS_MODIFIED                     = "ASSETS_MODIFIED";
        public const string ASSETS_ADDED                        = "ASSETS_ADDED";
        public const string ASSETS_DELETED                      = "ASSETS_DELETED";
        public const string ASSETS_SHARED                       = "ASSET_SHARED";
        public const string REINDEX                             = "REINDEX";
        public const string AI_TAGS_REQUESTED                   = "AI_TAGGING_REQUESTED";


        public const string CANCEL_UPLOAD_SESSION               = "CANCEL_UPLOAD_SESSION";
        public const string FILE_UPLOADED                       = "FILE_UPLOADED";
        public const string VIDEO_UPLOADED                      = "VIDEO_UPLOADED";


        public const string ASSETS_ADDED_TO_HUBSPOT             = "ASSETS_ADDED_TO_HUBSPOT";
        public const string ASSETS_REMOVED_FROM_HUBSPOT         = "ASSETS_REMOVED_FROM_HUBSPOT";
        public const string SYNC_ALL_TO_HUBSPOT                 = "SYNC_ALL_TO_HUBSPOT";
        public const string LOGIN_TO_HUBSPOT                    = "LOGIN_TO_HUBSPOT";

        public const string CONVERT_OR_RESIZE                   = "CONVERT_OR_RESIZE";
        public const string DOWNLOAD_CONVERSION_READY           = "DOWNLOAD_CONVERSION_READY";

        public const string FREE_TRIAL_ACCOUNT_REQUESTED        = "FREE_TRIAL_ACCOUNT_REQUESTED";
        public const string NOTIFICATION_INITIATED              = "NOTIFICATION_INITIATED";
    }
}
