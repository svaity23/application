﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApi.Dtos;
using WebApi.Extensions;
using WebApi.Enums;
using WebApi.Dtos.Context;

namespace WebApi.Services
{
    public class AccountService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<AccountService> _logger;
        private readonly ServiceBusService _serviceBusService;
        private AccountLogic _accountLogic;
        private RoleLogic _roleLogic;

        public AccountService(IConfiguration configuration, ILogger<AccountService> logger, damContext context, ServiceBusService serviceBusService)
        {
            _configuration = configuration;
            _logger = logger;
            _serviceBusService = serviceBusService;
            _accountLogic = new AccountLogic(context);
            _roleLogic = new RoleLogic(context);
        }

        public async Task<UpsertResponse<AccountDetailtDto>> UpsertAccountAsync(Guid userId, AccountDetailtDto dto)
        {
            // always set storage account name from config for upsert
            dto.StorageAccountName = _configuration["BlobStorage:StorageAccountName"];
            
            var result = await _accountLogic.UpsertAccountAsync(userId, dto.ToJsonString());
            var upsertResponse = System.Text.Json.JsonSerializer.Deserialize<UpsertResponse<AccountDetailtDto>>(result);

            if (upsertResponse.Entity != null && upsertResponse.Entity.UserId != Guid.Empty)
            {
                //Set SelfReg flag to false while sending a message to UserSync, as this is the regular Upsert.
                await SendUpsertUserMessage(upsertResponse.Entity.UserId, upsertResponse.Entity.Id, false);
                //Format the domain list
                upsertResponse.Entity.FederatedDomains = GetFederatedDomains(upsertResponse.Entity.FederatedDomains);
            }

            return upsertResponse;
        }

        public async Task<int> DeleteAcount(Guid accountId)
        {
            return await  _accountLogic.DeleteAccount(accountId);
        }

        private async Task SendCreateAccountMessage(AccountDetailtDto dto, Guid userId, FreeTrialSignalRDto signalRDto)
        {
            await _serviceBusService.SignalAccountRequested(
                new { 
                      MessageType = ServiceBusMessageType.FREE_TRIAL_ACCOUNT_REQUESTED,
                      Id = userId, 
                      AccountDetails = dto, 
                      SignalRConnectionId = signalRDto.SignalRConnectionId,
                      Source = signalRDto.SignalRSource
                });
        }

        /// <summary>
        /// This method sends a message to the CreateAccount container, which creates the FreeTrial account, 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="dto"></param>
        /// <param name="signalRDto"></param>
        /// <returns></returns>
        public async Task SelfRegUpsertAccountAsync(Guid userId, AccountDetailtDto dto, FreeTrialSignalRDto signalRDto)
        {
            // always set storage account name from config for upsert
            dto.StorageAccountName = _configuration["BlobStorage:StorageAccountName"];
            
            // Send a message on the 'account-requested' bus to the CreateAccount worker service where FreeTrial Accounts will be processed. 
            await SendCreateAccountMessage(dto, userId, signalRDto);
        }

        public async Task<SampleDataResponseDto> CreateFreeTrialSampleDataAsync(Guid accountId, Guid userId)
        {
            var sourceAccountId = _configuration["FreeTrial:SourceAccountId"];
            var collectionNames = _configuration["FreeTrial:CollectionNames"];
            SampleDataRequestDto request = new SampleDataRequestDto();
            request.SourceAccountId = Guid.Parse(sourceAccountId);
            request.CollectionNames = collectionNames;
            var jsonString = request.ToJsonString();

            var result = await _accountLogic.CreateFreeTrialSampleDataAsync(accountId, userId, jsonString);
            var sampleDataResponse = System.Text.Json.JsonSerializer.Deserialize<SampleDataResponseDto>(result);
            return sampleDataResponse;
        }

        public async Task<AccountBrandUpdateResponseDto> UpdateThemeAsync(Guid userId, Guid accountId, string theme)
        {
            var accountBrandParams = new AccountBrandParamsDto
            {
                Theme =  theme
            };
            var jsonString = accountBrandParams.ToJsonString();
            var jsonResult = await _accountLogic.UpdateAccountBrandDetailsAsync(userId, accountId, jsonString);            
            return JsonConvert.DeserializeObject<AccountBrandUpdateResponseDto>(jsonResult);
        }

        public async Task<IEnumerable<AccountDetailtDto>> GetAllAccountsAsync(bool includeInactive = true)
        {
            var jsonOutput = await _accountLogic.GetAllResultsAsync(includeInactive);
            var result = JsonConvert.DeserializeObject<GetEntitiesResponse<AccountDetailtDto>>(jsonOutput);

            // TODO: This logic should be handled in the getAccounts stored proc. Temp fix for now...
            foreach(var a in result.Entities)
            {
                a.FederatedDomains = GetFederatedDomains(a.FederatedDomains);
            }

            return result.Entities;
        }

        public async Task<GetEntitiesResponse<AccountDto>> GetAccountsByUserIdAsync(Guid userId)
        {
            var jsonOutput = await _accountLogic.GetAccountsByUserIdAsync(userId);
            var result = JsonConvert.DeserializeObject<GetEntitiesResponse<AccountDto>>(jsonOutput);            
            return result;
        }

        public async Task<AccountDetailtDto> GetFederateAdAccountByEmailAsync(string email)
        {
            var accountJson = await _accountLogic.GetFederateAdAccountByEmailAsync(email).ConfigureAwait(false);
            var account = JsonConvert.DeserializeObject<AccountDetailtDto>(accountJson);

            return account;
        }

        public async Task<Account> FindByIdAsync(Guid id)
        {
            return await _accountLogic.FindByIdAsync(id);
        }

        public async Task<AccountDetailtDto> GetAccountDetailByIdAsync(Guid id, Guid userId)
        {         
            var jsonOutput = await _accountLogic.GetAccountDetailByAccountId(id, userId);
            return JsonConvert.DeserializeObject<AccountDetailtDto>(jsonOutput);
        }

        public async Task<AccountDetail> GetAccountByNameAsync(string name)
        {          
            return await _accountLogic.GetByNameAsync(name);
        }

        public async Task<FeatureDto[]> GetAccountFeaturesAsync(Guid accountId, Guid userId)
        {
            var jsonOutput = await _accountLogic.GetAccountFeaturesAsync(accountId, userId);
            return JsonConvert.DeserializeObject<FeatureDto[]>(jsonOutput);
        }

        public async Task<FeatureDto[]> UpdateAccountFeaturesAsync(Guid accountId, Guid userId, FeatureDto[] features)
        {
            var jsonOutput = await _accountLogic.UpdateAccountFeaturesAsync(accountId, userId, features.ToJsonString());
            return JsonConvert.DeserializeObject<FeatureDto[]>(jsonOutput);
        }

        public static AccountDetailtDto ToDto(AccountDetail result)
        {
            // this is really a view, so we dont even need a dto conversion
            // but leaving as an example
            if (result == null)
            {
                return null;
            }

            return new AccountDetailtDto
            {
                Id = result.Id,
                Active = result.Active,
                Created = result.Created,
                Modified = result.Modified,
                AccountTypeName = result.AccountTypeName,
                Name = result.Name,
                SalesforceId = result.SalesforceId,
                TrialExpiration = result.TrialExpiration,
                StorageAccountName = result.StorageAccountName,
                UserEmail = result.UserEmail,
                UserFirstName = result.UserFirstName,
                UserLastName = result.UserLastName,
                UserId = result.UserId.Value,
                NetsuiteId = result.NetsuiteId,
                OpportunityId = result.OpportunityId,
                StorageMaximumGb = result.StorageMaximumGb,
                TrialVerified = result.TrialVerified,
                FederatedDomains = GetFederatedDomains(result.FederatedDomains)
            };
        }

        public static List<AccountDetailtDto> ToDto(IEnumerable<AccountDetail> accounts)
        {
            var dtos = new List<AccountDetailtDto>();
            foreach (var a in accounts)
            {
                dtos.Add(ToDto(a));
            }
            return dtos;
        }
       
        public async Task<UpsertResponse<FederatedDomainDto>> SaveFederatedDomainAsync(Guid accountId, Guid userId, Guid sessionId, FederatedDomainDto dto)
        {
            var jsonString = dto.ToJsonString();

            var result = await _accountLogic.SaveFederatedDomainAsync(accountId, userId, sessionId, jsonString);
            var upsertResponse = System.Text.Json.JsonSerializer.Deserialize<UpsertResponse<FederatedDomainDto>>(result);

            return upsertResponse;
        }

        public async Task<UpsertResponse<List<Guid>>> DeleteFederatedDomainsAsync(Guid accountId, Guid userId, Guid sessionId, BulkDeleteRequestDTO domains)
        {
            var result = await _accountLogic.DeleteFederatedDomainsAsync(accountId, userId, sessionId, domains.ToJsonString());
            var upsertResponse = System.Text.Json.JsonSerializer.Deserialize<UpsertResponse<List<Guid>>>(result);
            return upsertResponse;
        }

        private static string GetFederatedDomains(string domain)
        {
            if (domain == null)
            {
                return string.Empty;
            }
            else
            {
                domain = domain.Trim();
                // view is returning a comma separated list, remove last comma
                if (domain.EndsWith(","))
                {
                    return domain.Remove(domain.Length - 1, 1);
                }

                return domain;
            }
        }

        private async Task SendUpsertUserMessage(Guid userId, Guid accountId, bool selfReg = false)
        {
            await _serviceBusService.SignalUserSync(
                new
                {
                    Action = "UPSERT",
                    Id = userId,
                    SelfReg = selfReg,
                    AccountId = accountId
                });
        }
    }
}
