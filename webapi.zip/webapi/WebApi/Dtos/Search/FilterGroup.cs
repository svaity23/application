﻿using System;
using System.Collections.Generic;
using WebApi.Enums;

namespace WebApi.Dtos.Search
{
    public class FilterGroup
    {
        public int? DisplayOrder { get; set; }
        public FilterGroupTypeEnum FilterGroupType { get; set; }
        public Guid? MetadataFieldId { get; set; }
        public string Name { get; set; }
    }
}
