import { ActivatedRouteSnapshot, CanActivate, CanLoad, Route, Router, RouterStateSnapshot, UrlSegment, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { OidcFacade } from 'ng-oidc-client';

import { Observable, of } from 'rxjs';
import { switchMap, take } from 'rxjs/operators';

import * as LocalStorageKey from '@app/core/constants/local-storage-keys'

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate, CanLoad {

  constructor(private oidcFacade: OidcFacade, private router: Router) { }

  // canActivate is used to prevent an unauthorized user for components like TermsOfUseComponent(no module).
  canActivate(
    // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
    _next: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
    _state: RouterStateSnapshot): Observable<boolean | UrlTree> | boolean {

    return this.oidcFacade.waitForAuthenticationLoaded().pipe(
      switchMap(() => {
        return this.hasAuthenticatedUser(_state.url);
      })
    );
  }

  // canLoad is used to prevent the entire module of app. lazyloading.
  canLoad(_route: Route, _segments: UrlSegment[]): Observable<boolean | UrlTree> | boolean {
    return this.oidcFacade.waitForAuthenticationLoaded().pipe(
      switchMap(() => {
        return this.hasAuthenticatedUser(window.location.href);
      })
    );
  }

  // Check to see oidc identity exists in state
  hasAuthenticatedUser(url: string): Observable<boolean | UrlTree> {
    return this.oidcFacade.identity$.pipe(
      take(1),
      switchMap(user => {
        if (user && !user.expired) {
          // set to local storage selectedAccountId
          const extensionAccountId: string = user.profile?.extension_accountId;
          return this.hasMultipleAccounts(extensionAccountId);
        } else {
          // initiate sign in
          this.oidcFacade.signinRedirect(
            {
              state: { redirect_url: url }
            }
          );
          return of(false);
        }
      })
    );
  }

  private hasMultipleAccounts(extensionAccountId: string): Observable<boolean | UrlTree> {
    if (extensionAccountId == null) {
      window.localStorage.removeItem(LocalStorageKey.SELECTED_ACCOUNT_ID); // help clear out for sys-admin
      return of(true);
    }
    const accountIds: string[] = extensionAccountId.split(',');
    if (accountIds.length === 1) {
      window.localStorage.setItem(LocalStorageKey.SELECTED_ACCOUNT_ID, accountIds[0]);
      return of(true);
    }
    if (accountIds.length > 1) {
      const accountId: string = window.localStorage.getItem(LocalStorageKey.SELECTED_ACCOUNT_ID); // check if already set
      if (accountId != null && accountId !== '') {
        // check if account id exists in claims
        const accountExists = accountIds.find(a => a.toLocaleLowerCase() === accountId.toLocaleLowerCase());
        const additionalAccounts = accountIds.length > 6 // we save trailing comma for more than 6 accounts
        if (!accountExists && !additionalAccounts) {
          window.localStorage.removeItem(LocalStorageKey.SELECTED_ACCOUNT_ID); // clear storage
          return of(this.router.parseUrl('/select-account'));
        }
        return of(true);
      } else {
        // open account selection screen
        return of(this.router.parseUrl('/select-account'));
      }
    }
  }
}
