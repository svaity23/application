export interface ValidateEmailResponse {
  error: string,
  valid?: number
}
