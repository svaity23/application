﻿using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Primitives;
using System;
using System.Security.Cryptography;
using System.Text;

namespace WebApi.Extensions
{
    public static class HttpRequestEntensions
    {
        public static string GetHeaderValue(this HttpRequest request, string name)
        {
            StringValues values;
            var found = request.Headers.TryGetValue(name, out values);
            if (found)
            {
                return values.FirstOrDefault();
            }

            return null;
        }

        public static Guid GetB2CSessionId(this HttpRequest request)
        {
            var authString = GetHeaderValue(request, "Authorization");

            if (string.IsNullOrEmpty(authString))
                return Guid.Empty;

            using MD5 md5 = MD5.Create();
            byte[] hash = md5.ComputeHash(Encoding.UTF8.GetBytes(authString));
            var sesId = new Guid(hash);
            return sesId;
        }

    }
}
