using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using System;

namespace ApplicationLogic
{
    public class HelloWorld
    {  
        public string Greeting { get; set; }

    }
}
