using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AllowAnonymous]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class UserActivityController : ControllerBase
    {
        private readonly ILogger<UserActivityController> _logger;
        private readonly UserService _userService;
        
        public UserActivityController(ILogger<UserActivityController> logger, UserService userService)
        {
            _logger = logger;
            _userService = userService;
        }
    
        [HttpPost("logout/{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> LogoutUserActivity(Guid id)
        {
            var user = await _userService.GetUserByIdAsync(id);
            if (user != null)
            {
                var userId = user.Id;
                var accountId = user.AccountId;

                if (!Request.Headers.Keys.Contains("Authorization"))
                {
                    string authorization = this.Request.Form["authorization"];
                    this.Request.Headers["Authorization"] = string.Format("Bearer {0}", authorization);
                }
                var sessionId = this.Request.GetB2CSessionId();

                var results = await _userService.CreateUserLogoutAsync(userId, accountId, sessionId);
                return Ok(JsonConvert.SerializeObject(results));

            }
            else
            {
                return NotFound();
            }
        }
    }
}
