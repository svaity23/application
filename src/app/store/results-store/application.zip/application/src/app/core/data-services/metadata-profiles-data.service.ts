import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { BaseDataService } from './base-data.service';
import { MetadataField } from '../models/entities/metadata-field.model';
import { MetadataFieldValue } from '../models/entities/metadata-field-value.model';
import { MetaDataFieldView } from '../models/metadata-field-view.model';
import { MetadataProfileView } from '../models/metadata-profile-view.model';

export interface MetadataProfilesDataServiceInterface {
  add(profile: MetadataProfileView): Observable<MetadataProfileView>;
  delete(id: string): Observable<MetadataProfileView>;
  getAll(): Observable<MetadataProfileView[]>;
  getMetadataProfileFieldsByProfileId(id: string): Observable<MetaDataFieldView>;
  saveMetadataProfileFieldsByProfileId(id: string, metadataFields: MetadataField[], metadataFieldValues: MetadataFieldValue[]): Observable<MetaDataFieldView>;
  update(profile: MetadataProfileView): Observable<MetadataProfileView>;
}

@Injectable({
  providedIn: 'root'
})
export class MetadataProfilesDataService extends BaseDataService implements MetadataProfilesDataServiceInterface {

  add(profile: MetadataProfileView): Observable<MetadataProfileView> {
    console.log(profile);
    throw new Error('Method not implemented.');
  }

  delete(id: string): Observable<MetadataProfileView> {
    console.log(id);
    throw new Error('Method not implemented.');
  }

  getAll(): Observable<MetadataProfileView[]> {
    const url = `${this.webApiUrl}/metadataprofiles`;
    return this.createApiGet({ url });
  }

  getMetadataProfileFieldsByProfileId(id: string): Observable<MetaDataFieldView> {
    const url = `${this.webApiUrl}/metadataprofiles/${id}/fields`;
    return this.createApiGet({ url });
  }

  saveMetadataProfileFieldsByProfileId(id: string, metadataFields: MetadataField[], metadataFieldValues: MetadataFieldValue[]): Observable<MetaDataFieldView> {
    const fields = {
      metadataFields,
      metadataFieldValues
    };
    const url = `${this.webApiUrl}/metadataprofiles/${id}/fields`;
    return this.createApiPut({ url, data: fields });
  }

  update(profile: MetadataProfileView): Observable<MetadataProfileView> {
    console.log(profile);
    throw new Error('Method not implemented.');
  }
}
