import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Observable } from 'rxjs';

import { AccountDetail } from '@app/core/models/entities/account-detail.model';
import { AdminAccountStoreFacade } from '@app/store/admin-store/admin-account-store.facade';
import { AppStoreFacade } from '@app/store/app-store/app-store.facade';
import { Feature } from '@app/core/models/feature.model';
import { User } from '@app/core/models/entities/user.model';

@Component({
  selector: 'app-account-edit',
  templateUrl: './account-edit.component.html',
  styleUrls: ['./account-edit.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class AccountEditComponent implements OnInit {
  account$: Observable<AccountDetail>;
  accountFeatures$: Observable<Feature[]>;
  accountFormIsValidAndTouched = false;
  accountUsers$: Observable<User[]>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  error$: Observable<any>;
  hasUnsavedAccountDetailChanges$: Observable<boolean>;
  hasUnsavedAccountFeatureChanges$: Observable<boolean>;
  isSavingChanges$: Observable<boolean>;
  selectedTab = 'accountdetails';

  private isFeaturesLoaded = false; // temporary var, should be using something in state?
  private isUsersLoaded = false; // temporary var, should be using something in state?

  constructor(private appStoreFacade: AppStoreFacade, private adminAccountStoreFacade: AdminAccountStoreFacade) { }

  cancelChanges(accountId: string) {
    // force reload from server
    switch (this.selectedTab) {
      case 'accountdetails':
        this.adminAccountStoreFacade.loadAccountSelected();
        this.accountFormIsValidAndTouched = false; // ignoring potential race condition
        break;
      case 'integrations':
        this.adminAccountStoreFacade.loadAccountFeatures(accountId);
        break;
    }
  }

  changeTabs(value: string, accountId: string): void {
    if (value === this.selectedTab) {
      // same tab do nothing
      return;
    }

    this.adminAccountStoreFacade.verifyUnsavedAccountChangesAndChangeTab(
      () => { this.loadTabContents(value, accountId); },
      () => { this.cancelChanges(accountId); this.loadTabContents(value, accountId); },
      () => { }
    )
  }

  confirmDeleteAccount(id: string): void {
    this.appStoreFacade.openConfirmationModal({
      title: 'Delete Account',
      message: 'Are you sure? This will delete ALL account data and cannot be undone.',
      confirmButtonText: 'Delete',
      denyButtonText: 'Cancel',
      confirm: () => { this.adminAccountStoreFacade.deleteAccount(id); },
      deny: () => { },
      confirmButtonIcon: 'trash'
    });
  }

  generateAssetThumbnails(id: string): void {
    this.adminAccountStoreFacade.generateAssetThumbnails(id);
  }

  indexAssetSearch(id: string): void {
    this.adminAccountStoreFacade.indexAssetSearch(id);
  }

  navigateToAccounts(): void {
    this.appStoreFacade.navigate('/admin/accounts');
  }

  ngOnInit(): void {
    this.account$ = this.adminAccountStoreFacade.selectedAccount$;
    this.accountFeatures$ = this.adminAccountStoreFacade.accountFeatures$;
    this.accountUsers$ = this.adminAccountStoreFacade.selectedAccountUsers$;
    this.error$ = this.adminAccountStoreFacade.accountError$;
    this.hasUnsavedAccountDetailChanges$ = this.adminAccountStoreFacade.selectHasUnsavedAccountDetailChanges$;
    this.hasUnsavedAccountFeatureChanges$ = this.adminAccountStoreFacade.selectHasUnsavedAccountFeatureChanges$;
    this.isSavingChanges$ = this.adminAccountStoreFacade.isSavingChanges$;

    this.adminAccountStoreFacade.loadAccountSelected(); // better to load in the guard?
  }

  onAccountFieldsChange(account: AccountDetail): void {
    this.adminAccountStoreFacade.updateAccountToModify({ ...account });
  }

  onAccountFormChange(formValid: boolean): void {
    this.accountFormIsValidAndTouched = formValid;
  }

  onFeaturesChange(features: Feature[]): void {
    this.adminAccountStoreFacade.updateFeaturesToModify([...features])
  }

  processAssetsEvent(accountId: string): void {
    this.adminAccountStoreFacade.processAssets(accountId);
  }

  saveChanges(accountId: string): void {
    switch (this.selectedTab) {
      case 'accountdetails':
        if (accountId == null) {
          this.adminAccountStoreFacade.addAccount();
        } else {
          this.adminAccountStoreFacade.updateAccount();
        }
        break;
      case 'integrations':
        this.adminAccountStoreFacade.updateAccountFeatures();
        break;
    }
  }

  syncUsers(id: string): void {
    this.adminAccountStoreFacade.syncAccountUsers(id);
  }

  private loadTabContents(value: string, accountId: string) {
    switch (value) {
      case 'accountdetails':
        break;
      case 'integrations':
        // todo - prevent db call if already loaded
        if (!this.isFeaturesLoaded) {
          this.adminAccountStoreFacade.loadAccountFeatures(accountId);
          this.isFeaturesLoaded = true;  // not accurate... temporary for now, should be in state
        }
        break;
      case 'users':
        // todo - prevent db call if already loaded
        if (!this.isUsersLoaded) {
          this.adminAccountStoreFacade.loadAccountUsers(accountId);
          this.isUsersLoaded = true; // not accurate... temporary for now, should be in state
        }
        break;
    }
    this.selectedTab = value;
  }

}
