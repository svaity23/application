﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WebApi.Dtos
{
    public class SampleDataResponseDto
    {
        [JsonPropertyName("accounts")]
        public FreeTrialAccountMapDto Accounts { get; set; }

        [JsonPropertyName("assetMap")]
        public FreeTrialAssetMapDto[] AssetMap { get; set; }
    }
}
