import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { cn } from 'src/utils/cn';

import { AppStoreFacade } from '@app/store/app-store/app-store.facade';
import { Context } from '@app/core/models/context.model';
import { EllipsisIconType } from '@app/core/enums/ellipsis-icon-type.enum';
import { INTEGRATION_HUBSPOT_ENABLE_SETTING_KEY, INTEGRATION_MARCOMCENTRAL_ENABLE_SETTING_KEY, INTEGRATION_MICROSOFT_SSO_ENABLE_SETTING_KEY, INTEGRATION_SLACK_ENABLE_SETTING_KEY, INTEGRATION_WORDPRESS_ENABLE_SETTING_KEY } from '@app/core/constants/frontend-setting-key';
import { IntegrationSetting } from '@app/core/models/integration-setting.model';
import { Setting } from '@app/core/models/setting.model';

@Component({
  selector: 'app-integration-list',
  templateUrl: './integration-list.component.html',
  styleUrls: ['./integration-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class IntegrationListComponent implements OnInit, OnChanges {
  @Input() accountSettings: Setting[] = [];
  @Input() className = '';
  @Input() context: Context;
  @Output() enableIntegrationEvent = new EventEmitter<IntegrationSetting>();
  icons: number[] = [];
  integrationsListToDisplay: IntegrationSetting[] = [];
  @Output() integrationToggled = new EventEmitter<IntegrationSetting>();
  @Input() isHubspotFeatureEnabled: boolean;
  @Input() isMarcomPortalAssetFeatureEnabled: boolean;
  @Input() isMarcomPortalLibraryFeatureEnabled: boolean;
  @Input() isMicrosoftSsoFeatureEnabled: boolean;
  @Input() isSlackFeatureEnabled: boolean;
  @Input() isWordpressFeatureEnabled: boolean;
  show = false;
  sortField = 'name';
  sortOrder = 'desc';

  constructor(
    private appStoreFacade: AppStoreFacade
  ) { }

  configureHubspotEllipsisIcon(): void {
    this.icons.push(EllipsisIconType.Edit);
  }

  editHubspot(): void {
    this.appStoreFacade.navigate('account/hubspot-configuration-page');
  }

  editMarcomCentral(): void {
    this.appStoreFacade.navigate('account/marcomportal-integrations-page');
  }


  getDescription(integration: IntegrationSetting): string {
    return (integration.description) ? integration.description : '';
  }

  getLogo(integration: IntegrationSetting): string {
    return 'assets/img/' + integration.logo + '.svg';
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.accountSettings) {
      this.integrationsListToDisplay = this.prepareIntegrationListToDisplay();
      if (!changes.accountSettings.isFirstChange()) {
        this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
        this.sort(this.sortField);
      }
    }
  }

  ngOnInit(): void {
    this.configureHubspotEllipsisIcon();
    this.className = cn('integration-list', this.className);
    this.sort('name');
  }

  openMicrosoftLoginConfigurationModal(): void {
    this.appStoreFacade.openMicrosoftLoginConfigurationModal({
      title: 'Microsoft login',
      redirectToMicrosoftLogin: (claims) => { this.appStoreFacade.redirectToFederatedConsent(claims) },
      removeFederatedDomain: (id) => { this.appStoreFacade.removeFederatedDomain(id) }
    });
  }

  prepareIntegrationListToDisplay(): IntegrationSetting[] {

    const integrationsList: IntegrationSetting[] = [];

    if (this.isSlackFeatureEnabled) {
      const slackIntegrationSetting: IntegrationSetting = {
        key: INTEGRATION_SLACK_ENABLE_SETTING_KEY,
        enabled: this.updateEnableStatus(INTEGRATION_SLACK_ENABLE_SETTING_KEY),
        name: 'Slack',
        description: 'Enables option for users to share assets to Slack. User will be prompted to authorize the access prior to sharing.',
        logo: 'logo-slack',
        showContextMenu: false,
        editClicked: null
      }
      integrationsList.push(slackIntegrationSetting);
    }

    if (this.isHubspotFeatureEnabled) {
      const hubspotIntegrationSetting: IntegrationSetting = {
        key: INTEGRATION_HUBSPOT_ENABLE_SETTING_KEY,
        enabled: this.updateEnableStatus('integration-hubspot-enabled'),
        name: 'HubSpot',
        description: 'Enables option for users to share collections to HubSpot.',
        logo: 'logo-hubspot',
        showContextMenu: true,
        editClicked: () => { this.editHubspot(); }
      }
      integrationsList.push(hubspotIntegrationSetting);
    }

    if (this.isMicrosoftSsoFeatureEnabled) {
      const MicrosoftLoginIntegrationSetting: IntegrationSetting = {
        key: INTEGRATION_MICROSOFT_SSO_ENABLE_SETTING_KEY,
        enabled: this.updateEnableStatus(INTEGRATION_MICROSOFT_SSO_ENABLE_SETTING_KEY),
        name: 'Microsoft',
        description: 'Allows anyone within your organization to login using their Microsoft credentials. Approval by your Microsoft Account Admin is needed to complete this integration.',
        logo: 'logo-microsoft',
        showContextMenu: true,
        editClicked: () => { this.openMicrosoftLoginConfigurationModal(); },
      }
      integrationsList.push(MicrosoftLoginIntegrationSetting);
    }

    if (this.isWordpressFeatureEnabled) {
      const wordpressIntegrationSetting: IntegrationSetting = {
        key: INTEGRATION_WORDPRESS_ENABLE_SETTING_KEY,
        enabled: this.updateEnableStatus(INTEGRATION_WORDPRESS_ENABLE_SETTING_KEY),
        name: 'Wordpress',
        description: 'Allows access to use the MarcomGather plugin in WordPress.',
        logo: 'logo-wordpress',
        showContextMenu: false,
        editClicked: null,
      }
      integrationsList.push(wordpressIntegrationSetting);
    }

    if (this.isMarcomPortalLibraryFeatureEnabled || this.isMarcomPortalAssetFeatureEnabled) {
      const marcomCentralIntegrationSetting: IntegrationSetting = {
        key: INTEGRATION_MARCOMCENTRAL_ENABLE_SETTING_KEY,
        enabled: this.updateEnableStatus(INTEGRATION_MARCOMCENTRAL_ENABLE_SETTING_KEY),
        name: 'MarcomCentral',
        description: 'Enables option to configure MarcomCentral Library and Asset Integrations.',
        logo: 'MCC_PrimaryLogo',
        showContextMenu: true,
        editClicked: () => { this.editMarcomCentral() }
      }
      integrationsList.push(marcomCentralIntegrationSetting);
    }

    return integrationsList;
  }

  sort(columnName: string): void {
    // toggle sort order if already selected
    if (this.sortField === columnName) {
      this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortField = columnName;
      this.sortOrder = 'asc';
    }
    // setup the evaluation
    const v1 = this.sortOrder === 'asc' ? 1 : -1;
    const v2 = this.sortOrder === 'asc' ? -1 : 1;
    switch (this.sortField) {
      case 'name':
        this.integrationsListToDisplay.sort((s1, s2) => s1.name.toLocaleLowerCase() > s2.name.toLocaleLowerCase() ? v1 : v2);
        break;
      case 'description':
        this.integrationsListToDisplay.sort((s1, s2) =>
          this.getDescription(s1).toLocaleLowerCase() > this.getDescription(s2).toLocaleLowerCase() ? v1 : v2);
        break;
      default:
    }
  }

  toggleIntegration(integration: IntegrationSetting): void {
    if (integration.key === INTEGRATION_MICROSOFT_SSO_ENABLE_SETTING_KEY) {
      this.toggleMicrosoftLoginIntegration(integration);
    }
    else {
      this.integrationToggled.emit(integration);
    }
  }

  toggleMicrosoftLoginIntegration(integration: IntegrationSetting): void {
    if (integration.enabled) {
      if (confirm('Are you sure you want to disable Microsoft Login integration? This will remove all federation settings.')) {
        // we need confirmation if disabling bec it will delete federated domains
        this.appStoreFacade.toggleMicrosoftLoginStatus(integration);
      }
    }
    else {
      this.appStoreFacade.toggleMicrosoftLoginStatus(integration);
    }
  }

  updateEnableStatus(settingKey: string): boolean {
    const setting = this?.accountSettings?.find(n => n.key === settingKey);
    return setting ? setting.boolValue : false;
  }
}
