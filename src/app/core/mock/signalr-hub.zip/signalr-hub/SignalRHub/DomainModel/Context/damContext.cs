﻿using Microsoft.EntityFrameworkCore;

namespace SignalRHub.DomainModel.Context
{
    public partial class damContext : DbContext
    {
        public damContext()
        {
        }

        public damContext(DbContextOptions<damContext> options)
            : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=tcp:sql-dam-sbx.database.windows.net,1433;Initial Catalog=sqldb-dam-sbx;Persist Security Info=False;User ID=appPocoGen;Password=;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
