﻿using ApplicationLogic.Models;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace WebApi.Dtos.Asset.Response
{
    public class DeleteAssetsResponseDto
    {
        [JsonPropertyName("assetIds")]
        public List<IdEntity> AssetIds { get; set; }
        
        [JsonPropertyName("errors")]
        public string[] Errors { get; set; }

        [JsonPropertyName("idsOnHubspot")]
        public List<HubspotEntity> IdsOnHubspot { get; set; }
    }
}
