﻿using ApplicationLogic.Models;
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace WebApi.Dtos
{
    public class UpdateAssetsWithCollectionIdResponseDto
    {
        [JsonPropertyName("toCollectionId")]
        public Guid ToCollectionId { get; set; }

        [JsonPropertyName("assetIds")]
        public List<IdEntity> AssetIds { get; set; }
        
        [JsonPropertyName("idsOnHubspot")]
        public List<HubspotEntity> IdsOnHubspot { get; set; }
    }
}
