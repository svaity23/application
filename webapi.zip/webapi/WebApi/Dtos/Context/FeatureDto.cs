﻿using System.Text.Json.Serialization;

namespace WebApi.Dtos.Context
{
    public class FeatureDto
    {
        [JsonPropertyName("key")]
        public string Key { get; set; }
    }
}
