export enum ImageOrientation {
    landscape = 'landscape',
    portrait = 'portrait'
}