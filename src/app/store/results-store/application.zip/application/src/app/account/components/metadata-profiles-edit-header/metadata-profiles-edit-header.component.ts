import { Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation } from '@angular/core';

import { MetadataFieldAndValueForPreview } from '@app/core/models/metadata-field-and-value-for-preview';
import { MetadataProfileView } from '@app/core/models/metadata-profile-view.model';

@Component({
  selector: 'app-metadata-profiles-edit-header',
  templateUrl: './metadata-profiles-edit-header.component.html',
  styleUrls: ['./metadata-profiles-edit-header.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MetadataProfilesEditHeaderComponent implements OnInit {
  @Output() backToAllProfilesEvent = new EventEmitter();
  @Output() cancelEvent = new EventEmitter();
  isDisabled = true;

  navigateBackButtonText: string;
  @Output() previewEvent = new EventEmitter<{ profileFieldAndValues: MetadataFieldAndValueForPreview[], profileName: string}>();
  @Input() profile: MetadataProfileView;
  @Input() profileFieldAndValuesToPreview: MetadataFieldAndValueForPreview[];
  @Output() saveEvent = new EventEmitter();
  @Input() showSave: boolean;
  constructor() { }

  backToAllProfiles(): void {
    this.backToAllProfilesEvent.emit();
  }

  cancelChanges(): void {
    this.cancelEvent.emit();
  }

  ngOnInit(): void {
    this.navigateBackButtonText = 'All Profiles'
  }

  previewChanges(): void {
    this.previewEvent.emit({ profileFieldAndValues: this.profileFieldAndValuesToPreview, profileName: this.profile.name });
  }

  saveChanges(): void {
    this.saveEvent.emit();
  }
}
