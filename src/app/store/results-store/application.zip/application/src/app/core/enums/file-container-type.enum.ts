export enum FileContainerType {
  Asset = 'asset',
  Metadata = 'metadata',
  Thumbnail = 'thumbnail',
  Web = 'web',
  LowResolution = 'low-resolution',
  Brand = 'brand'
}
