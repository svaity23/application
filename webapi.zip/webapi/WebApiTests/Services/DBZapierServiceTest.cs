﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using WebApi.Dtos;
using WebApi.Extensions;
using WebApi.Services;
using WebApiTests.Shared;

namespace WebApiTests.Services
{
    [TestClass]
    public class DBZapierServiceTest
    {
        private static readonly Guid TEST_ACCOUNT = Guid.Parse("BBDA5AD0-664F-4B89-9F4E-5C82140AF39C"); // piri@saguaro.ro
        private static readonly Guid TEST_USER = Guid.Parse("79DB0E4E-F9C0-4A8B-86F2-70441663FB0D"); // piri@saguaro.ro
        private static readonly Guid EMPTY_COLLECTION = Guid.Parse("3D0118BF-C952-436E-B99C-14A33FA0E949");
        private static readonly Guid SUB_COLLECTION = Guid.Parse("86BE3659-5593-42FF-ADFE-0A50CD2F6786");

        #region [Click to open] Test initialization and configuration...
        private static damContext dbContext;
        private static readonly JsonSerializerOptions options = new JsonSerializerOptions()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            ReferenceHandler = ReferenceHandler.Preserve
        };


        [ClassInitialize]
        public static void BeforeClass(TestContext context)
        {
            Debug.WriteLine("Before all tests");
            dbContext = AzureSQLTools.InitializeDamContext();

            var loggerFactory = (ILoggerFactory)new LoggerFactory();
            
            string basePath = System.AppContext.BaseDirectory;
            IConfiguration config = new ConfigurationBuilder()
                .SetBasePath(basePath)
                .AddJsonFile("appsettings.json")
                .Build();
            sut = new ZapierService(dbContext);
        }


        [ClassCleanup]
        public static void AfterClass()
        {
            Debug.WriteLine("Clean up after all tests");
                
//            dbContext.SaveChanges();
            dbContext.Dispose();
        }

        [TestInitialize]
        public void BeforeTest()
        {
            Debug.WriteLine("...Prepare test");
        }

        [TestCleanup]
        public void AfterTest()
        {
            Debug.WriteLine("...Clear test\n");
        }
        #endregion

        // sut - Service Under Test
        private static ZapierService sut;

        [TestMethod("Retrieve all assets info for zapier")]
        public void GetAllAssetsInfo()
        {
            var response = sut.GetAssetsInfo(TEST_ACCOUNT, TEST_USER, null).Result;
            Assert.AreEqual(0, response.Error.Code);
            Assert.IsTrue(response.Entities.Count > 0);
        }

        [TestMethod("Retrieve the assets info for zapier from a specified collection")]
        public void GetCollectionAssetsInfo()
        {
            var response = sut.GetAssetsInfo(TEST_ACCOUNT, TEST_USER, SUB_COLLECTION).Result;
            Assert.AreEqual(0, response.Error.Code);
            Assert.IsTrue(response.Entities.Count > 0);
        }

        [TestMethod("Retrieve the assets info for zapier from an empty collection")]
        public void GetEmptyCollectionAssetsInfo()
        {
            var response = sut.GetAssetsInfo(TEST_ACCOUNT, TEST_USER, EMPTY_COLLECTION).Result;
            Assert.AreEqual(0, response.Error.Code);
            Assert.IsTrue(response.Entities == null || response.Entities.Count == 0);
        }

    }
}