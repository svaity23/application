 // naming with underscore to match clients properties
 export interface OidcClientConfig  {
    accessTokenExpiringNotificationTime: number,
    authority: string,
    automaticSilentRenew: boolean,
    client_id: string,
    filterProtocolClaims: boolean,
    loadUserInfo: false,
    metadataUrl: string,
    post_logout_redirect_uri: string,
    redirect_uri: string,
    response_mode: string,
    response_type: string,
    scope: string,
    silent_redirect_uri: string,
  }