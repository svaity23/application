﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos.Canva
{
    public class CanvaDatabaseResponse
    {
        public string Type { get; set; }
        public string ErrorCode { get; set; }
        public List<CanvaContainer> Resources { get; set; }
        public List<CanvaAsset> Assets { get; set; }
        public string Continuation { get; set; }
    }
}
