﻿using WebApi.Dtos.Asset.Comment;
using WebApi.Dtos.Asset.Revision;

namespace WebApi.Dtos.Asset.DetailsView
{
    public class AssetDetailDto
    {
        public AssetForDetailsViewDto Asset { get; set; }
        public AssetRevisionDto[] AssetRevisions {get; set;}
        //public CommentThreadDto CommentsThread { get; set; }
        public MetadataDto[] Metadata { get; set; }
        public MetadataFieldDto[] MetadataFields { get; set; }
        public MetadataFieldValueDto[] MetadataFieldValues { get; set; }
        public TagDto Tags { get; set; }

    }
}
