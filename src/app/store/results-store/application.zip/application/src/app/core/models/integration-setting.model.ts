export interface IntegrationSetting {
    description: string;
    editClicked: () => void;
    enabled: boolean;
    key: string;
    logo: string;
    name: string;
    showContextMenu: boolean;
}