﻿
namespace WebApi.Dtos.Asset.Request
{
    public class BulkRequest__TO_BE_DELETED
    {
        public RequestType RequestType { get; set; }

        // Request specific dtos
        // TODO REMOVED -- NO LONGER WRAPPING BULK REQUEST
    }

    // TODO: discuss to move RequestType in separate folder
    public enum RequestType
    {
        Create = 0,
        Delete = 1,
        UpdateCollection = 2,        
        UpdateMetadata = 3,
        FinishUploadSession = 4,
        ShareAssets = 5,
        DownloadAssets = 6,
        UpdateTags = 7,
        AddToLightbox = 8,
        RemoveFromLightbox = 9,
        UpdateFavorites = 10,
        AddToHubspot = 11,
        RemoveFromHubspot = 12
    }
}
