import { ChangeDetectionStrategy, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';

import { Observable } from 'rxjs';

import { AppGroupStoreFacade } from '@app/store/app-store/app-group-store.facade';
import { AppStoreFacade } from '@app/store/app-store/app-store.facade';
import { Context } from '@app/core/models/context.model';
import { Group } from '@app/core/models/entities/group.model';

@Component({
  selector: 'app-groups',
  templateUrl: './groups.component.html',
  styleUrls: ['./groups.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class GroupsComponent implements OnInit, OnDestroy {

  accountTypeName$: Observable<string>;
  context$: Observable<Context>;
  groups$: Observable<Group[]>;
  searchText$: Observable<string>;
  selectedGroups$: Observable<Group[]>;
  showIntegrations$: Observable<boolean>;
  showUserGroups$: Observable<boolean>;

  private groupToDelete: Group;

  constructor(
    private appStoreFacade: AppStoreFacade,
    private router: Router,
    private appGroupStoreFacade: AppGroupStoreFacade) { }

  addGroup(): void {
    this.appStoreFacade.navigate('account/groups/new');
  }

  editGroup(group: Group): void {
    this.appGroupStoreFacade.setSelectedGroupId(group.id);
    this.appStoreFacade.navigate(`/account/groups/${group.id}`);
  }

  filterGroups(searchText: string): void {
    if (searchText !== null) {
      this.appGroupStoreFacade.filterGroups(searchText);
    }
  }

  navigateTo(pageName: string): void {
    if(!pageName?.includes('/groups')) {
      this.appStoreFacade.partialResetAppStore();
    }
    this.appStoreFacade.navigate(`account/${pageName}`);
  }

  ngOnDestroy(): void {
    // clear search filter
    if(!this.router.url.includes('/account')) {
      this.appGroupStoreFacade.filterGroups('');
    }
  }

  ngOnInit(): void {
    this.appStoreFacade.setPageTitle('User Groups | MarcomGather');
    this.accountTypeName$ = this.appStoreFacade.accountTypeName$;
    this.context$ = this.appStoreFacade.context.context$;
    this.groups$ = this.appGroupStoreFacade.groups$;
    this.searchText$ = this.appGroupStoreFacade.searchText$;
    this.selectedGroups$ = this.appGroupStoreFacade.selectedGroups$;
    this.showIntegrations$ = this.appStoreFacade.showIntegrations$;
    this.showUserGroups$ = this.appStoreFacade.context.isUserGroupsFeatureEnabled$;
    this.appGroupStoreFacade.loadGroups();
  }

  openConfirmationModalToDeleteGroups(): void {
    this.appGroupStoreFacade.openGroupConfirmationModal({
      title: 'Delete Groups',
      message: 'Any users assigned to this group will be removed from the group and their permissions will be updated.\n\nThis action cannot be undone.',
      confirmButtonText: 'Delete',
      denyButtonText: 'Cancel',
      confirm: this.deleteGroups,
      deny: () => { },
      confirmButtonIcon: 'trash'
    });
  }

  openGroupConfirmationModal(group: Group): void {
    this.groupToDelete = group;
    this.appGroupStoreFacade.openGroupConfirmationModal({
      title: 'Delete Group',
      message: 'Any users assigned to this group will be removed from the group and their permissions will be updated.\n\nThis action cannot be undone.',
      confirmButtonText: 'Delete',
      denyButtonText: 'Cancel',
      confirm: this.deleteGroup,
      deny: () => { },
      confirmButtonIcon: 'trash'
    });
  }

  setAllGroupsSelected(selected: boolean): void {
    this.appGroupStoreFacade.setAllGroupsSelected(selected);
  }

  toggleGroupSelected(group: Group): void {
    this.appGroupStoreFacade.toggleGroupSelected(group);
  }

  private deleteGroup = () => {
    this.appGroupStoreFacade.setSelectedGroupId(this.groupToDelete.id);
    this.appGroupStoreFacade.deleteGroup();
  }

  private deleteGroups = () => {
    this.appGroupStoreFacade.bulkDeleteGroups();
  }
}
