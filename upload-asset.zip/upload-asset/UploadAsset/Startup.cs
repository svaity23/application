using ApplicationLogic.DomainModel.Context;
using Azure.Identity;
using Azure.Storage.Blobs;
using Marcom.Azure.ServiceBus;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using UploadAsset.Common;
using UploadAsset.Extensions;
using UploadAsset.OpenApi;
using UploadAsset.Middleware;
using UploadAsset.Services;

namespace UploadAsset
{
    public class Startup
    {
        const string AllowedOriginsPolicy = "AllowedOriginsPolicy";

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddSwaggerGen(c => {
                c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo { Title = "Gather Upload Api Documentation", Version = "v1" });                
                c.IncludeXmlComments(XmlCommentsFilePath);
                c.OperationFilter<UnboundParametersOperationFilter>();  // custom binding for multipart/form-data
                c.SupportNonNullableReferenceTypes();
            });

            // setup the authentication from configuration
            services.AddAuthenticationAndAuthorizationPolicies(Configuration);

            AddCorsPolicy(services);

            services.Configure<FormOptions>(options =>
            {
                // Set the limit to 4gb
                options.MultipartBodyLengthLimit = 4294967296;
            });

            services.AddControllers();

            services.AddDbContext<damContext>(
                options => options.UseSqlServer(Configuration["ConnectionStrings:damDbConnection"],
                o => o.EnableRetryOnFailure()),
                ServiceLifetime.Scoped
            );


            services.AddScoped<UploadService, UploadService>();
            services.AddScoped<BlobService, BlobService>();

            // DefaultAzureCredential with explicit retry and random retry delay
            var defaultAzureCredentialOptions = new DefaultAzureCredentialOptions();
            defaultAzureCredentialOptions.Retry.Mode = Azure.Core.RetryMode.Exponential;
            defaultAzureCredentialOptions.Retry.MaxRetries = 5;
            defaultAzureCredentialOptions.Retry.MaxDelay = TimeSpan.FromSeconds(60);
            defaultAzureCredentialOptions.Retry.Delay = TimeSpan.FromSeconds(2);
            var defaultAzureCredential = new DefaultAzureCredential(defaultAzureCredentialOptions);

            // singletons
            services.AddSingleton<ServiceBusService>();
            services.AddSingleton<BlobServiceClient>(bsc => new BlobServiceClient(GetBlobStorageUri(Configuration["BlobStorage:StorageAccountName"]), defaultAzureCredential));
            services.AddSingleton<AzureServiceTokenProvider, AzureServiceTokenProvider>();
            services.AddSingleton<IBusServiceFactory, BusServiceFactory>();
            services.AddSingleton<Health, Health>();
            services.AddSingleton<ITelemetryInitializer>(telemetry => new CloudRoleNameTelemetryInitializer("upload-asset"));
            services.AddApplicationInsightsTelemetry(Configuration["ApplicationInsights:InstrumentationKey"]);
            services.AddSingleton<IGoogleServiceFactory, GoogleServiceFactory>();
            services.AddSingleton<IDropboxServiceFactory, DropboxServiceFactory>();
            services.AddSingleton<IOneDriveServiceFactory, OneDriveServiceFactory>();
            services.AddScoped<UserAccountService, UserAccountService>();
            services.AddScoped<IntegrationService, IntegrationService>();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, Health health)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            // global handler
            app.ConfigureGlobalExceptionMiddleware();

            app.UseSwagger(c =>
                c.RouteTemplate = "upload/doc/{documentname}/swagger.json"
            ); ;
            app.UseSwaggerUI(s =>
            {
                s.SwaggerEndpoint("/upload/doc/v1/swagger.json", "OpenApi V1");
                s.RoutePrefix = "upload/doc";
                s.DocumentTitle = "Gather Upload Api Documentation";
            });

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseCors(AllowedOriginsPolicy);

            app.UseAuthentication();

            app.UseAuthorization();

            // HttpContext.Request.ContentLength will give you how many bytes are being sent. This contains file as well as other form data.
            // Other form data is negligible (maybe 100 bytes give or take).
            // Setting maxRequestBodySize to null allows for any upload size. Without setting this the default is 30MBs.
            // The validateAndCreate stored proc should reject files that are too large before this container gets hit with the upload request.
            app.Use(async (context, next) =>
            {                
                // MaxRequestBodySize is a nullable long. Setting it to null disables the limit like MVC's [DisableRequestSizeLimit]
                context.Features.Get<IHttpMaxRequestBodySizeFeature>().MaxRequestBodySize = null;
                await next.Invoke();
            });

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapGet("/upload", async context =>
                {
                    await context.Response.WriteAsync(Newtonsoft.Json.JsonConvert.SerializeObject(new { status = "OK" }));
                });          
                endpoints.MapGet("/dropboxFile", async context =>
                {
                    await context.Response.WriteAsync(Newtonsoft.Json.JsonConvert.SerializeObject(new { status = "OK" }));
                });
                endpoints.MapGet("/googleFile", async context =>
                {
                    await context.Response.WriteAsync(Newtonsoft.Json.JsonConvert.SerializeObject(new { status = "OK" }));
                });
                endpoints.MapGet("/oneDriveFile", async context =>
                {
                    await context.Response.WriteAsync(Newtonsoft.Json.JsonConvert.SerializeObject(new { status = "OK" }));
                });

            });

            health.Live = true;
            health.Ready = true;
        }

        private void AddCorsPolicy(IServiceCollection services)
        {
            var origins = new List<string>();
            Configuration.GetSection("CorsOriginsEnabled").Bind(origins);

            if (origins.Count == 0 || !origins.Any(o => !string.IsNullOrWhiteSpace(o)))
            {
                throw new ApplicationException("CORS is not configured");
            }

            // NOTE: Some CORS errors happen because the CORS pre-flight gets a 500 server error.  Look for those before you assume this code or its config is wrong.
            services.AddCors(options =>
            {
                options.AddPolicy(AllowedOriginsPolicy,
                    builder =>
                    {
                        builder.WithOrigins(origins.ToArray())
                        .AllowAnyMethod()
                        .AllowAnyHeader()
                        .WithExposedHeaders("Content-Disposition") // Need this so content-disposition gets sent back to client on download. Used so client knows name of file being saved
                        .WithExposedHeaders("Token-Expired");
                    });
            });
        }

        private Uri GetBlobStorageUri(string storageAccountName)
        {
            return new Uri($"https://{storageAccountName}.blob.core.windows.net");
        }

        private string XmlCommentsFilePath
        {
            get
            {
                var basePath = AppContext.BaseDirectory;
                var fileName = typeof(Startup).GetTypeInfo().Assembly.GetName().Name + ".xml";
                return System.IO.Path.Combine(basePath, fileName);
            }
        }
    }
}
