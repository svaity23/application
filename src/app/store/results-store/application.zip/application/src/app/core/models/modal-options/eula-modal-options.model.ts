export interface EulaModalOptions {
  accept: () => void;
  decline: () => void;
  title: string;
}
