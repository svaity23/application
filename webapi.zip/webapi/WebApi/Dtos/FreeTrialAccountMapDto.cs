﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WebApi.Dtos
{
    public class FreeTrialAccountMapDto
    {
        [JsonPropertyName("sourceAccountId")]
        public Guid SourceAccountId { get; set; }

        [JsonPropertyName("targetAccountId")]
        public Guid TargetAccountId { get; set; }
    }
}
