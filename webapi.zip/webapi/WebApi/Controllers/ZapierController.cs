﻿using ApplicationLogic.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Dtos;
using WebApi.Dtos.Zapier;
using WebApi.Enums;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class ZapierController : ControllerBase
    {
        private readonly ILogger<ZapierController> _logger;
        private readonly UserAccountService _userAccountService;
        private readonly CollectionService _collectionService;
        private readonly ZapierService _zapierService;

        public ZapierController(ILogger<ZapierController> logger, UserAccountService userAccountService, CollectionService collectionService, ZapierService zapierService)
        {
            _logger = logger;
            _userAccountService = userAccountService;
            _collectionService = collectionService;
            _zapierService = zapierService;
        }

        [HttpGet]
        [Authorize]
        [Route("assetsInfo")]
        public async Task<IActionResult> GetAssetsInfo([FromQuery] string collectionId)
        {
            string successMsg = $@"
                ******************************************************
                * /Zapier post hit at {DateTime.Now}  {Request.Path}                    
                ******************************************************";
            _logger.LogInformation(successMsg);

            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            bool byColl = Guid.TryParse(collectionId, out Guid collIdGuid);

            GetEntitiesResponse<ZapAssetInfo> results = await _zapierService.GetAssetsInfo(accountId, userId, byColl ? collIdGuid : null);
            if (results != null)
            {
                int err = results.Error.Code;
                if (err == 0)
                {
                    if (results.Entities == null || results.Entities.Count == 0) return Ok(new List<ZapAssetInfo>());

                    var outResult = results.Entities.Select(x => {
                        string tags = "";
                        if (x.Tags != null)
                        {
                            if (x.Tags.AiGeneratedValues != null && x.Tags.AiGeneratedValues.Length > 0) tags += string.Join(", ", x.Tags.AiGeneratedValues);
                            if (x.Tags.Values != null && x.Tags.Values.Length > 0)
                            {
                                if (tags.Length > 0) tags += ", ";
                                tags += string.Join(", ", x.Tags.Values);
                            }
                            if (!string.IsNullOrEmpty(x.Tags.OcrGeneratedValues))
                            {
                                if (tags.Length > 0) tags += ", ";
                                tags += x.Tags.OcrGeneratedValues;
                            }
                        }
                        return new
                        {
                            Id = x.Id,
                            Name = x.Name,
                            Description = x.Description,
                            FileName = x.FileName,
                            FileGroup = FileTypes.GetFileGroupName(x.FileGroup),
                            ExpireOn = x.ExpireOn != null ? ((DateTime)x.ExpireOn).ToString("D") : "Never",
                            UploadDate = x.UploadDate.ToString("f"),
                            UploadBy = x.UploadBy,
                            Author = x.Author ?? "",
                            DateCreated = x.DateCreated ?? "",
                            Tags = tags
                        };
                    });
                    return Ok(outResult);
                } 
                else
                {
                    return BadRequest("Unexpected error: " + err);
                }
            }
            return NotFound();
        }

        [HttpGet]
        [Authorize]
        [Route("collections")]
        public async Task<IActionResult> GetCollections()
        {
            string successMsg = $@"
                ******************************************************
                * /Zapier post hit at {DateTime.Now}  {Request.Path}                    
                ******************************************************";
            _logger.LogInformation(successMsg);

            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            GetEntitiesResponse<CollectionDto> results =
                await _collectionService.GetAllAsync(accountId, userId);
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entities ?? new List<CollectionDto>()),
                    3 => Forbid("User forbidden to read collections: " + userId),// the user doesn't have rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }

        [HttpPost]
        public IActionResult Post()
        {
            string successMsg = $@"
                ******************************************************
                * /Zapier post hit at {DateTime.Now}                      
                ******************************************************";
            _logger.LogInformation(successMsg);

            if (Request?.Body != null)
            {
                _logger.LogInformation(Request.Body.ToString());
            }

            return Ok();
        }

        [HttpGet]
        public IActionResult Get()
        {
            string successMsg = $@"
                ******************************************************
                * /Zapier get hit at {DateTime.Now}                      
                ******************************************************";
            _logger.LogInformation(successMsg);

            if (Request?.Body != null)
            {
                _logger.LogInformation(Request.Body.ToString());
            }

            return Ok();
        }

        [HttpPost]
        [Authorize]
        [Route("authpost")]
        public IActionResult Auth()
        {
            string successMsg = $@"
                ******************************************************
                * /Zapier auth post hit at {DateTime.Now}                      
                ******************************************************";
            _logger.LogInformation(successMsg);

            if (Request?.Body != null)
            {
                _logger.LogInformation(Request.Body.ToString());
            }

            return Ok();
        }

        [HttpGet]
        [Authorize]
        [Route("authget")]
        public IActionResult AuthGet()
        {

            string successMsg = $@"
                ******************************************************
                * /Zapier auth get hit at {DateTime.Now}                      
                ******************************************************";
            _logger.LogInformation(successMsg);

            if (Request?.Body != null)
            {
                _logger.LogInformation(Request.Body.ToString());
            }

            return  Ok("{\"Response\": \"Got token\"}");
        }
        [HttpGet]
        [Authorize]
        [Route("authGet1")]
        public IActionResult AuthGet1()
        {

            string successMsg = $@"
                ******************************************************
                * /Zapier auth get hit at {DateTime.Now}                      
                ******************************************************";
            _logger.LogInformation(successMsg);

            if (Request?.Body != null)
            {
                _logger.LogInformation(Request.Body.ToString());
            }

            return Ok("Got token");
        }

        [HttpGet]
        [Authorize]
        [Route("authGet2")]
        public IActionResult AuthGet2()
        {

            string successMsg = $@"
                ******************************************************
                * /Zapier auth get hit at {DateTime.Now}                      
                ******************************************************";
            _logger.LogInformation(successMsg);

            if (Request?.Body != null)
            {
                _logger.LogInformation(Request.Body.ToString());
            }

            return Ok("Got token".ToJsonString());
        }
    }
}
