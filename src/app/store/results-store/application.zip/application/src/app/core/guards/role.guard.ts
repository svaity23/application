import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { filter, first, map, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AppStoreFacade } from '@app/store/app-store/app-store.facade';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {
  constructor(private appStoreFacade: AppStoreFacade, private router: Router) { }
  canActivate(
    currentRoute: ActivatedRouteSnapshot,
    _state: RouterStateSnapshot): Observable<boolean | UrlTree> {

    const roles: string[] = currentRoute.data.roles;
    return this.hasRoles(roles);
  }

  private hasRoles(roles: string[]): Observable<boolean | UrlTree> {
    return this.appStoreFacade.context.context$.pipe(
      tap(context => {
        if (!context) {
          this.appStoreFacade.loadContext();
        }
      }),
      filter(context => context != null),
      first(),
      map(context => {
        if (roles.includes(context.roleKey)) {
          return true;
        } else {
          return this.router.parseUrl('/page-not-found');
        }
      })
    );
  }
}
