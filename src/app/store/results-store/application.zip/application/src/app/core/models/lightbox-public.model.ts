import { LightboxAsset } from './entities/lightbox-asset.model';

export interface LightboxPublic {
	accountId: string;
	accountLogo:  string;
    accountTheme: string;
	assetCount: number;
	assets: LightboxAsset[];
	id: string;
	logoUrl?: string;
	name: string;
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	sasTokens: any;
	storageAccountName: string;
}
