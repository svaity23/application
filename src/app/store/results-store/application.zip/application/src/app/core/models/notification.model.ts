import { NotificationComment } from './notification-comment.model';
import { NotificationType } from '../enums/notification-type.enum';

export interface Notification {
    comment: NotificationComment;
    created: Date;
    id: string;
    read: boolean;
    type: NotificationType;
}
