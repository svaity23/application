﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using WebApi.Dtos;
using WebApi.Dtos.Canva;

namespace WebApi.Services
{
    public class CanvaService
    {
        private readonly CanvaLogic _canvaLogic;
        private readonly IConfiguration _configuration;
        private readonly ILogger<CanvaService> _logger;
        private readonly JsonSerializerOptions _options = new JsonSerializerOptions()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };

        public CanvaService(IConfiguration configuration, ILogger<CanvaService> logger, damContext damContext)
        {
            _canvaLogic = new CanvaLogic(damContext);
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<UpsertResponse<CanvaUser>> SaveCanvaUserAsync(CanvaUser user)
        {
            var jsonCanvaUser = JsonSerializer.Serialize(user, _options);
            var resultJson = await _canvaLogic.SaveCanvaUserAsync(user.AccountId, jsonCanvaUser);
            UpsertResponse<CanvaUser> result = JsonSerializer.Deserialize<UpsertResponse<CanvaUser>>(resultJson, _options);
            return result;
        }

        public async Task DeleteCanvaUserAsync(CanvaRequestDto canvaRequest)
        {
            var jsonCanvaReq = JsonSerializer.Serialize(canvaRequest, _options);
            await _canvaLogic.DeleteCanvaUserAsync(jsonCanvaReq);
        }

        public async Task<CanvaResponseDto> GetAssetsAsync(CanvaRequestDto canvaRequest)
        {
            var downloadUrl = _configuration["Integration:Canva:DownloadApiUrl"];
            var jsonCanvaReq = JsonSerializer.Serialize(canvaRequest, _options);
            string result = await _canvaLogic.GetAssetsAsync(jsonCanvaReq);
            CanvaDatabaseResponse dbResponse = JsonSerializer.Deserialize<CanvaDatabaseResponse>(result, _options);
            CanvaResponseDto respObj = new CanvaResponseDto()
            {
                Type = dbResponse.Type,
                Resources = new List<object>(),
                ErrorCode = dbResponse.ErrorCode,
                Continuation = dbResponse.Continuation
            };
            dbResponse.Resources?.ForEach(x => respObj.Resources.Add(x));
            dbResponse.Assets?.ForEach(x =>
                {
                    x.Url = downloadUrl + "/" + x.Url;
                    x.Thumbnail.Url = downloadUrl + "/" + x.Thumbnail.Url;
                    respObj.Resources.Add(x);
                }
            );
 
            return respObj;
        }
    }
}
