﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace ApplicationLogic.Models
{
    public class DeleteEntityResponse<T>
    {
        [JsonPropertyName("entity")]
        public T Entity { get; set; }

        [JsonPropertyName("errors")]
        public IEnumerable<ErrorResponse> Errors { get; set; }
    }
}
