﻿using Marcom.Azure.ServiceBus;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using SignalRHub.Hub;
using SignalRHub.Messages;
using SignalRHub.Services;
using System;
using System.Globalization;
using System.Threading;
using System.Threading.Tasks;

namespace SignalRHub
{
    public class Worker : BackgroundService
    {
        private readonly IBusServiceFactory _busServiceFactory;
        private IBusReceiveService _imageBusService;
        private IBusReceiveService _tagsBusService;
        private IBusReceiveService _accountProcessedService;
        private IBusReceiveService _customizeAssetProcessedService;
        private IBusReceiveService _notificationInitiatedService;
        private readonly IAssetServiceFactory _assetServiceFactory;
        private readonly INotificationServiceFactory _notificationServiceFactory;
        private readonly IConfiguration _configuration;
        private readonly IHubContext<UploadHub, IUploadHub> _hubContext;
        private readonly ILogger<Worker> _logger;
        private readonly ReceiveServiceBusesConfig _receiveServiceBusesConfig;

        public Worker(IConfiguration configuration, 
            ILogger<Worker> logger, 
            IHubContext<UploadHub, IUploadHub> hubContext,
            IBusServiceFactory busServiceFactory,
            IAssetServiceFactory assetServiceFactory,
            INotificationServiceFactory notificationServiceFactory,
            IOptions<ReceiveServiceBusesConfig> receiveServiceBusesConfig
            )
        {
            _logger = logger;
            _hubContext = hubContext;
            _configuration = configuration;
            
            _busServiceFactory = busServiceFactory;
            _assetServiceFactory = assetServiceFactory;
            _notificationServiceFactory = notificationServiceFactory;
            _receiveServiceBusesConfig = receiveServiceBusesConfig.Value;
        }

        public override async Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogDebug("BEGIN: StopAsync");
            await _imageBusService.CloseAsync();
            await _tagsBusService.CloseAsync();
            await _accountProcessedService.CloseAsync();
            await _customizeAssetProcessedService.CloseAsync();
            await _notificationInitiatedService.CloseAsync();
            _logger.LogDebug("END: StopAsync");
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("BEGIN: ExecuteAsync");

            try
            {
                _imageBusService = await _busServiceFactory.CreateBusReceiveServiceAsync(
                    _receiveServiceBusesConfig.ImageProcessedServiceBus.EndPoint,
                    _receiveServiceBusesConfig.ImageProcessedServiceBus.TopicName,
                    _receiveServiceBusesConfig.ImageProcessedServiceBus.SubscriptionName,
                    HandleImageProcessedMessageAsync,
                    new Marcom.Azure.ServiceBus.Config.ServiceBusReceiveSettings
                    {
                        ComputerName = _configuration["COMPUTERNAME"],
                        Environment = _configuration["DotnetEnvironment"],
                        WorkerName = _configuration["WorkerName"],
                        SubscriptionOptions = _receiveServiceBusesConfig.ImageProcessedServiceBus.SubscriptionOptions
                    }
                );

                _tagsBusService = await _busServiceFactory.CreateBusReceiveServiceAsync(
                    _receiveServiceBusesConfig.TagsProcessedServiceBus.EndPoint,
                    _receiveServiceBusesConfig.TagsProcessedServiceBus.TopicName,
                    _receiveServiceBusesConfig.TagsProcessedServiceBus.SubscriptionName,
                    HandleTagsProcessedMessageAsync,
                    new Marcom.Azure.ServiceBus.Config.ServiceBusReceiveSettings
                    {
                        ComputerName = _configuration["COMPUTERNAME"],
                        Environment = _configuration["DotnetEnvironment"],
                        WorkerName = _configuration["WorkerName"],
                        SubscriptionOptions = _receiveServiceBusesConfig.TagsProcessedServiceBus.SubscriptionOptions
                    }
                );              

                _accountProcessedService = await _busServiceFactory.CreateBusReceiveServiceAsync(
                    _receiveServiceBusesConfig.AccountProcessedServiceBus.EndPoint,
                    _receiveServiceBusesConfig.AccountProcessedServiceBus.TopicName,
                    _receiveServiceBusesConfig.AccountProcessedServiceBus.SubscriptionName,
                    HandleAccountProcessedMessageAsync,
                    new Marcom.Azure.ServiceBus.Config.ServiceBusReceiveSettings
                    {
                        ComputerName = _configuration["COMPUTERNAME"],
                        Environment = _configuration["DotnetEnvironment"],
                        WorkerName = _configuration["WorkerName"],
                        SubscriptionOptions = _receiveServiceBusesConfig.AccountProcessedServiceBus.SubscriptionOptions
                    }
                );

                _customizeAssetProcessedService = await _busServiceFactory.CreateBusReceiveServiceAsync(
                    _receiveServiceBusesConfig.CustomizeAssetProcessedServiceBus.EndPoint,
                    _receiveServiceBusesConfig.CustomizeAssetProcessedServiceBus.TopicName,
                    _receiveServiceBusesConfig.CustomizeAssetProcessedServiceBus.SubscriptionName,
                    HandleCustomizeAssetProcessedMessageAsync,
                    new Marcom.Azure.ServiceBus.Config.ServiceBusReceiveSettings
                    {
                        ComputerName = _configuration["COMPUTERNAME"],
                        Environment = _configuration["DotnetEnvironment"],
                        WorkerName = _configuration["WorkerName"],
                        SubscriptionOptions = _receiveServiceBusesConfig.CustomizeAssetProcessedServiceBus.SubscriptionOptions
                    }
                );

                _notificationInitiatedService = await _busServiceFactory.CreateBusReceiveServiceAsync(
                    _receiveServiceBusesConfig.NotificationInitiatedServiceBus.EndPoint,
                    _receiveServiceBusesConfig.NotificationInitiatedServiceBus.TopicName,
                    _receiveServiceBusesConfig.NotificationInitiatedServiceBus.SubscriptionName,
                    HandleNotificationInitiatedMessageAsync,
                    new Marcom.Azure.ServiceBus.Config.ServiceBusReceiveSettings
                    {
                        ComputerName = _configuration["COMPUTERNAME"],
                        Environment = _configuration["DotnetEnvironment"],
                        WorkerName = _configuration["WorkerName"],
                        SubscriptionOptions = _receiveServiceBusesConfig.NotificationInitiatedServiceBus.SubscriptionOptions
                    }
                );

                _logger.LogInformation("Live and Ready");
            }

#pragma warning disable CA1031 // Do not catch general exception types TODO catch specific types
            catch (Exception ex)
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _logger.LogError(ex.Message);
            }          

            _logger.LogInformation("END: ExecuteAsync");
        }

        private static string GetOpaqueSource(dynamic message)
        {
            if (message.Opaque?.Source?.Value != null)
            {
                return message.Opaque?.Source?.Value;
            }

            return message.Source?.Value;
        }

        private static string GetOpaqueSignalRConnectionId(dynamic message)
        {
            if (message.Opaque?.SignalRConnectionId?.Value != null)
            {
                return message.Opaque?.SignalRConnectionId?.Value;
            }

            return message.SignalRConnectionId?.Value;
        }

        private async Task HandleImageProcessedMessageAsync(string jsonString, CancellationToken cancellationToken)
        {
            _logger.LogDebug($"BEGIN: HandleImageProcessedMessageAsync {jsonString}");

            if (!TryGetDynamicSignalRMessage(jsonString, out dynamic message))
            {
                // Test case returns false, so we can exit early
                return;
            }


            object payload = null;
            // currently connectionId varies from the sender of message on the the same topic
            // todo - standardize if message is on same topic
            string connectionId = null;

            switch (message.MessageType.Value)
            {
                case "FILE_UPLOADED":
                    connectionId = message.Opaque.SignalRConnectionId;
                    payload = new { MessageType = message.MessageType.Value, AssetId = message.AssetId.Value, Source = GetOpaqueSource(message) };
                    break;
                case "CONVERSION_READY": 
                    connectionId = message.Opaque.SignalRConnectionId;
                    ThumbReadyDTO thumbReady = GetThumbnailReadyPayload(message);

                    try
                    {
                        var assetService = _assetServiceFactory.CreateAssetService();
                        _logger.LogDebug($"Image Converter did its job.");
                        var resultJson = await assetService.StoreAttachmentsAsync(thumbReady);
                        _logger.LogDebug($"Store asset attachments returns: {resultJson}");

                        AssetAttachmentReplyDTO obj = JsonConvert.DeserializeObject<AssetAttachmentReplyDTO>(resultJson);
                        if (obj != null && obj.MetadataInfo != null)
                        {
                            foreach (var item in obj.MetadataInfo)
                            {
                                thumbReady.AddMetaResults(item);
                            }
                        }
                    }
                    catch (InvalidOperationException invalidOpEx)
                    {
                        // Timeout expired.  The timeout period elapsed prior to obtaining a connection from the pool.  
                        // This may have occurred because all pooled connections were in use and max pool size was reached.

                        // TODO - figure out why db connection pools running out.
                        // Let's alert the client anyways that the conversion is good, we just dont have the data saved on the asset table
                        this._logger.LogError(invalidOpEx, "Failed saving asset attachment");
                    }
                    catch (Exception ex)// should be System.InvalidOperationException 
                    {
                        // just in case
                        this._logger.LogError(ex, "Failed saving asset attachment");
                    }

                    payload = thumbReady;

                    break;
                case "DOWNLOAD_CONVERSION_READY":
                    connectionId = message.Opaque.SignalRConnectionId;
                    var downloadFolderName = message.Opaque?.DownloadFolderName?.Value;
                    payload = new { MessageType = message.MessageType.Value, AssetId = message.Opaque?.AssetId?.Value, ContainerName = message.ProcessorInfo?.Tasks[0].Destinations[0]?.Details?.ContainerName?.Value, DownloadFolderName = downloadFolderName, Source = GetOpaqueSource(message), StatusCode = message.StatusCode.Value };
                    break;
                case "ERROR":
                    connectionId = message.SignalRConnectionId.Value;
                    payload = new { MessageType = message.MessageType.Value, ErrorMessage = message.ErrorMessage.Value, AssetId = message.AssetId.Value, Source = GetOpaqueSource(message) };
                    break;
                case "HUBSPOT_SYNC_ASSET_STARTED":
                    connectionId = message.SignalRConnectionId.Value;
                    if (string.IsNullOrWhiteSpace(connectionId)) break;
                    payload = new { 
                        MessageType = message.MessageType.Value, 
                        AssetId = message.AssetId.Value 
                    };
                    break;
                case "HUBSPOT_SYNC_ASSET_SUCCESS":
                    connectionId = message.SignalRConnectionId.Value;
                    if (string.IsNullOrWhiteSpace(connectionId)) break;
                    payload = new { 
                        MessageType = message.MessageType.Value, 
                        AssetId = message.AssetId.Value 
                    };
                    break;
                case "HUBSPOT_SYNC_ASSET_ERROR":
                    connectionId = message.SignalRConnectionId.Value;
                    if (string.IsNullOrWhiteSpace(connectionId)) break;
                    payload = new { 
                        MessageType = message.MessageType.Value, 
                        AssetId = message.AssetId.Value,
                        SyncError = new { 
                            Code = message.Error?.Code.Value,
                            Description = message.Error?.Description.Value
                        }
                    };
                    break;
                default:
                    _logger.LogWarning($"\n\n\t### Missing case for message type {message.MessageType.Value}\n");
                    break;
            }

            await BroadcastMessageAsync(payload, connectionId);                 

            _logger.LogDebug("END: HandleImageProcessedMessageAsync");
        }

        private async Task HandleTagsProcessedMessageAsync(string jsonString, CancellationToken cancellationToken)
        {
            _logger.LogDebug($"BEGIN: HandleTagsProcessedMessageAsync {jsonString}");

            if (!TryGetDynamicSignalRMessage(jsonString, out dynamic message))
            {
                // Test case returns false, so we can exit early
                return;
            }

            object payload = null;
            string connectionId = message.Opaque.SignalRConnectionId;

            switch (message.MessageType.Value)
            {  
                case "TAGGING_READY":
                    TagsReadyDTO tagsReady = GetTagsReadyPayload(message);
                    // this one back to application as imageTags instead of color/landmarks/celebrities
                    TagsReadyDTO tagsReadyToBroadcast = GetTagsReadyPayloadToBroadcast(message);
                    try
                    {
                        _logger.LogDebug("TAGGING_READY received, store the tags to database");
                        var assetService = _assetServiceFactory.CreateAssetService();

                        var test = await assetService.StoreAiAndOcrTextAsync(tagsReady);
                        _logger.LogDebug("Store asset attachments returns: {test}", test);
                    }
                    catch (InvalidOperationException invalidOpEx)
                    {
                        _logger.LogError(invalidOpEx, "Failed saving asset AI tags");
                    }

                    payload = tagsReadyToBroadcast;
                    break;

                default:
                    _logger.LogWarning($"\n\n\t### Missing case for message type {message.MessageType.Value}\n");
                    break;
            }

            await BroadcastMessageAsync(payload, connectionId);

            _logger.LogDebug("END: HandleTagsProcessedMessageAsync");
        }

        private async Task HandleAccountProcessedMessageAsync(string jsonString, CancellationToken cancellationToken)
        {
           _logger.LogInformation($"BEGIN: HandleAccountProcessedMessageAsync");

            if (!TryGetDynamicSignalRMessage(jsonString, out dynamic message))
            {
                // Test case returns false, so we can exit early
                return;
            }

            object payload = null;
            string connectionId = message.SignalRConnectionId.Value;
            
            switch (message.MessageType.Value)
            {
                case "EMAIL_SENT":
                    payload = new { MessageType = message.MessageType.Value, message.Email?.Value, Source = GetOpaqueSource(message) };
                    break;
                case "USER_SYNCED":
                    payload = new { MessageType = message.MessageType.Value, message.UserId?.Value, Source = GetOpaqueSource(message) };
                    break;
                case "STORAGE_CONTAINER_CREATED":
                    payload = new { MessageType = message.MessageType.Value, message.AccountId?.Value, Source = GetOpaqueSource(message) };
                    break;
                case "FREETRIAL_SAMPLE_ASSETS_COPIED":
                    payload = new { MessageType = message.MessageType.Value, message.SourceContainer?.Value, Source = GetOpaqueSource(message) };
                    break; 
                case "LEAD_CREATED_OR_CONVERTED":
                    payload = new { MessageType = message.MessageType.Value, message.Email?.Value, Source = GetOpaqueSource(message) };
                    break;
                case "ERROR":
                    payload = new { MessageType = "PROVISION_ERROR", Email = message.Email?.Value, ErrorMessage = message.ErrorMessage?.Value, Source = GetOpaqueSource(message) };
                    _logger.LogInformation($"SignalR Error {message.ErrorMessage?.Value} ");
                    break;

                default:
                    _logger.LogWarning($"\n\n\t### Missing case for message type {message.MessageType.Value}, {jsonString}\n");
                    break;
            }

            await BroadcastMessageAsync(payload, connectionId);

            _logger.LogInformation("END: HandleAccountProcessedMessageAsync");
        }

        private async Task HandleCustomizeAssetProcessedMessageAsync(string jsonString, CancellationToken cancellationToken)
        {
            _logger.LogDebug($"BEGIN: HandleCustomizeAssetProcessedMessageAsync {jsonString}");

            if (!GetValidatedSignalRMessage(jsonString, out CustomizeAssetReadyMessage message))
            {
                // Test case returns false, so we can exit early
                return;
            }

            object payload = null;
            string connectionId = message.Opaque.SignalRConnectionId;

            switch (message.MessageType)
            {
                case "CUSTOMIZE_ASSET_READY":
                    payload = new
                    {
                        MessageType = message.MessageType,
                        TestData = new
                        {
                            Body = "More things todo!!"
                        }
                    };
                    break;

                default:
                    _logger.LogWarning($"\n\n\t### Missing case for message type {message.MessageType}\n");
                    break;
            }

            await BroadcastMessageAsync(payload, connectionId);

            _logger.LogDebug("END: HandleCustomizeAssetProcessedMessageAsync");
        }

        private async Task HandleNotificationInitiatedMessageAsync(string jsonString, CancellationToken cancellationToken)
        {
            _logger.LogDebug($"BEGIN: HandleNotificationInitiatedMessageAsync {jsonString}");

            if (!GetValidatedSignalRMessage(jsonString, out NotificationInitiatedMessage message))
            {

                // Test case returns false, so we can exit early
                return;
            }

            object payload = null;

            switch (message.MessageType)
            {
                case "NOTIFICATION_INITIATED":
                    try
                    {
                        // Get the notification from database using the assetCommentId from the message.
                        var notificationService = _notificationServiceFactory.CreateNotificationService();
                        var resultJson = await notificationService.GetNotificationByAssetCommentIdAsync(message.AssetCommentId);
                        _logger.LogDebug($"GetNotificationByAssetCommentIdAsync returns: {resultJson}");

                        NotificationDTO obj = JsonConvert.DeserializeObject<NotificationDTO>(resultJson);

                        payload = new
                        {
                            MessageType = message.MessageType,
                            Notification = obj
                        };
                    }
                    catch (InvalidOperationException invalidOpEx)
                    {                        
                        _logger.LogError(invalidOpEx, "Failed getting notification");
                    }
                    
                    break;

                default:
                    _logger.LogWarning($"\n\n\t### Missing case for message type {message.MessageType}\n");
                    break;
            }            

            foreach (Guid userId in message.UserIds)
            {
                await BroadcastMessageAsync(payload, userId);
            }

            _logger.LogDebug("END: HandleNotificationInitiatedMessageAsync");
        }

        // Broadcasts message to client with the matching connectionId.
        private async Task BroadcastMessageAsync(object payload, string connectionId)
        {
            _logger.LogDebug("BEGIN: BroadcastMessageAsync");
            if (payload != null)
            {
                _logger.LogDebug("BEGIN: hubContext.Clients BroadcastMessage" +
                    $"\n\tPayload: {JsonConvert.SerializeObject(payload)}" +
                    $"\n\tConnectionId: {connectionId}\n");

                await _hubContext.Clients.Client(connectionId).BroadcastMessage(payload);
                _logger.LogDebug("END: hubContext BroadcastMessage");
            }
            _logger.LogDebug("END: BroadcastMessageAsync");
        }

        // Broadcasts message to client with the matching idpId.
        private async Task BroadcastMessageAsync(object payload, Guid userId)
        {
            _logger.LogDebug("BEGIN: BroadcastMessageAsync");
            if (payload != null)
            {
                _logger.LogDebug("BEGIN: hubContext.Clients BroadcastMessage" +
                    $"\n\tPayload: {JsonConvert.SerializeObject(payload)}" +
                    $"\n\tIdpId: {userId}\n");

                await _hubContext.Clients.User(userId.ToString().ToLower())?.BroadcastMessage(payload); 

                _logger.LogDebug("END: hubContext BroadcastMessage");
            }
            _logger.LogDebug("END: BroadcastMessageAsync");
        }

        private static ThumbReadyDTO GetThumbnailReadyPayload(dynamic message)
        {
            var assetId = message.Opaque?.AssetId?.Value;
            var statusCode = message.StatusCode;
            ThumbReadyDTO ret = new ThumbReadyDTO(assetId)
            {
                StatusCode = statusCode,
                AssetBlob = message.DownloadInfo?.Details?.Location,
                ContainerName = message.DownloadInfo?.Details?.ContainerName,
                AccountName = message.DownloadInfo?.Details?.AccountName,
                Source = GetOpaqueSource(message)
            };

            ret.MetadataInfo = new MetadataInfoDTO()
            {
                Author = message.MetadataInfo?.Author ?? "",
                Created = message.MetadataInfo?.Created ?? ""                
            };
            ret.AssetDescription = message.MetadataInfo?.Description ?? "";
            
            if (message.MetadataInfo?.Tags?.Value != null)
            {
                var splitTags = message.MetadataInfo?.Tags?.Value?.ToString().Trim().Split(';');

                if (splitTags != null && splitTags.Length > 0)
                {
                    for (int i = 0, tagsCount = splitTags.Length; i < tagsCount; i++)
                    {
                        var tag = splitTags[i];
                        FileMetadataTagDTO tagDTO = new FileMetadataTagDTO()
                        {
                            Name = tag?.ToLowerInvariant(),
                        };

                        ret.FileMetadataTags.Add(tagDTO);
                    }
                }
            }
            
            if (statusCode == 200 || statusCode == 206)
            {
                var tasks = message.ProcessorInfo?.Tasks;
                if (tasks != null)
                {
                    for (int i = 0; i < tasks.Count; i++)
                    {
                        var task = tasks[i];
                        TaskResultDTO taskResult = new TaskResultDTO()
                        {
                            Name = task.Name,
                            StatusCode = task.StatusCode
                        };

                        if (task.StatusCode == 200)
                        {
                            taskResult.ContainerName = task.Destinations[0]?.Details?.ContainerName;
                            taskResult.BlobName = task.Destinations[0]?.Details?.Location;
                        }
                        ret.AddTaskResult(taskResult);
                    }
                }

            }
            return ret;
        }

        private static TagsReadyDTO GetTagsReadyPayload(dynamic message)
        {
            var assetId = message.Opaque?.AssetId?.Value;
            var statusCode = message.StatusCode;
            var accountId = message.AccountId;
            TagsReadyDTO ret = new TagsReadyDTO(assetId)
            {
                StatusCode = statusCode,
                AccountId = accountId,
                Source = GetOpaqueSource(message)
            };

            if (statusCode == 200 || statusCode == 206)
            {
                var tags = message.ImageTags;
                
                if (tags != null && tags.Count > 0)
                {
                    for (int i = 0, tagsCount = tags.Count; i < tagsCount; i++)
                    {
                        var tag = tags[i];
                        ImageTagDTO tagDTO = new ImageTagDTO()
                        {
                            Name = tag.Name,
                            Confidence = tag.Confidence
                        };
                        ret.ImageTags.Add(tagDTO);
                    }
                }

                var colorTags = message.ColorInfo?.DominantColors;

                if (colorTags != null && colorTags?.Count > 0)
                {
                    for (int i = 0, tagsCount = colorTags.Count; i < tagsCount; i++)
                    {
                        var tag = colorTags[i];
                        ColorInfoDTO tagDTO = new ColorInfoDTO()
                        {
                            Name = tag?.ToString().ToLowerInvariant(),
                        };
                        
                        ret.ColorTags.Add(tagDTO);
                    }
                }

                var celebritiesTags = message.CelebritiesTags;
                if (celebritiesTags != null && celebritiesTags?.Count > 0)
                {
                    for (int i = 0, tagsCount = celebritiesTags.Count; i < tagsCount; i++)
                    {
                        var tag = celebritiesTags[i];
                       CelebritiesTagsDTO tagDTO = new CelebritiesTagsDTO()
                        {
                            Name = tag.Name,
                            Confidence = tag.Confidence
                        };
                        ret.CelebritiesTags.Add(tagDTO);
                    }
                }

                var landmarksTags = message.LandmarksTags;
                if (landmarksTags != null && landmarksTags?.Count > 0)
                {
                    for (int i = 0, tagsCount = landmarksTags.Count; i < tagsCount; i++)
                    {
                        var tag = landmarksTags[i];
                        LandmarksTagDTO tagDTO = new LandmarksTagDTO()
                        {
                            Name = tag.Name,
                            Confidence = tag.Confidence
                        };
                        ret.LandmarksTags.Add(tagDTO);
                    }
                }
                var ocrText = message.OcrText?.Value;
                if (!string.IsNullOrEmpty(ocrText))
                {
                    ret.OcrText = ocrText;  
                }
            }
            return ret;
        }

        private static TagsReadyDTO GetTagsReadyPayloadToBroadcast(dynamic message)
        {
            var assetId = message.Opaque?.AssetId?.Value;
            var statusCode = message.StatusCode;
            var accountId = message.AccountId;
            TagsReadyDTO ret = new TagsReadyDTO(assetId)
            {
                StatusCode = statusCode,
                AccountId = accountId,
                Source = GetOpaqueSource(message)
            };

            if (statusCode == 200 || statusCode == 206)
            {
                var tags = message.ImageTags;

                if (tags != null && tags.Count > 0)
                {
                    for (int i = 0, tagsCount = tags.Count; i < tagsCount; i++)
                    {
                        var tag = tags[i];
                        ImageTagDTO tagDTO = new ImageTagDTO()
                        {
                            Name = tag.Name,
                            Confidence = tag.Confidence
                        };
                        ret.ImageTags.Add(tagDTO);
                    }
                }

                var colorTags = message.ColorInfo?.DominantColors;

                if (colorTags != null && colorTags?.Count > 0)
                {
                    for (int i = 0, tagsCount = colorTags.Count; i < tagsCount; i++)
                    {
                        var tag = colorTags[i];
                        ImageTagDTO tagDTO = new ImageTagDTO()
                        {
                            Name = tag?.ToString().ToLowerInvariant(),
                        };
                        ret.ImageTags.Add(tagDTO);
                    }
                }

                var celebritiesTags = message.CelebritiesTags;
                if (celebritiesTags != null && celebritiesTags?.Count > 0)
                {
                    for (int i = 0, tagsCount = celebritiesTags.Count; i < tagsCount; i++)
                    {
                        var tag = celebritiesTags[i];
                        ImageTagDTO tagDTO = new ImageTagDTO()
                        {
                            Name = tag.Name,
                            Confidence = tag.Confidence
                        };
                        ret.ImageTags.Add(tagDTO);
                    }
                }

                var landmarksTags = message.LandmarksTags;
                if (landmarksTags != null && landmarksTags?.Count > 0)
                {
                    for (int i = 0, tagsCount = landmarksTags.Count; i < tagsCount; i++)
                    {
                        var tag = landmarksTags[i];
                        ImageTagDTO tagDTO = new ImageTagDTO()
                        {
                            Name = tag.Name,
                            Confidence = tag.Confidence
                        };
                        ret.ImageTags.Add(tagDTO);
                    }
                }
                ret.OcrText = message.OcrText?.Value;
            }
            return ret;
        }
       
        private bool TryGetDynamicSignalRMessage(string jsonString, out dynamic message)
        {
            if (jsonString == null)
            {
                _logger.LogInformation("jsonString is null");
                throw new Marcom.Azure.ServiceBus.Exceptions.InvalidServiceBusMessageException("jsonString is null");
            }

            message = null;
            try
            {
                message = JsonConvert.DeserializeObject<dynamic>(jsonString);
            }
            catch
            {
                _logger.LogInformation(string.Format(CultureInfo.InvariantCulture, $"Failed to deserialize to dynamic: msg = {jsonString}"));
            }

            var messageType = message?.MessageType?.Value;
            // Calling methods needs to exit early if message is null which signals
            // we're handling a TEST message.  Currently only sent from webapi
            // but we'll want to handle it all the same.
            if (messageType == "TEST_STARTED")
            {
                // webapi will send the message with a TestMessage property
                // which should include the TestId property
                HandleTestStartedMessage(Guid.Parse(message.TestMessage?.TestId?.Value));
                return false;
            }

            // Here's the validation, handle SignalrConnectionId for the different variations it may be included
            if (message == null)
                throw new Marcom.Azure.ServiceBus.Exceptions.InvalidServiceBusMessageException($"Message is null - {jsonString}");
            else if (message.MessageType == null)
                throw new Marcom.Azure.ServiceBus.Exceptions.InvalidServiceBusMessageException($"MessageType is null - {jsonString}");
            else if (message.MessageType != "NOTIFICATION_INITIATED" // This is ugly. Validation may need to be done on individual message handlers.
                    && string.IsNullOrEmpty(GetOpaqueSignalRConnectionId(message)))
                throw new Marcom.Azure.ServiceBus.Exceptions.InvalidServiceBusMessageException($"SignalRConnectionId is null for {messageType}");

            return true;
        }

        private bool GetValidatedSignalRMessage<T>(string jsonString, out T message)
        {
            message = default(T);
            if(!TryGetDynamicSignalRMessage(jsonString, out dynamic dynamicMessage))
            {
                // Test case returns false, so we can exit early
                return false;
            }

            // double de-serialization after we did the dynamic check, is there a way around this?
            message = JsonConvert.DeserializeObject<T>(jsonString);
            return message != null;
        }

        private void HandleTestStartedMessage(Guid testId)
        {
            _logger.LogInformation($@"
                    **********************************************************
                    * Message Received: {testId} *
                    **********************************************************
                    ");
        }
    }
}
