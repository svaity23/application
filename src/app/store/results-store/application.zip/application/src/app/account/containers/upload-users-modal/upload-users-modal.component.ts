import { ChangeDetectionStrategy, Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { Observable } from 'rxjs';

import { AccountUserStoreFacade } from '@app/store/account-store/account-user-store.facade';
import { UploadUsersModalOptions } from '@app/core/models/modal-options/upload-users-modal-options.model';
import { User } from '@app/core/models/entities/user.model';

@Component({
	selector: 'app-upload-users-modal',
	templateUrl: './upload-users-modal.component.html',
	styleUrls: ['./upload-users-modal.component.scss'],
 	encapsulation: ViewEncapsulation.None,
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class UploadUsersModalComponent implements OnInit {
  acceptedFileTypes = '.csv, .xlsx';
  errorsForUsersToUpload$: Observable<string[]>;
  @ViewChild('fileInput') fileInput: ElementRef;
  fileUploaded = false;
  isValidating$: Observable<boolean>
  modalRef: BsModalRef;
	options: UploadUsersModalOptions;
  sampleCsvFileLocation = '/assets/Users-spreadsheet.csv';
  sampleXlsxFileLocation = '/assets/Users-spreadsheet.xlsx';
	title: string;
  usersToUpload$: Observable<User[]>;
  warningsForUsersToUpload$: Observable<string[]>;


	constructor(private accountUserStoreFacade: AccountUserStoreFacade) {}

	closeModal(): void {
		this.modalRef.hide();
		this.modalRef = null;
    this.fileUploaded = false;
    this.accountUserStoreFacade.resetUploadUsers();
	}

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  fileChangeEvent($event: any): void {
    if ($event?.target?.files[0]) {
      this.fileUploaded = true;
      this.accountUserStoreFacade.validateUploadUsersFile($event?.target?.files[0]);
    }

  }

  fileDropped(files: File[]): void {
    if (files && files[0]) {
      this.fileUploaded = true;
      this.accountUserStoreFacade.validateUploadUsersFile(files[0]);
    }
  }

	ngOnInit(): void {
    this.title = this.options.title;
    this.isValidating$ = this.accountUserStoreFacade.isValidating$;
    this.usersToUpload$ = this.accountUserStoreFacade.usersToUpload$;
    this.errorsForUsersToUpload$ = this.accountUserStoreFacade.errorsForUsersToUpload$;
    this.warningsForUsersToUpload$ = this.accountUserStoreFacade.warningsForUsersToUpload$;
 	}

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  openFilePicker($event: any): void {
    this.fileInput.nativeElement.click();
    if ($event) {
      $event.stopPropagation();
    }
  }

	uploadUsers(): void {
    this.options.confirm();
    this.closeModal();
  }
}
