import { ChangeDetectionStrategy, Component, EventEmitter, HostBinding, Output, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-utilities-sidebar',
  templateUrl: './utilities-sidebar.component.html',
  styleUrls: ['./utilities-sidebar.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UtilitiesSidebarComponent  {
  @Output() navigateToAccountsEvent = new EventEmitter();
  @HostBinding('attr.ngNoHost') noHost = '';

  constructor() { }

  navigateToAccounts(): void {
    this.navigateToAccountsEvent.emit();
  }
}
