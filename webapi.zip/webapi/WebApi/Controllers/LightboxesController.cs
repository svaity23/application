﻿using ApplicationLogic.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Dtos;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class LightboxesController : ControllerBase
    {
        private readonly ILogger<LightboxesController> _logger;
        private readonly LightboxService _lightboxService;
        private readonly UserAccountService _userAccountService;

        public LightboxesController(ILogger<LightboxesController> logger, LightboxService lightboxService, UserAccountService userAccountService)
        {
            _logger = logger;
            _lightboxService = lightboxService;
            _userAccountService = userAccountService;
        }

        /// <summary>
        /// Get all light-boxes for current user
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ApiExplorerSettings(IgnoreApi = false)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<LightboxDto>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> GeLightboxesAsync()
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            GetEntitiesResponse<LightboxDto> results = await _lightboxService.GetAllAsync(accountId, userId);

            int err = results.Error.Code;
            return err switch
            {
                0 => Ok(results.Entities ?? new List<LightboxDto>()),
                3 => Forbid(),// the user doesn't have rights
                _ => BadRequest(),// invalid json input for stored procedure
            };
        }

        /// <summary>
        /// Get all light-boxes preview assets
        /// </summary>
        /// <returns></returns>
        [HttpGet("previewAssets")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<LightboxPreviewDto>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> GetLightboxPreviewAssetsAsync()
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            GetEntitiesResponse<LightboxPreviewDto> results = await _lightboxService.GetPreviewAssetsAsync(accountId, userId);

            int err = results.Error.Code;
            return err switch
            {
                0 => Ok(results.Entities ?? new List<LightboxPreviewDto>()),
                3 => Forbid(),// the user doesn't have rights
                _ => BadRequest(),// invalid json input for stored procedure
            };
        }

        /// <summary>
        /// Get lightbox by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(LightboxDto))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetLightboxByIdAsync(Guid id)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            GetEntityResponse<LightboxDto> results = await _lightboxService.GetLightboxByIdAsync(accountId, userId, id);
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entity),
                    3 => Forbid(),// the user doesn't have rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }

        /// <summary>
        /// Creates or updates lightbox
        /// </summary>
        /// <returns>Created or updated LightboxDto</returns>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(LightboxDto))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> UpsertLightboxAsync([FromBody] LightboxDto lightbox)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            if (lightbox == null) return BadRequest();
            
            if (string.IsNullOrEmpty(lightbox.Name))
                ModelState.AddModelError("Name", "lightbox name is empty");

            if (ModelState.ErrorCount > 0)
                return BadRequest(ModelState);

            _logger.LogWarning($"User {userId} updates the lightbox {lightbox.Name}");
            var results = await _lightboxService.UpsertLightboxAsync(accountId, userId, lightbox);
            if (results != null)
            {
                int err = results.Errors[0].Code;
                return err switch
                {
                    0 => StatusCode(StatusCodes.Status201Created, results.Entity),
                    2 => Conflict(),// a group with the specified name already exists in db
                    3 => Forbid(),// the user doesn't have rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }

        /// <summary>
        /// Delete lightbox by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Id of the deleted lightbox</returns>
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Guid))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> DeleteByIdAsync(Guid id)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService); ;
            var userId = this.User.GetUserId();

            _logger.LogWarning($"User {userId} initiate the delete of the lightbox {id}");
            var result = await _lightboxService.DeleteByIdAsync(accountId, userId, id);
            if (result != null)
            {
                int err = result.Errors.FirstOrDefault().Code;
                return err switch
                {
                    0 => Ok(result.Entity),
                    3 => Forbid(),// the user doesn't have rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }

            return NotFound();
        }
    }
}
