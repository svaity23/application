﻿using System;

namespace SignalRHub.Messages
{
    public class AttachmentDTO
    {
        public string AccountName { get; set; }
        public string AssetBlob { get; set; }
        public Guid AssetId { get; set; }
        public string ContainerName { get; set; }
        public AttachmentEntryDTO[] Results { get; set; }
        public int StatusCode { get; set; }
    }
}
