﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Net.Mime;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Dtos;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class LegalController : ControllerBase
    {
        private readonly ILogger<LegalController> _logger;
        private readonly LegalService _legalService;
        private readonly UserAccountService _userAccountService;

        public LegalController(ILogger<LegalController> logger, LegalService legalService, UserAccountService userAccountService)
        {
           _logger = logger;
           _legalService = legalService;
            _userAccountService = userAccountService;
        }

        [HttpPut]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> AcceptLegal([FromBody] AcceptLegalDto legal)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            if(accountId.ToString().ToLowerInvariant() != legal.AccountId.ToLowerInvariant() 
                || userId.ToString().ToLowerInvariant() != legal.UserId.ToLowerInvariant())
            {
                return BadRequest();
            }


            int ret = await _legalService.AcceptLegal(legal);
            _logger.LogDebug("Legal documents accepted {0}", ret);
            return Ok();
        }
    }
}
