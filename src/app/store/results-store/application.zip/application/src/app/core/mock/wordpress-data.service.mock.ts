import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { BaseDataService } from '../data-services/base-data.service';
import { WordPressDataServiceInterface } from '../data-services/wordpress-data.service';

import { AssetDownloadRequest } from '../models/asset-download-request.model';

@Injectable({ providedIn: 'root' })
export class WordPressDataServiceMock extends BaseDataService implements WordPressDataServiceInterface {

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  downloadAssets(assetDownloadRequests: Array<AssetDownloadRequest>): Observable<any> {
    const returnList = [];
    assetDownloadRequests.forEach(assetDownReq => {
      const returnVal = {
        fileName: assetDownReq.sourceFileName,
        key: '23192-43566-436346-432523'
      };
      returnList.push(returnVal);
    })
    return new Observable(observer => {
      // Yield a single value and complete
      observer.next(returnList)
      observer.complete();
    });
  }

}
