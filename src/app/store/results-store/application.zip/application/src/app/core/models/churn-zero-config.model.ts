export interface ChurnZeroConfig {
    churnZeroAppKey: string,
    churnZeroUrl: string
}