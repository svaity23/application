﻿using Microsoft.AspNetCore.Http;
using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using WebApi.Services;

namespace WebApi.Extensions
{
    public static class SystemSecurity
    {
        public static Guid GetIdpId(this ClaimsPrincipal user)
        {
            if (Guid.TryParse(user.GetClaim("sub").Trim(), out Guid idpId))
            {
                return idpId;
            }
            throw new InvalidAuthorizationClaimsException("Sub missing in claims");
        }

        public static async Task<Guid> GetAccountIdAsync(this ClaimsPrincipal user, HttpRequest request, UserAccountService userAccountService)
        {
            var isAccountIdFromHeaderValid = Guid.TryParse(request.GetHeaderValue("accountId"), out Guid accountIdFromHeader);
            if (isAccountIdFromHeaderValid)
            {
                var extension_accountId = user.GetClaim("extension_accountId").Trim();
                if (!string.IsNullOrEmpty(extension_accountId))
                {
                    var accountIds = user.GetClaim("extension_accountId").Trim().Split(',');
                    var lowercaseAccountIds = accountIds.Select(c => c.ToLowerInvariant()).ToArray();
                    if (lowercaseAccountIds.Contains(accountIdFromHeader.ToString().ToLowerInvariant()))
                    {
                        return accountIdFromHeader;
                    }
                    else if (accountIds.Length > 6) // we save a trailing comma more than 6 accounts, last string is empty
                    {
                        var accountGuids = await userAccountService.GetAccountIdsByUserIdAsync(user.GetUserId());
                        if (accountGuids.Contains(accountIdFromHeader))
                        {
                            return accountIdFromHeader;
                        }
                    }
                }
            }

            // Sys admin users do not have account Ids
            // return Guid.Empty;

            // for not throw the exception until we add logic to test for it in the controller
            throw new InvalidAuthorizationClaimsException("Account Id missing in claims/header or inValid");
        }

        public static Guid GetUserId(this ClaimsPrincipal user)
        {
            if (Guid.TryParse(user.GetClaim("extension_userId").Trim(), out Guid userId))
            {
                return userId;
            }
            throw new InvalidAuthorizationClaimsException("User Id missing in claims");
        }

        public static string GetClaim(this ClaimsPrincipal user, string claimName)
        {
            var claimsPrincipal = user;
            var claims = from c in claimsPrincipal.Claims
                         where c.Type.ToLowerInvariant() == claimName.ToLowerInvariant()
                         select c.Value;

            return claims.LastOrDefault() ?? string.Empty;
        }
    }

    public class InvalidAuthorizationClaimsException : Exception
    {
        public InvalidAuthorizationClaimsException(string message) : base(message)
        {
        }
    }
}
