﻿namespace WebApi.Dtos.Search
{
    public class AggregationBucketDto
    {
        public int Count { get; set; }
        public string Name { get; set; }
    }
}
