export interface IdEntityResponse {
    id: string;
}
