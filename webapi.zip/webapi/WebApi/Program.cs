using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using System;
using System.Threading.Tasks;
using WebApi.Extensions;

namespace WebApi
{
    public static class Program
    {
        public static async Task Main(string[] args)
        {
            var host = CreateHostBuilder(args).Build();
            await host.InitializeAsync();
            host.Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args) 
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder
                    .UseStartup<Startup>()
                    .UseKestrel(o => { o.Limits.KeepAliveTimeout = TimeSpan.FromMinutes(3); });
                })
                .ConfigureAppConfiguration(c =>
                {
                    c.AddJsonFile("configmaps/appsettings.json", optional: true, reloadOnChange: false);
                    c.AddJsonFile("c:/damConfig/shared/appsettings.json", optional: true, reloadOnChange: true);
                });
    }
}
