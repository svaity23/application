import { Injectable } from '@angular/core';

import * as faker from 'faker/locale/en_US';
import { interval, Observable, of, Subject } from 'rxjs';
import { take } from 'rxjs/operators';

import { FileTypeService } from '../services/file-type.service';
import { SignalRService } from '../services/signal-r.service';
import { UploadDataServiceInterface } from '../data-services/upload-data.service';

import { FileGroupType, FileType } from '../enums';

import { Asset } from '../models/entities/asset.model';
import { AssetUploadProgress } from '../models/asset-upload-progress.model';
import { AssetValidateCreateResponse } from '../models/entities/asset-validate-create-response.model';
import { MetadataField } from '../models/entities/metadata-field.model';
import { MetadataProfile } from '../models/entities/metadata-profile.model';
import { MetadataProfileType } from '../models/entities/metadata-profile-type.model';
import { PayloadType } from '../enums/payload-type.enum';
import { Tag } from '../models/entities/tag.model';
import { UpdateEntitiesResponse } from '../models/api-responses/update-entities-response.model';

@Injectable({
  providedIn: 'root'
})
export class UploadDataServiceMock implements UploadDataServiceInterface {
  private internalMetadataFields: MetadataField[] = [];
  private internalMetadataProfiles: MetadataProfile[] = [];

  // TODO: need to remove from here
  private internalMetadataTypes: MetadataProfileType[] = [];
  private mockableFileTypes: FileType[];

  constructor(private fileTypeService: FileTypeService, private signalRService: SignalRService) {
    this.mockableFileTypes = this.fileTypeService.getImageFileTypes().concat(this.fileTypeService.getVideoFileTypes()).concat(this.fileTypeService.getDocumentFileTypes());

    // may use faker
    const metadataProfileTypes: MetadataProfileType[] = [
      { id: 0, name: 'Image' },
      { id: 1, name: 'Video' },
      { id: 2, name: 'Audio' },
      { id: 3, name: 'Design File' },
      { id: 4, name: 'Presentation' },
      { id: 5, name: 'Document' }
    ];
    this.internalMetadataTypes = metadataProfileTypes;
    const accountId = faker.random.number().toString();
    const defaultMetadataProfiles: MetadataProfile[] = [
      { accountId, id: '1', name: 'Image', metadataProfileTypeId: 0 },
      { accountId, id: '2', name: 'Video', metadataProfileTypeId: 1 },
      { accountId, id: '3', name: 'Audio', metadataProfileTypeId: 2 },
      { accountId, id: '4', name: 'Design File', metadataProfileTypeId: 3 },
      { accountId, id: '5', name: 'Presentation', metadataProfileTypeId: 4 },
      { accountId, id: '6', name: 'Document', metadataProfileTypeId: 5 },
    ];

    // const metadataFieldTypes: MetadataFieldType[] = [
    //   { id: '0', name: 'Text box' },
    //   { id: '5', name: 'Daterime' }
    // ];

    this.internalMetadataProfiles = defaultMetadataProfiles;
    const metadataFields: MetadataField[] = [
      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '1', label: 'Photographer', previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Photographer', metadataFieldTypeId: 0 },
      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '1', label: 'Date image taken',  previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Date image taken', metadataFieldTypeId: 5 },
      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '1', label: 'Location',  previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Location', metadataFieldTypeId: 0 },
      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '1', label: 'Camera',  previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Camera', metadataFieldTypeId: 0 },

      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '2', label: 'Videographer',  previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Videographer', metadataFieldTypeId: 0 },
      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '2', label: 'Date video recorded', previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Date video recorded', metadataFieldTypeId: 5 },
      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '2', label: 'Location',  previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Location', metadataFieldTypeId: 0 },

      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '3', label: 'Author',  previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Author', metadataFieldTypeId: 0 },
      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '3', label: 'Date audio recorded',  previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Date audio recorded', metadataFieldTypeId: 5 },
      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '3', label: 'Location',  previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Location', metadataFieldTypeId: 0 },

      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '6', label: 'Author',  previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Author', metadataFieldTypeId: 0 }
    ];
    this.internalMetadataFields = metadataFields;
  }

  // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
  cancelUploadWizard(_uploadSessionId: string)
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    : Observable<any> {
    return of(null);
  }

  finishUploadSession(assets: Asset[], uploadSessionId: string): Observable<UpdateEntitiesResponse> {
    console.log(assets, uploadSessionId);
    return of(null);
  }

  getAllMetadataFields(): Observable<MetadataField[]> {
    return new Observable(observer => {
      // Yield a single value and complete
      const clone = JSON.parse(JSON.stringify(this.internalMetadataFields));

      observer.next(clone);
      observer.complete();
    });
  }

  // This method is used to create empty Assets from the passed in files array and adds them to
  // queue stream.
  // The empty assets that get created will get returned to be displayed on the UI while the upload process continues.
  // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
  getFilesForUpload(_files: File[]): Observable<File[]> {
    // Ignore files parameter and create fake files and fake assets for mock data.
    const files: File[] = [];
    for (let i = 0; i < 10; i++) {
      const file = this.createFakeFile();
      files.push(file);
    }
    return of(files);
  }

  loadMetadataProfileFieldsByFileGroupType(fileGroupType: FileGroupType): Observable<MetadataField[]> {
    return new Observable(observer => {
      const types = this.internalMetadataTypes.filter(c => {
        return c.name === fileGroupType.toString();
      });
      const profiles = this.internalMetadataProfiles.filter(c => {
        return c.metadataProfileTypeId === types[0].id;
      });
      const metadataFields = this.internalMetadataFields.filter(f => {
        return f.metadataProfileId === profiles[0].id;
      });

      // Yield a single value and complete
      const clone = JSON.parse(JSON.stringify(metadataFields));
      observer.next(clone);
      observer.complete();
    });
  }

  loadMetadataProfiles(): Observable<MetadataProfile[]> {
    return new Observable(observer => {
      const clone = JSON.parse(JSON.stringify(this.internalMetadataProfiles));

      // Yield a single value and complete
      observer.next(clone);
      observer.complete();
    });
  }

  loadMetadataProfileTypes(): Observable<MetadataProfileType[]> {
    return new Observable(observer => {
      // Yield a siingle value and complete
      const clone = JSON.parse(JSON.stringify(this.internalMetadataTypes));
      observer.next(clone);
      observer.complete();
    });
  }

  saveTags(assets: Asset[], tagValues: string[]): Observable<Tag[]> {
    return new Observable(observer => {
      const newArray: Tag[] = [];
      assets.forEach((asset) => {
        const tag: Tag = {
          assetId: asset.id,
          values: tagValues,
          aiGeneratedValues: []
        };
        newArray.push(tag);
      });

      // Yield a single value and complete
      observer.next(newArray);
      observer.complete();
    });
  }

  // Fakes an upload post to the server and emits the progress of the upload.
  uploadAsset(asset: Asset): Observable<AssetUploadProgress> {
    const assetUploadProgress = new Subject<AssetUploadProgress>();

    // Randomize the progress interval so there is some variation in mocked upload speed.
    const uploadProgressInterval = this.randomInteger(5, 5);
    const progressSource = interval(uploadProgressInterval);
    progressSource.pipe(take(100)).subscribe((progress: number) => {
      // Stop on 99 since interval starts at 0.
      if (progress === 99) {
        assetUploadProgress.next({ asset, progress: 100 });
        assetUploadProgress.complete();
        // Fakes the signal R message from the server.
        // In a real word scenario this will be coming from the server.
        this.broadcastMessage(asset);
      } else {
        assetUploadProgress.next({ asset, progress });
      }
    });

    return assetUploadProgress.asObservable();
  }

  validateAndCreateAssets(assets: Asset[]): Observable<AssetValidateCreateResponse[]> {
    const newAssets: AssetValidateCreateResponse[] = [];
    for(let i; i < assets.length; i++){
       const a: AssetValidateCreateResponse = {
        accountId: assets[i].accountId,
        active: assets[i].active,
        created: new Date(assets[i].created),
        createdByByUserId: assets[i].createdByUserId,
        error: assets[i].error,
        fileExtension: assets[i].fileExtension,
        fileGroup: assets[i].fileGroup,
        fileName: assets[i].fileName,
        fileSize: assets[i].fileSize,
        id: assets[i].id,
        lastModifiedByUserId: assets[i].lastModifiedByUserId,
        modified: new Date(assets[i].modified),
        uploadSessionId: assets[i].uploadSessionId
      }
      newAssets.push(a);
    }

    return of(newAssets);
  }

  // Helper method to talk with signalRService when a fileError occurs.
  private broadcastFileError(asset: Asset): void {
    // This  would be coming from the server.
    const payload = {
      messageType: PayloadType.Error,
      error: 'some error message',
      fileName: asset.fileName,
      assetId: asset.id
    };

    this.signalRService.broadcast(payload);
  }

  // Randomly send file ready or file error message.
  private broadcastMessage(asset: Asset): void {
    const rand = this.randomInteger(5, 5);
    if (rand < 1) {
      this.broadcastFileError(asset);
    } else {
      this.broadcastThumbnailReady(asset);
    }
  }

  // Helper method to talk with signalRService when a fileReady occurs.
  private broadcastThumbnailReady(asset: Asset): void {
    // These payloads would be coming from the server.
    const payload = {
      messageType: PayloadType.ThumbnailReady,
      uri: this.getRandomThumnail(),
      fileName: asset.fileName,
      assetId: faker.random.number().toString()
    };

    this.signalRService.broadcast(payload);
  }

  private createFakeFile(): File {
    let fileName = faker.system.fileName().split('.').slice(0, -1).join('.');
    const fileType = this.mockableFileTypes[this.randomInteger(0, this.mockableFileTypes.length - 1)];
    fileName += '.' + FileType[fileType].toString();
    return new File([''], fileName);
  }
  // private createMetadataProfileType(): MetadataProfileType {
  //   const metadataProfileType: MetadataProfileType = {
  //     id: faker.random.number().toString(),
  //     name: FileGroupType.Image.toString(),
  //     type: FileGroupType.Image
  //   };
  //   return metadataProfileType;
  // }
  private getRandomThumnail(): string {
    return faker.random.arrayElement([
      'assets/img/thumbs/academic-degree-accomplishment-adult-2408471.jpg',
      'assets/img/thumbs/image_thumb-3x1.png',
      'assets/img/thumbs/erica-thomas-1653389-unsplash.jpg',
      'assets/img/thumbs/academic-regalia-accomplishment-alumni-2495232.jpg',
      'assets/img/thumbs/mimi-thian-jxUuXxUFfp4-unsplash.jpg',
      'assets/img/thumbs/stemshare-nsw-CFfoGuhptok-unsplash.jpg',
      'assets/img/thumbs/ryan-jacobson-687814-unsplash.jpg'
    ]);
  }

  private randomInteger(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
}
