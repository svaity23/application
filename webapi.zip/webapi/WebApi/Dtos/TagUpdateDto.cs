﻿using System;

namespace WebApi.Dtos
{
    public class TagUpdateDto
    {
        public Guid Id { get; set; }
        public Guid AssetId { get; set; }
        public string[] Values { get; set; }
    }
}
