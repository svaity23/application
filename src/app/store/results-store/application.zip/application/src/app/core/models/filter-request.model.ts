import { FilterGroupType } from '../enums/filter-group-type.enum';

export interface FilterRequest {
  filterGroupType: FilterGroupType;
  metadataFieldId?: string;  // Will be null except for metadata filter group types
  values: string[];
}
