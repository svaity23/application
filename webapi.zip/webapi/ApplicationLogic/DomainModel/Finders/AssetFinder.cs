﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using ApplicationLogic.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class AssetFinder
    {
        private const string UploadSessionIdParam = "uploadSessionId";
        private const string ActionParam = "action";
        private const string AssetIdsJsonParam = "assetIdsJson";
        private const string ExpDateParam = "expirationDate";
        private const string ZipIdParam = "zipId";
        private const string RecordUsageParam = "recordUsage";


        public ILogger<AssetFinder> Logger { get; set; }

        private damContext _context;

        public AssetFinder(damContext context)
        {
            _context = context;
            Logger = NullLogger<AssetFinder>.Instance;
        }

        public async Task<string> ActivateAssets(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            List<SqlParameter> paramList = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithSessionId(sessionId)
                .WithJson(jsonInput)
                .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("finishAssetsUpload", paramList);
        }

        public async Task<Asset> CreateAsync(Asset asset)
        {
            _context.Asset.Add(asset);
            await _context.SaveChangesAsync();
            return asset;
        }

        public async Task<string> UpdateFavoritesAsync(Guid accountId, Guid userId, string jsonInput)
        {
            List<SqlParameter> paramList = new SpParams()
              .WithAccountId(accountId)
              .WithUserId(userId)
              .WithJson(jsonInput)
              .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("upsertFavorites", paramList);
        }

        public async Task<List<Asset>> GetActiveAssets(Guid accountId)
        {
            return await _context.Asset.Where(a => a.AccountId.Equals(accountId) && a.Active).ToListAsync();
        }

        public async Task<string> GetAssetDetailForDetailsViewAsync(Guid accountId, Guid assetId, Guid userId)
        {
            List<SqlParameter> paramList = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithAssetId(assetId)
                .Build();

            return await _context.ExecuteNonQueryJsonOutputAsync("getAssetDetailForDetailsView", paramList);
        }

        public async Task<string> GetAssetForPreviewAsync(Guid accountId, Guid assetId, Guid userId, string jsonInput)
        {
            List<SqlParameter> paramList = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithAssetId(assetId)
                .WithJson(jsonInput)
                .Build();

            return await _context.ExecuteNonQueryJsonOutputAsync("getAssetForPreview", paramList);
        }

        public async Task<string> GetByAccountIdAsync(Guid accountId, Guid userId, string jsonInput)
        {
            List<SqlParameter> paramList = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithJson(jsonInput)
                .Build();

            return await _context.ExecuteNonQueryJsonOutputAsync("getAssetsByAccountId", paramList);
        }

        public async Task<string> GetAccountAssetInfoByIdsAsync(Guid accountId, Guid userId, Guid sessionId, string action, List<Guid> assetIds, bool recordUsage = false, DateTime? expirationDate = null, string zipId = null)
        {
            var listOfDic = assetIds.ConvertAll<Dictionary<string, Guid>>(x =>
            {
                var dic = new Dictionary<string, Guid>();
                dic.Add("id", x);
                return dic;
            });
            var assetIdsjson = JsonSerializer.Serialize(listOfDic);

            List<SqlParameter> paramList = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithSessionId(sessionId)
                .WithString(ActionParam, action)
                .WithDateTime2(ExpDateParam, expirationDate)
                .WithString(ZipIdParam, zipId)
                .WithString(AssetIdsJsonParam, assetIdsjson)
                .WithString(RecordUsageParam, recordUsage.ToString())
                .Build();


            var ret = await _context.ExecuteNonQueryJsonOutputAsync("getAssetInfoForDownload", paramList);
            Console.WriteLine("[getAssetInfoForDownload]: " + ret);

            return ret;

        }

        public async Task<string> GetAccountAssetsForCleanUpAsync(Guid accountId, Guid userId, string jsonInput)
        {
            List<SqlParameter> paramList = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithJson(jsonInput)
                .Build();

            return await _context.ExecuteNonQueryJsonOutputAsync("getAssetsForCleanUpByAccountId", paramList);
        }

        public async Task<string> GetCommentsAsync(Guid accountId, Guid userId, Guid assetId)
        {
            List<SqlParameter> paramList = new SpParams()
               .WithAccountId(accountId)
               .WithUserId(userId)
               .WithAssetId(assetId)
               .Build();

            return await _context.ExecuteNonQueryJsonOutputAsync("getCommentsThreadsAndUsersAndResetNotificationFlagsByAssetId", paramList);
        }

        public async Task<string> AddCommentAsync(Guid accountId, Guid userId, Guid assetId, string jsonInput)
        {
            List<SqlParameter> paramList = new SpParams()
               .WithAccountId(accountId)
               .WithUserId(userId)
               .WithAssetId(assetId)
               .WithJson(jsonInput)
               .Build();

            return await _context.ExecuteNonQueryJsonOutputAsync("saveAssetComment", paramList);
        }

        public async Task<string> UpdateCommentAsync(Guid accountId, Guid userId, Guid assetId, string jsonInput)
        {
            List<SqlParameter> paramList = new SpParams()
               .WithAccountId(accountId)
               .WithUserId(userId)
               .WithAssetId(assetId)
               .WithJson(jsonInput)
               .Build();

            return await _context.ExecuteNonQueryJsonOutputAsync("updateAssetComment", paramList);
        }


        public async Task<List<Asset>> GetAssetsByIdsAsync(Guid accountId, Guid[] ids)
        {
            Logger.LogInformation(string.Format(CultureInfo.InvariantCulture, "[Finder] Getting assets for account = {0}, for ids = {1}", accountId, string.Join(",", ids.Select(g => g.ToString()))));

            // TODO -refactor to stored proc
            var results = _context.Asset
                    .Include(u => u.CreatedByNavigation)
                    .Include(u => u.LastModifiedByNavigation)
                .Where(a =>
                    a.AccountId == accountId &&
                    (ids.Contains(a.Id))
                ).ToListAsync();
            return await results;
        }

        public async Task<string> UpdateAssetsWithCollectionIdAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            List<SqlParameter> paramList = new SpParams()
               .WithAccountId(accountId)
               .WithUserId(userId)
               .WithSessionId(sessionId)
               .WithJson(jsonInput)
               .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("updateAssetsWithCollectionId", paramList);
        }

        public async Task<string> DeleteAssetsAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            List<SqlParameter> paramList = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithSessionId(sessionId)
                .WithJson(jsonInput)
                .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("deleteAssetsByIdList", paramList);
        }

        public async Task<string> GetMetadataFieldsMetadataProfilesAndProfileTypesAsync(Guid accountId) // remove warning(s) once used.
        {
            List<SqlParameter> paramList = new SpParams()
                .WithAccountId(accountId)
                .Build();
            // metadata profile implementation requires to pass account id instead of null which is default

            return await _context.ExecuteNonQueryJsonOutputAsync("getMetadataFieldsMetadataProfilesAndProfileTypes", paramList);
        }

        public async Task<string> GetPostUploadSummaryAsync(Guid accountId, Guid uploadSessionId)
        {
            List<SqlParameter> paramList = new SpParams()
                 .WithAccountId(accountId)
                 .WithGuid(UploadSessionIdParam, uploadSessionId)
                 .Build();

            return await _context.ExecuteNonQueryJsonOutputAsync("getPostUploadSummary", paramList);
        }

        public async Task<string> UpdateAssetAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            List<SqlParameter> paramList = new SpParams()
              .WithAccountId(accountId)
              .WithUserId(userId)
              .WithSessionId(sessionId)
              .WithJson(jsonInput)
              .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("saveAsset", paramList);
        }

        public async Task<string> UpdateFavoriteAsync(Guid accountId, Guid userId, string jsonInput)
        {
            List<SqlParameter> paramList = new SpParams()
              .WithAccountId(accountId)
              .WithUserId(userId)
              .WithJson(jsonInput)
              .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("upsertFavorite", paramList);
        }

        public async Task<string> ValidateAndReplaceAsset(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            List<SqlParameter> paramList = new SpParams()
              .WithAccountId(accountId)
              .WithUserId(userId)
              .WithSessionId(sessionId)
              .WithJson(jsonInput)
              .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("validateAndReplaceAsset", paramList);
        }

        public async Task<string> ValidateAndCreateAssets(Guid accountId, Guid userId, string jsonInput, long maxFileUploadSizeInBytes)
        {
            List<SqlParameter> paramList = new SpParams()
              .WithAccountId(accountId)
              .WithUserId(userId)
              .WithJson(jsonInput)
              .WithBigInt("MaxFileUploadSizeInBytes", maxFileUploadSizeInBytes)
              .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("validateAndCreateAssets", paramList);
        }

        public async Task<string> UpdateMetadatumAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            List<SqlParameter> paramList = new SpParams()
              .WithAccountId(accountId)
              .WithUserId(userId)
              .WithSessionId(sessionId)
              .WithJson(jsonInput)
              .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("saveMetadatum", paramList);
        }

        public async Task<string> UpdateMetadataAsync(Guid accountId, Guid userId, string jsonInput)
        {
            List<SqlParameter> paramList = new SpParams()
               .WithAccountId(accountId)
               .WithUserId(userId)
               .WithJson(jsonInput)
               .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("saveAssetAndMetadataAndTags", paramList);
        }

        public async Task<string> UpdateTagAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            List<SqlParameter> paramList = new SpParams()
               .WithAccountId(accountId)
               .WithUserId(userId)
               .WithSessionId(sessionId)
               .WithJson(jsonInput)
               .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("saveTag", paramList);
        }
        public async Task<string> UpdateTagsAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            List<SqlParameter> paramList = new SpParams()
               .WithAccountId(accountId)
               .WithUserId(userId)
               .WithSessionId(sessionId)
               .WithJson(jsonInput)
               .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("saveTags", paramList);
        }

        public async Task<string> RecordAssetUsage(Guid accountId, Guid userId, Guid? sessionId, string jsonInput)
        {
            List<SqlParameter> paramList = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithSessionId(sessionId)
                .WithJson(jsonInput)
                .Build();

            var ret = await _context.ExecuteNonQueryJsonOutputAsync("saveAssetUsage", paramList);
            Logger.LogDebug($"RecordAssetUsage: {ret}");

            return ret;
        }

        public async Task<string> GetAssetHistoryAsync(Guid accountId, Guid assetId)
        {
            List<SqlParameter> paramList = new SpParams()
                .WithAccountId(accountId)
                .WithAssetId(assetId)
                .Build();

            return await _context.ExecuteNonQueryJsonOutputAsync("getAssetHistory", paramList);
        }

    }
}
