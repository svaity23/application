﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLogic.Logic
{
    public class SettingLogic
    {
        private readonly SettingFinder _finder;
        private readonly NullLogger<GroupLogic> _logger;

        public SettingLogic(damContext context)
        {
            _finder = new SettingFinder(context);
            _logger = NullLogger<GroupLogic>.Instance;
        }

        public async Task<string> GetFrontEndSettings(Guid accountId, Guid userId)
        {
            return await _finder.GetFrontEndSettings(accountId, userId);
        }

        public async Task<string> UpdateFrontEndSettings(Guid accountId, Guid userId, string jsonInput)
        {
            return await _finder.UpdateFrontEndSettings(accountId, userId, jsonInput);
        }
    }
}
