import { Page } from './page.model';

export interface Design {
    activePage: Page;
    fonts?: null;
    hasSubsetFonts: boolean;
    id: string;
    messageType?: string;
    pageCount?: number;
    pages: Page[];
    signalRConnectionId?: string;
    source?: string;
}