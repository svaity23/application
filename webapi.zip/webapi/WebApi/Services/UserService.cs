﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualBasic.FileIO;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using WebApi.Common.Constants;
using WebApi.Dtos;
using WebApi.Dtos.Context;
using WebApi.Extensions;

namespace WebApi.Services
{
    public class UserService
    {
        private readonly ILogger<UserService> _logger;
        private readonly ServiceBusService _serviceBusService;
        private readonly IConfiguration _configuration;
        private RoleLogic _roleLogic;
        private UserLogic _userLogic;
        private readonly BlobService _blobService;
        private readonly List<string> _allRoles = new List<string>() { "Admin", "Contributor", "Viewer" };
        private readonly JsonSerializerOptions _options = new JsonSerializerOptions()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };
        private readonly Regex _emailRegex = new Regex(@"^(([^<>()\[\]\\.,;:\s@""]+(\.[^<> ()\[\]\\.,;:\s@""]+)*)|("".+ ""))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$");   // the same regex used in UI app

        public static List<string> INTERNAL_ROLE_KEYS = new List<string>()
        {
            InternalUserRoleKeys.SystemAdmin,
            InternalUserRoleKeys.MccAdmin,
            InternalUserRoleKeys.TrialUser
        };

        public UserService(IConfiguration configuration, ILogger<UserService> logger, damContext context, ServiceBusService serviceBusService, BlobService blobService)
        {
            _configuration = configuration;
            _logger = logger;
            _serviceBusService = serviceBusService;
            _blobService = blobService;
            _userLogic = new UserLogic(context);
            _roleLogic = new RoleLogic(context);

            // TODO - create logger for _userLogic
            //_userLogic.Logger = 
        }

        public async Task<UserCsvResponseDto> BulkValidateCsvAsync(Stream csvFileStream, Guid accountId)
        {
            UserCsvResponseDto responseDto = new UserCsvResponseDto();
            int row = 0;
            using (TextFieldParser parser = new TextFieldParser(csvFileStream, Encoding.UTF8))
            {
                parser.Delimiters = new string[] { "," };

                int fni = -1, lni = -1, emi = -1, rli = -1;
                while (!parser.EndOfData)
                {
                    if (row == 0)   // Ignore first line: 'Email and name fields are required. Role will default to Viewer if left empty.'
                    {
                        parser.ReadLine();
                    }
                    else if (row >= 502)
                    {
                        _logger.LogDebug("Reached the 503th line in CVS, break the loop.");
                        responseDto.Warnings.Add("The limit of maximum 500 rows per upload was reached. The rows over this limit have been ignored.");
                        break;
                    }
                    else
                    {
                        try
                        {
                            var fields = parser.ReadFields();
                            if (row == 1)   // Read header line: 'Email Address,First Name,Last Name,"Role (Admin, Contributor, Viewer)"'
                            {
                                for (int i = 0; i < fields.Length; i++)
                                {
                                    var f = fields[i].Trim().ToLower();
                                    if (f.Contains("email")) { emi = i; }
                                    else if (f.Contains("first") && f.Contains("name")) { fni = i; }
                                    else if (f.Contains("last") && f.Contains("name")) { lni = i; }
                                    else if (f.Contains("role")) { rli = i; }
                                }

                                if (emi < 0) responseDto.Errors.Add("Column 'Email Address' is missing.");
                                if (fni < 0) responseDto.Errors.Add("Column 'First Name' is missing.");
                                if (lni < 0) responseDto.Errors.Add("Column 'Last Name' is missing.");
                                if (rli < 0) responseDto.Errors.Add("Column 'Role' is missing.");

                                if (responseDto.Errors.Count > 0) break;
                            }
                            else    // read user data lines
                            {
                                List<string> rowErrors = new List<string>();
                                if (fields == null || fields.Length < 4) { 
                                    var errStr = $"Row {row}: Required field values are missing";
                                    responseDto.Errors.Add(errStr);
                                }
                                else
                                {
                                    var email = fields[emi]?.Trim();
                                    if (string.IsNullOrEmpty(email)) rowErrors.Add("Email address is missing.");
                                    else if (!_emailRegex.IsMatch(email)) rowErrors.Add($"'{email}' is not a valid email address.");
                                    var firstName = fields[fni]?.Trim();
                                    if (string.IsNullOrEmpty(firstName)) rowErrors.Add($"First name is missing.");
                                    var lastName = fields[lni]?.Trim();
                                    if (string.IsNullOrEmpty(lastName)) rowErrors.Add($"Last name is missing.");
                                    var roleName = fields[rli]?.Trim();
                                    if (string.IsNullOrEmpty(roleName)) roleName = "Viewer";
                                    if (roleName.Equals("Admin - Account Owner")) roleName = "Admin";
                                    if (!_allRoles.Contains(roleName)) rowErrors.Add($"'{roleName}' is not a valid role name.");

                                    if (rowErrors.Count == 0)
                                    {
                                        responseDto.Users.Add(new UserDetailDto()
                                        {
                                            Email = email,
                                            FirstName = firstName,
                                            LastName = lastName,
                                            RoleName = roleName
                                        });
                                    }
                                    else
                                    {
                                        var errStr = $"Row {row}:";
                                        rowErrors.ForEach(x => errStr += $" {x}");
                                        responseDto.Errors.Add(errStr);
                                    }
                                }
                            }
                        }
                        catch (MalformedLineException)
                        {
                            responseDto.Errors.Add($"Row {row}: Invalid CSV format.");
                        }
                    }

                    row++;
                }   // end while loop thru rows
            }
            _logger.LogDebug($"Parsing CSV file with {row} rows, {responseDto.Users.Count} users and {responseDto.Errors.Count} errors was found");

            if (responseDto.Users.Count > 0)    // check any email exists in database
            {
                var jsonUsers = System.Text.Json.JsonSerializer.Serialize(responseDto.Users, _options);
                var resultJson = await _userLogic.ValidateBulkAsync(jsonUsers, accountId);
                var dbResult = System.Text.Json.JsonSerializer.Deserialize<UserCsvResponseDto>(resultJson, _options);
                
                responseDto.Users = dbResult.Users;
                responseDto.Errors.AddRange(dbResult.Errors);
            }

            return responseDto;
        }

        public async Task<UpsertResponse<List<UserDetailDto>>> CreateBulkAsync(Guid accountId, Guid byUserId, Guid sessionId, List<UserDetailDto> dto)
        {
            var jsonInput = System.Text.Json.JsonSerializer.Serialize(dto, _options);
            var jsonOutput = await _userLogic.CreateBulkAsync(accountId, byUserId, sessionId, jsonInput);
            UpsertResponse<List<UserDetailDto>> response = System.Text.Json.JsonSerializer.Deserialize<UpsertResponse<List<UserDetailDto>>>(jsonOutput, _options);

            if (response.Entity != null && response.Entity.Count > 0)
            {
                _ = Task.Run(async () =>
                {
                    foreach (var user in response.Entity)
                    {
                        await SendUpsertUserMessage(user.Id, user.AccountId);
                    }
                 });
            }

            return response;
        }


        public async Task<UpsertResponse<List<UserDetailDto>>> AssignGroupToUsers(Guid accountId, Guid userId, BulkAssignGroupDto bulkGroupAssign)
        {

            var jsonGroupAssign = JsonConvert.SerializeObject(bulkGroupAssign);
            var resultJson = await _userLogic.AssignGroupToUsers(accountId, userId, jsonGroupAssign);
            UpsertResponse<List<UserDetailDto>> result = JsonConvert.DeserializeObject<UpsertResponse<List<UserDetailDto>>>(resultJson);
            return result;
        }

        public async Task<List<UserDetailDto>> GetByAccountIdAsync(Guid accountId, bool includeInactive = false)
        {
            _logger.LogInformation($"[Service] Getting users for account = {accountId}");

            var users = await _userLogic.GetByAccountIdAsync(accountId, includeInactive);
            var result = JsonConvert.DeserializeObject<List<UserDetailDto>>(users);
            return result;
        }

        public async Task<UserDto> GetByAccountIdAndEmailAsync(Guid accountId, string email)
        {
            var user = await _userLogic.GetByAccountIdAndEmailAsync(accountId, email);
            var result = JsonConvert.DeserializeObject<UserDto>(user);
            return result;
        }

        public async Task<User> GetUserByIdAsync(Guid id)
        {
            return await _userLogic.GetUserByIdAsync(id);
        }

        //public async Task<User> GetUserByIdpIdAsync(string idpId)
        //{
        //    return await _userLogic.GetUserByIdpIdAsync(idpId);
        //}

        public async Task<User> GetUserByEmailAsync(string email)
        {
            return await _userLogic.GetUserByEmailAsync(email);
        }

        public async Task<dynamic> GetUserContext(Guid accountId, Guid userId, Guid sessionId, bool asViewer)
        {
            string resultJson = await _userLogic.GetUserContext(accountId, userId, asViewer);
            
            GetEntityResponse<UserContextDto> result = JsonConvert.DeserializeObject<GetEntityResponse<UserContextDto>>(resultJson);
            if (result == null || result.Error.Code != 0)
                // there is no context for the current user...
                return null;

            UserContextDto userContext = result.Entity;
            
            if (userContext.AccountId != null && userContext.AccountActive.HasValue && userContext.AccountActive.Value == false)
            {
                userContext.AccountSalesforceId = null;
                userContext.AccountStorageMaximumGb = null;
                userContext.AccountStorageUsed = null;
                userContext.AccountTrialExpiration = null;
                userContext.AccountTypeName = null;
                userContext.AccountUserEmail = null;
                userContext.Email = null;
                userContext.Features = null;
                userContext.FirstName = null;
                userContext.LastName = null;
                userContext.LegalDocuments = null;
                userContext.Permissions = null;
                userContext.UserSalesforceId = null;
            }
            // TODO: move this logic to stored procedure
            if (userContext.AccountId == null && userContext.RoleKey == InternalUserRoleKeys.SystemAdmin)
            {
                userContext.Permissions = null;
                return userContext.ToDynamic();
            }
            var dynamicUserContext = userContext.ToDynamic();

            var storageAccountname = _configuration["BlobStorage:StorageAccountName"];
            dynamicUserContext.StorageAccountName = storageAccountname;

            if (userContext.AccountId != null)
            {
                if (userContext.AccountActive.HasValue && userContext.AccountActive.Value == true)
                {
                    var sasKeys = await _blobService.GetContainerSasTokens(storageAccountname, userContext.AccountId.Value, 1440);
                    dynamicUserContext.SasKeys = sasKeys;

                    // TODO: Not used yet but can possibly be used to refresh sas keys/tokens when they expire
                    dynamicUserContext.ContextExpires = DateTime.Now.AddMinutes(1440);
                }
                await _userLogic.CreateUserLoginAsync(userId, userContext.AccountId.Value, sessionId);
            }
            else
            {
                await _userLogic.CreateUserLoginAsync(userId, null, sessionId);
            }

            return dynamicUserContext;
        }

        // TODO - Deserialize to DTO or correct primitive
        public async Task<string> DeleteUsersAsync(Guid accountId, Guid userId, Guid sessionId, BulkDeleteRequestDTO deleteUsersRequest)
        {
            var jsonInput = deleteUsersRequest.ToJsonString();
            
            var jsonOutput = await _userLogic.DeleteUsersAsync(accountId, userId, sessionId, jsonInput);
            var ids = Newtonsoft.Json.JsonConvert.DeserializeObject<Guid[]>(jsonOutput);            
            foreach (var id in ids)
            {
                await SendDeleteUserMessage(id, accountId);

            }
            return jsonOutput;
        }

        public async Task<UpsertResponse<UserDetailDto>> CreateUserAsync(Guid byUserId, Guid sessionId, UserDetailDto dto, bool federated = false, string idpId = "", string federatedUpn = "")
        {
            if (dto == null
                || dto.FirstName == null
                || dto.Email == null) return null;

            // dont allow federated signup without IdpId
            if (federated && string.IsNullOrEmpty(idpId))
            {
                return null;
            }

            dto.Active = true;
            var dynamicUserDto = dto.ToDynamic();
            dynamicUserDto.Federated = federated;
            dynamicUserDto.IdpId = idpId;
            dynamicUserDto.Upn = federatedUpn;

            var settings = new JsonSerializerSettings();
            settings.ContractResolver = new CamelCasePropertyNamesContractResolver();
            var jsonInput = JsonConvert.SerializeObject(dynamicUserDto, settings);

            var createdUserResult = await _userLogic.CreateUserAsync(byUserId, sessionId, jsonInput).ConfigureAwait(false);
            var createdUser = Newtonsoft.Json.JsonConvert.DeserializeObject<UpsertResponse<UserDetailDto>>(createdUserResult);

            if (createdUser.Entity != null && createdUser.Entity.Id != Guid.Empty)
            {
                await SendUpsertUserMessage(createdUser.Entity.Id, createdUser.Entity.AccountId);

                if(createdUser.Entity.RoleId != null)
                {
                    var role = await _roleLogic.FindByIdAsync(createdUser.Entity.RoleId);
                    if(role.Internal)
                    {
                        // so we don't expose an internal id that can be posted on update or create
                        // and elevate user's privileges;
                        // Use a roleKey, so we can identify the Role in the UI. 
                        // hide 'internal' role ids
                        createdUser.Entity.RoleId = null;
                    }
                }
            }
            
            return createdUser;
        }        

        public async Task<int> SaveUserEmailVerification(Guid accountId, Guid userId, Guid sessionId)
        {
            return await _userLogic.SaveUserEmailVerification(accountId, userId, sessionId).ConfigureAwait(false);
        }

        public async Task<int> SaveUserEmailVerification(string idpId, string email)
        {
            return await _userLogic.SaveUserEmailVerification(idpId, email).ConfigureAwait(false);
        }

        public async Task SyncUser(Guid id, Guid? accountId, bool active)
        {
            if(active)
            {
                await SendUpsertUserMessage(id, accountId);
            }
            else
            {
                await SendDeleteUserMessage(id, accountId);
            }
        }


        public async Task<UserModel> UpdateUserAsync(Guid byUserId, Guid forUserId, Guid accountId, Guid sessionId, UserDetailDto userDTO) 
        {

            if (userDTO == null
                || userDTO.FirstName == null
                || userDTO.LastName == null
                || userDTO.Email == null) return null;

            // update fields 
            // for now just what we expect the UI can change to avoid over-posting
            User forUser = new User()
            {
                Id = forUserId,
                FirstName = userDTO.FirstName,
                LastName = userDTO.LastName,
                Email = userDTO.Email,
                RoleId = userDTO.RoleId,
                AccountId = accountId,
                GroupId = userDTO.GroupId,
                Active = userDTO.Active
            };

            
            var jsonInput = forUser.ToJsonString();

            var updatedUserResult = await _userLogic.UpdateUserAsync(byUserId, accountId, sessionId, jsonInput).ConfigureAwait(false);
            if (updatedUserResult != null)
            {
                var updatedUser = Newtonsoft.Json.JsonConvert.DeserializeObject<UserModel>(updatedUserResult);

                // TODO - refactor stored proc so we can handle unform error messages, leverage UpsertResponse
                if (updatedUser != null)
                {
                    if (updatedUser.Active == false)
                    {
                        await SendDeleteUserMessage(updatedUser.Id, accountId);
                    }                      
                    else
                    {
                        await SendUpsertUserMessage(updatedUser.Id, accountId);
                    }
                    
                    return updatedUser;
                }
            }

            return null;

        }

        /// <summary>
        ///  This is a tempory solution until we get claims transformation 
        ///  and authorization done properly
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<bool> ValidateSysAdminAccess(Guid userId)
        {
            var userEntity = await GetUserByIdAsync(userId);
            return userEntity != null && userEntity.Role?.Key == InternalUserRoleKeys.SystemAdmin;
        }

        // TODO - Deserialize to DTO or correct primitive
        public async Task<string> ValidateEmailAsync(string email, Guid accountId, string firstName, string lastName, bool federated, Guid? userId)
        {
            return await _userLogic.ValidateEmailAsync(email, accountId, firstName, lastName, federated, userId);
        }

        // TODO - Deserialize to DTO or correct primitive
        public async Task<string> CreateUserLogoutAsync(Guid userId, Guid? accountId, Guid sessionId)
        {
            return await _userLogic.CreateUserLogoutAsync(userId, accountId, sessionId);
        }

        public static UserDetailDto ToDto(User user)
        {
            if(user == null)
            {
                return null;
            }

            // so we don't expose an internal id that can be posted on update or create
            // and elevate user's privileges;
            // Use a roleKey, so we can identify the Role in the UI. 
            string roleKey = "";
            if(user.Role != null && user.Role.Internal) {
                roleKey = user.Role.Key;
            }

            return new UserDetailDto()
            {
                Id = user.Id,
                AccountId = user.AccountId,
                ExternalId = user.ExternalId,
                Active = user.Active,
                RoleId = string.IsNullOrEmpty(roleKey) ? user.RoleId : null, // hide 'internal' role ids
                RoleKey = roleKey, 
                RoleName = user.Role?.Name,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                GroupId = user.GroupId
            };
        }

        public static UserDetailDto ToDto(UserModel user)
        {
            if (user == null)
            {
                return null;
            }

            
            var internalRoles = new List<string>() { InternalUserRoleKeys.MccAdmin, InternalUserRoleKeys.SystemAdmin };

            return new UserDetailDto()
            {
                Id = user.Id,
                AccountId = user.AccountId,
                ExternalId = user.ExternalId,
                Active = user.Active,
                RoleId = internalRoles.Contains(user.RoleKey) ? null : user.RoleId, // hide 'internal' role ids
                RoleKey = user.RoleKey,
                RoleName = user.RoleName,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                GroupId = user.GroupId
            };
        }

        public static List<UserDetailDto> ToDto(IEnumerable<User> users)
        {
            var dtos = new List<UserDetailDto>();
            foreach(var u in users)
            {
                dtos.Add(ToDto(u));
            }
            return dtos;
        }

        public async Task<GetEntityResponse<UserDto>> GetByIdAndAccountIdAsync(Guid userId, Guid? accountId)
        {
            var jsonOutput = await _userLogic.GetByIdAndAccountIdAsync(userId, (Guid)accountId);

            GetEntityResponse<UserDto> user = Newtonsoft.Json.JsonConvert.DeserializeObject<GetEntityResponse<UserDto>>(jsonOutput);
            return user;
        }

        public async Task SendEmailVerificationMessageAsync(Guid userId, Guid accountId)
        {
            var response = await GetByIdAndAccountIdAsync(userId, accountId);
            if (response.Entity == null)
            {
                _logger.LogDebug("No user found.");
                // todo?
                return;
            }
            var user = response.Entity;

            object message = new
            {
                Action = "EMAIL_VERIFICATION",
                User = new
                {
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Email = user.Email,
                    CompanyName = user.AccountName
                }
            };


            await _serviceBusService.SignalSendEmail(new { Action = "EMAIL_VERIFICATION", User = user });
        }

        public async Task ResendWelcomEmailMessageAsync(Guid userId, Guid accountId)
        {
            var response = await GetByIdAndAccountIdAsync(userId, accountId);
            if (response.Entity == null)
            {
                _logger.LogDebug("No user found.");
                // todo?
                return;
            }
            var user = response.Entity;
            object message = new
            {
                Action = "RESEND_WELCOME_EMAIL",
                User = new
                {
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Email = user.Email,
                    CompanyName = user.AccountName
                }
            };

            await _serviceBusService.SignalSendEmail(message);
        }


        private async Task SendUpsertUserMessage(Guid userId, Guid? accountId)
        {
            await _serviceBusService.SignalUserSync(new { Action = "UPSERT", Id = userId, AccountId = accountId });
        }

        private async Task SendDeleteUserMessage(Guid userId, Guid? accountId)
        {
            await _serviceBusService.SignalUserSync(new { Action = "DELETE", Id = userId, AccountId = accountId });
        }
    }
}
