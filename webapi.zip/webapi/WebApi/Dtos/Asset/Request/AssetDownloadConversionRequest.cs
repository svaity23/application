﻿using System.Collections.Generic;
using WebApi.Enums;

namespace WebApi.Dtos.Asset.Request
{
    public class AssetDownloadConversionRequest
    {     
        public string Source { get; set; }
        public string SignalRConnectionId { get; set; }
        public DownloadConversionType ConversionType { get; set; }
        public List<AssetDownloadRequest> Assets { get; set; }
    }
}
