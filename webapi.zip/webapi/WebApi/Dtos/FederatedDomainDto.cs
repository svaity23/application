﻿using System;
using System.Text.Json.Serialization;

namespace WebApi.Dtos
{
    public class FederatedDomainDto
    {
        [JsonPropertyName("id")]
        public Guid? Id { get; set; }
        [JsonPropertyName("domain")]
        public string Domain { get; set; }
        [JsonPropertyName("active")]
        public bool Active { get; set; }
    }
}
