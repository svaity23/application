export interface FreeTrialConfig {
    freeTrialErrorTimer: number
    freeTrialUserCreationTimer: number,
}