import { Group } from '../entities/group.model';
import { User } from '../entities/user.model';

export interface AssignGroupsModalOptions {
  confirm: (users: User[], groupId: string) => void;
  confirmButtonText: string;
  deny: () => void;
  denyButtonText: string;
  selectedUsers: User[];
  title: string;
  userGroups: Group[];
}