﻿using System;

namespace WebApi.Dtos.Asset.Comment
{
    public class CommentThreadDto
    {
        public int ThreadId { get; set; }
        public DateTime Modified { get; set; }
        public AssetCommentDto[] Comments { get; set; }
    }
}
