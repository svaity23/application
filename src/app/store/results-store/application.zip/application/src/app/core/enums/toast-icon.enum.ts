export enum ToastIcon {
  Trash,
  InfoCircle,
  CheckCircle,
  Unicorn,
  ShareLink,
  Download,
	SyncAlt,
  Upload,
  ExclamationTriangle,
  SearchEngin,
  Heart
}
