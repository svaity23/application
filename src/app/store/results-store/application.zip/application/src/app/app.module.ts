import { APP_INITIALIZER, ErrorHandler, Injector, NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule, HammerModule } from '@angular/platform-browser';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppNgNoHostModule } from 'src/angular-contrib/common/ng-no-host';
import { Config, NgOidcClientModule, OIDC_CONFIG } from 'ng-oidc-client';
import { Log, WebStorageStateStore } from 'oidc-client';

import { APP_CONFIG, AppConfig } from './app-config';
import { AppComponent } from './app.component';
import { AppInitService } from './core/services/app-init.service';
import { AppInjectorService } from './core/services/app-injector.service';
import { AppRoutingModule } from './app-routing.module';
import { AppStoreModule } from './store/app-store/app-store.module';
import { CoreModule } from './core/core.module';
import { ErrorHandlerService } from './core/services/error-handler.service';
import { EulaModule } from './eula/eula.module';
import { RouterStoreModule } from './store/router-store/router-store.module';
import { SandBoxComponent } from './sand-box/sand-box.component';
import { SharedModule } from './shared/shared.module';
import { SignalRInterceptorService } from './core/services/signal-r-interceptor.service';
import { TokenInterceptorService } from './core/services/token-interceptor.service';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function appInit(appInitService: AppInitService): any {
  return (): Promise<void> => {
    return appInitService.init();
  };
}

export function provideOidcConfigFactory(config: AppConfig): Config {
  return {
    oidc_config: {
      ...config.oidcConfig,
      userStore: () => new WebStorageStateStore({ store: window.localStorage })
    },
    log: {
      logger: console,
      level: Log.NONE
    }
  };
}



@NgModule({
  declarations: [
    AppComponent,
    SandBoxComponent
  ],
  imports: [
    AppNgNoHostModule,
    AppRoutingModule,
    AppStoreModule,
    BrowserAnimationsModule,
    BrowserModule,
    CoreModule,
    EulaModule,
    HammerModule,
    HttpClientModule,
    NgOidcClientModule.forRoot(),
    RouterModule,
    RouterStoreModule,
    SharedModule
  ],
  providers: [
    AppInitService,
    AppInjectorService,
    {
      provide: APP_INITIALIZER,
      useFactory: appInit,
      multi: true,
      deps: [AppInitService, Injector]
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptorService,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: SignalRInterceptorService,
      multi: true
    },
    {
      provide: OIDC_CONFIG,
      useFactory: provideOidcConfigFactory,
      deps: [APP_CONFIG]
    },
    { provide: ErrorHandler, useClass: ErrorHandlerService }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(injector: Injector) {
    // global injector so we can do inheritance without constructor dependency injection
    AppInjectorService.injector = injector;
  }
}
