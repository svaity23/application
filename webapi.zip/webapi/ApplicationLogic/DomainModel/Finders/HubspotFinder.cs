﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class HubspotFinder
    {
        private readonly ILogger<HubspotFinder> _logger;
        private readonly damContext _context;

        public HubspotFinder(damContext context)
        {
            _context = context;
            _logger = NullLogger<HubspotFinder>.Instance;
        }

        public async Task<string> GetHubspotAssets(Guid accountId, Guid userId, string jsonParams)
        {
            _logger.LogInformation($"[Finder] Get shared HubSpot assets for " +
                $"\n\taccountId = {accountId}" +
                $"\n\tuserId    = {userId}" +
                $"\n\tusing \n{jsonParams}");

            List<SqlParameter> paramList = new SpParams()
                 .WithAccountId(accountId)
                 .WithUserId(userId)
                 .WithJson(jsonParams)
                 .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("getHubspotAssetsByAccountId", paramList);
        }

        public async Task<string> GetHubspotSyncErrorsAsync(Guid accountId)
        {
            _logger.LogInformation($"[Finder] Get HubSpot sync errors for accountId = {accountId}");

            List<SqlParameter> paramList = new SpParams()
                 .WithAccountId(accountId)
                 .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("getHubspotSyncErrorsByAccountId", paramList);
        }

        public async Task<string> SyncAllAsync(Guid accountId)
        {
            _logger.LogInformation($"[Finder] Get HubSpot sync errors for accountId = {accountId}");

            List<SqlParameter> paramList = new SpParams()
                 .WithAccountId(accountId)
                 .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("syncHubspotAssetsByAccountId", paramList);
        }

        public async Task<string> StopSyncCollectionAsync(Guid accountId, Guid userId, Guid sessionId, Guid? collectionId)
        {
            _logger.LogInformation($"[Finder] Stop sync collection on HubSpot " +
                $"\n\taccountId       = {accountId}" +
                $"\n\tuserId          = {userId}" +
                $"\n\tcollectionId    = {collectionId}");

            List<SqlParameter> paramList = new SpParams()
                 .WithAccountId(accountId)
                 .WithUserId(userId)
                 .WithSessionId(sessionId)
                 .WithGuid(nameof(collectionId), (Guid)collectionId)
                 .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("stopHubSpotSyncCollection", paramList);
        }

        public async Task<string> ResyncCollectionAsync(Guid accountId, Guid userId, Guid sessionId, Guid? collectionId)
        {
            _logger.LogInformation($"[Finder] Re-sync collection on HubSpot " +
                $"\n\taccountId       = {accountId}" +
                $"\n\tuserId          = {userId}" +
                $"\n\tcollectionId    = {collectionId}");

            List<SqlParameter> paramList = new SpParams()
                 .WithAccountId(accountId)
                 .WithUserId(userId)
                 .WithSessionId(sessionId)
                 .WithGuid(nameof(collectionId), (Guid)collectionId)
                 .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("resyncHubSpotCollection", paramList);
        }

        public async Task<string> DeleteHubspotAssetsAsync(Guid accountId, Guid userId, Guid sessionId, string jsonParams)
        {
            _logger.LogInformation($"[Finder] Bulk remove HubSpot assets for " +
                $"\n\taccountId = {accountId}" +
                $"\n\tuserId    = {userId}" +
                $"\n\tusing \n{jsonParams}");

            List<SqlParameter> paramList = new SpParams()
                 .WithAccountId(accountId)
                 .WithUserId(userId)
                 .WithSessionId(sessionId)
                 .WithJson(jsonParams)
                 .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("deleteHubspotAssets", paramList);
        }

        public async Task<string> UpsertHubspotAssetsAsync(Guid accountId, Guid userId, Guid sessionId, string jsonParams)
        {
            _logger.LogInformation($"[Finder] Bulk remove HubSpot assets for " +
                $"\n\taccountId = {accountId}" +
                $"\n\tuserId    = {userId}" +
                $"\n\tusing \n{jsonParams}");

            List<SqlParameter> paramList = new SpParams()
                 .WithAccountId(accountId)
                 .WithUserId(userId)
                 .WithSessionId(sessionId)
                 .WithJson(jsonParams)
                 .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("upsertHubspotAssets", paramList);
        }
    }
}
