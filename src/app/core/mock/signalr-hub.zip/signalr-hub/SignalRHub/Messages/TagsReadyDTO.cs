﻿using System.Collections.Generic;

namespace SignalRHub.Messages
{
    public class TagsReadyDTO: AbstractAssetMessageDTO
    {
        private const string MESSAGE_TYPE = "TAGGING_READY";
        public int StatusCode { get; set; }

        public string Source { get; set; }
        public string AccountId { get; set; }

        private readonly IList<ImageTagDTO> _imageTags = new List<ImageTagDTO>();
        private readonly IList<ColorInfoDTO> _colorTags = new List<ColorInfoDTO>();
        private readonly IList<CelebritiesTagsDTO> _celebritiesTags = new List<CelebritiesTagsDTO>();
        private readonly IList<LandmarksTagDTO> _landmarksTags = new List<LandmarksTagDTO>();
        
        public TagsReadyDTO(string assetId) : base(MESSAGE_TYPE, assetId) { }
        public string OcrText { get; set; }

        public IList<ImageTagDTO> ImageTags
        {
            get { return _imageTags; }
        }

        public IList<ColorInfoDTO> ColorTags
        {
            get { return _colorTags; }
        }

        public IList<CelebritiesTagsDTO> CelebritiesTags
        {
            get { return _celebritiesTags; }
        }

        public IList<LandmarksTagDTO> LandmarksTags
        {
            get { return _landmarksTags; }
        }
    }

    public class ImageTagDTO
    {
        public string Name { get; set; }
        
        public double Confidence { get; set; }
    }
    // todo: seperate this into file LandmarksTagDTO
    public class LandmarksTagDTO
    {
        public string Name { get; set; }
        public double Confidence { get; set; }
    }
    public class ColorInfoDTO
    {
        public string Name { get; set; }
    }
    public class CelebritiesTagsDTO
    {
        public string Name { get; set; }
        public double Confidence { get; set; }
    }
}
