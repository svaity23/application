import { AssetSyncError } from './asset-sync-error.model';

export interface HubspotSyncStatus {
    assetSyncErrors?: AssetSyncError[];
    lastSync?: string;
}
