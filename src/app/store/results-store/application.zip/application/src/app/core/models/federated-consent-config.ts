export interface FederatedConsentConfig {
    authority: string,
    client_id: string;
    loadUserInfo: false,
    redirect_uri: string,
    response_mode: string,
    response_type: string,
    scope: string
  }