﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Threading.Tasks;

namespace ApplicationLogic.Logic
{
    public class LightboxAssetLogic
    {
        public ILogger<LightboxAssetLogic> Logger { get; set; }

        private readonly LightboxAssetFinder _finder;

        public LightboxAssetLogic(damContext context)
        {
            _finder = new LightboxAssetFinder(context);
            Logger = NullLogger<LightboxAssetLogic>.Instance;
        }

        public async Task<string> GetByAccountIdAsync(Guid accountId, Guid userId, string json)
        {
            return await _finder.GetByAccountIdAsync(accountId, userId, json);
        }

        public async Task<string> GetShareAssetsAsync(Guid accountId, Guid userId, string json)
        {
            return await _finder.GetShareAssetsAsync(accountId, userId, json);
        }
        public async Task<string> GetAssetForPreviewAsync(Guid accountId, Guid assetId, Guid lightboxId)
        {
            return await _finder.GetAssetForPreviewAsync(accountId, assetId, lightboxId);
        }

        public async Task<string> UpsertLightboxAssetsAsync(Guid accountId, Guid userId, string json)
        {
            return await _finder.UpsertLightboxAssetsAsync(accountId, userId, json);
        }
        public async Task<string> DeleteAssetsAsync(Guid accountId, Guid userId, string jsonInput)
        {
            return await _finder.DeleteAssetsAsync(accountId, userId, jsonInput);
        }

        public async Task<string> GetLightboxAssetsById(Guid id, string jsonInput)
        {
            return await _finder.GetLightboxAssetsById(id, jsonInput);
        }
    }
}
