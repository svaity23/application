﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using WebApi.Dtos;
using WebApi.Services;
using WebApiTests.Shared;

namespace WebApiTests.Services
{
    [TestClass]
    public class DBCollectionServiceTests
    {
        const string TEST_COLLECTION_PREFIX = "MSTest-collections-";
        const string TEST_GROUP_PREFIX = "MSTest-group-";
        const string GROUP_DESCRIPTION = "This is a sample group";


        private static damContext dbContext;
        private static readonly Random _rnd = new Random();
        private static readonly Guid TEST_ACCOUNT = Guid.Parse("D84F58F4-067F-456A-9132-919EAA696832");

        private static readonly JsonSerializerOptions options = new JsonSerializerOptions()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            ReferenceHandler = ReferenceHandler.Preserve
        };

        private static List<UserDetailDto> _testUsers;
        private static UserDetailDto _admin;
        private static UserDetailDto _contributor;
        private static GroupService _groupService;
        private static GroupDto _groupOne;
        private static GroupDto _groupTwo;
        private static CollectionDto _justOne;
        private static CollectionDto _justTwo;
        private static CollectionDto _oneNTwo;
        private static CollectionDto _anybody;

        [ClassInitialize]
        public static void BeforeClass(TestContext context)
        {
            Debug.WriteLine("Before all tests");
            dbContext = AzureSQLTools.InitializeDamContext();
            CleanUp();
            var loggerFactory = (ILoggerFactory)new LoggerFactory();

            _sut = new CollectionService(dbContext);
            _groupService = new GroupService(loggerFactory.CreateLogger<GroupService>(), dbContext);

            _testUsers = AzureSQLTools.GetAccountUsers(dbContext, TEST_ACCOUNT);
            _admin = AzureSQLTools.GetTestUser(dbContext, "admin", TEST_ACCOUNT);
            _contributor = AzureSQLTools.GetTestUser(dbContext, "contributor", TEST_ACCOUNT);

            _groupOne = AddGroup(_admin, "One");
            _groupTwo = AddGroup(_admin, "Two");
            _justOne = AddCollection("JustOne", new Guid[] { _groupOne.Id });
            _justTwo = AddCollection("JustTwo", new Guid[] { _groupTwo.Id });
            _oneNTwo = AddCollection("OneNTwo", new Guid[] { _groupOne.Id, _groupTwo.Id });
            _anybody = AddCollection("Anybody");

            //Assign the contributor to group one
            _contributor.GroupId = _groupOne.Id;
            dbContext.SaveChanges();
        }

        [ClassCleanup]
        public static void AfterClass()
        {
            CleanUp();
            dbContext.Dispose();
        }


        private static void CleanUp() 
        {
            Debug.WriteLine("Clean up after all tests");
            dbContext.Database.ExecuteSqlRaw("delete from [dbo].[groupCollection] where [accountId] = {0} and [groupId] in (select [id] from [group] where [accountId] = {0} and [group].[name] like 'MSTest-%')", TEST_ACCOUNT);
            dbContext.Database.ExecuteSqlRaw("delete from [dbo].[groupCollection] where [accountId] = {0} and [collectionId] in (select [id] from [collection] where [accountId] = {0} and [collection].[name] like 'MSTest-%')", TEST_ACCOUNT);

            dbContext.Database.ExecuteSqlRaw("delete from [dbo].[group] where [accountId] = {0} and [name] like 'MSTest-%'", TEST_ACCOUNT);
            dbContext.Database.ExecuteSqlRaw("delete from [dbo].[collection] where [accountId] = {0} and [name] like 'MSTest-%'", TEST_ACCOUNT);
        }

        private static CollectionDto AddCollection(string name = "", Guid[] groupIds = null) 
        {
            CollectionDto newCollection = new CollectionDto()
            {
                AccountId = TEST_ACCOUNT,
                Active = true,
                Name = $"{TEST_COLLECTION_PREFIX}-{_rnd.Next(0, 999)}-{name}"
            };
            if (groupIds != null && groupIds.Length > 0) {
                newCollection.GroupIds = groupIds;
            }

            UpsertResponse<CollectionDto> result = 
                _sut.SaveAsync(TEST_ACCOUNT, _admin.Id, newCollection).Result;

            return result.Entity;
        }

        private static GroupDto AddGroup(UserDetailDto usingUser, string suffix = "", string description = null)
        {
            GroupDto group = new GroupDto()
            {
                Id = Guid.Empty,
                Name = $"{TEST_GROUP_PREFIX}{_rnd.Next(0, 9999)}{suffix}",
                Description = (description == null ? GROUP_DESCRIPTION : description),
                Active = true,
                AccountId = TEST_ACCOUNT
            };

            UpsertResponse<GroupDto> result =
                _groupService.SaveGroupAsync((Guid)usingUser.AccountId, usingUser.Id, group).Result;
            // It failed from duplicate error or something else...
            if (result == null
                || result.Errors.Length < 1
                || result.Errors[0].Code != 0
                || result.Entity == null) return null;

            GroupDto ret = result.Entity;
            return ret;
        }



        private static bool HasItem(List<CollectionDto> list, CollectionDto item)
        {

            if (item == null) return false;

            foreach (CollectionDto i in list)
            {
                if (EqualityComparer<Guid>.Default.Equals(i.Id, item.Id)
                    && i.Active == item.Active
                    && i.Name.Equals(item.Name)
                    && EqualityComparer<Guid?>.Default.Equals(i.AccountId, item.AccountId)
                   ) {
                    return true;
                }
            }
            return false;
        }


        // sut - Service Under Test
        private static CollectionService _sut;


        [TestMethod("Get all collections as admin")]
        public void GetCollections()
        {
            GetEntitiesResponse<CollectionDto> result =
                _sut.GetAllAsync(TEST_ACCOUNT, _admin.Id).Result;

            Assert.IsNotNull(result, "No result");
            Assert.IsNotNull(result.Entities, "No entities");
            Assert.IsNotNull(result.Error, "No error within result");
            Assert.IsTrue(result.Entities.Count > 0, "No error entries");

            Assert.IsTrue(HasItem(result.Entities, _justOne), "Missing One");
            Assert.IsTrue(HasItem(result.Entities, _justTwo), "Missing Two");
            Assert.IsTrue(HasItem(result.Entities, _oneNTwo), "Missing One & Two");
            Assert.IsTrue(HasItem(result.Entities, _anybody), "Missing Anybody");


        }


        [TestMethod("Check collections to always have a group assigned")]
        public void CheckCollectionGroupExistance()
        {
            GetEntitiesResponse<CollectionDto> result =
                _sut.GetAllAsync(TEST_ACCOUNT, _admin.Id).Result;

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Entities);
            Assert.IsNotNull(result.Error);
            Assert.IsTrue(result.Entities.Count > 0);


            foreach(CollectionDto collection in result.Entities)
            {
                Trace.WriteLine($"Checking collection '{collection.Name}'");
                Assert.IsNotNull(collection.GroupIds, "Group list is null.");
                Assert.IsTrue(collection.GroupIds.Length > 0, "The group list is empty, when it should have at least one.");
            }
        }


        [TestMethod("Get all collections as contributor with group assign")]
        public void GetCollectionsContributor()
        {
            GetEntitiesResponse<CollectionDto> result =
                _sut.GetAllAsync(TEST_ACCOUNT, _contributor.Id).Result;

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Entities);
            Assert.IsNotNull(result.Error);
            Assert.IsTrue(result.Entities.Count > 0);

            // Make sure there is no group two for this user
            Assert.IsTrue(HasItem(result.Entities, _justOne), "Missing One");
            Assert.IsFalse(HasItem(result.Entities, _justTwo), "Missing Two");
            Assert.IsTrue(HasItem(result.Entities, _oneNTwo), "Missing One & Two");
            Assert.IsTrue(HasItem(result.Entities, _anybody), "Missing Anybody");
        }

        [TestMethod("Create a new collection")]
        public void CreateCollection() 
        {
            CollectionDto newCollection = new CollectionDto()
            {
                AccountId = TEST_ACCOUNT,
                Active = true,
                Name = $"{TEST_COLLECTION_PREFIX}-{_rnd.Next(0, 999)}"
            };
            
            UpsertResponse<CollectionDto> result =
                _sut.SaveAsync(TEST_ACCOUNT, _admin.Id, newCollection).Result;

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Errors);
            Assert.AreNotEqual(0, result.Errors.Length);
            Assert.AreEqual(0, result.Errors[0].Code);

            Assert.IsNotNull(result.Entity);
            Assert.IsNotNull(result.Entity.Id);
            Assert.AreNotEqual(Guid.Empty, result.Entity.Id);
        }


        [TestMethod("List the collections ids available for admin")]
        public void GetCollectionIdsAdmin()
        {
            // In case there is no group associated with the account
            // there shouldn't be any collection returned by this path
            // This is used only by the ElasticSearch 
            GetEntitiesResponse<Guid> result =
                _sut.GetEntitledIdsForUserAsync(TEST_ACCOUNT, _admin.Id).Result;

            Assert.IsNotNull(result);
            Assert.IsNull(result.Entities);
            Assert.IsNotNull(result.Error);
        }

        [TestMethod("List the collections ids available for contributor")]
        public void GetCollectionIdsContributor()
        {
            GetEntitiesResponse<Guid> result =
                _sut.GetEntitledIdsForUserAsync(TEST_ACCOUNT, _contributor.Id).Result;

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Entities);
            Assert.IsNotNull(result.Error);
            Assert.IsTrue(0 < result.Entities.Count);

            if (result.Entities.Count > 0)
            {

                Guid collectionId = result.Entities[_rnd.Next(result.Entities.Count)];

                GetEntitiesResponse<CollectionDto> collectionResult = _sut.GetCollectionByIdAsync(TEST_ACCOUNT, _admin.Id, collectionId).Result;
                Assert.IsNotNull(collectionResult);
                Assert.IsNotNull(collectionResult.Entities);
                Assert.IsNotNull(collectionResult.Error);
                Assert.AreEqual(1, collectionResult.Entities.Count);
            }
        }

    }
}
