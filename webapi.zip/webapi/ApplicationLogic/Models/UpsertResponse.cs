﻿using System.Text.Json.Serialization;

namespace ApplicationLogic.Models
{
    public class UpsertResponse<T>
    {
        [JsonPropertyName("entity")]
        public T Entity { get; set; }
        
        [JsonPropertyName("errors")]
        public ErrorResponse[] Errors { get; set; }
    }
}
