export interface AssetFile {
	fileName?: string;
	fileSizeBytes?: number;
	provider: 'google' | 'file-system' | 'dropbox' | 'onedrive';
}
