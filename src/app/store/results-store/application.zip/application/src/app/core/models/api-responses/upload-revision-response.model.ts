
export interface UploadRevisionResponse {
    error?: string[];
    progress: number;
    uploadComplete: boolean;
}
