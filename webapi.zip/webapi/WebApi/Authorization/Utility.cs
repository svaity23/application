﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Linq;

namespace WebApi.Authorization
{
    /// <summary>
    /// For use in place of standard context.Succeed to succeed all related
    /// requirements with the same identifier.
    /// </summary>
    public static class Utility
    {
        public static void Succeed(AuthorizationHandlerContext context, Guid identifier)
        {
            var groupedRequirements = context.Requirements.Where(r => (r as IIdentifiable)?.Identifier == identifier);

            foreach (var requirement in groupedRequirements)
            {
                context.Succeed(requirement);
            }
        }
    }
}
