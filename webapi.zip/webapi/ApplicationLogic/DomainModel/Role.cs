﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ApplicationLogic.DomainModel
{
    [Table("role")]
    [Index(nameof(AccountId), nameof(Name), Name = "uniq_role_accountId_name", IsUnique = true)]
    public partial class Role
    {
        public Role()
        {
            Setting = new HashSet<Setting>();
            User = new HashSet<User>();
        }

        [Key]
        [Column("id")]
        public Guid Id { get; set; }
        [Column("key")]
        [StringLength(16)]
        public string Key { get; set; }
        [Column("externalId")]
        [StringLength(64)]
        public string ExternalId { get; set; }
        [Column("accountId")]
        public Guid? AccountId { get; set; }
        [Column("active")]
        public bool Active { get; set; }
        [Column("created")]
        public DateTime Created { get; set; }
        [Column("modified")]
        public DateTime? Modified { get; set; }
        [Column("internal")]
        public bool Internal { get; set; }
        [Required]
        [Column("name")]
        [StringLength(64)]
        public string Name { get; set; }
        [Column("description")]
        [StringLength(256)]
        public string Description { get; set; }

        [ForeignKey(nameof(AccountId))]
        [InverseProperty("Role")]
        public virtual Account Account { get; set; }
        [InverseProperty("RoleIdCriteriaNavigation")]
        public virtual ICollection<Setting> Setting { get; set; }
        [InverseProperty("Role")]
        public virtual ICollection<User> User { get; set; }
    }
}
