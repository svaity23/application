﻿namespace SignalRHub.Messages
{
    public class CustomizeAssetReadyMessage: AbstractMessage
    {  
        public OpaqueData Opaque { get; set; }
    }
}
