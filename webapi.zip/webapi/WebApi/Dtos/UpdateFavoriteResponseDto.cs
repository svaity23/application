﻿using System;
using System.Text.Json.Serialization;

namespace WebApi.Dtos.Asset.Response
{
    public class UpdateFavoriteResponseDto
    {
        [JsonPropertyName("assetId")]
        public Guid AssetId { get; set; } 

        [JsonPropertyName("name")]
        public string Name{ get; set; } 

        [JsonPropertyName("favorite")]
        public bool Favorite { get; set; }

        [JsonPropertyName("fileName")]
        public string FileName { get; set; }

        [JsonPropertyName("totalFavorites")]
        public int TotalFavorites { get; set; } 
    }
}
