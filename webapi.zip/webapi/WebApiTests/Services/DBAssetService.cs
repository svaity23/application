﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebApi.Dtos;
using WebApi.Dtos.Asset.Comment;
using WebApi.Dtos.Asset.DetailsView;
using WebApi.Services;
using WebApiTests.Shared;

namespace WebApiTests.Services
{
    [TestClass]
    public class DBAssetService
    {
        private static damContext dbContext;
        private static AssetService _sut;
        private static UserDetailDto _admin;
        private static UserDetailDto _contributor;
        private static UserDetailDto _viewer;
        private static List<Asset> _assets;
        private static readonly Random _rnd = new Random();
        
        private static readonly Guid TEST_ACCOUNT = Guid.Parse("5189526F-642F-449F-B018-5F5027A7191B"); // marcel@saguaro.ro
        private static readonly Guid TEST_USER = Guid.Parse("C42E63D8-383F-4BF2-9264-5FFE1767C931"); // marcel@saguaro.ro

        private static readonly JsonSerializerOptions options = new JsonSerializerOptions()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            ReferenceHandler = ReferenceHandler.Preserve
        };
        private const string COMMENT_PREFIX = "~MSTest~ ";


        [ClassInitialize]
        public static void BeforeClass(TestContext context)
        {
            Debug.WriteLine("Before all tests");
            dbContext = AzureSQLTools.InitializeDamContext();
            CleanUp();
            var loggerFactory = (ILoggerFactory)new LoggerFactory();

            _sut = new AssetService(null, null, null, null, dbContext, null);

            //_testUsers = AzureSQLTools.GetAccountUsers(dbContext, TEST_ACCOUNT);
            _admin = AzureSQLTools.GetTestUser(dbContext, "admin", TEST_ACCOUNT);
            _contributor = AzureSQLTools.GetTestUser(dbContext, "contributor", TEST_ACCOUNT);
            _viewer = AzureSQLTools.GetTestUser(dbContext, "viewer", TEST_ACCOUNT);
            _assets = _sut.GetActiveAssets(TEST_ACCOUNT).Result;
        }

        [ClassCleanup]
        public static void AfterClass()
        {
            CleanUp();
            dbContext.Dispose();
        }


        private static void CleanUp()
        {
            Debug.WriteLine("Clean up after all tests");
            dbContext.Database.ExecuteSqlRaw("delete from [dbo].[assetComment] " +
                "where [accountId] = {0} " +
                "and comment like '"+ COMMENT_PREFIX + "%'", TEST_ACCOUNT);
        }


        [TestMethod("Get details from an asset")]
        public void GetAssetDetails()
        {
            GetEntityResponse<AssetDetailDto> ret = _sut.GetAssetDetailForDetailsViewAsync(TEST_ACCOUNT, _assets[0].Id, TEST_USER).Result;
            Assert.IsNotNull(ret);
            var assetDetails = ret.Entity;
            Assert.IsNotNull(assetDetails);
            Assert.IsNotNull(assetDetails.Asset);
        }

        [TestMethod("Check if get all assets is returning valid/cleaned-up assets")]
        public void TestGetAllAssets()
        {
            GetEntitiesResponse<AssetDto> ret =  _sut.GetAccountAssetsAsync(TEST_ACCOUNT, TEST_USER, 0, null, 0, 100).Result;
            Assert.IsNotNull(ret);
            Assert.AreEqual(ret.Error.Code, 0);
            Assert.IsTrue(ret.Entities.Count > 0);

            for(int i=0; i< ret.Entities.Count;i++)
            {
                Assert.IsNotNull(ret.Entities[i].CollectionId);
            }
        }

        [TestMethod("Check if get all assets that should be cleaned-up")]
        public void TestGetCleanUpAssets()
        {
            GetEntitiesResponse<AssetDto> ret = _sut.GetAccountAssetsAsync(TEST_ACCOUNT, TEST_USER, 0, null, 0, 100, false, false, false, true).Result;
            Assert.IsNotNull(ret);
            Assert.AreEqual(ret.Error.Code, 0);
            Assert.IsTrue(ret.Entities.Count > 0);

            for (int i = 0; i < ret.Entities.Count; i++)
            {
                Assert.IsNull(ret.Entities[i].CollectionId);
            }
        }

        [TestMethod("Check if get expired assets")]
        public void TestExpiredAssets()
        {
            GetEntitiesResponse<AssetDto> ret = _sut.GetAccountAssetsAsync(TEST_ACCOUNT, TEST_USER, 0, null, 0, 100, false, false, true, false).Result;
            Assert.IsNotNull(ret);
            Assert.AreEqual(ret.Error.Code, 0);
            Assert.IsTrue(ret.Entities.Count > 0);
            for (int i = 0; i < ret.Entities.Count; i++)
            {
                Assert.IsTrue(ret.Entities[i].Expired);
            }
        }


        [TestMethod("Add a new comment on first asset as Admin")]
        public void PostNewComment_Admin()
        {
            AssetCommentDto commentDto = new AssetCommentDto() 
            { 
                Comment = COMMENT_PREFIX + "Admin::Can somebody check this message?"
            };
            UpsertResponse<AssetCommentDto> ret = _sut.AddCommentAsync(TEST_ACCOUNT, _admin.Id, _assets[0].Id, commentDto).Result;

            Assert.IsNotNull(ret);
            Assert.IsNotNull(ret.Entity);
            Assert.IsFalse(Guid.Empty.Equals(ret.Entity.Id));
        }


        [TestMethod("Add a new comment on first asset as Contributor")]
        public void PostNewComment_Contributor()
        {
            AssetCommentDto commentDto = new AssetCommentDto()
            {
                Comment = COMMENT_PREFIX + "Contributor::Can somebody check this message?"
            };
            UpsertResponse<AssetCommentDto> ret = _sut.AddCommentAsync(TEST_ACCOUNT, _contributor.Id, _assets[0].Id, commentDto).Result;

            Assert.IsNotNull(ret);
            Assert.IsNotNull(ret.Entity);
            Assert.IsFalse(Guid.Empty.Equals(ret.Entity.Id));
        }

        [TestMethod("Add a new comment on first asset as Contributor, tagging a user")]
        public void PostNewComment_WithTaggedUsers()
        {
            AssetCommentDto commentDto = new AssetCommentDto()
            {
                Comment = COMMENT_PREFIX + "Tagged Admin :: Can somebody check this message?",
                TaggedUserIds = new Guid[] { _admin.Id, _contributor.Id }
            };
            UpsertResponse<AssetCommentDto> ret = _sut.AddCommentAsync(TEST_ACCOUNT, _contributor.Id, _assets[0].Id, commentDto).Result;

            Assert.IsNotNull(ret);
            Assert.IsNotNull(ret.Entity);
            Assert.IsFalse(Guid.Empty.Equals(ret.Entity.Id));

            GetEntitiesResponse<CommentResponseDto> test = _sut.GetCommentsAsync(TEST_ACCOUNT, _admin.Id, _assets[0].Id).Result;
            Assert.IsNotNull(test);
            Assert.IsNotNull(test.Entities);
            Assert.IsTrue(test.Entities.Count > 0);
            bool wasSaved = false;
            foreach(CommentResponseDto ct in test.Entities)
            {
                foreach (CommentThreadDto thr in ct.Threads)
                { 
                    foreach (AssetCommentDto ac in thr.Comments)
                    {
                        if (!ret.Entity.Id.Equals(ac.Id)) continue;

                        Assert.AreEqual(ret.Entity.Comment, ac.Comment);
                        Assert.IsNotNull(ac.TaggedUserIds);

                        wasSaved = true;
                    }
                }
            }
            Assert.IsTrue(wasSaved);

        }


        [TestMethod("Add a new comment on first asset as Viewer")]
        public void PostNewComment_Viewer()
        {
            AssetCommentDto commentDto = new AssetCommentDto()
            {
                Comment = COMMENT_PREFIX + "Viewer::Can somebody check this message?"
            };
            UpsertResponse<AssetCommentDto> ret = _sut.AddCommentAsync(TEST_ACCOUNT, _viewer.Id, _assets[0].Id, commentDto).Result;

            Assert.IsNotNull(ret);
            Assert.IsNull(ret.Entity);
            Assert.IsNotNull(ret.Errors);
            Assert.IsTrue(ret.Errors.Length > 0);
            Assert.IsTrue(ret.Errors[0].Code == 3);
        }


        [TestMethod("Check get comments results")]
        public void CheckGetComments() 
        {
            AssetCommentDto commentDto = new AssetCommentDto()
            {
                Comment = COMMENT_PREFIX + "Can somebody check this message?"
            };
            UpsertResponse<AssetCommentDto> post = _sut.AddCommentAsync(TEST_ACCOUNT, _admin.Id, _assets[0].Id, commentDto).Result;
            Assert.IsNotNull(post);

            Thread.Sleep(2000);
            commentDto.Comment = COMMENT_PREFIX + "Never mind... I figure it out.";
            commentDto.ThreadId = post.Entity.ThreadId;
            post = _sut.AddCommentAsync(TEST_ACCOUNT, _admin.Id, _assets[0].Id, commentDto).Result;
            Assert.IsNotNull(post);

            Thread.Sleep(2000);
            commentDto.Comment = COMMENT_PREFIX + "I approved this version.";
            commentDto.ThreadId = -1; // reset the thread id, to force a new comment
            post = _sut.AddCommentAsync(TEST_ACCOUNT, _admin.Id, _assets[0].Id, commentDto).Result;
            Assert.IsNotNull(post);

            GetEntitiesResponse<CommentResponseDto> test = _sut.GetCommentsAsync(TEST_ACCOUNT, _admin.Id, _assets[0].Id).Result;


            Assert.IsNotNull(test);
            Assert.IsNotNull(test.Entities);
            Assert.IsTrue(test.Error.Code == 0);

        }

        [TestMethod("No comments for viewers")]
        public void CheckGetComments_Viewers()
        {
            AssetCommentDto commentDto = new AssetCommentDto()
            {
                Comment = COMMENT_PREFIX + "Can somebody check this message?"
            };
            UpsertResponse<AssetCommentDto> post = _sut.AddCommentAsync(TEST_ACCOUNT, _admin.Id, _assets[0].Id, commentDto).Result;
            Assert.IsNotNull(post);

            GetEntitiesResponse<CommentResponseDto> test = _sut.GetCommentsAsync(TEST_ACCOUNT, _viewer.Id, _assets[0].Id).Result;


            Assert.IsNotNull(test);
            Assert.IsNotNull(test.Entities);
            Assert.IsTrue(test.Entities.Count == 0);
            Assert.IsTrue(test.Error.Code != 0);

        }

    }
}
