﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class UserFinder
    {
        public ILogger<UserFinder> Logger { get; set; }

        private damContext _context;

        public UserFinder(damContext context) {
            _context = context;
            Logger = NullLogger<UserFinder>.Instance;
        }

        public async Task<string> GetByAccountIdAsync(Guid accountId, bool includeInactive = false)
        {
            Logger.LogInformation($"[Finder] Getting users for account = {accountId}, includeInactive = {includeInactive}");
            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithIncludeInactive(includeInactive)
                .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("getUsersByAccountId", parameters);
        }
        public async Task<string> GetByAccountIdAndEmailAsync(Guid accountId, string email)
        {
            Logger.LogInformation($"[Finder] Getting user by accountid = {accountId}, email = {email}");
            const string paramEmail = "email";
            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithString(paramEmail, email)
                .Build();

            return await _context.ExecuteNonQueryJsonOutputAsync("getUserByAccountIdAndEmail", parameters);
        }

        public async Task<string> GetUserContext(Guid accountId, Guid userId, bool asViewer)
        {
            List<SqlParameter> parameters = new SpParams()
                .WithUserId(userId)
                .WithAccountId(accountId)
                .Build();
            parameters.Add(
                new SqlParameter("asViewer", SqlDbType.Bit)
                {
                    Value = asViewer ? 1 : 0
                }
            );

            Logger.LogInformation(string.Format(CultureInfo.InvariantCulture, "[Finder] GetUserContext Params = \n{0}", parameters.ToString()));

            return await _context.ExecuteNonQueryJsonOutputAsync("getUserContext", parameters).ConfigureAwait(false);
        }


        public async Task<string> GetByIdAndAccountIdAsync(Guid userId, Guid accountId)
        {
            Logger.LogInformation($"[Finder] Getting user by id and accountId = {accountId}, userId = {userId}");
            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("getUserByIdAndAccountId", parameters);
        }

        public async Task<User> GetByIdAsync(Guid id)
        {
            return await _context.User
                 .Include(u => u.Role)
                 .FirstOrDefaultAsync(u => u.Id == id);
        }

        public async Task<User> GetByIdpIdAsync(string idpId)
        {
            return await _context.User
                 .Include(u => u.Role)
                 .FirstOrDefaultAsync(u => u.IdpId == idpId);
        }

        public async Task<User> GetByEmailAsync(string email)
        {
            return await _context.User
                 .Include(u => u.Role)
                 .FirstOrDefaultAsync(u => u.Email == email);
        }

        public async Task<string> CreateAsync(Guid byUserId, Guid sessionId, string jsonInput)
        {
            if (jsonInput == null) return null;

            List<SqlParameter> parameters = new SpParams()
                .WithUserId(byUserId)
                .WithSessionId(sessionId)
                .WithJson(jsonInput)
                .Build();

            Logger.LogInformation(string.Format(CultureInfo.InvariantCulture, "[Finder] CreateAsync Params = \n{0}", parameters.ToString()));

            return await _context.ExecuteNonQueryJsonOutputAsync("createUser", parameters).ConfigureAwait(false);
        }

        public async Task<string> ValidateBulkAsync(string jsonUsers, Guid accountId)
        {
            List<SqlParameter> parameters = new SpParams()
                           .WithJson(jsonUsers)
                           .WithAccountId(accountId)
                           .Build();

            Logger.LogInformation(string.Format(CultureInfo.InvariantCulture, "[Finder] BulkVerifyForCeate Params = \n{0}", parameters.ToString()));

            return await _context.ExecuteNonQueryJsonOutputAsync("validateBulkUsers", parameters).ConfigureAwait(false);
        }

        public async Task<string> CreateBulkAsync(Guid accountId, Guid byUserId, Guid sessionId, string jsonInput)
        {
            List<SqlParameter> parameters = new SpParams()
                           .WithJson(jsonInput)
                           .WithAccountId(accountId)
                           .WithUserId(byUserId)
                           .WithSessionId(sessionId)
                           .Build();

            Logger.LogInformation(string.Format(CultureInfo.InvariantCulture, "[Finder] BulkCeate Params = \n{0}", parameters.ToString()));

            return await _context.ExecuteNonQueryJsonOutputAsync("createBulkUsers", parameters).ConfigureAwait(false);

        }

        public async Task<string> AssignGroupToUsers(Guid accountId, Guid userId, string jsonInput)
        {
            if (jsonInput == null) return null;


            List<SqlParameter> parameters = new SpParams()
                .WithUserId(userId)
                .WithAccountId(accountId)
                .WithJson(jsonInput)
                .Build();

            Logger.LogInformation(string.Format(CultureInfo.InvariantCulture, "[Finder] AssignGroup2Users Params = \n{0}", parameters.ToString()));

            return await _context.ExecuteNonQueryJsonOutputAsync("assignGroupToUsers", parameters).ConfigureAwait(false);
        }       

        public async Task<IEnumerable<User>> GetAccountUsersByIdsAsync(Guid accountId, Guid[] ids)
        {
            Logger.LogInformation(string.Format(CultureInfo.InvariantCulture, "[Finder] Getting users for account = {0}, for ids = {1}", accountId, string.Join(",", ids.Select(g => g.ToString()))));

            var results = _context.User
                .Include(u => u.Role)
                .Where(u =>
                    u.AccountId == accountId &&
                    (ids.Contains(u.Id))
                ).ToListAsync();
            return await results;
        }
                
        public async Task<string> DeleteUsersAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithSessionId(sessionId)
                .WithJson(jsonInput)
                .Build();
            
            return await _context.ExecuteNonQueryJsonOutputAsync("deleteUsersByIdList", parameters);
        }

        public async Task<int> SaveUserEmailVerification(Guid accountId, Guid userId, Guid sessionId)
        {
            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithSessionId(sessionId)
                .Build();

            return await _context.ExecuteNonQueryAsync("saveUserEmailVerification", parameters);
        }

        public async Task<int> SaveUserEmailVerification(string idpId, string email)
        {
            List<SqlParameter> parameters = new SpParams()
                .WithString("idpId", idpId)
                .WithEmail(email)
                .Build();

            return await _context.ExecuteNonQueryAsync("saveUserEmailVerificationByIdpId", parameters);
        }

        public async Task<string> ValidateEmailAsync(string email, Guid accountId, string firstName, string lastName, bool federated, Guid? userId)
        {
            const string paramEmail = "email";
            const string paramFirstName = "firstName";
            const string paramLastName = "lastName";            
            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithString(paramEmail, email)
                .WithString(paramFirstName, firstName ?? "")
                .WithString(paramLastName, lastName ?? "")                
                .WithUserId(userId)
                .Build();

            parameters.Add(
                new SqlParameter("federated", SqlDbType.Bit)
                {
                    Value = federated ? 1 : 0
                }
            );

            return await _context.ExecuteNonQueryJsonOutputAsync("getUpsertUserValidation", parameters);
        }

        public async Task<string> getAccountIdsByUserId(Guid accountId, string email)
        {
            Logger.LogInformation($"[Finder] Getting user by accountid = {accountId}, email = {email}");
            const string paramEmail = "email";
            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithString(paramEmail, email)
                .Build();

            return await _context.ExecuteNonQueryJsonOutputAsync("getUserByAccountIdAndEmail", parameters);
        }

        public async Task<string> GetAccountIdsByUserIdAsync(Guid userId)
        {
            Logger.LogInformation($"[Finder] Getting accountIds by userId = {userId}");
            List<SqlParameter> parameters = new SpParams()
                .WithUserId(userId)
                .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("getAccountIdsByUserId", parameters);
        }

        public async Task<string> UpdateAsync(Guid byUserId, Guid accountId, Guid sessionId, string jsonInput)
        {
            if (jsonInput == null) return null;

            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(byUserId)
                .WithSessionId(sessionId)
                .WithJson(jsonInput)
                .Build();

            Logger.LogInformation(string.Format(CultureInfo.InvariantCulture, "[Finder] Params = \n{0}", parameters.ToString() ));

            return await _context.ExecuteNonQueryJsonOutputAsync("updateUser", parameters).ConfigureAwait(false);
        }

        public async Task<string> CreateUserLogoutAsync(Guid userId, Guid? accountId, Guid sessionId)
        {
            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithSessionId(sessionId)
                .Build();

            Logger.LogInformation(string.Format(CultureInfo.InvariantCulture, "[Finder] Params = \n{0}", parameters.ToString()));

            return await _context.ExecuteNonQueryJsonOutputAsync("createUserLogout", parameters).ConfigureAwait(false);
        }

        public async Task<string> CreateUserLoginAsync(Guid userId, Guid? accountId, Guid sessionId)
        {
            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithSessionId(sessionId)
                .Build();

            Logger.LogInformation(string.Format(CultureInfo.InvariantCulture, "[Finder] Params = \n{0}", parameters.ToString()));

            return await _context.ExecuteNonQueryJsonOutputAsync("createUserLogin", parameters).ConfigureAwait(false);
        }
    }
}
