export interface Favorite {
    assetId: string;
    favorite: boolean;
    fileName?: string;
    name?: string;
    totalFavorites?: number;
}