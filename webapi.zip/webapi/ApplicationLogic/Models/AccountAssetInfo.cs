﻿using System;
using System.Text.Json.Serialization;

namespace ApplicationLogic.Models
{
    public class AccountAssetInfo
    {
        [JsonPropertyName("storageAccountName")]
        public string StorageAccountName { get; set; }

        [JsonPropertyName("Assets")]
        public DownloadAssetModel[] Assets { get; set; }
    }
}
