﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Dtos.Asset.Request;
using WebApi.Enums;

namespace WebApi.Services
{
    public class DownloadService
    {
        private readonly ILogger<DownloadService> _logger;
        private readonly ServiceBusService _serviceBusService;
        private readonly IConfiguration _configuration;
        private readonly AccountLogic _accountLogic;
        private readonly BlobService _blobService;
        private readonly damContext _context;

        // todo consolidate into const file


        public DownloadService(IConfiguration configuration, ILogger<DownloadService> logger, ServiceBusService serviceBusService, BlobService blobService, damContext context)
        {
            _logger = logger;
            _serviceBusService = serviceBusService;
            _configuration = configuration;
            _blobService = blobService;
            _context = context;

            _accountLogic = new AccountLogic(_context);
        }

        public async Task QueueDownload(Guid accountId, AssetDownloadConversionRequest request)
        {
            if (request.ConversionType == DownloadConversionType.ScreenQualityPdfLowResolution)
            {
                await QueueDownloadPdf(accountId, request);
            }
            else
            {
                await QueueDownloadImage(accountId, request);
            }
        }

        private async Task QueueDownloadImage(Guid accountId, AssetDownloadConversionRequest request)
        {
            var storageAccountName = _configuration["BlobStorage:StorageAccountName"];
            var uploadContainerName = "zip";
            var downloadFolderName = Guid.NewGuid().ToString().ToLowerInvariant();

            var uploadContainerNameSource = _configuration["BlobStorage:UploadContainerName"]; // asset

            foreach (var asset in request.Assets)
            {
                await _serviceBusService.SignalImageUploaded(CreateBusMessage(request, asset, accountId, storageAccountName, uploadContainerName, downloadFolderName, uploadContainerNameSource));
            }
        }

        private async Task QueueDownloadPdf(Guid accountId, AssetDownloadConversionRequest request)
        {
            var storageAccountName = _configuration["BlobStorage:StorageAccountName"];
            var uploadContainerName = "zip";
            var downloadFolderName = Guid.NewGuid().ToString().ToLowerInvariant();

            var uploadContainerNameSource = _configuration["BlobStorage:UploadContainerName"]; // asset

            foreach (var asset in request.Assets)
            {
                await _serviceBusService.SignalPDFUploaded(CreateBusMessage(request, asset, accountId, storageAccountName, uploadContainerName, downloadFolderName, uploadContainerNameSource));
            }
        }

        private object CreateBusMessage(AssetDownloadConversionRequest request, AssetDownloadRequest asset, Guid accountId, string storageAccountName, string uploadContainerName, String downloadFolderName, string uploadContainerNameSource)
        {
            return new
            {
                MessageType = ServiceBusMessageType.CONVERT_OR_RESIZE,
                AssetId = asset.AssetId.ToString(),
                AccountId = accountId.ToString(),
                StorageAccountName = storageAccountName,
                BlobName = asset.SourceFileName,

                ID = Guid.NewGuid(),
                Opaque = new
                {
                    request.SignalRConnectionId,
                    AssetId = asset.AssetId.ToString(),
                    UploadContainerName = uploadContainerName,
                    DownloadFolderName = downloadFolderName,
                    Source = request.Source
                },
                TenantInfo = new
                {
                    Account = new
                    {
                        Type = "AzureBlobStorage",
                        Details = new
                        {
                            AccountName = storageAccountName,
                            ContainerName = uploadContainerNameSource,
                            ContainerNamePrefix = accountId.ToString()
                        }
                    }
                },
                Source = new
                {
                    FileName = $"{asset.AssetId}{Path.GetExtension(asset.SourceFileName)}".ToLowerInvariant()
                },
                Processing = new
                {
                    ResponseMessageType = ServiceBusMessageType.DOWNLOAD_CONVERSION_READY,
                    Tasks = new[]
                                    {
                            GetTaskObject(request.ConversionType, uploadContainerName, GetUniqueFileNameForConversion(request.Assets, asset.SaveAsFileName, request.ConversionType), downloadFolderName)
                        }
                }
            };
        }

        /// <summary>
        /// Returns a 'safe' filename that will be used to save to to azure storage after conversion.
        /// This is needed because sometimes filenames can have the same name but not the same extension. If we
        /// are converting filename1.jpg and filename1.png to png's at the same time then filename1.jpg will be renamed to filename1.png which
        /// causes a conflict. This method checks for that and if there is a conflict returns a unique id to save file as.
        /// </summary>
        /// <param name="requests"></param>
        /// <param name="assetFileName"></param>
        /// <param name="conversionType"></param>
        /// <returns></returns>
        private string GetUniqueFileNameForConversion(List<AssetDownloadRequest> requests, string assetFileName, DownloadConversionType conversionType)
        {
            string fileName = assetFileName;

            var assetFileNameWithoutExtension = Path.GetFileNameWithoutExtension(assetFileName);
            var assetExtension = Path.GetExtension(assetFileName).ToLowerInvariant();

            switch (conversionType)
            {
                case DownloadConversionType.PrintQualityJpgHighResolution:
                case DownloadConversionType.ScreenQualityJpgLowResolution:
                    // We are going to convert to a jpg. We need to make sure this filename AFTER converting to a jpg doesn't conflict with any other files names.
                    if (assetExtension != ".jpg")
                    {
                        var matchingFilesWithJpg = requests.Where(r => r.SourceFileName == assetFileNameWithoutExtension + ".jpeg" || r.SourceFileName == assetFileNameWithoutExtension + ".jpg");
                        if (matchingFilesWithJpg.Count() > 0)
                        {
                            // There is a match. So return a unique filename.
                            fileName = $"{Guid.NewGuid()}{".jpg"}".ToLowerInvariant();
                        }
                    }

                    break;
                case DownloadConversionType.PrintQualityPngHighResolution:
                case DownloadConversionType.ScreenQualityPngLowResolution:
                    // We are going to convert to a png. We need to make sure this filename AFTER converting to a png doesn't conflict with any other files names.
                    if (assetExtension != ".png")
                    {
                        var mathingFilesWithPng = requests.Where(r => r.SourceFileName == assetFileNameWithoutExtension + ".png").ToList();
                        if (mathingFilesWithPng.Count() > 0)
                        {
                            // There is a match. So return a unique filename.
                            fileName = $"{Guid.NewGuid()}{".png"}".ToLowerInvariant();
                        }
                    }
                    break;
            }

            return fileName;
        }

        // The conversion type details are defined in the image-converter project appsettings file.
        private object GetTaskObject(DownloadConversionType conversionType, string containerName, string fileNameWithExtension, string prefix)
        {
            string conversionTypeName;
            switch (conversionType)
            {
                case DownloadConversionType.OriginalQualityJpg:
                    conversionTypeName = "original-quality-jpg";
                    break;
                case DownloadConversionType.PrintQualityJpgHighResolution:
                    conversionTypeName = "print-quality-jpg-high-res";
                    break;
                case DownloadConversionType.PrintQualityPngHighResolution:
                    conversionTypeName = "print-quality-png-high-res";
                    break;
                case DownloadConversionType.ScreenQualityJpgLowResolution:
                    conversionTypeName = "screen-quality-jpg-low-res";
                    break;
                case DownloadConversionType.ScreenQualityPngLowResolution:
                    conversionTypeName = "screen-quality-png-low-res";
                    break;
                case DownloadConversionType.ScreenQualityPdfLowResolution:
                    conversionTypeName = "screen-quality-pdf-low-res";
                    break;
                default:
                    return null;
            }

            return new
            {
                Name = conversionTypeName,
                Destinations = new[] {
                    new {
                        Type = "AzureBlobStorage",
                        Details = new {
                            ContainerName = containerName,
                            Location = string.IsNullOrEmpty(prefix)
                                ? Path.GetFileNameWithoutExtension(fileNameWithExtension)
                                : prefix + "/" + Path.GetFileNameWithoutExtension(fileNameWithExtension)  // Send without extension since the converter could convert to different file type
                        }
                    }
                }
            };
        }
    }
}
