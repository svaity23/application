export interface DownloadProgress {
    file?: File;
    isComplete: boolean;
    progress: number;
  }
