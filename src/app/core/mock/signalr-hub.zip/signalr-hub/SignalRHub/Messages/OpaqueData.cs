﻿namespace SignalRHub.Messages
{
    public class OpaqueData
    {        
        public string SignalRConnectionId { get; set; }      
        public string Source { get; set; }
    }
}
