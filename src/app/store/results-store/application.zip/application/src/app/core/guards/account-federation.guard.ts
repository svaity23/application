import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable, Injector } from '@angular/core';

import { OidcFacade } from 'ng-oidc-client';
import Oidc from 'oidc-client';

import { Observable, of } from 'rxjs';
import { switchMap, take } from 'rxjs/operators';

import { APP_CONFIG, AppConfig } from '@app/app-config';

@Injectable({
  providedIn: 'root'
})
export class AccountFederationGuard implements CanActivate {

  private appSettings: AppConfig;

  constructor(private oidcFacade: OidcFacade, private injector: Injector, private router: Router) {
    this.appSettings = this.injector.get(APP_CONFIG);
    }

  areClaimsValid(): Observable<boolean | UrlTree> {
    return this.oidcFacade.identity$.pipe(
      take(1),
      switchMap(user => {
        if (user && !user.expired) {
            const config = {
                ...this.appSettings.federatedConsentConfig,
                userStore: new Oidc.WebStorageStateStore({ store: window.sessionStorage })
            }
            // check federated consent claims
            return new Oidc.UserManager(config).getUser()
                .then(consentUser => {
                    if(consentUser && user.profile?.extension_userId.toLowerCase() === consentUser.profile?.userId.toLowerCase() &&
                        user.profile?.extension_accountId.toLowerCase().indexOf(consentUser.profile?.accountId.toLowerCase()) >= 0) {
                        return true;
                    }
                    else {
                        return this.router.parseUrl('/integration-error');
                    }
                });
        } else {
          return of(false);
        }
      })
    );
  }

  // canActivate is used to prevent an unauthorized user for components like TermsOfUseComponent(no module).
  canActivate(
    // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
    _route: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
    _state: RouterStateSnapshot): Observable<boolean | UrlTree> {

    return this.oidcFacade.waitForAuthenticationLoaded().pipe(
      switchMap(() => {
        return this.areClaimsValid();
      })
    );
  }
}
