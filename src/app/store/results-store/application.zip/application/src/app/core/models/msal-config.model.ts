export interface MsalConfig {
    config: {
        auth: {
            clientId: string,
            authority: string,
            knownAuthorities: string[],
            redirectUri: string,
        },
        cache: {
            cacheLocation: string,
            storeAuthStateInCookie: boolean
        }
    },
    loginRequest: {
        scopes: string[]
    },
    msalLibraryUrl: string
}