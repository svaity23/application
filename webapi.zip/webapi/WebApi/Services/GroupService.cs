﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using WebApi.Dtos;

namespace WebApi.Services
{
    public class GroupService
    {
        private readonly ILogger<GroupService> _logger;
        private readonly GroupLogic _groupLogic;
        private readonly JsonSerializerOptions _options = new JsonSerializerOptions()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };


        public GroupService(ILogger<GroupService> logger, damContext context)
        {
            _logger = logger;
            _groupLogic = new GroupLogic(context);
            _logger.LogInformation("GroupService initialized");
        }

        public async Task<GetEntitiesResponse<GroupDto>> GetAllGroupsAsync(Guid accountId, Guid userId)
        {
            string resultJson = await _groupLogic.GetAllGroupsAsync(accountId, userId);
            GetEntitiesResponse<GroupDto> result = JsonSerializer.Deserialize<GetEntitiesResponse<GroupDto>>(resultJson, _options);
            return result;
        }

        public async Task<UpsertResponse<List<Guid>>> BulkDeleteGroupsAsync(Guid accountId, Guid userId, BulkDeleteRequestDTO groups)
        {
            var jsonGroups = JsonSerializer.Serialize(groups, _options);
            var resultJson = await _groupLogic.DeleteGroupAsync(accountId, userId, jsonGroups);
            UpsertResponse<List<Guid>> result = JsonSerializer.Deserialize<UpsertResponse<List<Guid>>>(resultJson, _options);
            return result;
        }

        public async Task<UpsertResponse<List<Guid>>> DeleteGroupAsync(Guid accountId, Guid userId, Guid group)
        {
            BulkDeleteRequestDTO groups = new BulkDeleteRequestDTO
            {
                Ids = new Guid[] { group }
            };
            var jsonGroups = JsonSerializer.Serialize(groups, _options);
            var resultJson = await _groupLogic.DeleteGroupAsync(accountId, userId, jsonGroups);
            UpsertResponse<List<Guid>> result = JsonSerializer.Deserialize<UpsertResponse<List<Guid>>>(resultJson, _options);
            return result;
        }

        public async Task<UpsertResponse<GroupDto>> SaveGroupAsync(Guid accountId, Guid userId, GroupDto group)
        {
            var jsonGroupUpdate = JsonSerializer.Serialize(group, _options);
            var resultJson = await _groupLogic.SaveGroupAsync(accountId, userId, jsonGroupUpdate);
            UpsertResponse<GroupDto> result = JsonSerializer.Deserialize<UpsertResponse<GroupDto>>(resultJson, _options);
            return result;
        }
    }
}
