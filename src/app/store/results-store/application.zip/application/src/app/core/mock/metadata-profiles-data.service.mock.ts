import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

import { MetadataField } from '../models/entities/metadata-field.model';
import { MetadataFieldValue } from '../models/entities/metadata-field-value.model';
import { MetaDataFieldView } from '../models/metadata-field-view.model';
import { MetadataProfilesDataServiceInterface } from '../data-services/metadata-profiles-data.service';
import { MetadataProfileView } from '../models/metadata-profile-view.model';

@Injectable({ providedIn: 'root' })
export class MetadataProfilesDataServiceMock implements MetadataProfilesDataServiceInterface {

    constructor() { }

    add(profile: MetadataProfileView): Observable<MetadataProfileView> {
        console.log(profile);
        throw new Error('Method not implemented.');
    }

    delete(id: string): Observable<MetadataProfileView> {
        console.log(id);
        throw new Error('Method not implemented.');
    }

    getAll(): Observable<MetadataProfileView[]> {
        return this.getMockData();
    }

    getMetadataProfileFieldsByProfileId(id: string): Observable<MetaDataFieldView> {
        console.log(id);
        throw new Error('Method not implemented.');
    }

    saveMetadataProfileFieldsByProfileId(id: string, metadataFields:MetadataField[], metadataFieldValues:MetadataFieldValue[]): Observable<MetaDataFieldView> {
        console.log(id);
        console.log(metadataFields);
        console.log(metadataFieldValues);
        throw new Error('Method not implemented.');
    }

    update(profile: MetadataProfileView): Observable<MetadataProfileView> {
        console.log(profile);
        throw new Error('Method not implemented.');
    }

    private getMockData(): Observable<MetadataProfileView[]> {
        const profiles = [];
        const profileImage: MetadataProfileView = {
            id: '0image',
            metadataProfileTypeId: 0,
            assetCount: 100,
            fieldCount: 5,
            name: 'Image'
        };
        const profileVideo: MetadataProfileView = {
            id: '1video',
            metadataProfileTypeId: 1,
            assetCount: 11,
            fieldCount: 5,
            name: 'Video'
        };
        const profileAudio: MetadataProfileView = {
            id: '2audio',
            metadataProfileTypeId: 2,
            assetCount: 22,
            fieldCount: 4,
            name: 'Audio'
        };
        const profileDesign: MetadataProfileView = {
            id: '3design',
            metadataProfileTypeId: 3,
            assetCount: 33,
            fieldCount: 5,
            name: 'Design'
        };
        const profilePresentation: MetadataProfileView = {
            id: '4presentation',
            metadataProfileTypeId: 4,
            assetCount: 44,
            fieldCount: 6,
            name: 'Presentation'
        };
        const profileDocument: MetadataProfileView = {
            id: '5document',
            metadataProfileTypeId: 5,
            assetCount: 55,
            fieldCount: 6,
            name: 'Document'
        };
        profiles.push(profileImage);
        profiles.push(profileVideo);
        profiles.push(profileAudio);
        profiles.push(profileDesign);
        profiles.push(profilePresentation);
        profiles.push(profileDocument);
        return of(profiles);
    }
}
