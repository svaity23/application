export enum NotificationType {
  AssetExpired = 'assetExpired',
  Comment = 'comment',
}
