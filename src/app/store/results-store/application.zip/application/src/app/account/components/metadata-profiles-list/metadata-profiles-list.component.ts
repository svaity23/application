import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';

import * as FileGroupTypes from '@app/core/enums/file-group-type.enum';
import { EllipsisIconType } from '@app/core/enums/ellipsis-icon-type.enum';
import { MetadataProfileView } from '@app/core/models/metadata-profile-view.model';

@Component({
  selector: 'app-metadata-profiles-list',
  templateUrl: './metadata-profiles-list.component.html',
  styleUrls: ['./metadata-profiles-list.component.scss']
})
export class MetadataProfilesListComponent implements OnInit, OnChanges {
  @Output() editProfileEvent = new EventEmitter<MetadataProfileView>();
  FileGroupType = FileGroupTypes.FileGroupType;
  icons: number[] = [];
  @Input() profiles: MetadataProfileView[];
  profilesToDisplay: MetadataProfileView[]; // we need this because we do a sort, and do not want to modify state itself
  @Input() showEdit = false;

  constructor() { }

  editProfile(profile: MetadataProfileView): void {
    console.log(profile);
    this.editProfileEvent.emit(profile);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.profiles) {
      this.profilesToDisplay = [...changes.profiles.currentValue];
      this.profilesToDisplay.sort((s1, s2) => s1.name.toLocaleLowerCase() > s2.name.toLocaleLowerCase() ? 1 : -1);
    }
  }

  ngOnInit(): void {
    this.configureEllipsisIcons();
  }

  private configureEllipsisIcons(): void {
    if (this.showEdit) {
      this.icons.push(EllipsisIconType.Edit);
    }
  }

}
