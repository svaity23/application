﻿using Microsoft.ApplicationInsights.Channel;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UploadAsset.Common
{
    public class CloudRoleNameTelemetryInitializer : ITelemetryInitializer
    {

        private readonly string CloudRole;

        public CloudRoleNameTelemetryInitializer(string roleName)
        {
            CloudRole = roleName;
        }


        public void Initialize(ITelemetry telemetry)
        {
            telemetry.Context.Cloud.RoleName = CloudRole;
        }
    }
}
