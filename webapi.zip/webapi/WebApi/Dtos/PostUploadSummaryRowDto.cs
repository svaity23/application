﻿using System;
using System.Text.Json.Serialization;

namespace WebApi.Dtos
{
    public class PostUploadSummaryRowDto
    {
        [JsonPropertyName("collectionId")]
        public Guid CollectionId { get; set; }

        [JsonPropertyName("collectionName")]
        public string CollectionName { get; set; }

        [JsonPropertyName("postUploadSummaryFileGroups")]
        public PostUploadSummaryFileGroupDto[] PostUploadSummaryFileGroups { get; set; }
    }
}
