﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Dtos.Canva;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class CanvaIntegrationController : ControllerBase
    {
        private readonly ILogger<IntegrationController> _logger;
        private readonly CanvaService _canvaAuthService;
        private readonly UserAccountService _userAccountService;

        public CanvaIntegrationController(ILogger<IntegrationController> logger, CanvaService canvaAuthService, UserAccountService userAccountService)
        {
            _logger = logger;
            _canvaAuthService = canvaAuthService;
            _userAccountService = userAccountService;
        }

        [HttpGet("signin")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> StoreCanvaCredentials(
            string user,
            string state)
        {
            _logger.LogInformation("Storing Canva credentials");
            
            var canvaUser = new CanvaUser
            {
                CanvaUserId = user,
                AccountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService),
                UserId = this.User.GetUserId()
            };
            await _canvaAuthService.SaveCanvaUserAsync(canvaUser);

            CanvaStateDto result = new CanvaStateDto();
            result.State = state;

            return Ok(result);
        }
    }
}
