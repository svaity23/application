﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class IntegrationFinder
    {
        private damContext _context;

        public IntegrationFinder(damContext context)
        {
            _context = context;
        }

        public async Task<string> GetMarcomIntegrations(Guid accountId)
        {
            SpParams paramList = new SpParams();
            paramList.WithAccountId(accountId);
            return await ExecuteAsync("getMarcomIntegrationsByAccountId", paramList);
        }
        //public async Task<string> GetMarcomPortalCredentialsByAccountId(Guid accountId)
        //{
        //    SpParams paramList = new SpParams();
        //    paramList.WithAccountId(accountId);
        //    return await ExecuteAsync("getMarcomPortalCredentialsByAccountId", paramList);
        //}

        public async Task<string> UpsertIntegrationAsync(Guid accountId, string jsonInput)
        {
            if (jsonInput == null) return null;

            SpParams paramList = new SpParams();
            paramList.WithAccountId(accountId);
            
            
            return await ExecuteAsync("upsertIntegration", paramList, jsonInput);
        }


        private async Task<string> ExecuteAsync(string procedure, SpParams paramList, string json = null)
        {

            if (json != null) paramList.WithJson(json);

            List<SqlParameter> sqlParmsList = paramList.Build();
            return await _context.ExecuteNonQueryJsonOutputAsync(procedure, sqlParmsList).ConfigureAwait(false);
        }
    }
}
