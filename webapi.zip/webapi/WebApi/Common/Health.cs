﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Common
{
    public class Health
    {
        public Health()
        {
            Ready = true;
            Live = true;
        }
        public bool Live { get; set; }
        public bool Ready { get; set; }
    }
}
