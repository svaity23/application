import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { filter, first, map, switchMap, take, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AccountUserStoreFacade } from '@app/store/account-store/account-user-store.facade';
import { User } from '../models/entities/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserGuard implements CanActivate {

  constructor(private userStorefacade: AccountUserStoreFacade, private router: Router) { }

  canActivate(
    // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
    _route: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
    _state: RouterStateSnapshot): Observable<boolean | UrlTree> {

    return this.prefetchUsers().pipe(
      switchMap(() => this.isUserInState())
    );
  }

  private isUserInState(): Observable<boolean | UrlTree> {
    return this.userStorefacade.selectedUser$.pipe(
      take(1),
      map(user => {
        if (user) {
          return true;
        } else {
          return this.router.parseUrl('/account/users');
        }
      })
    );
  }

  private prefetchUsers(): Observable<User[]> {
    return this.userStorefacade.isLoaded$.pipe(
      tap(isLoaded => {
        if (isLoaded !== true) {
          this.userStorefacade.loadUsers();
        }
      }),
      filter(isLoaded => isLoaded === true),
      switchMap(() => this.userStorefacade.users$),
      first()
    );
  }
}
