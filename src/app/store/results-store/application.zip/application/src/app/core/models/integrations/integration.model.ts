export interface Integration {
	id?: string;
    accountId?: string;
    key?: string;
    token?: string;
    name?: string;
    status?: string;
}
