import { AccountTypeKey } from '@app/core/enums/account-type-key.enum';

export interface AccountDetail {
    accountTypeName: AccountTypeKey;
    active: boolean;
    created: Date;
    federatedDomains?: string;
    id: string;
    modified?: Date;
    name: string;
    netsuiteId?: string;
    opportunityId?: string;
    salesforceId?: string;
    storageMaximumGb?: number;
    trialExpiration?: Date;
    userEmail: string;
    userFirstName: string;
    userId: string;
    userLastName: string;
}
