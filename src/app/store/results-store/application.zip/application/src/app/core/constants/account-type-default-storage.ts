import { AccountTypeKey } from '../enums/account-type-key.enum';
import { KeyValuePair } from '../models/key-value-pair.model';

export const ACCOUNT_TYPE_DEFAULT_STORAGE: KeyValuePair[] = [
    { key: AccountTypeKey.Business, value: 3000 },
    { key: AccountTypeKey.MCCInternal, value: 250 },
    { key: AccountTypeKey.Team, value: 2000 },
    { key: AccountTypeKey.Essential, value: 500 },
    { key: AccountTypeKey.Evaluation, value: 250 },
    { key: AccountTypeKey.Trial, value: 5 }
  ];