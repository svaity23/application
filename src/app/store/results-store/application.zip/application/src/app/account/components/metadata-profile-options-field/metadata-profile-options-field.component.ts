import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { createGuid, nullGuid } from 'src/utils/guid';

import { FieldType } from '@app/core/enums/field-type.enum';
import { MetadataField } from '@app/core/models/entities/metadata-field.model';
import { MetadataFieldValue } from '@app/core/models/entities/metadata-field-value.model';

@Component({
  selector: 'app-metadata-profile-options-field',
  templateUrl: './metadata-profile-options-field.component.html',
  styleUrls: ['./metadata-profile-options-field.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MetadataProfileOptionsFieldComponent implements OnInit, OnChanges {
  @Input() field: MetadataField;
  @Output() fieldDeleteAttempted = new EventEmitter<MetadataField>();
  fieldToModify: MetadataField;
  fieldType = FieldType;
  @Output() fieldUpdated = new EventEmitter<MetadataField>();
  @Output() fieldValueDeleteAttempted = new EventEmitter<MetadataFieldValue>();
  @Input() fieldValues: MetadataFieldValue[];
  @Output() fieldValuesAdded = new EventEmitter<MetadataFieldValue[]>();
  @Output() fieldValuesSorted = new EventEmitter<MetadataFieldValue[]>();
  fieldValuesToModify: MetadataFieldValue[];
  @Output() fieldValueUpdated = new EventEmitter<MetadataFieldValue>();
  isDuplicateLabel = false;
  placeholder: string;
  @Input() profileFieldLabels: string[];
  valueToMove: MetadataFieldValue;
  valueToMoveAfter: MetadataFieldValue;

  constructor() { }

  addFieldValue(): void {
    const fieldValues = this.createFieldValues(this.fieldToModify.id)
    this.fieldValuesAdded.emit(fieldValues);
  }

  allowDrop($event): void {
    $event.preventDefault();
  }

  deleteProfileFieldClick(): void {
    this.fieldDeleteAttempted.emit(this.fieldToModify);
  }

  dragValueEnd(): void {
    this.clearDragAndDropValues();
  }

  dragValueOver(option: MetadataFieldValue): void {
    this.valueToMoveAfter = option;
  }

  dragValueStart($event, option: MetadataFieldValue): void {
    this.clearDragAndDropValues();
    this.valueToMove = option;

    // creating a copy of the div to show whats being dragged over
    const ghostElem = $event.currentTarget.cloneNode(true);
    ghostElem.classList.add('drag-ghost');
    document.body.appendChild(ghostElem);
    $event.dataTransfer.setDragImage(ghostElem, 0, 0);
    $event.dataTransfer.setData('text', $event.target.id);
  }

  dropValue($event): void {
    $event.preventDefault();
    if (this.valueToMove.id === this.valueToMoveAfter.id) {
      return; // nothing to do
    } else {
      this.reOrderValues();
    }
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  enter($event: any): void {
    $event.preventDefault();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.field) {
      this.fieldToModify = { ...changes.field.currentValue };
      // if the label being entered exists > 1 means its a duplicate ( first occurence is the field label being modified)
      this.isDuplicateLabel = this.profileFieldLabels.filter((item) => item.toLocaleLowerCase() === this.fieldToModify.label.toLocaleLowerCase()).length > 1;

    }
    if (changes.fieldValues) {
      const copyOfFieldValuesToModify = { ...changes.fieldValues.currentValue };
      this.fieldValuesToModify = this.getSortedProfileFieldValuesForTheField(copyOfFieldValuesToModify);
    }
  }

  ngOnInit(): void {
    switch(this.field.metadataFieldTypeId) {
      case this.fieldType.Checkbox:
        this.placeholder = 'Checkbox option...';
        break;
      case this.fieldType.Dropdown:
        this.placeholder = 'Dropdown option...';
        break;
      case this.fieldType.Radio:
        this.placeholder = 'Radio option...';
        break;
      default:
        this.placeholder = 'Option...';
        break;
    }
  }

  removeFieldValue(fieldValueToRemove: MetadataFieldValue): void {
    this.fieldValueDeleteAttempted.emit(fieldValueToRemove);
  }

  toggleExpandField(): void {
    this.fieldToModify.expandField = !this.fieldToModify.expandField;
  }

  updateFieldLabel(): void {
    this.fieldUpdated.emit(this.fieldToModify);
  }

  updateFieldValue(event, fieldValueToUpdate: MetadataFieldValue): void {
    const updatedFieldValue = {...fieldValueToUpdate, value : event.target.value}
    this.fieldValueUpdated.emit(updatedFieldValue);
  }

  private clearDragAndDropValues(): void {
    this.valueToMove = this.valueToMoveAfter = null;
  }

  private createFieldValues(id: string): MetadataFieldValue[] {
    const listOps: MetadataFieldValue[] = [];
    let previousId = nullGuid;
    let listOp: MetadataFieldValue;
      previousId = this.fieldValuesToModify[this.fieldValuesToModify.length - 1].id;
      // eslint-disable-next-line prefer-const
      listOp = {
        accountId: this.fieldToModify.accountId,
        active: true,
        id: createGuid(),
        metadataFieldId: id,
        previous: previousId,
        value: ''
      }
      listOps.push(listOp);

    return listOps;
  }

  private getSortedProfileFieldValuesForTheField(profileFieldValues: MetadataFieldValue[]): MetadataFieldValue[] {
    const filteredProfileFieldValues = Object.values(profileFieldValues).filter(fieldValue => fieldValue.metadataFieldId.toLowerCase() === this.fieldToModify.id.toLowerCase())
    const profileFieldsToDisplay = [];
    let previousToFind = nullGuid;
    const n = filteredProfileFieldValues.length;
    for (let i = 0; i < n; i++) {
      const fieldIndex = filteredProfileFieldValues.findIndex(item => item.previous.toLocaleLowerCase() === previousToFind);
      previousToFind = filteredProfileFieldValues[fieldIndex].id.toLocaleLowerCase();
      profileFieldsToDisplay.push(filteredProfileFieldValues[fieldIndex]);
    }
    return profileFieldsToDisplay;
  }

  private reOrderValues(): void {
    // removes from old location in values array
    const itemToMoveIndex = this.fieldValuesToModify.findIndex(item => item.id === this.valueToMove.id);
    const itemToMove = this.fieldValuesToModify.splice(itemToMoveIndex, 1)[0];

    // adds to new location in values array
    const itemToMoveAfterIndex = this.fieldValuesToModify.findIndex(item => item.id === this.valueToMoveAfter.id);
    this.fieldValuesToModify.splice(itemToMoveAfterIndex + 1, 0, itemToMove);

    const tempFieldValuesToModify: MetadataFieldValue[] = [];
    this.fieldValuesToModify.forEach(element => {
      const newElement = { ...element };
      tempFieldValuesToModify.push(newElement);
    });

    // loop from the end and update the 'previous' field to update the sort order
    for (let i = tempFieldValuesToModify.length - 1; i > 0; i--) {
      tempFieldValuesToModify[i].previous = tempFieldValuesToModify[i-1].id
    }
    tempFieldValuesToModify[0].previous = nullGuid; // first one is always a null guid
    this.clearDragAndDropValues();
    this.fieldValuesSorted.emit(tempFieldValuesToModify);
  }
}
