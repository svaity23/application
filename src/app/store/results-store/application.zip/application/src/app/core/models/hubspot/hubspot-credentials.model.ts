export interface HubspotCredentials {
	expiration: number
	refreshToken: string,
	token: string,
}
