export interface CustomTheme {
    color1: string;
    color2: string;
    displayName: string;
    title: string;
}