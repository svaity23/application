import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';

import { MetadataField } from '@app/core/models/entities/metadata-field.model';

@Component({
  selector: 'app-metadata-profile-text-field',
  templateUrl: './metadata-profile-text-field.component.html',
  styleUrls: ['./metadata-profile-text-field.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MetadataProfileTextFieldComponent implements OnChanges {
  @Output() fieldDeleteAttempted = new EventEmitter<MetadataField>();

  @Output() fieldUpdated = new EventEmitter<MetadataField>();
  isDuplicateLabel = false;
  @Input() profileFieldLabels: string[];
  @Input() textField: MetadataField;
  textFieldToModify: MetadataField;

  constructor() { }

  addFieldLabel(): void {
    this.fieldUpdated.emit(this.textFieldToModify);
  }

  deleteProfileFieldClick(): void {
    this.fieldDeleteAttempted.emit(this.textFieldToModify);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  enter($event: any): void {
    $event.preventDefault();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.textField) {
      this.textFieldToModify = { ...changes.textField.currentValue };
       // if the label being entered exists > 1 means its a duplicate ( first occurence is the field label being modified)
      this.isDuplicateLabel = this.profileFieldLabels.filter((item) => item.toLocaleLowerCase() === this.textFieldToModify.label.toLocaleLowerCase()).length > 1;
    }
  }

}
