﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using System.Data;
using System.Collections.Generic;

namespace SignalRHub.DomainModel.Context
{
    public partial class damContext : DbContext
    {
        public damContext(
            DbContextOptions<damContext> options, 
            AzureServiceTokenProvider azureServiceTokenProvider, 
            ILogger<damContext> logger, 
            IConfiguration configuration)
            : base(options)
        {
            logger.LogDebug("BEGIN: SignalRContext constructor");

            var conn = (SqlConnection)this.Database.GetDbConnection();
            var localDockerConnectionString = configuration["LOCAL_DOCKER_CONNECTION_STRING"];

            // if normal case (not Docker running locally)
            if (string.IsNullOrWhiteSpace(localDockerConnectionString))
            {
                // use Managed Identity to authenticate into database
                logger.LogDebug("using Managed Identity to authenticate to database");
                logger.LogDebug("BEGIN: get access token");
                conn.AccessToken = azureServiceTokenProvider.GetAccessTokenAsync("https://database.windows.net/")
                    .Result; 
                // TODO: make async. Hard given it's a constructor. 
                // Look to lib source code to see how to create dbContext an asyc way
                logger.LogDebug("END: (success) get access token");
            }
            else
            {
                // Docker container running locally under Docker For Windows cannot 
                // use Managed Identity to authenticate into database. Get connection string
                logger.LogDebug("using launchsettings.json connection string to authenticate to " +
                    "database because LOCAL_DOCKER_CONNECTION_STRING was set " +
                    "(likely a docker container running locally)");
                conn.ConnectionString = localDockerConnectionString;
            }

            logger.LogDebug("END: SignalRContext constructor");
        }


        /// <summary>
        /// Calls a stored procedure within the database
        /// </summary>
        /// <param name="spName">Procedure's name</param>
        /// <param name="parameters">List of parameters to pass to the execution step</param>
        /// <returns></returns>
        public async Task<string> ExecuteNonQueryJsonOutputAsync(string spName, List<SqlParameter> parameters)
        {
            string jsonResult = string.Empty;
            string JsonOutputParam = "@jsonOutput";

            var conn = (SqlConnection)this.Database.GetDbConnection();
            if (conn.State == ConnectionState.Closed)
            {
                await conn.OpenAsync();
            }

#pragma warning disable CA2100 // Review SQL queries for security vulnerabilities
            using (SqlCommand cmd = new SqlCommand(spName, conn)) // we can ignore this here. The string used is a sproc name not a query
#pragma warning restore CA2100 // Review SQL queries for security vulnerabilities
            {
                cmd.CommandType = CommandType.StoredProcedure;

                foreach (SqlParameter param in parameters)
                {
                    cmd.Parameters.Add(param);
                }

                cmd.Parameters.Add(JsonOutputParam, SqlDbType.NVarChar, -1).Direction = ParameterDirection.Output;

                // Execute the command
                await cmd.ExecuteNonQueryAsync();

                // Get the values
                jsonResult = cmd.Parameters[JsonOutputParam].Value.ToString();

                // close so we dont exhaust the db connection pool
                await conn.CloseAsync();
            }

            return jsonResult.ToString();
        }
    }
}
