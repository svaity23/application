import { ErrorResponse } from '../api-responses/error-response';
import { FileGroupType, FileType } from '@app/core/enums';

export interface AssetValidateCreateResponse {
    accountId?: string;
    active?: boolean;
    created: Date;
    createdByByUserId: string;
    error?: ErrorResponse[];
    fileExtension: FileType;
    fileGroup: FileGroupType;
    fileName: string;
    fileSize: number;
    id: string;
    lastModifiedByUserId?: string;
    modified?: Date;
    uploadSessionId?: string;
}
