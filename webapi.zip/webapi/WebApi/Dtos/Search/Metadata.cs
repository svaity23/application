﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WebApi.Dtos.Search
{
    public class Metadata
    {
        [JsonPropertyName("metadataFieldId")]
        public Guid MetadataFieldId { get; set; }

        [JsonPropertyName("value")]
        public string Value { get; set; }

        [JsonPropertyName("label")]
        public string Label { get; set; }

        [JsonPropertyName("metadataProfileId")]
        public Guid MetadataProfileId { get; set; }

        [JsonPropertyName("metadataFieldTypeId")]
        public int MetadataFieldTypeId { get; set; }

        [JsonPropertyName("displayOrder")]
        public int? DisplayOrder { get; set; }
    }
}
