import { DeleteEntityResponse } from './delete-entity-response.model';

export interface DeleteEntitiesResponse {
    deletes: DeleteEntityResponse[]
}
