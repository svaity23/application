﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using System.Collections.Generic;
using System.Threading.Tasks;
using Newtonsoft.Json.Serialization;
using WebApi.Dtos;
using WebApi.Dtos.Asset.Request;
using System.Linq;
using Newtonsoft.Json;
using WebApi.Extensions;

namespace WebApi.Services
{
    public class MetadataProfileService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<MetadataProfileService> _logger;
        private readonly MetadataProfileLogic _metadataProfileLogic;
        
        public MetadataProfileService(IConfiguration configuration, ILogger<MetadataProfileService> logger, damContext context)
        {
            _configuration = configuration;
            _logger = logger;
            _metadataProfileLogic = new MetadataProfileLogic(context);

        }

        public async Task<MetadataProfileViewResponseDto[]> GetMetadataProfilesAsync(Guid accountId)
        {

            var jsonOutput = await _metadataProfileLogic.GetMetadataProfilesByAccountIdAsync(accountId);
            return JsonConvert.DeserializeObject<MetadataProfileViewResponseDto[]>(jsonOutput);
        }

        public async Task<MetadataFieldResponseDto> GetMetadataProfileFieldsByProfileIdAsync(Guid accountId, Guid profileId)
        {
            var jsonOutput = await _metadataProfileLogic.GetMetadataProfileFieldsByProfileIdAsync(accountId, profileId);
            return JsonConvert.DeserializeObject<MetadataFieldResponseDto>(jsonOutput);
        }

        public async Task<MetadataFieldResponseDto> SaveMetadataProfileFieldsByProfileIdAsync(Guid accountId, MetadataFieldRequestDto metadataFieldRequest)
        {
            var jsonString = metadataFieldRequest.ToJsonString();
            var jsonOutput = await _metadataProfileLogic.SaveMetadataProfileFieldsByProfileIdAsync(accountId, jsonString);
            return JsonConvert.DeserializeObject<MetadataFieldResponseDto>(jsonOutput);
        }

    }
}
