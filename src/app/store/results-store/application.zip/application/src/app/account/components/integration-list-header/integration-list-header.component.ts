import { ChangeDetectionStrategy, Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { cn } from 'src/utils/cn';

@Component({
  selector: 'app-integration-list-header',
  templateUrl: './integration-list-header.component.html',
  styleUrls: ['./integration-list-header.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class IntegrationListHeaderComponent implements OnInit {
  @Input() className = '';
  visible = true;

  constructor() { }

  ngOnInit(): void {
    this.className = cn('integration-list-header is-visible', this.className);
  }

}
