﻿using ApplicationLogic.Models;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Nest;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace WebApi.Services
{
    public interface ISearchAssetsServiceFactory
    {
        Task<ISearchAssetsService> CreateSearchAssetServiceAsync(Guid accountId, Guid userId, CollectionService collectionService);
        Task<ISearchAssetsService> CreateSearchLightboxAssetServiceAsync(Guid accountId);
    }

    public class SearchAssetsServiceFactory : ISearchAssetsServiceFactory
    {
        private readonly IConfiguration _configuration;
        private readonly SecretClient _secretClient;
        private readonly ILogger<SearchAssetsServiceFactory> _logger;
        private readonly ILoggerFactory _loggerFactory;


        public SearchAssetsServiceFactory(IConfiguration configuration, SecretClient secretClient, ILogger<SearchAssetsServiceFactory> logger, ILoggerFactory loggerFactory)
        {
            _configuration = configuration;
            _secretClient = secretClient;
            _logger = logger;
            _loggerFactory = loggerFactory;
        }


        public async Task<ISearchAssetsService> CreateSearchAssetServiceAsync(Guid accountId, Guid userId, CollectionService collectionService)
        {
            List<Guid> collectionIds = new List<Guid>();
            GetEntitiesResponse<Guid> results = await collectionService.GetEntitledIdsForUserAsync(accountId, userId);

            // no errors or the error code is set to 0 ==> there's something into the entity list 
            
            if (results?.Error?.Code == 0)
            {
                // Entities can be null if a user does not belong
                // to a group, else entities will returned as a list, which could 
                // also be empty. 
                collectionIds = results.Entities;
            }

            IElasticClient _elasticClient = await CreateClientAsync();
            var logger = _loggerFactory.CreateLogger<SearchAssetsService>();
            return new SearchAssetsService(_configuration, logger, _elasticClient, accountId, userId, collectionIds);
        }

        public async Task<ISearchAssetsService> CreateSearchLightboxAssetServiceAsync(Guid accountId)
        {
            IElasticClient _elasticClient = await CreateClientAsync();
            var logger = _loggerFactory.CreateLogger<SearchAssetsService>();
            return new SearchAssetsService(_configuration, logger, _elasticClient, accountId, Guid.Empty, null);
        }

        private async Task<IElasticClient> CreateClientAsync()
        {           
            var secretElasticsearchApiKey = await _secretClient.GetSecretAsync(_configuration["KeyVault:Secrets:ElasticsearchApiKey"]);
            var secretElasticsearchApiKeyId = await _secretClient.GetSecretAsync(_configuration["KeyVault:Secrets:ElasticsearchApiKeyId"]);                

            var apiKey = secretElasticsearchApiKey.Value.Value;
            var apiKeyId = secretElasticsearchApiKeyId.Value.Value;

            if (string.IsNullOrWhiteSpace(apiKeyId) || string.IsNullOrWhiteSpace(apiKey))
            {
                throw new InvalidOperationException("Elasticsearch: Can not configure the elasticsearch client without a valid api key"
                          + "; configuration[KeyVault:Secrets:ElasticsearchApiKey] - " + _configuration["KeyVault:Secrets:ElasticsearchApiKey"]
                          + "; configuration[KeyVault:Secrets:ElasticsearchApiKeyId] - " + _configuration["KeyVault:Secrets:ElasticsearchApiKeyId"]);
            }

            var esUri = _configuration["Elasticsearch:Uri"];
#pragma warning disable CA2000 // Dispose objects before losing scope
            var settings = new ConnectionSettings(new Uri(esUri)) 
#pragma warning restore CA2000 // Dispose objects before losing scope
                .ApiKeyAuthentication(apiKeyId, apiKey)
                .ThrowExceptions(true);

            var client = new ElasticClient(settings);
            return client;
        }
    }
}
