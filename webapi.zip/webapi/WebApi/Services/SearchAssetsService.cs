﻿using ApplicationLogic.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Nest;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Dtos;
using WebApi.Dtos.Search;
using WebApi.Enums;

namespace WebApi.Services
{
    public interface ISearchAssetsService
    {
        Task<SearchFilters> GetSearchFiltersAsync(string searchTerm, Guid? collectionId, bool? searchFavorites, Guid? lightboxId, bool searchExpiredAssets, bool searchCleanupAssets);
        Task<SearchResultsDto> GetSearchResultsFromElasticsearchAsync(string searchTerm, int sortField, int skip, int pageSize, bool includeFilters, Guid? collectionId, 
                                                                      FilterRequest[] filterRequests, Guid? lightboxId, bool searchFavorites, bool searchExpiredAssets, bool searchCleanupAssets);
        Task<PublicLightboxSearchResultsDto> GetPublicLightboxAssetsSearchResultsFromElasticsearchAsync(string searchTerm, int sortField, int skip, int pageSize, Guid? lightboxId);
        Task<List<SearchSuggestionDto>> GetSearchSuggestionsAsync(string searchTerm, Guid? collectionId, bool searchFavorites, Guid? lightboxId, bool searchExpiredAssets, bool searchCleanupAssets);
        Task<List<string>> GetTagsSuggestionsAsync(string term);
    }

    public class SearchAssetsService : ISearchAssetsService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<SearchAssetsService> _logger;
        private readonly IElasticClient _elasticClient;
        private Guid _accountId;
        private readonly Guid _userId;
        private readonly List<Guid> _entitledCollectionIds;
        private readonly bool _entitledToAll;
        private readonly bool _entitledToNone;
        private string _indexName;
        private bool _useMultiTenantIndex;

        private const string FILE_GROUP_AGG_NAME = "fileGroup";
        private const string FILE_SIZE_MAX_AGG_NAME = "fileSizeMax";
        private const string FILE_SIZE_MIN_AGG_NAME = "fileSizeMin";
        private const string METADATA_AGG_NAME = "metadata";
        private const string TAGS_AGG_NAME = "tags";
        private const string UPLOAD_DATE_AGG_NAME = "uploadDate";

        private const string DATE_FILTER_TYPE_ALL = "all";
        private const string DATE_FILTER_TYPE_TODAY = "today";
        private const string DATE_FILTER_TYPE_WEEK = "week";
        private const string DATE_FILTER_TYPE_MONTH = "month";

        public SearchAssetsService(IConfiguration configuration, ILogger<SearchAssetsService> logger, IElasticClient client, Guid accountId, Guid userId, List<Guid> entitledCollectionIds)
        { 
            _configuration = configuration;
            _logger = logger;
            _elasticClient = client;
            _accountId = accountId;
            _userId = userId;
            _entitledCollectionIds = entitledCollectionIds;
            _entitledToAll = _entitledCollectionIds == null;
            _entitledToNone = _entitledCollectionIds != null && _entitledCollectionIds.Count() == 0;
            _useMultiTenantIndex = bool.Parse(_configuration["Elasticsearch:UseMultiTenantIndex"] ?? "false"); //  future we can configure based on account

            string env = _configuration["Elasticsearch:IndexEnvironment"];
            string index = _configuration["Elasticsearch:Index"];
            string multiTenantIndex = _configuration["Elasticsearch:MultiTenantIndex"];

            _indexName = _useMultiTenantIndex
                ? $"{env}.{_accountId.ToString("D")}.{multiTenantIndex}"
                : $"{env}.{_accountId.ToString("D")}.{index}";
        }

        public async Task<SearchFilters> GetSearchFiltersAsync(string searchTerm, Guid? collectionId, bool? searchFavorites, Guid? lightboxId, bool searchExpiredAssets = false, bool searchCleanupAssets = false)
        {
            var searchResponse = await GetSearchResponseAsync(searchTerm, 0, 0, 0, true, collectionId, null, lightboxId, searchFavorites ?? false, searchExpiredAssets, searchCleanupAssets);
            return await GetSearchFiltersAsync(searchResponse);
        }

        public async Task<SearchResultsDto> GetSearchResultsFromElasticsearchAsync(string searchTerm, int sortField, int skip, int pageSize, bool includeFilters, Guid? collectionId, 
                                                                                   FilterRequest[] filterRequests, Guid? lightboxId, bool searchFavorites, bool searchExpiredAssets = false,
                                                                                   bool searchCleanupAssets = false)
        {
            var searchResponse = await GetSearchResponseAsync(searchTerm, sortField, skip, pageSize, includeFilters, collectionId, filterRequests, lightboxId, searchFavorites, searchExpiredAssets, searchCleanupAssets);
            var searchResultDto = GetSearchResultsDto(searchResponse, _userId);
            if (includeFilters)
            {
                searchResultDto.Filters = await GetSearchFiltersAsync(searchResponse);
            }

            return searchResultDto;
        }

        public async Task<PublicLightboxSearchResultsDto> GetPublicLightboxAssetsSearchResultsFromElasticsearchAsync(string searchTerm, int sortField, int skip, int pageSize, Guid? lightboxId)
        {
            var searchResponse = await GetLightboxSearchResponseAsync(searchTerm, sortField, skip, pageSize, lightboxId);
            var searchResultDto = GetLightboxSearchResultsDto(searchResponse);

            return searchResultDto;
        }

        public async Task<List<string>> GetTagsSuggestionsAsync(string term)
        {
            var searchSuggestions = new List<SearchSuggestionDto>();
            var tags = new List<string>();

            if (string.IsNullOrEmpty(term))
            {
                return tags;
            }
            term = term.ToLowerInvariant();
            var boolFilters = new List<Func<QueryContainerDescriptor<Asset>, QueryContainer>>();
            AddPermissionFilters(boolFilters);

            var searchResponse = await _elasticClient.SearchAsync<Asset>(s => s
                .Index(_indexName)
                .Routing(_useMultiTenantIndex ? _accountId : null)
                .Query(q => q
                    .Bool(b => b
                        .Filter(
                            boolFilters
                        )
                    )
                    &&
                    q.Bool(b => b
                        .Should(
                            bs => bs.Match(m => m
                                .Query(term)
                                .Field(p => p.Tags.Suffix("partial"))
                            )
                        )
                    )
                )
                .Aggregations(a => a
                    .Terms("tags", t => t
                        .Field(p => p.Tags.Suffix("keyword"))
                        .Size(100)
                        .Include(".*" + term + ".*")
                    )
                )
            );

            var aggregations = searchResponse.Aggregations;
            var bucketAggs = new List<BucketAggregate>();

            var tagsAgg = (BucketAggregate)aggregations["tags"];
            bucketAggs.Add(tagsAgg);

            foreach (var bucketAgg in bucketAggs)
            {
                foreach (KeyedBucket<object> bucket in bucketAgg.Items)
                {
                    searchSuggestions.Add(new SearchSuggestionDto() { Name = bucket.Key.ToString() });
                }
            }

            // dtos are all in-memory and should not cause any performance issues with the linq queries.
            var distinctAndSortedDtos = searchSuggestions
                .GroupBy(d => d.Name)   // Removes duplicates
                .Select(d => d.First())
                .OrderByDescending(d => d.Name)
                .ToList();

            foreach (var dto in distinctAndSortedDtos)
            {
                tags.Add(dto.Name);
            }
            return tags;
        }

        public async Task<List<SearchSuggestionDto>> GetSearchSuggestionsAsync(string searchTerm, Guid? collectionId, bool searchFavorites, Guid? lightboxId, bool searchExpiredAssets, bool searchCleanupAssets)
        {
            var dtos = new List<SearchSuggestionDto>();
            if (string.IsNullOrEmpty(searchTerm)) {
                return dtos;
            }

            searchTerm = searchTerm.ToLowerInvariant();

            var boolFilters = new List<Func<QueryContainerDescriptor<Asset>, QueryContainer>>();

            // filter collection and subcollections; make sure collection Id is actually valid for user
            if (collectionId != null && !searchCleanupAssets)
            {
                // no need to perform a search if requested
                // collection is not valid for user
                if (!CollectionIdValidForUser(collectionId))
                    return dtos;

                boolFilters.Add(f => f.Terms(t => t.Field(c => c.CollectionId).Terms(collectionId?.ToString()))
                || f.Terms(t => t.Field(c => c.ParentCollectionId).Terms(collectionId?.ToString())));
            }
            else
            {
                if (searchCleanupAssets)
                {
                    boolFilters.Add(f => f.Bool(t => t.MustNot(c => c.Exists(t => t.Field(c => c.CollectionId)))));
                }
                else
                {
                    // no collections, no need to search
                    if (_entitledToNone)
                        return dtos;

                    // adds standard filters for entitled collections
                    AddPermissionFilters(boolFilters);
                }
            }

            // TODO: SV - another pbi
            if (lightboxId != null)
            {
                boolFilters.Add(f => f.Match(m => m.Field(mf => mf.LightboxIds).Query(lightboxId.ToString())));                
            }

            if (searchFavorites)
            {
                boolFilters.Add(f => f.Match(m => m.Field(mf => mf.FavoriteUserIds).Query(_userId.ToString())));
            }

            AddExpiredAssetsFilter(searchExpiredAssets, boolFilters);

            var searchResponse = await _elasticClient.SearchAsync<Asset>(s => s
                .Index(_indexName)
                .Routing(_useMultiTenantIndex ? _accountId : null)
                .Query(q => q
                    .Bool(b => b
                        .Filter(
                            boolFilters
                        )
                    )
                    &&
                    q.Bool(b => b
                        .Should(
                            bs => bs.MultiMatch(mm => mm
                                .Query(searchTerm)
                                .Fields(fs => fs
                                    .Field(p => p.DisplayName.Suffix("partial"))
                                    .Field(p => p.Tags.Suffix("partial"))
                                )
                            ),
                            bs => bs.Nested(bsn => bsn
                                .Path(bsnp => bsnp.Metadata)
                                .Query(bsnq => bsnq
                                    .Match(m => m
                                        .Field(f => f.Metadata.Suffix("value.partial"))
                                        .Query(searchTerm)
                                    )
                                )
                            )
                        )
                    )
                )
                .Aggregations(a => a
                    .Terms("tags", t => t
                        .Field(p => p.Tags.Suffix("keyword"))
                        .Size(100)
                        .Include(".*" + searchTerm + ".*")
                    )
                    .Terms("displayName", t => t
                        .Field(p => p.DisplayName.Suffix("keyword"))
                        .Size(100)
                        .Include(".*" + searchTerm + ".*")
                    )
                    .Nested("metadata", n => n
                        .Path(p => p.Metadata)
                        .Aggregations(aa => aa
                            .Terms("metadata", t => t
                                .Field(f => f.Metadata.Suffix("value.keyword"))
                                .Size(100)
                                .Include(".*" + searchTerm + ".*")
                            )
                        )
                    )
                )
            );

            var aggregations = searchResponse.Aggregations;
            var bucketAggs = new List<BucketAggregate>();

            var displayNameAgg = (BucketAggregate)aggregations["displayName"];
            bucketAggs.Add(displayNameAgg);

            var tagsAgg = (BucketAggregate)aggregations["tags"];
            bucketAggs.Add(tagsAgg);

            // Metadata comes back as SingleBucketAggregate so need to collect data a little differently
            var metadataAgg = (SingleBucketAggregate)aggregations["metadata"];
            foreach (BucketAggregate bucketAgg in metadataAgg.Values)
            {
                bucketAggs.Add(bucketAgg);
            }

            foreach (var bucketAgg in bucketAggs)
            {
                foreach (KeyedBucket<object> bucket in bucketAgg.Items)
                {
                    // Elasticsearch aggregation turns results to lowercase due to lowercase filter but need to show display Name as is
                    var asset = searchResponse.Documents.FirstOrDefault(d => d.DisplayName.ToLowerInvariant() == bucket.Key.ToString());
                    dtos.Add(new SearchSuggestionDto() { Count = (int)bucket.DocCount, Name = (asset != null) ? asset.DisplayName : bucket.Key.ToString() });
                }
            }

            // dtos are all in-memory and should not cause any performance issues with the linq queries.
            var distinctAndSortedDtos = dtos
                .GroupBy(d => d.Name)   // Removes duplicates
                .Select(d => d.First())
                .OrderByDescending(d => d.Count)
                .ToList();


          return distinctAndSortedDtos;
        }

        #region Private Methods
        private static List<Func<QueryContainerDescriptor<Asset>, QueryContainer>> BuildBoolFilters(FilterRequest[] filterRequests, List<Func<QueryContainerDescriptor<Asset>, QueryContainer>> boolFilters)
        {
            if (filterRequests.Length > 0)
            {
                foreach (var filterRequest in filterRequests)
                {
                    var values = filterRequest.Values;
                    FilterGroupTypeEnum filterGroupType = filterRequest.FilterGroupType;
                    // FileGroup
                    if (filterGroupType == FilterGroupTypeEnum.FileGroup)
                    {
                        boolFilters.Add(f => f.Terms(t => t.Field(c => c.FileGroup).Terms(filterRequest.Values)));
                    }
                    // fileSize -  range
                    if (filterGroupType == FilterGroupTypeEnum.FileSize)
                    {
                        if (values[0].ToLower(CultureInfo.InvariantCulture).StartsWith("min"))
                        {
                            var minSize = values[0].Split(':')[1].Trim();
                            if (!string.IsNullOrEmpty(minSize))
                            {
                                boolFilters.Add(bf => bf.TermRange(dr => dr.Field(f => f.FileSize).GreaterThanOrEquals(minSize)));
                            }
                        }
                        if (values[1].ToLower(CultureInfo.InvariantCulture).StartsWith("max"))
                        {
                            var maxSize = values[1].Split(':')[1].Trim();
                            if (!string.IsNullOrEmpty(maxSize))
                            {
                                boolFilters.Add(bf => bf.TermRange(dr => dr.Field(f => f.FileSize).LessThanOrEquals(maxSize)));
                            }
                        }
                    }
                    // UploadDate
                    if (filterGroupType == FilterGroupTypeEnum.UploadDate)
                    {
                        if (values?.Length > 0)
                        {
                            var value = values[0].ToLower(CultureInfo.InvariantCulture).Trim();
                            switch (value)
                            {
                                case DATE_FILTER_TYPE_TODAY:
                                    boolFilters.Add(f => f.DateRange(t => t.Field(c => c.Created).GreaterThanOrEquals(DateMath.Now.RoundTo(DateMathTimeUnit.Day))));
                                    break;
                                case DATE_FILTER_TYPE_WEEK:
                                    boolFilters.Add(bf => bf.DateRange(dr => dr.Field(f => f.Created).GreaterThanOrEquals(DateMath.Now.RoundTo(DateMathTimeUnit.Week)).LessThanOrEquals(DateMath.Now.RoundTo(DateMathTimeUnit.Week))));
                                    break;
                                case DATE_FILTER_TYPE_MONTH:
                                    boolFilters.Add(bf => bf.DateRange(dr => dr.Field(f => f.Created).GreaterThanOrEquals(DateMath.Now.RoundTo(DateMathTimeUnit.Month)).LessThanOrEquals(DateMath.Now.RoundTo(DateMathTimeUnit.Month))));
                                    break;
                                case DATE_FILTER_TYPE_ALL:
                                    boolFilters.Add(bf => bf.DateRange(dr => dr.Field(f => f.Created).GreaterThanOrEquals(DateMath.FromString("2020-01-01"))));
                                    break;
                                default:
                                    break;
                            }
                        }

                        // custom - date range
                        // values: [
                        //   'from:somedate',
                        //   'to:someotherdate'
                        // ]
                        if (values?.Length > 1)
                        {
                            if (values[0].ToLower(CultureInfo.InvariantCulture).StartsWith("from"))
                            {
                                var fromDateValue = values[0].Split(':')[1];
                                if (!string.IsNullOrEmpty(fromDateValue))
                                {
                                    boolFilters.Add(bf => bf.DateRange(dr => dr.Field(f => f.Created).GreaterThanOrEquals(DateMath.FromString(fromDateValue.Trim()))));
                                }
                            }
                            if (values[1].ToLower(CultureInfo.InvariantCulture).StartsWith("to"))
                            {
                                var toDateValue = values[1].Split(':')[1];
                                if (!string.IsNullOrEmpty(toDateValue))
                                {
                                    boolFilters.Add(bf => bf.DateRange(dr => dr.Field(f => f.Created).LessThanOrEquals(DateMath.FromString(toDateValue.Trim()))));
                                }
                            }

                        }
                    }

                    // tags
                    if (filterGroupType == FilterGroupTypeEnum.Tags)
                    {
                        foreach (var tag in filterRequest.Values)
                        {
                            boolFilters.Add(f => f.Match(m => m.Field(mf => mf.Tags.Suffix("keyword")).Query(tag)));
                        }
                    }
                    // Metadata
                    if (filterGroupType == FilterGroupTypeEnum.Metadata)
                    {

                    }
                }
            }
            return boolFilters;
        }

        private static List<Func<QueryContainerDescriptor<Asset>, QueryContainer>> BuildSearchShouldFunctions(string searchTerm)
        {
            if (string.IsNullOrEmpty(searchTerm))
            {
                return new List<Func<QueryContainerDescriptor<Asset>, QueryContainer>>();
            }
            searchTerm = searchTerm.ToLowerInvariant();
            var queryShouldDescriptors = new List<Func<QueryContainerDescriptor<Asset>, QueryContainer>>();
            queryShouldDescriptors.Add(q => q
                .SimpleQueryString(d => d
                    .Fields(fs => fs
                            .Field(f => f.DisplayName, boost: 5)
                            .Field(f => f.DisplayName.Suffix("partial"))
                            .Field(f => f.Description)
                            .Field(f => f.Description.Suffix("autocomplete"))
                            .Field(f => f.FileExtension)
                            .Field(f => f.FileName, boost: 2)
                            .Field(f => f.FileName.Suffix("partial"))
                            .Field(f => f.Tags, boost: 4)
                            .Field(f => f.Tags.Suffix("partial"))
                            .Field(f => f.OcrText)
                            .Field(f => f.OcrText.Suffix("keyword"))
                    )
                    .DefaultOperator(Operator.Or)
                    .Query(searchTerm)
                    .Lenient()
                    .AnalyzeWildcard(true)
                )
            );

            queryShouldDescriptors.Add(q => q
                .Nested(n => n
                    .Path(np => np.Metadata)
                        .Boost(3)
                        .Query(npq => npq
                            .Match(m => m
                                .Field(f => f.Metadata.Suffix("value.partial"))
                                .Query(searchTerm)
                            )
                        )
                )
            );

            return queryShouldDescriptors;
        }

        private static List<Func<AggregationContainerDescriptor<Asset>, IAggregationContainer>> BuildSearchAggregationFunctions()
        {
            var aggregations = new List<Func<AggregationContainerDescriptor<Asset>, IAggregationContainer>>
            {
               a => a
                .Terms(FILE_GROUP_AGG_NAME, t => t
                    .Field(p => p.FileGroup)
                    .Size(10)
                ),
               a => a
                .Max(FILE_SIZE_MAX_AGG_NAME, m => m
                    .Field(p => p.FileSize)
                ),
               a => a
                .Min(FILE_SIZE_MIN_AGG_NAME, m => m
                            .Field(p => p.FileSize)
                ),
               a => a
                .DateRange(UPLOAD_DATE_AGG_NAME, dr => dr
                    .Field(p => p.Created)
                    .Ranges(
                        r => r.Key(DATE_FILTER_TYPE_TODAY).From(DateMath.Now.RoundTo(DateMathTimeUnit.Day)),
                        r => r.Key(DATE_FILTER_TYPE_WEEK).From(DateMath.Now.RoundTo(DateMathTimeUnit.Week)),
                        r => r.Key(DATE_FILTER_TYPE_MONTH).From(DateMath.Now.RoundTo(DateMathTimeUnit.Month)),
                        r => r.Key(DATE_FILTER_TYPE_ALL).From(DateMath.FromString("2020-01-01"))
                    )
                ),
               a => a
                .Terms(TAGS_AGG_NAME, t => t
                    .Field(p => p.Tags.Suffix("keyword"))
                    .Size(50)
                ),
               a => a
                .Nested(METADATA_AGG_NAME, n => n
                    .Path("metadata")
                    .Aggregations(na => na
                        .Terms("metadataField", t => t.Field(p => p.Metadata.Suffix("metadataFieldId"))
                            .Aggregations(childAggs => childAggs
                                .Terms("metadataValues", avg => avg
                                    .Field(p => p.Metadata.Suffix("value.keyword"))
                                    .Size(50)
                                )
                            )
                        )
                    )
                )
            };

            return aggregations;
        }

        private static async Task<List<FilterGroup>> GetFilterGroupsAsync(int[] metadataProfileIds)
        {
            // TODO - this would generally come back from the database, but for first go, we'll hard code the filters
            // Should use the MetadataProfileIds to filter out which metadata fields come back
            if (metadataProfileIds.Length == 0)
            {
                return null;
            }

            var filterGroups = new List<FilterGroup>()
            {
                new FilterGroup
                {
                    DisplayOrder = 1,
                    FilterGroupType = FilterGroupTypeEnum.UploadDate,
                    Name = "Uploaded Date"
                },
                new FilterGroup
                {
                    DisplayOrder = 2,
                    FilterGroupType = FilterGroupTypeEnum.FileGroup,
                    Name = "Type"
                },
                new FilterGroup
                {
                    DisplayOrder = 3,
                    FilterGroupType = FilterGroupTypeEnum.FileSize,
                    Name = "File Size"
                },
                new FilterGroup
                {
                    DisplayOrder =4,
                    FilterGroupType = FilterGroupTypeEnum.Tags,
                    Name = "Tags"
                }
                // metadata is dynamic, and it will be from the database
                // we have a limitation here, and the client will just be responsible for creating them for now
            };

            await Task.CompletedTask;
            return filterGroups;
        }

        private static async Task<SearchFilters> GetSearchFiltersAsync(ISearchResponse<Asset> searchResponse)
        {
            var searchAggregations = GetSearchAggregationDto(searchResponse);

            var fileGroupAggs = searchAggregations?.FirstOrDefault(a => a.FilterGroupType == FilterGroupTypeEnum.FileGroup);
            var metadataProfileIds = new List<int>(); // todo enumeration
            if (fileGroupAggs != null)
            {
#pragma warning disable CA1305 // Specify IFormatProvider
                metadataProfileIds = fileGroupAggs.Buckets.Select(b => int.Parse(b.Name)).ToList();
#pragma warning restore CA1305 // Specify IFormatProvider
            }

            var filterGroups = await GetFilterGroupsAsync(metadataProfileIds.ToArray());
            return new SearchFilters
            {
                Aggregations = searchAggregations,
                Groups = filterGroups
            };
        }

        private static List<SearchAggregationDto> GetSearchAggregationDto(ISearchResponse<Asset> searchResponse)
        {
            if (searchResponse == null || !searchResponse.IsValid)
            {
                return null;
            }

            var aggregations = searchResponse.Aggregations;

            var fileGroupAgg = aggregations.Terms(FILE_GROUP_AGG_NAME);
            var fileSizeMax = aggregations.Max(FILE_SIZE_MAX_AGG_NAME);
            var fileSizeMin = aggregations.Min(FILE_SIZE_MIN_AGG_NAME);
            var uploadDateAgg = aggregations.DateRange(UPLOAD_DATE_AGG_NAME);
            var tagsAgg = aggregations.Terms(TAGS_AGG_NAME);
            var metadataAgg = aggregations.Nested(METADATA_AGG_NAME);

            var dtos = new List<SearchAggregationDto>();
            if (fileGroupAgg != null)
            {
                var buckets = new List<AggregationBucketDto>();
                fileGroupAgg.Buckets.ToList().ForEach(b =>
                {
                    buckets.Add(new AggregationBucketDto()
                    {
                        Name = b.Key,
                        Count = (int)b.DocCount
                    });
                });

                dtos.Add(new SearchAggregationDto()
                {
                    Buckets = buckets,
                    FilterGroupType = FilterGroupTypeEnum.FileGroup,
                    Name = "fileGroup"
                });
            }

            if (fileSizeMax != null && fileSizeMin != null)
            {
                var buckets = new List<AggregationBucketDto>();
                var min = new AggregationBucketDto()
                {
                    Name = string.Format(CultureInfo.InvariantCulture, $"min:{fileSizeMin.Value}"), // TODO -- this is kinda weird
                    Count = 0
                };

                var max = new AggregationBucketDto()
                {
                    Name = string.Format(CultureInfo.InvariantCulture, $"max:{fileSizeMax.Value}"), // TODO -- this is kinda weird
                    Count = 0
                };

                buckets.Add(min);
                buckets.Add(max);
                dtos.Add(new SearchAggregationDto()
                {
                    Buckets = buckets,
                    FilterGroupType = FilterGroupTypeEnum.FileSize,
                    Name = "fileSize"
                });
            }

            if (uploadDateAgg != null)
            {
                var buckets = new List<AggregationBucketDto>();
                uploadDateAgg.Buckets.ToList().ForEach(b =>
                {
                    buckets.Add(new AggregationBucketDto()
                    {
                        Name = b.Key,
                        Count = (int)b.DocCount
                    });
                });

                dtos.Add(new SearchAggregationDto()
                {
                    Buckets = buckets,
                    FilterGroupType = FilterGroupTypeEnum.UploadDate,
                    Name = "uploadDate"
                });
            }

            if (tagsAgg != null)
            {
                var buckets = new List<AggregationBucketDto>();
                tagsAgg.Buckets.ToList().ForEach(b =>
                {
                    buckets.Add(new AggregationBucketDto()
                    {
                        Name = b.Key,
                        Count = (int)b.DocCount
                    });
                });

                dtos.Add(new SearchAggregationDto()
                {
                    Buckets = buckets,
                    FilterGroupType = FilterGroupTypeEnum.Tags,
                    Name = "tags"
                });
            }

            if (metadataAgg != null)
            {
                foreach (var metadataFieldBucket in metadataAgg.Terms("metadataField").Buckets)
                {
                    var buckets = new List<AggregationBucketDto>();
                    foreach (var value in metadataFieldBucket.Terms("metadataValues").Buckets)
                    {
                        buckets.Add(new AggregationBucketDto()
                        {
                            Name = value.Key,
                            Count = (int)value.DocCount
                        });
                    }

                    dtos.Add(new SearchAggregationDto()
                    {
                        Buckets = buckets,
                        FilterGroupType = FilterGroupTypeEnum.Metadata,
                        Name = metadataFieldBucket.Key
                    });
                }
            }

            return dtos;
        }

        private static SearchResultsDto GetSearchResultsDto(ISearchResponse<Asset> searchResponse, Guid userId)
        {
            if(searchResponse == null)
            {
                return new SearchResultsDto
                {
                    AssetCount = 0,
                    Assets = null
                };
            }

            var dtos = new List<AssetDto>();
            foreach (var document in searchResponse.Documents)
            {
                dtos.Add(ToDto(document, userId));
            }

            return new SearchResultsDto()
            {
                AssetCount = (int)searchResponse.Total,
                Assets = dtos
            };
        }

        private static PublicLightboxSearchResultsDto GetLightboxSearchResultsDto(ISearchResponse<Asset> searchResponse)
        {
            if (searchResponse == null)
            {
                return new PublicLightboxSearchResultsDto
                {
                    AssetCount = 0,
                    Assets = null
                };
            }

            var dtos = new List<LightboxAssetDto>();
            foreach (var document in searchResponse.Documents)
            {                
                dtos.Add(ToLightboxAssetDto(document));
            }

            return new PublicLightboxSearchResultsDto()
            {
                AssetCount = (int)searchResponse.Total,
                Assets = dtos
            };
        }

        private async Task<ISearchResponse<Asset>> GetSearchResponseAsync(string searchTerm, int sortField, int skip, int pageSize, bool includeFilters, Guid? collectionId, 
                                                                          FilterRequest[] filterRequests, Guid? lightboxId, bool searchFavorites, bool searchExpiredAssets, bool searchCleanupAssets)
        {
            _logger.LogDebug("BEGIN: GetSearchAggregationsResponseAsync ");

            if (!string.IsNullOrEmpty(searchTerm))
            {
                searchTerm = searchTerm.ToLowerInvariant();
            }
            var boolFilters = new List<Func<QueryContainerDescriptor<Asset>, QueryContainer>>();

            // filter collection and subcollections; make sure collection Id is actually valid for user
            if (collectionId != null && !searchCleanupAssets)
            {
                // no need to perform a search if requested
                // collection is not valid for user
                if (!CollectionIdValidForUser(collectionId)) 
                    return null;
               
                boolFilters.Add(f => f.Terms(t => t.Field(c => c.CollectionId).Terms(collectionId?.ToString()))
                || f.Terms(t => t.Field(c => c.ParentCollectionId).Terms(collectionId?.ToString())));
               
            }
            else
            {
                if (searchCleanupAssets)
                {
                    boolFilters.Add(f => f.Bool(t => t.MustNot(c => c.Exists(t => t.Field(c => c.CollectionId)))));
                }
                else
                {
                    // no collections, no need to search
                    if (_entitledToNone)
                        return null;

                    // adds standard filters for entitled collections
                    AddPermissionFilters(boolFilters);
                }

            }


            if (lightboxId != null)
            {
                boolFilters.Add(f => f.Match(m => m.Field(mf => mf.LightboxIds).Query(lightboxId.ToString())));
            }

            if (searchFavorites)
            {
                boolFilters.Add(f => f.Match(m => m.Field(mf => mf.FavoriteUserIds).Query(_userId.ToString())));
            }

            AddExpiredAssetsFilter(searchExpiredAssets, boolFilters);

            if (filterRequests != null)
            {
                boolFilters = BuildBoolFilters(filterRequests, boolFilters);
            }

            var queryShouldDescriptors = BuildSearchShouldFunctions(searchTerm);
            var aggregationFunctions = includeFilters ? BuildSearchAggregationFunctions() : new List<Func<AggregationContainerDescriptor<Asset>, IAggregationContainer>>();

            var searchResponse = await _elasticClient.SearchAsync<Asset>(s => s
                .Index(_indexName)
                .Routing(_useMultiTenantIndex ? _accountId : null)
                .From(skip)
                .Size(pageSize)
                .Sort(ss => GetSearchAssetsSort(ss, (SortType)sortField))
                .Query(q =>
                    q.Bool(b => b
                        .Filter(
                            boolFilters
                        )
                    )
                    &&
                    q.Bool(b => b
                        .Should(queryShouldDescriptors)
                    )
                )
                .Aggregations(a =>
                {
                    aggregationFunctions.ForEach(agg => agg(a));
                    return a;
                })
            );

            if (!searchResponse.IsValid)
            {
                _logger.LogError("Invalid Elasticsearch response" + searchResponse.DebugInformation);
                _logger.LogDebug("Elasticsearch Server Error" + searchResponse.ServerError);
            }

            _logger.LogDebug("END: GetSearchAggregationsForFilterAsync");
            return searchResponse;

        }

        private async Task<ISearchResponse<Asset>> GetLightboxSearchResponseAsync(string searchTerm, int sortField, int skip, int pageSize, Guid? lightboxId)
        {
            _logger.LogDebug("BEGIN: GetSearchAggregationsResponseAsync ");

            if (!string.IsNullOrEmpty(searchTerm))
            {
                searchTerm = searchTerm.ToLowerInvariant();
            }
            var boolFilters = new List<Func<QueryContainerDescriptor<Asset>, QueryContainer>>();

            if (lightboxId != null)
            {
                boolFilters.Add(f => f.Match(m => m.Field(mf => mf.LightboxIds).Query(lightboxId.ToString())));
            }

            var queryShouldDescriptors = BuildSearchShouldFunctions(searchTerm);
            var searchResponse = await _elasticClient.SearchAsync<Asset>(s => s
                .Index(_indexName)
                .Routing(_useMultiTenantIndex ? _accountId : null)
                .From(skip)
                .Size(pageSize)
                .Sort(ss => GetSearchAssetsSort(ss, (SortType)sortField))
                .Query(q =>
                    q.Bool(b => b
                        .Filter(
                            boolFilters
                        )
                    )
                    &&
                    q.Bool(b => b
                        .Should(queryShouldDescriptors)
                    )
                )
            );

            if (!searchResponse.IsValid)
            {
                _logger.LogError("Invalid Elasticsearch response" + searchResponse.DebugInformation);
                _logger.LogDebug("Elasticsearch Server Error" + searchResponse.ServerError);
            }

            _logger.LogDebug("END: GetSearchAggregationsForFilterAsync");
            return searchResponse;

        }

        private static void AddExpiredAssetsFilter(bool searchExpiredAssets, List<Func<QueryContainerDescriptor<Asset>, QueryContainer>> boolFilters)
        {
            if (searchExpiredAssets)
            {
                boolFilters.Add(f => f.DateRange(t => t.Field(ef => ef.ExpireOn).LessThanOrEquals(DateMath.Now.RoundTo(DateMathTimeUnit.Day))));
            }
            else
            {
                boolFilters.Add(f => f.Bool(t => t.MustNot(c => c.Exists(t => t.Field(ef => ef.ExpireOn)))) ||
                                f.DateRange(t => t.Field(ef => ef.ExpireOn).GreaterThan(DateMath.Now.RoundTo(DateMathTimeUnit.Day))));
            }
        }

        /// <summary>
        /// Used to help build a dynamic ES query with sorting.
        /// </summary>
        /// <param name="s">The ES sort descriptor object</param>
        /// <param name="sortType">The type of sord operation to perform</param>
        /// <returns></returns>
        private static SortDescriptor<Asset> GetSearchAssetsSort(SortDescriptor<Asset> s, SortType sortType)
        {
            // Note: Text fields are not optimised for operations that require per-document
            // field data like aggregations and sorting.
            // Fields we need to exclude:
            //      Description


            switch (sortType)
            {
                case SortType.CreatedDescending:
                    return s.Field(f => f.Field(p => p.Created).Order(SortOrder.Descending).Missing(-1));
                case SortType.ModifiedDescending:
                    return s.Field(f => f.Field(p => p.Modified).Order(SortOrder.Descending).Missing(-1));
                case SortType.NameAscending:
                    return s.Field(f => f.Field(p => p.DisplayName.Suffix("keyword")).Order(SortOrder.Ascending).Missing(-1));
                case SortType.NameDescending:
                    return s.Field(f => f.Field(p => p.DisplayName.Suffix("keyword")).Order(SortOrder.Descending).Missing(-1));
                case SortType.FileSizeAscending:
                    return s.Field(f => f.Field(p => p.FileSize).Order(SortOrder.Ascending).Missing(-1));
                case SortType.FileSizeDescending:
                    return s.Field(f => f.Field(p => p.FileSize).Order(SortOrder.Descending).Missing(-1));
                case SortType.TypeAscending:
                    // TODO - HOW TO? Cast filegroup to string representation of so we get it in alpha?  For now sort as is.
                    return s.Field(f => f.Field(p => p.FileGroup).Order(SortOrder.Ascending).Missing(-1));
                case SortType.TypeDescending:
                    // TODO - HOW TO? Cast filegroup to string representation of so we get it in alpha?  For now sort as is.
                    return s.Field(f => f.Field(p => p.FileGroup).Order(SortOrder.Descending).Missing(-1));
                case SortType.ModifiedAscending:
                    return s.Field(f => f.Field(p => p.Modified).Order(SortOrder.Ascending).Missing(-1));
                case SortType.CreatedByAscending:
                    return s.Field(f => f.Field(p => p.CreatedByUserFullName.Suffix("keyword")).Order(SortOrder.Ascending).Missing(-1));
                case SortType.CreatedByDescending:
                    return s.Field(f => f.Field(p => p.CreatedByUserFullName.Suffix("keyword")).Order(SortOrder.Descending).Missing(-1));
                case SortType.ExtensionAscending:
                    return s.Field(f => f.Field(p => p.FileExtension.Suffix("keyword")).Order(SortOrder.Ascending).Missing(-1));
                case SortType.ExtensionDescending:
                    return s.Field(f => f.Field(p => p.FileExtension.Suffix("keyword")).Order(SortOrder.Descending).Missing(-1));
                case SortType.Relevance:
                    return s.Descending(SortSpecialField.Score);
                default:
                    return s.Field(f => f.Field(p => p.Created).Order(SortOrder.Descending).Missing(-1));
            }
        }

        // TODO: This function will be removed once Sear.Asset dto and Dto.Asset are in sync
        private static LightboxAssetDto ToLightboxAssetDto(Asset asset)
        {
            if (asset == null)
            {
                return null;
            }            
            return new LightboxAssetDto()
            {
                Id = asset.Id,
                FileName = asset.FileName,                
                AccountId = asset.AccountId,
                Active = true,                
                Created = asset.Created,
                Modified = asset.Modified,                
                Name = asset.Name,
                Description = asset.Description,
                FileGroup = asset.FileGroup,
                FileSize = asset.FileSize,
                FileExtension = asset.FileExtension,                
                Attachment = !string.IsNullOrEmpty(asset.Attachment) ? Newtonsoft.Json.JsonConvert.DeserializeObject<AttachmentDto>(asset.Attachment) : null                      
            };
        }

        // TODO: This function will be removed once Sear.Asset dto and Dto.Asset are in sync
        private static AssetDto ToDto(Asset asset, Guid userId)
        {
            if (asset == null)
            {
                return null;
            }
            bool favorite = false;
            if (asset.FavoriteUserIds != null)
            {
                var favoriteUserIdsString = string.Join("", asset.FavoriteUserIds).ToLower();
                favorite = favoriteUserIdsString.IndexOf(userId.ToString().ToLower()) > -1;
            }

            return new AssetDto()
            {
                Id = asset.Id,
                FileName = asset.FileName,
                ExternalId = asset.ExternalId,
                AccountId = asset.AccountId,
                Active = true,
                CollectionId = asset.CollectionId,
                Created = asset.Created,
                Modified = asset.Modified,
                UploadSessionId = asset.UploadSessionId,
                // todo remove hardcoded values below
                UploadStatus = 2,
                Name = asset.Name,
                Description = asset.Description,
                FileGroup = asset.FileGroup,
                FileSize = asset.FileSize,
                FileExtension = asset.FileExtension,
                CreatedByUserName = asset.CreatedByUserFullName,
                ModifiedByUserName = asset.ModifiedByUserFullName,
                CreatedByUserId = asset.CreatedBy,
                LastModifiedByUserId = asset.LastModifiedBy,
                Attachment = !string.IsNullOrEmpty(asset.Attachment) ? Newtonsoft.Json.JsonConvert.DeserializeObject<AttachmentDto>(asset.Attachment) : null,
                Favorite = favorite,
                LightboxIds = asset.LightboxIds
            };
        }

        private bool CollectionIdValidForUser(Guid? collectionId)
        {
            return _entitledToAll || _entitledCollectionIds.Contains(collectionId.GetValueOrDefault());
        }

        private void AddPermissionFilters(List<Func<QueryContainerDescriptor<Asset>, QueryContainer>> boolFilters)
        {
            if (!_entitledToAll && !_entitledToNone)
            {
                // entitled to some collections, add filter for provided ids
                boolFilters.Add(f => f.Terms(t => t.Field(c => c.CollectionId).Terms(_entitledCollectionIds))
                || f.Terms(t => t.Field(c => c.ParentCollectionId).Terms(_entitledCollectionIds)));
            }
        }

        // TODO: This function will be removed once Sear.Asset dto and Dto.Asset are in sync
        private static List<AssetDto> ToDto(IEnumerable<Asset> assets, Guid userId, Guid? lightboxId)
        {
            var dtos = new List<AssetDto>();
            foreach (var a in assets)
            {
                dtos.Add(ToDto(a, userId));
            }
            return dtos;
        }
        #endregion
    }
}
