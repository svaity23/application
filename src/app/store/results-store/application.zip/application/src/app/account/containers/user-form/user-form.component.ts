import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import { AccountRoleStoreFacade } from '@app/store/account-store/account-role-store.facade';
import { AccountUserStoreFacade } from '@app/store/account-store/account-user-store.facade';
import { AppGroupStoreFacade } from '@app/store/app-store/app-group-store.facade';
import { AppStoreFacade } from '@app/store/app-store/app-store.facade';
import { Context } from '@app/core/models/context.model';
import { Group } from '@app/core/models/entities/group.model';
import { Role } from '@app/core/models/entities/role.model';
import { User } from '@app/core/models/entities/user.model';

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.scss']
})
export class UserFormComponent implements OnInit {
  accountTypeName$: Observable<string>;
  context$: Observable<Context>;
  invalidEmail$: Observable<boolean>;
  invalidUserEmailMessage$: Observable<string>;
  isUserModified = false;
  isValidating$: Observable<boolean>;
  roles$: Observable<Role[]>;
  searchText$: Observable<string>;
  showIntegrations$: Observable<boolean>;
  showUserGroups$: Observable<boolean>;
  user$: Observable<User>;
  userGroups$: Observable<Group[]>;
  userRoleKey$: Observable<string>;

  private newUser = false;

  constructor(
    private appStoreFacade: AppStoreFacade,
    private accountRoleStoreFacade: AccountRoleStoreFacade,
    private accountUserStoreFacade: AccountUserStoreFacade,
    private appGroupStoreFacade: AppGroupStoreFacade) { }

  navigateTo(pageName): void {
    this.appStoreFacade.navigate(`account/${pageName}`);
    this.accountUserStoreFacade.clearInvalidUserEmail();
  }

  navigateToUserList(): void {
    this.appStoreFacade.navigate('/account/users');
    this.accountUserStoreFacade.clearInvalidUserEmail();
  }

  ngOnInit(): void {
    this.invalidEmail$ = this.accountUserStoreFacade.invalidUserEmail$;
    this.invalidUserEmailMessage$ = this.accountUserStoreFacade.invalidUserEmailMessage$;
    this.isValidating$ = this.accountUserStoreFacade.isValidating$;
    this.user$ = this.accountUserStoreFacade.selectedUser$;
    this.roles$ = this.accountRoleStoreFacade.roles$;
    this.context$ = this.appStoreFacade.context.context$;
    this.accountTypeName$ = this.appStoreFacade.accountTypeName$;
    this.searchText$ = this.accountUserStoreFacade.searchText$;
    this.showIntegrations$ = this.appStoreFacade.showIntegrations$;
    this.showUserGroups$ = this.appStoreFacade.context.isUserGroupsFeatureEnabled$;
    this.userRoleKey$ = this.appStoreFacade.userRoleKey$;
    this.userGroups$ = this.appGroupStoreFacade.groups$;
  }

  onSaveChanges(): void {
    if (this.newUser) {
      this.accountUserStoreFacade.addUser();
    } else {
      this.accountUserStoreFacade.updateUser();
    }
  }

  onUserFieldsChange(user: User): void {
    if (user.id == null) {
      this.newUser = true;
    }
    this.accountUserStoreFacade.updateUserToModify({ ...user })
    // this.accountUserStoreFacade.validateUser({ ...user });
    this.isUserModified = (user.roleId == null) ? false : true;
  }

  onUserValidateChange(user: User): void {
    this.accountUserStoreFacade.updateIsValidating(true);
    this.accountUserStoreFacade.validateUser({ ...user });
  }

  openConfirmationModal(errMessage: string): void {
    this.accountUserStoreFacade.openConfirmationModal({
      title: 'Existing User',
      message: errMessage,
      confirmButtonText: 'Yes',
      denyButtonText: 'No',
      confirm: this.saveChanges,
      deny: () => { },
      confirmButtonIcon: null
    });
  }

  openResendConfirmationModal(user: User): void {
    this.accountUserStoreFacade.openConfirmationModal({
      title: 'Resend Welcome Email',
      message: 'This user has not logged into their account. Would you like to resend them the welcome email? \n\n If the user does not receive the email, they can click on Forgot Password on the login page.',
      confirmButtonText: 'Yes',
      denyButtonText: 'No',
      confirm: () => this.resendWelcomeEmail(user),
      deny: () => { },
      confirmButtonIcon: null
    });
  }

  private resendWelcomeEmail = (user: User) => {
    this.accountUserStoreFacade.resendWelcomeEmail(user);
  }

  private saveChanges = () => {
    if (this.newUser) {
      this.accountUserStoreFacade.addUser();
    } else {
      this.accountUserStoreFacade.updateUser();
    }
    this.navigateToUserList();
  }

}
