export interface AssetDownloadRequest {
  assetId: string;
  fileSize: number | string;  // In bytes
  saveAsFileName: string; // Includes file extension
  sourceFileName: string; // Includes file extension
}
