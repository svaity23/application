export const InternalRoles: { [key: string]: string } = {
    'sys-admin': 'System Admin',
    'mcc-admin': 'MCC Admin'
};


