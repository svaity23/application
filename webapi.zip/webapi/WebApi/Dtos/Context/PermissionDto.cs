﻿using System.Text.Json.Serialization;

namespace WebApi.Dtos.Context
{
    public class PermissionDto
    {
        [JsonPropertyName("key")]
        public string Key { get; set; }
    }
}
