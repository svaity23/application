﻿using System.Text.Json.Serialization;

namespace ApplicationLogic.Models
{
    public class UpdateEntitiesResponse
    {
        [JsonPropertyName("updates")]
        public UpdateEntityResponse[] Updates { get; set; }
    }
}
