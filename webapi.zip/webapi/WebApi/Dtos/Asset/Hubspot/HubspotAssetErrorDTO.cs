﻿using System;
using System.Text.Json.Serialization;

namespace WebApi.Dtos.Asset.Hubspot
{
    public class HubspotAssetErrorDTO
    {
        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [JsonPropertyName("accountId")]
        public Guid AccountId { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("collection")]
        public string Collection { get; set; }

        [JsonPropertyName("attachment")]
        public AttachmentDto Attachment { get; set; }

        [JsonPropertyName("error")]
        public HubspotErrorDTO Error { get; set; }

    }
}
