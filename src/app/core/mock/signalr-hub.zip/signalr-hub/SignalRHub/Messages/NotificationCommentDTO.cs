﻿using System;

namespace SignalRHub.Messages
{
    public class NotificationCommentDTO
    {
        public Guid Id { get; set; }
        public NotificationAuthorDTO Author { get; set; }
        public int ThreadId { get; set; }
        public string Comment { get; set; }
        public NotificationAssetDTO Asset { get; set; }
    }
}
