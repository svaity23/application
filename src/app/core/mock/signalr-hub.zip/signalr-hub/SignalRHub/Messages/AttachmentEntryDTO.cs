﻿namespace SignalRHub.Messages
{
    public class AttachmentEntryDTO
    {
        public string BlobName { get; set; }
        public string ContainerName { get; set; }
        public string Name { get; set; }
        public int StatusCode { get; set; }
    }
}
