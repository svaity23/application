﻿using System;

namespace UploadAsset.Services
{
    public class BlobUploadProgressHandler : IProgress<long>
    {
        public event EventHandler<BlobUploadProgressEventArgs> ProgressHandler;

        private int currentPercent = 0;
        private double _fileSizeBytes;
        private bool isDone = false;
        private int totalPercentagePointsProgressed = 0;

        public BlobUploadProgressHandler(double fileSizeBytes)
        {
            _fileSizeBytes = fileSizeBytes;
        }

        /// <summary>
        /// Reports the difference in progress (in percentage)
        /// </summary>
        /// <param name="value">Indicates the amount of bytes that have been uploaded to azure storage.</param>
        public void Report(long value)
        {
            if (isDone || value == 0) return;
            
            int percentComplete = (int)Math.Ceiling((value / _fileSizeBytes * 100));
            int percentagePointsToProgress = percentComplete - currentPercent;

            currentPercent = percentComplete;
            
            // Make sure we don't progress more than 100
            if (totalPercentagePointsProgressed + percentagePointsToProgress > 100)
            {
                percentagePointsToProgress = 100 - totalPercentagePointsProgressed;
            }
            
            totalPercentagePointsProgressed += percentagePointsToProgress;

            ProgressHandler?.Invoke(this, new BlobUploadProgressEventArgs { PercentagePointsToProgress = percentagePointsToProgress, IsDone = isDone });
        }
    }

    public class BlobUploadProgressEventArgs : EventArgs
    {
        public bool IsDone { get; set; }        
        public int PercentagePointsToProgress { get; set; }
    }
}
