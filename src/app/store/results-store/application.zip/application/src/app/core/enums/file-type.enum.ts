export enum FileType {
  // Image file extensions
  JPEG = 'JPEG',
  JPG = 'JPG',
  GIF = 'GIF',
  PNG = 'PNG',
  TIFF = 'TIFF',
  TIF = 'TIF',
  BMP = 'BMP',
  SVG = 'SVG',
  RAW = 'RAW',
  HEIC = 'HEIC',
  NEF = 'NEF',
  ORF = 'ORF',
  CR2 = 'CR2',
  DNG = 'DNG',
  ICO = 'ICO',
  CUR = 'CUR',

  // Video file extensions
  AVI = 'AVI',
  WMV = 'WMV',
  MOV = 'MOV',
  MP4 = 'MP4',
  HEVC = 'HEVC',
  R3D = 'R3D',
  VID = 'VID',
  MPEG = 'MPEG',
  LRV = 'LRV',
  SWF = 'SWF',
  FLV = 'FLV',

  // Audio file extensions
  MP3 = 'MP3',
  WAV = 'WAV',
  M4A = 'M4A',
  FLAC = 'FLAC',
  AIF = 'AIF',
  AAC = 'AAC',
  WMA = 'WMA',

  // Design file extensions
  EPS = 'EPS',
  HTML = 'HTML',
  PUB = 'PUB',
  SKETCH = 'SKETCH',
  PSD = 'PSD',
  AI = 'AI',
  INDD = 'INDD',
  XD = 'XD',
  ASE = 'ASE',
  // Invision ???

  // FusionPro file extensions
  // Template files ???

  // Presentation file extensions
  PPT = 'PPT',
  PPTX = 'PPTX',
  PPTM = 'PPTM',
  POT = 'POT',
  POTX = 'POTX',
  POTM = 'POTM',
  PPS = 'PPS',
  PPSX = 'PPSX',
  PPSM = 'PPSM',
  PEZ = 'PEZ',
  KEY = 'KEY',

  // Document file extensions
  XLS = 'XLS',
  XLSX = 'XLSX',
  TXT = 'TXT',
  DOC = 'DOC',
  DOCX = 'DOCX',
  CSV = 'CSV',
  PDF = 'PDF',

  // Font file extensions
  FNT = 'FNT',
  FON = 'FON',
  TTF = 'TTF',
  OTF = 'OTF',
  WOFF = 'WOFF',
  TTC = 'TTC',

  // Archive file extensions
  ZIP = 'ZIP'
}

