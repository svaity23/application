﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace ApplicationLogic.Models
{
    public class Permalink
    {
        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [JsonPropertyName("externalId")]
        public string ExternalId { get; set; }

        [JsonPropertyName("accountId")]
        public Guid? AccountId { get; set; }
        
        [JsonPropertyName("active")]
        public bool Active { get; set; }

        [JsonPropertyName("userId")]
        public Guid? UserId { get; set; }

        [JsonPropertyName("path")]
        public string Path { get; set; }

        [JsonPropertyName("assetId")]
        public Guid? AssetId { get; set; }

        [JsonPropertyName("resolution")]
        public string Resolution { get; set; }

        [JsonPropertyName("sas")]
        public string Sas { get; set; }

        [JsonPropertyName("sasExpiration")]
        public DateTime SasExpiration { get; set; }
    }
}
