export interface NotificationAuthor {
    authorId: string;
    firstName: string;
    lastName: string;
}
