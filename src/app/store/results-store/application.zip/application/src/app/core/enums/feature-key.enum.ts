export enum FeatureKey {
    Analytics               = 'analytics',
    AssetCustomizeBasic     = 'asset-customize-basic',
    AssetExpiration         = 'asset-expiration',
    AssetRenditions         = 'asset-renditions',
    BrandedUx               = 'branded-ux',
    Collaboration           = 'collaboration',
    DarkLaunchDemo          = 'dark-launch-demo',
    Hubspot                 = 'hubspot',
    Lightbox                = 'lightbox',
    MarcomPortalAsset       = 'marcom-portal-asset',
    MarcomPortalLibrary     = 'marcom-portal-library',
    MicrosoftSso            = 'microsoft-sso',
    Permalinks              = 'permalinks',
    Slack                   = 'slack',
    UserGroups              = 'usergroups',
    Wordpress               = 'wordpress'
}
