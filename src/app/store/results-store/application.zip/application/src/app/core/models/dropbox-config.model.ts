export interface DropboxConfig {
	appKey: string,
	type: string
}