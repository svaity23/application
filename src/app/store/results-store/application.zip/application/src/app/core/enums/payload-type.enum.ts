export enum PayloadType {
  AccountProcessed = 'ACCOUNT_PROCESSED',
  DownloadConversionReady = 'DOWNLOAD_CONVERSION_READY',
  ThumbnailReady = 'THUMBNAIL_READY',
  FileUploaded = 'FILE_UPLOADED',
  ShareProcessed = 'SHARE_PROCESSED',
  TaggingReady = 'TAGGING_READY',
  HubspotSyncAssetStarted = 'HUBSPOT_SYNC_ASSET_STARTED',
  HubspotSyncAssetSuccess = 'HUBSPOT_SYNC_ASSET_SUCCESS',
  HubspotSyncAssetError = 'HUBSPOT_SYNC_ASSET_ERROR',
  UserSynced = 'USER_SYNCED',
  Error = 'ERROR',
  ProvisionError = 'PROVISION_ERROR',
  NotificationInitiated = 'NOTIFICATION_INITIATED'
}
