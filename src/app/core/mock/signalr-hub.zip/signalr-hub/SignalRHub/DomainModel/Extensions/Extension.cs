﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SignalRHub.DomainModel.Extensions
{
    public static class Extension
    {
        public static string ToJsonString(this object value)
        {
            var settings = new JsonSerializerSettings();
            settings.ContractResolver = new CamelCasePropertyNamesContractResolver();
            var jsonString = JsonConvert.SerializeObject(value, settings);
            return jsonString;
        }
    }
}
