﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ApplicationLogic.DomainModel
{
    [Table("metadata")]
    [Index(nameof(AssetId), nameof(MetadataFieldId), Name = "uniq_metadata_assetId_metadataFieldId", IsUnique = true)]
    public partial class Metadatum
    {
        [Key]
        [Column("id")]
        public Guid Id { get; set; }
        [Column("accountId")]
        public Guid AccountId { get; set; }
        [Column("active")]
        public bool Active { get; set; }
        [Column("created")]
        public DateTime Created { get; set; }
        [Column("modified")]
        public DateTime? Modified { get; set; }
        [Column("value")]
        [StringLength(500)]
        public string Value { get; set; }
        [Column("assetId")]
        public Guid AssetId { get; set; }
        [Column("metadataFieldId")]
        public Guid MetadataFieldId { get; set; }

        [ForeignKey(nameof(AccountId))]
        [InverseProperty("Metadata")]
        public virtual Account Account { get; set; }
        [ForeignKey(nameof(AssetId))]
        [InverseProperty("Metadata")]
        public virtual Asset Asset { get; set; }
    }
}
