﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ApplicationLogic.Logic
{
    public class MetadataProfileLogic
    {
        public ILogger<MetadataProfileLogic> Logger { get; set; }

        private readonly MetadataProfileFinder _finder;

        public MetadataProfileLogic(damContext context)
        {
            _finder = new MetadataProfileFinder(context);
            Logger = NullLogger<MetadataProfileLogic>.Instance;
        }

        public async Task<string> GetMetadataProfilesByAccountIdAsync(Guid accountId)
        {
            return await _finder.GetMetadataProfilesByAccountIdAsync(accountId);
        }
        public async Task<string> GetMetadataProfileFieldsByProfileIdAsync(Guid accountId, Guid profileId)
        {
            return await _finder.GetMetadataProfileFieldsByProfileIdAsync(accountId, profileId);
        }
        public async Task<string> SaveMetadataProfileFieldsByProfileIdAsync(Guid accountId, string jsonInput)
        {
            return await _finder.SaveMetadataProfileFieldsByProfileIdAsync(accountId, jsonInput);
        }

    }
}
