import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { filter, first, map, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AccountTypeKey } from '@app/core/enums/account-type-key.enum';
import { AppStoreFacade } from '@app/store/app-store/app-store.facade';

@Injectable({
  providedIn: 'root'
})
export class AccountTrialGuard implements CanActivate {

  accountTypeKeyEnum = AccountTypeKey;
  constructor(private appStoreFacade: AppStoreFacade, private router: Router) { }

  canActivate(
    // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
    _route: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
    _state: RouterStateSnapshot,
    ): Observable<boolean | UrlTree>  {

      return this.isAccountTrialNotExpired();
  }

  private isAccountTrialNotExpired(): Observable<boolean | UrlTree> {
    return this.appStoreFacade.context.context$.pipe(
      tap(context => {
        if (!context) {
          this.appStoreFacade.loadContext();
        }
      }),
      filter(context => context != null),
      first(),
      map(context => {
        if (context.accountTypeName !== this.accountTypeKeyEnum.Trial) {
            return true
        } else {
            if(!context.accountTrialExpiration || new Date(context.accountTrialExpiration) < new Date()) {
                if (this.router.url.startsWith('/library')) {
                  // this will recreate the component, even if it is redirecting to itself
                  this.router.routeReuseStrategy.shouldReuseRoute = () => false;
                  this.router.onSameUrlNavigation = 'reload';
                }

                return this.router.parseUrl('/library');

            } else {
                return true;
            }
        }
      })
    );
  }
}
