﻿using ApplicationLogic.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Dtos;
using WebApi.Dtos.Asset.Hubspot;
using WebApi.Dtos.Setting;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class HubspotController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<HubspotController> _logger;
        private readonly HubspotService _service;
        private readonly SettingService _settingService;
        private readonly UserAccountService _userAccountService;

        public HubspotController(IConfiguration configuration, ILogger<HubspotController> logger, HubspotService service, SettingService settingService, UserAccountService userAccountService)
        {
            _configuration = configuration;
            _logger = logger;
            _service = service;
            _settingService = settingService;
            _userAccountService = userAccountService;
        }


        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetHubSpotAssets(int sortField, int skip, int pageSize, Guid? collectionId)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            _logger.LogInformation("### AppInsights InstrumentationKey ### - " +
                _configuration
                    .GetSection("ApplicationInsights")
                    .GetSection("InstrumentationKey").Value);

            GetEntitiesResponse<AssetDto> results = await _service.GetHubspotAssets(accountId, userId, sortField, skip, pageSize, collectionId);
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entities ?? new List<AssetDto>()),
                    3 => Forbid(),// the user doesn't have rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }

        [HttpGet("syncErrors")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetHubSpotSyncErrors()
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);

            GetEntityResponse<HubspotSyncErrorsDTO> results = await _service.GetHubspotSyncErrorsAsync(accountId);
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entity),
                    1 => NotFound(),// the user doesn't have rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }


        [HttpPost("resync")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> ResyncCollection([FromBody] HubspotCollectionDTO request)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();

            GetEntityResponse<SyncAllResponseDTO> results = await _service.ResyncCollectionAsync(accountId, userId, sessionId, request);
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entity),
                    1 => NotFound(),// the user doesn't have rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return BadRequest();
        }

        [HttpPost("stopsync")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> StopSyncCollection([FromBody] HubspotCollectionDTO request)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();

            GetEntityResponse<SyncAllResponseDTO> results = await _service.StopSyncCollectionAsync(accountId, userId, sessionId, request);
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entity),
                    1 => NotFound(),// the user doesn't have rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return BadRequest();
        }


        [HttpPost("bulk/adds")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> BulkAddHubspotAssetsAsync([FromBody] UpsertHubspotAssetsRequestDTO updateAssetRequest)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();

            if (updateAssetRequest == null)
            {
                return BadRequest();
            }

            return Ok(await _service.UpsertHubspotAssetsAsync(accountId, userId, sessionId, updateAssetRequest));
        }

        [HttpPost("bulk/deletes")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> BulkDeleteAssetsAsync([FromBody] DeleteHubspotAssetsRequestDTO deleteRequest)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();

            if (deleteRequest == null)
            {
                return BadRequest();
            }
            return Ok(await _service.DeleteHubspotAssetsAsync(accountId, userId, sessionId, deleteRequest));
        }


        [HttpPost("syncAll")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> SynchronizeAllAssetsAsync([FromBody] SyncAllRequestDTO requestDTO)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);

            GetEntityResponse<SyncAllResponseDTO> results = await _service.SyncAllAsync(accountId, requestDTO.SignalRConnectionId);
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entity),
                    1 => NotFound(),// the user doesn't have rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }

        [HttpPut("login")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<AreaSettingDto>))]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> LoginToHubspot([FromBody] AreaSettingDto update)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            UpsertResponse<AreaSettingDto> results = await _settingService.UpdateAccountSettings(accountId, userId, update);
            if (results != null)
            {
                int err = results.Errors[0].Code;
                if (err == 0)
                {
                    await _service.LoginToHubspotAsync(accountId, update?.StringValue);
                }
                return err switch
                {
                    0 => Ok(results.Entity ?? new AreaSettingDto()),
                    3 => Forbid(),// the user doesn't have admin rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return Ok();
        }

    }
}
