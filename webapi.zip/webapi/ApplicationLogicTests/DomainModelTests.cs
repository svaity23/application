﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ApplicationLogic.Logic;

namespace ApplicationLogic.Tests
{
    [TestClass()]
    [Ignore]
    public class DomainModelTests
    {
        private Guid AliceId = Guid.Parse("A28C7E8F-8D69-4DF3-9F61-A9FF883FF9C0");
        private damContext _context;

        [TestInitialize]
        public void Init()
        {
            var configuration = new ConfigurationBuilder()
                       .AddJsonFile("appsettings.json", true, true)
                       .Build();

            var optionBuilder = new DbContextOptionsBuilder<damContext>();
            optionBuilder.UseSqlServer(configuration["ConnectionStrings:damDbConnection"]);

            var loggerFactory = (ILoggerFactory)new LoggerFactory();
            var logger = loggerFactory.CreateLogger<AzureAccessTokens>();

            _context = new damContext(optionBuilder.Options,
                new AzureAccessTokens(logger),
                new Microsoft.Extensions.Logging.Abstractions.NullLogger<damContext>(),
                configuration);
        }

        [TestMethod()]
        [Ignore]
        public async Task CreateMetaDataTest()
        {
            var accountId = Guid.Parse("BC3ADB5D-2E37-4F9F-8108-3304328A7CFF");
            var assetId = Guid.Parse("1A483A02-4170-4358-9A11-086F2A35B5B7");
            var metaDataFieldId = Guid.Parse("F0AEEFA7-6B2C-4831-93FA-F1A0BFC186BF");



            var metaData = new Metadata
            {
                AccountId = accountId,
                AssetId = assetId,
                MetadataFieldId = metaDataFieldId,
                Value = "bem test"
            };



            _context.Metadata.Add(metaData);
            await _context.SaveChangesAsync();



            Assert.IsNotNull(metaData.Id);
        }

        [TestMethod()]
        public async Task GetUserTest()
        {
            var user = await _context.FindAsync<User>(AliceId);
            Assert.IsNotNull(user);
            Assert.AreEqual("Alice", user.FirstName);
            Assert.IsNull(user.Account); // we aren't using Lazy Loading.
        }

        [TestMethod()]
        public async Task GetUserAccountExplicitTest()
        {
            var user = await _context.FindAsync<User>(AliceId);

            // This is an example of explicit loading 
            // see https://docs.microsoft.com/en-us/ef/core/querying/related-data#explicit-loading
            await _context.Entry(user)
            .Reference(u => u.Account)
            .LoadAsync();

            Assert.IsNotNull(user);
            Assert.AreEqual("Alice", user.FirstName);
            Assert.AreEqual("ACME Advertising", user.Account.Name);
        }

        [TestMethod()]
        public async Task GetUserQueryableTest()
        {

            // This is a simplified example of the following (without the join):
            // https://docs.microsoft.com/en-us/ef/core/querying/complex-query-operators#join

            var user = await
                        (from u in _context.User
                         where u.Id == AliceId
                         select new User()
                         {
                             Account = u.Account
                           ,
                             AccountId = u.AccountId
                           ,
                             FirstName = u.FirstName
                         }
                        )
                        .FirstOrDefaultAsync();

            Assert.IsNotNull(user);
            Assert.AreEqual("Alice", user.FirstName);
            Assert.IsNotNull(user.Account); // BY ALL RIGHTS, this should fail because we aren't using Lazy Loading.           
        }

        [TestMethod()]
        public async Task GetUserAccountQueryableTest()
        {
            // This is an example of eager loading 
            // see https://docs.microsoft.com/en-us/ef/core/querying/related-data#eager-loading

            var user = await _context.User
                            .Include(u => u.Account)
                            .Where(u => u.Id == AliceId)
                            .FirstOrDefaultAsync();

            Assert.IsNotNull(user);
            Assert.AreEqual("Alice", user.FirstName);
            Assert.AreEqual("ACME Advertising", user.Account.Name);
        }


        [TestMethod()]
        public async Task GetAccountByInvalidId()
        {
            // purposely using userId of alice which should not exists in account
            var account = await _context.FindAsync<Account>(AliceId);

            Assert.IsNull(account);
        }

        [TestMethod()]
        [Ignore]
        public async Task GetAccountUsers()
        {
            var accountId = Guid.Parse("BC3ADB5D-2E37-4F9F-8108-3304328A7CFF");
            //var accountId = Guid.Parse("BD9729B3-0810-4FC8-BC4D-4B7E171FC237");                
            var includeInactive = false;

            var results = await _context.User
              .Where(u =>
                  u.AccountId == accountId &&
                  (includeInactive ? u.Active == u.Active : u.Active == true)).ToListAsync();

            Assert.IsTrue(results.Count == 4);
        }

        [TestMethod()]
        [Ignore]
        public async Task TestQueryFromSqlByIdAsync()
        {
            var user = await _context.User
                .FromSqlInterpolated($"Select * from [User] where id = {AliceId}")
                .FirstOrDefaultAsync();
            Assert.IsNotNull(user);
        }

        [TestMethod()]
        [Ignore]
        public async Task TestQueryRaw()
        {
            var accountId = Guid.Parse("BC3ADB5D-2E37-4F9F-8108-3304328A7CFF");

            // demonstrate parameters as guids
            var guids = new List<Guid>() {
                    Guid.Parse("3E82249D-E7A8-4BF9-AA68-B2B7412A4969"),
                    Guid.Parse("AA3D1759-1497-4192-8549-510A87E700B4")
                };
            //var guidStr = string.Join(",", guids.Select(g => $"'{g}'"));
            var guidStr2 = string.Join(",", guids.Select(g => $"{g}"));
            //var result = await context.Database
            //    .ExecuteSqlInterpolatedAsync($"Select * from  [dbo].[user] where accountid = {accountId} and id in ({guidStr2})");

            var result = await _context.User.FromSqlInterpolated($"Select * from [User] where accountId = {accountId}").ToListAsync();
            Assert.IsNotNull(result);
        }
       
        [TestMethod()]
        [Ignore] // ignored because it creates too many rows
        public async Task NavigationPropertySemanticsOnInsertTest()
        {
            var userId = Guid.NewGuid();

            var user = new User
            {
                Id = userId,
                Active = true,
                Email = $"tom{DateTime.Now}@marcom.com",
                FirstName = "Tom",
                LastName = "William Hilliard",
            };

            var typeId = Guid.Parse("D7124D8F-7396-47CB-911F-96FC23817D99"); // trial account type on dev
            var account = new Account
            {
                Active = true,
                Name = "acme2" + DateTime.Now,
                Type = typeId,
                UserId = userId
            };

            account.User.Add(user);

            _context.Add(account);
            await _context.SaveChangesAsync();

            var checkUser = await _context.User
                            .Where(u => u.Id == user.Id)
                            .FirstOrDefaultAsync();

            Assert.AreEqual("Tom", checkUser.FirstName);
        }


        [TestMethod()]
        [Ignore]
        public async Task UpsertAccountTest()
        {
            var accountDTO = new
            {
                Name = "BEM(SBX - test sproc5)",                
                Active = true,
                UserEmail = "bem.test.sproc5@pti.com",
                UserFirstName = "b",
                UserLastName = "e"
            };
            var userId = Guid.Parse("bb905074-c3f3-42d4-818f-000000000000"); // fake guid

            var accountLogic = new AccountLogic(_context);

            var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(accountDTO);
            var result = await accountLogic.UpsertAccountAsync(userId, jsonString);

            Assert.AreEqual(result, "break "); // really use for dev testing only to see result
        }
    }
}
