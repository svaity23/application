﻿using Microsoft.AspNetCore.Authorization;
using System;

namespace WebApi.Authorization
{
    public class ScopesRequirement : IAuthorizationRequirement, IIdentifiable
    {
        public Guid Identifier { get; set; }
        public string Scopes { get; }

        public ScopesRequirement(string scopes, Guid identifier)
        {
            Scopes = scopes;
            Identifier = identifier;
        }
    }
}
