﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using WebApi.Dtos;
using WebApi.Dtos.Asset;
using WebApi.Extensions;

namespace WebApi.Services
{
    public class LightboxService
    {
        private readonly BlobService _blobService;
        private readonly LightboxLogic _lightboxLogic;
        private readonly LightboxAssetLogic _lightboxAssetLogic;
        private readonly IConfiguration _configuration;
        private readonly ILogger<LightboxService> _logger;
        private readonly JsonSerializerOptions _options = new JsonSerializerOptions()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };

        public LightboxService(IConfiguration configuration, ILogger<LightboxService> logger, BlobService blobService, damContext context)
        {
            _blobService = blobService;
            _configuration = configuration;
            _logger = logger;
            _lightboxLogic = new LightboxLogic(context);
            _lightboxAssetLogic = new LightboxAssetLogic(context);
        }

        /// <summary>
        /// Returns all lightboxes visible to the specified user, 
        /// together their details. This is used in the initialization process
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<GetEntitiesResponse<LightboxDto>> GetAllAsync(Guid accountId, Guid userId)
        {
            string resultJson = await _lightboxLogic.GetAllAsync(accountId, userId);
            GetEntitiesResponse<LightboxDto> result = JsonSerializer.Deserialize<GetEntitiesResponse<LightboxDto>>(resultJson, _options);
            return result;
        }

        public async Task<GetEntitiesResponse<LightboxPreviewDto>> GetPreviewAssetsAsync(Guid accountId, Guid userId)
        {
            string resultJson = await _lightboxLogic.GetPreviewAssetsAsync(accountId, userId);
            GetEntitiesResponse<LightboxPreviewDto> result = JsonSerializer.Deserialize<GetEntitiesResponse<LightboxPreviewDto>>(resultJson, _options);
            return result;
        }

        public async Task<GetEntityResponse<LightboxDto>> GetLightboxByIdAsync(Guid accountId, Guid userId, Guid id)
        {
            string resultJson = await _lightboxLogic.GetByIdAsync(accountId, userId, id);
            GetEntityResponse<LightboxDto> result = JsonSerializer.Deserialize<GetEntityResponse<LightboxDto>>(resultJson, _options);
            return result;
        }

        // TODO: This function needs revisiting or deleting. 
        // This passes in a single id to delete but returns an array of deleted items.
        // It also returns an UpsertResponse
        public async Task<UpsertResponse<List<Guid>>> DeleteAsync(Guid accountId, Guid userId, Guid id)
        {
            BulkDeleteRequestDTO lightboxes = new BulkDeleteRequestDTO
            {
                Ids = new Guid[] { id }
            };
            var jsonIdArray = JsonSerializer.Serialize(lightboxes, _options);
            var resultJson = await _lightboxLogic.DeleteAsync(accountId, userId, jsonIdArray);
            UpsertResponse<List<Guid>> result = JsonSerializer.Deserialize<UpsertResponse<List<Guid>>>(resultJson, _options);
            return result;
        }

        public async Task<DeleteEntityResponse<Guid>> DeleteByIdAsync(Guid accountId, Guid userId, Guid id)
        {
            var resultJson = await _lightboxLogic.DeleteByIdAsync(accountId, userId, id);
            DeleteEntityResponse<Guid> result = JsonSerializer.Deserialize<DeleteEntityResponse<Guid>>(resultJson, _options);
            return result;
        }

        public async Task<UpsertResponse<LightboxDto>> UpsertLightboxAsync(Guid accountId, Guid userId, LightboxDto lightbox)
        {
            var json = lightbox.ToJsonString();
            var resultJson = await _lightboxLogic.UpsertLightboxAsync(accountId, userId, json);
            UpsertResponse<LightboxDto> result = JsonSerializer.Deserialize<UpsertResponse<LightboxDto>>(resultJson, _options);
            return result;
        }

        public async Task<LightboxPublicDto> GetBaseLightboxPublicAsync(Guid id)
        {
            // Get base lightbox.
            var jsonOutput = await _lightboxLogic.GetByIdAsync(id);
            GetEntityResponse<LightboxPublicDto> lightboxPublicResponse = Newtonsoft.Json.JsonConvert.DeserializeObject<GetEntityResponse<LightboxPublicDto>>(jsonOutput);
            LightboxPublicDto lightboxPublic = lightboxPublicResponse.Entity;
            return lightboxPublic;            
        }

        public async Task<LightboxPublicDto> GetLightboxPublicAsync(Guid id, int sortField, int skip, int pageSize)
        {            
            // Get base lightbox.
            var jsonOutput = await _lightboxLogic.GetByIdAsync(id);            
            GetEntityResponse<LightboxPublicDto> lightboxPublicResponse = Newtonsoft.Json.JsonConvert.DeserializeObject<GetEntityResponse<LightboxPublicDto>>(jsonOutput);            
            LightboxPublicDto lightboxPublic = lightboxPublicResponse.Entity;
            
            if (lightboxPublic == null)
            {
                return null;
            }
            var currentDate = DateTime.Today;
            if (lightboxPublic?.ExpirationDate < currentDate)
            {
                return null;
            }
            // Need accountId from lightbox entity so we know how to construct the asset uris.
            var accountId = lightboxPublic.AccountId;
            var storageAccountName = _configuration["BlobStorage:StorageAccountName"];
            var sasTokens = await _blobService.GetContainerSasTokens(storageAccountName, accountId ?? Guid.Empty, 1440);

            // Get assets inside lightbox
            var listParams = new LightboxAssetListParamsDto
            {
                SortField = sortField,
                LightboxId = id,
                Skip = skip,
                PageSize = pageSize,
                IncludeInactive = false
            };
            var jsonString = listParams.ToJsonString();
            var jsonOutputAssets = await _lightboxAssetLogic.GetLightboxAssetsById(id, jsonString);
            // TODO: refactor to merge 2 database calls to pull lightbox data and assets in single webApi call
            //       or 2 client calls to get lightbox details and assets 
            GetEntitiesResponse<LightboxAssetDto> lightboxAssets = Newtonsoft.Json.JsonConvert.DeserializeObject<GetEntitiesResponse<LightboxAssetDto>>(jsonOutputAssets);

            return new LightboxPublicDto
            {
                AssetCount = lightboxPublic.AssetCount,
                AccountId = lightboxPublic.AccountId,
                Name = lightboxPublic.Name,
                Assets = lightboxAssets.Entities,
                SasTokens = sasTokens,
                StorageAccountName = storageAccountName,
                AccountLogo = lightboxPublic.AccountLogo,
                AccountTheme = lightboxPublic.AccountTheme
            };
        }
    }
}
