﻿using System;
using System.Text.Json.Serialization;

namespace WebApi.Dtos.Asset.Response
{
    public class MetadatumUpdateDto
    {
        [JsonPropertyName("assetId")]
        public Guid AssetId { get; set; }

        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [JsonPropertyName("metadataFieldId")]
        public Guid MetadataFieldId { get; set; }

        [JsonPropertyName("metadataFieldTypeId")]
        public int MetadataFieldTypeId { get; set; }

        [JsonPropertyName("metadataFieldValueId")]
        public Guid? MetadataFieldValueId { get; set; }

        [JsonPropertyName("modified")]
        public DateTime? Modified { get; set; }

        [JsonPropertyName("modifiedByUserFullName")]
        public string ModifiedByUserFullName { get; set; }

        [JsonPropertyName("value")]
        public string Value { get; set; }

    }
}
