﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using System.IO;
using System.Threading.Tasks;
using UploadAsset.Dtos;
using UploadAsset.Extensions;
using UploadAsset.Services;

namespace UploadAsset.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize(Policy = "FullOrLimitedApi")]
    public class UploadController : ControllerBase
    {
        private readonly ILogger<UploadController> _logger;
        private readonly UploadService _uploadService;
        private readonly UserAccountService _userAccountService;


        public UploadController (ILogger<UploadController> logger, UploadService uploadService, UserAccountService userAccountService)
        {
            _logger = logger;
            _uploadService = uploadService;
            _userAccountService = userAccountService;

            logger.LogDebug("Unconditional debug line");
        }

        /// <summary>
        /// Upload file
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        //public async Task Upload([FromForm] FileUploadRequest request)
        public async Task Upload()
        {
            try
            {
                var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
                var userId = this.User.GetUserId();

                var boundary = HeaderUtilities.RemoveQuotes(MediaTypeHeaderValue.Parse(HttpContext.Request.ContentType).Boundary).Value;
                var formReader = new MultipartReader(boundary, HttpContext.Request.Body);

                await _uploadService.ProcessFileUploadAsync(formReader, accountId, userId); // old multipart for reader way
                //await _uploadService.UploadFileAsync(Response, request, accountId); // todo - revisit
                //await Response.CompleteAsync();
            }
            catch (BadHttpRequestException ex)
            {
                _logger.LogWarning(ex, "BadHttpRequest");

                // Incase we can't gaurantee that BadHttpRequestException has a StatusCode of Status413PayloadTooLarge...
                // Check for it here and return appropriate status code.
                // This scenario should not really occur. The validateAndCreate sproc should reject files that are too large and this
                // request should not occur.
                if (ex.StatusCode == StatusCodes.Status413PayloadTooLarge)
                {
                    //return StatusCode(StatusCodes.Status413PayloadTooLarge);
                    Response.StatusCode = StatusCodes.Status413PayloadTooLarge;
                }

                // Let error pass threw and have ExceptionHandlerMiddleware handle it.
                throw;
            }
            catch (IOException ioEx)
            {
                // Upload cancelled.
                _logger.LogWarning(ioEx, "Upload cancelled");
                Response.StatusCode = StatusCodes.Status200OK;
            }
        }

        // If below commented out, it's because there's a MapGet line in startup.cs Configure() that does this.
        //[AllowAnonymous]
        //[HttpGet]
        //public JsonResult UploadGet()
        //{
        //    _logger.LogInformation("Unconditional information line");
        //    return new JsonResult( new { status = "OK" });
        //}


        // Test policies
        [Authorize(Policy = "FullOrLimitedApi")]
        [HttpGet("Test")]
        public JsonResult UploadGet()
        {
            _logger.LogInformation("Unconditional information line");
            return new JsonResult(new { status = "OK" });
        }
    }
}
