# Introduction
MarcomCentral's digitial asset management (DAM) product

# Getting Started

### 1.	Installation process
Install and run a dev server.  Navigate to [http://localhost:4200](http://localhost:4200).  The app will automatically reload if you change any of the source files.
```cmd
    npm install
```
```cmd
    npm start
```

### 2.	Software dependencies
### 3.	Latest releases
### 4.	API references

# Build and Test

## Build
 ### Run 'ng build' to build the project. The build artifacts will be stored in the `dist/` directory.
 Use the `--prod` flag for a production build.
```cmd
    ng build
```

## Running unit tests
Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).
```cmd
    ng test
```

## Running end-to-end tests
Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).
```cmd
    ng e2e
```

# Contribute
TODO: Explain how other users and developers can contribute to make your code better.

- [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md)
- [NgRx](https://ngrx.io/docs)
- [Visual Studio Code](https://github.com/Microsoft/vscode)

# Container Development

For those with Windows 10 Proffesional or Enterprise, it's possible to run this application within a container.

### Install Docker

Install [Docker For Windows](https://hub.docker.com/editions/community/docker-ce-desktop-windows).

### Build and Run the Container

The DockerFile in this project uses a [multi-stage build](https://docs.docker.com/develop/develop-images/multistage-build/) to build the application in a container! Feel free to view the DockerFile at the root of this project. Port 4200 is exposed/used so the IDP works (allowed redirect URLs). Make sure port 4200 isn't in use (for example, if an "ng s -o" was used) and from the root directory of this project, execute these commands:

```cmd
    docker build . -t application:v1
    docker run  --name "application" --rm -d -p 4200:5080 application:v1
    start explorer http://localhost:4200
```

When you are done viewing your website, issue a docker stop command.

```cmd
    docker stop application
```

