﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Dynamic;
using System.Text.Json;
using System.Text.Json.Serialization;
using WebApi.Dtos;
using WebApi.Dtos.Context;
using WebApiTests.Shared;

namespace WebApiTests.Services
{
    [TestClass]
    public class DBContextServiceTest
    {
        #region [Click to open] Test initialization and configuration...
        private static damContext dbContext;
        private static UserLogic _userLogic;
        private static UserDetailDto adminUser;
        private static UserDetailDto contributorUser;
        private static UserDetailDto viewerUser;





        private static readonly Random _rnd = new Random();
        private static readonly Guid TEST_ACCOUNT = Guid.Parse("5189526F-642F-449F-B018-5F5027A7191B"); // marcel@saguaro.ro
        private const string COMMENT_PREFIX = "~MSTest~ ";



        private static readonly JsonSerializerOptions options = new JsonSerializerOptions()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };


        [ClassInitialize]
        public static void BeforeClass(TestContext context)
        {
            Debug.WriteLine("Before all tests");
            dbContext = AzureSQLTools.InitializeDamContext();

            _userLogic = new UserLogic(dbContext);
            adminUser = AzureSQLTools.GetTestUser(dbContext, "admin", TEST_ACCOUNT);
            contributorUser = AzureSQLTools.GetTestUser(dbContext, "contributor", TEST_ACCOUNT);
            viewerUser = AzureSQLTools.GetTestUser(dbContext, "viewer", TEST_ACCOUNT);
        }

        [ClassCleanup]
        public static void AfterClass()
        {
            Debug.WriteLine("Clean up after all tests");
        }

        [TestInitialize]
        public void BeforeTest()
        {
            Debug.WriteLine("...Prepare test");
        }

        [TestCleanup]
        public void AfterTest()
        {
            Debug.WriteLine("...Clear test\n");
        }

        public static bool ItHasProperty(dynamic settings, string name)
        {
            if (settings is ExpandoObject)
                return ((IDictionary<string, object>)settings).ContainsKey(name);

            return settings.GetType().GetProperty(name) != null;
        }
        #endregion

        [TestMethod("Get context for admin user - normal case")]
        public void GetAdminContext_FromApp()
        {
            string json = _userLogic.GetUserContext(TEST_ACCOUNT, adminUser.Id, false).Result;
            GetEntitiesResponse<UserContextDto> result = JsonConvert.DeserializeObject<GetEntitiesResponse<UserContextDto>>(json);
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Entities);
            Assert.IsNotNull(result.Error);
            Assert.AreEqual(1, result.Entities.Count);
            Assert.AreEqual(0, result.Error.Code);

            UserContextDto uc = result.Entities[0];

            bool createFound = false;
            foreach (PermissionDto p in uc.Permissions)
            {
                if (p.Key.Contains("create")) createFound = true;
            }
            Assert.IsTrue(createFound);

        }

        [TestMethod("Get context for admin user - plugin case")]
        public void GetAdminContext_FromPlugin()
        {
            string json = _userLogic.GetUserContext(TEST_ACCOUNT, adminUser.Id, true).Result;
            GetEntitiesResponse<UserContextDto> result = JsonConvert.DeserializeObject<GetEntitiesResponse<UserContextDto>>(json);
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Entities);
            Assert.IsNotNull(result.Error);
            Assert.AreEqual(1, result.Entities.Count);
            Assert.AreEqual(0, result.Error.Code);

            UserContextDto uc = result.Entities[0];

            Assert.AreEqual(0, uc.Notifications.Count);
            bool createFound = false;
            foreach(PermissionDto p in uc.Permissions)
            {
                if (p.Key.Contains("create")) createFound = true;
            }
            Assert.IsFalse(createFound);

        }


        /*
        [DataTestMethod]
        [DynamicData("UsersToTestWith")]
        public void CheckContextForGroupId(User user)
        {
            try
            {
                dynamic context = sut.GetUserContextByUserId(user.Id, user.AccountId).Result;
                Assert.IsNotNull(context);
                Assert.IsNotNull(ItHasProperty(context, "GroupId"));
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }

        }

        public static IEnumerable<User[]> UsersToTestWith
        {
            get
            {
                return new[]
                {
                    new User[] { adminUser },
                    new User[] { contributorUser },
                    new User[] { viewerUser }
                };
            }
        }

        */


    }
}
