import { AssetFile } from './asset-file.model';

export interface DropboxFile extends AssetFile {
	link: string;
}
