﻿using System;

namespace WebApi.Dtos.Asset.Request
{
    public class ShareAssetsRequestDto
    {
        public Guid[] Ids { get; set; }
        public int DaysValid { get; set; }
        public string Source { get; set; }
    }
}
