import { Frame } from './frame.model';

export interface Page {
    blobDetails?: string;
    frames?: Frame[];
    height?: number;
    imageFrames?: Frame[]; // subset of frames
    logMessages?: string;
    messageType?: string;
    pageIndex?: number;
    textFrames?: Frame[]; // subset of frames
    url?: string; // native size / high resolution
    width?: number;

    // fontUsage?: string;
    // id: string;
    // imageFrames: Frame[];
    // pageNumber?: number;
    // textFrames: Frame[];

}