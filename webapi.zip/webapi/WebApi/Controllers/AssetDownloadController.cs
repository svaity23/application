﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;
using System.Web;
using WebApi.Dtos.Asset.Request;
using WebApi.Services;

namespace WebApi.Controllers
{
    [Route("[controller]")]
    [AllowAnonymous]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class AssetDownloadController : ControllerBase
    {
        private ILogger<AssetDownloadController> _logger;
        private AssetService _assetService;

        public AssetDownloadController(ILogger<AssetDownloadController> logger, AssetService assetService)
        {
            _logger = logger;
            _assetService = assetService;
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status302Found)]
        public async Task<IActionResult> DownloadSharedLink(string mg_san, string mg_cn, string mg_bn, string mg_aid, string mg_uid, string mg_accid, string multiple)
        {
            var storageAccountName = mg_san;
            var containerName = mg_cn;
            var blobName = mg_bn;
            var assetId = multiple == "true"? Guid.Empty : Guid.Parse(mg_aid);
            var userId = Guid.Parse(mg_uid);
            var accountId = Guid.Parse(mg_accid);

            if(assetId != Guid.Empty)
            {
                // single asset, make sure its still active.  AssetForPreview filter for active assets.
                var asset = await _assetService.GetAssetForPreviewAsync(accountId, assetId, userId, true);
                if(asset == null)
                {
                    return NotFound();
                }
            }

            var requestQuery = HttpContext.Request.Query;

            UriBuilder fullUri = new UriBuilder()
            {
                Scheme = "https",
                Host = string.Format(CultureInfo.InvariantCulture, "{0}.blob.core.windows.net", storageAccountName),
                Path = string.Format(CultureInfo.InvariantCulture, "{0}/{1}", containerName, blobName),
                Query = ""
             };
            
            foreach(var pKey in requestQuery.Keys)
            {
                if (!pKey.StartsWith("mg_", StringComparison.InvariantCulture)) {
                    if (fullUri.Query.Length > 0) fullUri.Query += '&';
                    requestQuery.TryGetValue(pKey, out StringValues pValue);
                    var encValue = HttpUtility.UrlEncode(pValue.ToString());
                    fullUri.Query += $"{pKey}={encValue}";
                }
            }
            if (string.IsNullOrEmpty(multiple))
            {
                UseageRequestDTO usage = new UseageRequestDTO()
                {
                    Action = "accessLink",
                    AssetIds = new List<Guid> { assetId }
                };
                await _assetService.RecordAssetUsage(accountId, userId, null, usage);
            }
            _logger.LogDebug("Redirect to: "+fullUri.ToString());

            return Redirect(fullUri.ToString());
        }

    }
}
