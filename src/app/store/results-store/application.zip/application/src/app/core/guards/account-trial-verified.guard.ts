import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { filter, first, map, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AccountTypeKey } from '@app/core/enums/account-type-key.enum';
import { AppStoreFacade } from '@app/store/app-store/app-store.facade';
import { Context } from '../models/context.model';

@Injectable({
  providedIn: 'root'
})
export class AccountTrialVerifiedGuard implements CanActivate {

  accountTypeKeyEnum = AccountTypeKey;
  constructor(private appStoreFacade: AppStoreFacade, private router: Router) { }

  canActivate(
    // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
    _route: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
    _state: RouterStateSnapshot,
  ): Observable<boolean | UrlTree> {

    return this.isAccountTrialVerified(_state);
  }

  private isAccountTrialVerified(state: RouterStateSnapshot): Observable<boolean | UrlTree> {
    return this.appStoreFacade.context.context$.pipe(
      tap(context => {
        if (!context) {
          this.appStoreFacade.loadContext();
        }
      }),
      filter(context => context != null),
      first(),
      map((context: Context) => {
        // old free trial accounts accountTrialVerified was set to null, handling that unique case, until data is seeded.
        if (context.accountTypeName !== this.accountTypeKeyEnum.Trial || context.accountTrialVerified === true || context.accountTrialVerified == null) {
          return true
        } else {
          this.appStoreFacade.evaluateAndOpenUnverifiedTrialAccountModal(
            () => { },
            () => { }
          );

          // kinda hacky, and this list might grown depending on where we want the user might end up
          if (state.url.indexOf('account/users') > 0) {
            return this.router.parseUrl('account/users');
          } else {
            // the catch all for other routes we need to restrict
            return this.router.parseUrl('library');
          }
        }
      })
    );
  }
}
