export interface User {
    accountCount?: number | null;    // number of accounts user in
    accountId: string; // guid
    accountName: string; // company name
    active: boolean | true;
    email: string;
    emailVerified?: boolean;
    externalId: string;
    federated?: boolean;
    firstName: string;
    groupId: string; // guid
    id: string; // guid
    lastLoginDate?: Date;
    lastName: string;
    roleId: string; // guid
    roleKey: string;
    roleName: string;
    selected: boolean | false;
}
