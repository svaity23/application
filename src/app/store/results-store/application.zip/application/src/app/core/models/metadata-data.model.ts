export interface MetadataData { // TODO: rename MetadataData just for storing temp. metada values
    metadataFieldId: string;
    metadataFieldValueId: string;
    value: string;
}
