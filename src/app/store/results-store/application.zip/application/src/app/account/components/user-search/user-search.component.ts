import {  ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { cn } from 'src/utils/cn';

import { AccountTypeKey } from '@app/core/enums/account-type-key.enum';
import { Context } from '@app/core/models/context.model';
import { User } from '@app/core/models/entities/user.model';


@Component({
  selector: 'app-user-search',
  templateUrl: './user-search.component.html',
  styleUrls: ['./user-search.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UserSearchComponent implements OnInit, OnChanges {
  accountTypeKeyEnum = AccountTypeKey;
  @Output() addNewUser = new EventEmitter();
  @Input() className = '';
  @Input() context: Context;
  @Output() downloadAllUsers = new EventEmitter();
  isEnabled = false;
  @Output() searchInputChange: EventEmitter<string> = new EventEmitter<string>();
  @Input() searchText: string;
  @Input() selectedUsers: User[];
  show = false;
  @Output() uploadMultipleUsers = new EventEmitter();
  visible = false;

  constructor() { }

  create(): void {
    this.addNewUser.emit();
  }

  downloadUsers(): void {
    this.downloadAllUsers.emit();
  }

  filterUsers(): void {
    this.searchInputChange.emit(this.searchText);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.searchText?.currentValue) {
      this.toggleSearchButton();
    }
  }

  ngOnInit(): void {
    this.className = cn('user-search', this.className);
  }

  onInputTextFocus(): void {
    this.show = true;
    this.isEnabled = false;
  }

  toggleSearchButton(): void {
    this.show = true;
    this.isEnabled = true;
  }

  uploadUsers(): void {
    this.uploadMultipleUsers.emit();
  }
}

