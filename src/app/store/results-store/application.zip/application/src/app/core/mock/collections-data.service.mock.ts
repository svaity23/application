import { Injectable } from '@angular/core';

import * as faker from 'faker/locale/en_US';
import { Observable } from 'rxjs';

import { Asset } from '../models/entities/asset.model';
import { Collection } from '../models/entities/collection.model';
import { CollectionsDataServiceInterface } from '../data-services/collections-data.service';
import { VisibleToType } from '../enums/visible-to-type.enum';

@Injectable({ providedIn: 'root' })
export class CollectionsDataServiceMock implements CollectionsDataServiceInterface {
    private internalCollectionList: Collection[] = [];

    constructor() {
        const oneCollection = (id: string, parentId?: string): Collection => {
            const collection: Collection = {
                id,
                parentId,
                name: faker.commerce.productName(),
                assetCount: faker.random.number({ min: 1, max: 2000 }),
                hubspotAssetCount: faker.random.number({ min: 1, max: 2000 }),
                isFavorited: faker.random.boolean(),
                groupIds: [],
                visibleTo: VisibleToType.All
            };
            return collection;
        };

        const randomCollections = (count = faker.random.number({ min: 5, max: 10 }), parentId?: string, startId = 1) => {
            const results = [];
            for (let i = startId; i < startId + count; i++) {
                results.push(oneCollection(i.toString(), parentId?.toString()));
            }
            return results;
        };

        const randomWithSubCollection = (parentCollections: Collection[]): Collection[] => {
            let results = [...parentCollections];
            const iterations = faker.random.number({ min: 1, max: parentCollections.length / 2 });
            for (let i = 0; i < iterations; i++) {
                // eslint-disable-next-line prefer-spread
                const startId = Math.max.apply(Math, results.map(o => o.id));
                const randomParent = faker.random.arrayElement(parentCollections);

                results = results.concat(randomCollections(faker.random.number({ min: 2, max: 5 }), randomParent.id, startId));
            }
            return results;
        };

        this.internalCollectionList = randomWithSubCollection(randomCollections());

        // need this for testing Search functionality - DND
        // const defaultCollections: Collection[] = [
        //     { id: '1', parentId: undefined, name: '2019 Spring Photoshoot', assetCount: 1123, isFavorited: faker.random.boolean(), selected: true },
        //     { id: '2', parentId: undefined, name: '2019 Summer Photoshoot', assetCount: 14, isFavorited: faker.random.boolean() , selected: false},
        //     { id: '3', parentId: undefined, name: '2019 Winter Photoshoot', assetCount: 15, isFavorited: faker.random.boolean() , selected: false},
        //     { id: '4', parentId: undefined, name: 'Athletics', assetCount: 156, isFavorited: faker.random.boolean() , selected: false},
        //     { id: '5', parentId: undefined, name: 'Art/Design', assetCount: 123, isFavorited: faker.random.boolean() , selected: false},
        //     { id: '6', parentId: '1', name: 'Graduation Photos', assetCount: 305, isFavorited: faker.random.boolean() , selected: false},
        //     { id: '7', parentId: '1', name: 'Faculty Portraits', assetCount: 35, isFavorited: faker.random.boolean() , selected: false},
        //     { id: '8', parentId: '1', name: 'Classroom', assetCount: 65, isFavorited: faker.random.boolean() , selected: false},
        //     { id: '9', parentId: '1', name: 'Other Photos', assetCount: 95, isFavorited: faker.random.boolean() , selected: false},
        //     { id: '10', parentId: '4', name: 'Graduation Photos', assetCount: 95, isFavorited: faker.random.boolean() , selected: false},
        //     { id: '11', parentId: '4', name: 'Homecoming Weekend', assetCount: 95, isFavorited: faker.random.boolean() , selected: false},
        //     { id: '12', parentId: '4', name: 'Springfest Photos', assetCount: 95, isFavorited: faker.random.boolean() , selected: false},
        //     { id: '12', parentId: '4', name: 'Athletics Photos', assetCount: 95, isFavorited: faker.random.boolean() , selected: false},
        //     { id: '13', parentId: '3', name: 'Community', assetCount: 95, isFavorited: faker.random.boolean() , selected: false},
        //     { id: '14', parentId: '3', name: 'Class Images', assetCount: 95, isFavorited: faker.random.boolean() , selected: false},
        //     { id: '15', parentId: undefined, name: '2019 Fall Photoshoot', assetCount: 15, isFavorited: faker.random.boolean() , selected: false},
        // ];

        // this.internalCollectionList = defaultCollections;
    }

    add(collectionName: string, parentId: string): Observable<Collection> {
        return new Observable(observer => {
            const collection: Collection = {
                id: faker.random.number().toString(),
                parentId,
                name: collectionName,
                assetCount: 0,
                hubspotAssetCount: 0,
                isFavorited: false,
                groupIds: [],
                visibleTo: VisibleToType.All
            };
            const collectionCount = this.internalCollectionList.length + 1;
            this.internalCollectionList.splice(collectionCount, 0, { ...collection });
            const clone = JSON.parse(JSON.stringify(collection));
            // Yield a single value and complete
            observer.next(clone);
            observer.complete();
        });
    }
    delete(id: string): Observable<string> {
        throw new Error('Method not implemented.' + id.toString());
    }

    deleteIncludeSubs(id: string): Observable<string[]> {
        throw new Error('Method not implemented.' + id.toString());
    }

    filterCollections(searchText: string): Observable<Collection[]> {
        return new Observable(observer => {
            const items =
                this.internalCollectionList.filter(c => {
                    return c.name.toString().toLocaleLowerCase().includes(searchText.toLocaleLowerCase());
                });

            const newArray: Collection[] = [];
            items.forEach(element => {
                if (element.parentId != null) {
                    const item = this.internalCollectionList.find(x => x.id === element.parentId);
                    if (!newArray.includes(element)) {
                        newArray.push(item);
                        newArray.push(element);
                    }
                } else {
                    if (!newArray.includes(element)) {
                        newArray.push(element);
                    }
                }
            });
            // Yield a single value and complete
            const clone = JSON.parse(JSON.stringify(newArray));

            observer.next(clone);
            observer.complete();
        });
    }

    getAll(): Observable<Collection[]> {
        return new Observable(observer => {
            // clone this internal list because store-freeze will make it immutable later in the dispatch pipeline
            const clone = JSON.parse(JSON.stringify(this.internalCollectionList));

            // Yield a single value and complete
            observer.next(clone);
            observer.complete();
        });
    }

    getById(id: string): Observable<Collection> {
        return new Observable(observer => {
            const item = this.internalCollectionList.find(x => x.id === id);

            // Yield a single value and complete
            observer.next(item);
            observer.complete();
        });
    }

    loadCollectionsWithAssets(assets: Asset[], collections: Collection[]): Observable<Collection[]> {
        return new Observable(observer => {
            const assetsWithCollection = assets.filter(asset => {
                return asset.collectionId != null;
            });
            const collectionIds = assetsWithCollection.map(c => c.collectionId);
            const filteredCollections = collections.filter(collection => collectionIds.includes(collection.id));
            const newArray: Collection[] = [];
            filteredCollections.forEach(element => {
                if (!newArray.includes(element)) {
                    newArray.push(element);
                }
            });
            // Yield a single value and complete
            const clone = JSON.parse(JSON.stringify(newArray));

            observer.next(clone);
            observer.complete();
        });
    }

    move(collectionId: string, parentId: string): Observable<Collection[]> {
        return new Observable(observer => {
            // clone this internal list because store-freeze will make it immutable later in the dispatch pipeline
            const clone: Collection[] = JSON.parse(JSON.stringify(this.internalCollectionList));
            const found = clone.find(c => c.id === collectionId);
            if (found) {
                found.parentId = parentId;
            }

            // Yield a single value and complete
            observer.next(clone);
            observer.complete();
        });
    }

    update(collection: Collection): Observable<Collection> {
        return new Observable(observer => {
            const itemToModify = this.internalCollectionList.find(x => x.id === collection.id);
            const indexToModify = this.internalCollectionList.indexOf(itemToModify);

            this.internalCollectionList.splice(indexToModify, 1, { ...collection });

            // Yield a single value and complete
            observer.next(collection);
            observer.complete();
        });
    }
}
