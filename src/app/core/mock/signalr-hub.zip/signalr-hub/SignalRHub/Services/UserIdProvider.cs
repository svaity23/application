﻿using Microsoft.AspNetCore.SignalR;
using System;
using System.Linq;
using System.Security.Claims;

namespace SignalRHub.Services
{
    public class UserIdProvider : IUserIdProvider
    {
        public string GetUserId(HubConnectionContext connection)
        {
            var user = connection.User;
            var userId = GetClaim(user, "extension_userId")?.Trim();
            if (!string.IsNullOrEmpty(userId)) {
                return userId;
            }

            var sub = GetClaim(user, "sub")?.Trim();
            if (!string.IsNullOrEmpty(sub))
            {
                return sub;
            }            
            
            throw new ApplicationException("User does not have a valid claim");
        }

        private static string GetClaim(ClaimsPrincipal user, string claimName)
        {
            var claimsPrincipal = user;
            var claims = from c in claimsPrincipal.Claims
                         where c.Type.ToLowerInvariant() == claimName.ToLowerInvariant()
                         select c.Value;

            return claims.LastOrDefault() ?? string.Empty;
        }
    }
}
