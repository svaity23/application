import { CustomTheme } from '../custom-theme.model';

export interface StorageFullModalOptions {
  cancel: () => void;
  cancelButtonText: string;
  message: string;
  selectedTheme?: CustomTheme;
  showUpgradeButton: boolean;
  title: string;
  upgrade: () => void;
  upgradeButtonText: string;
}