﻿using System;
using System.Text.Json.Serialization;

namespace WebApi.Dtos.Setting
{
    public class AreaSettingDto
    {
        [JsonPropertyName("key")]
        public string Key { get; set; }
        [JsonPropertyName("valueType")]
        public int ValueType { get; set; }

        [JsonPropertyName("boolValue")]
        public bool BoolValue { get; set; }
        [JsonPropertyName("intValue")]
        public int IntValue { get; set; }
        [JsonPropertyName("dateValue")]
        public DateTime DateValue { get; set; }
        [JsonPropertyName("stringValue")]
        public string StringValue { get; set; }



        // NewtonSoft is looking after the methods ShouldSerialize<PropertyName>
        // for determining if it should serialize it or not
        // https://www.linkedin.com/pulse/4-ways-make-property-deserializable-serializable-dean-xu
        public bool ShouldSerializeBoolValue()
        {
            return ValueType == 0;
        }
        public bool ShouldSerializeIntValue()
        {
            return ValueType == 1;
        }
        public bool ShouldSerializeDateValue()
        {
            return ValueType == 2;
        }
        public bool ShouldSerializeStringValue()
        {
            return ValueType == 3;
        }

    }
}
