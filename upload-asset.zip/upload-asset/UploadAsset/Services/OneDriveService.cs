﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace UploadAsset.Services
{
    public class OneDriveService
    {
        private readonly ILogger<OneDriveService> _logger;
        private readonly IConfiguration _configuration;        

        public OneDriveService(IConfiguration configuration, ILogger<OneDriveService> logger) {
            
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<Stream> GetFileStreamAsync(string fileUrl)
        {
            return await new HttpClient().GetStreamAsync(fileUrl); ;
        }
    }
}
