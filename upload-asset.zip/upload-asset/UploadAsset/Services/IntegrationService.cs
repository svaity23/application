﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Threading.Tasks;
using UploadAsset.Dtos;

namespace UploadAsset.Services
{
    public class IntegrationService
    {
        private readonly ILogger<IntegrationService> _logger;
        private IntegrationLogic _integrationLogic;
      
        public IntegrationService(ILogger<IntegrationService> logger, damContext context)
        {
            _logger = logger;
            _integrationLogic = new IntegrationLogic(context);
        }

        public async Task<GetEntityResponse<AreaSettingDto[]>> GetIntegrationSettingsByAccountIdAsync(Guid accountId)
        {
            string resultJson = await _integrationLogic.GetIntegrationSettingsByAccountIdAsync(accountId);
            GetEntityResponse<AreaSettingDto[]> settings = JsonConvert.DeserializeObject<GetEntityResponse<AreaSettingDto[]>>(resultJson);
            return settings;
        }
    }
}
