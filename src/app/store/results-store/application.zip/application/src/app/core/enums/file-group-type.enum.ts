export enum FileGroupType {
  Image = 0,
  Video = 1,
  Audio = 2,
  Design = 3,
  Presentation = 4,
  Document = 5,
  FusionPro = 6,
  Font = 7,
  Archive = 8
}
