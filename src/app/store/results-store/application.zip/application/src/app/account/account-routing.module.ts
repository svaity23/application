import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AccountFederationComponent } from './containers/account-federation/account-federation.component';
import { AccountFederationGuard } from '@app/core/guards/account-federation.guard';
import { AccountTrialVerifiedGuard } from '@app/core/guards/account-trial-verified.guard';
import { FeatureGuard } from '@app/core/guards/feature.guard';
import { FeatureKey } from '@app/core/enums/feature-key.enum';
import { GeneralInformationComponent } from './containers/general-information/general-information.component';
import { GroupFormComponent } from './containers/group-form/group-form.component';
import { GroupsComponent } from './containers/groups/groups.component';
import { HubspotConfigurationPageComponent } from './containers/hubspot-configuration-page/hubspot-configuration-page.component';
import { HubspotSyncErrorsResolver } from '@app/core/resolvers/hubspot-sync-errors.resolver';
import { IntegrationsComponent } from './containers/integrations/integrations.component';
import { IntegrationsGuard } from '@app/core/guards/integrations.guard';
import { MarcomPortalIntegrationsPageComponent } from './containers/marcomportal-integrations-page/marcomportal-integrations-page.component';
import { MetadataProfileFormComponent } from './containers/metadata-profile-form/metadata-profile-form.component';
import { MetadataProfileGuard } from '@app/core/guards/metadata-profile.guard';
import { MetadataProfilesComponent } from './containers/metadata-profiles/metadata-profiles.component';
import { RolesResolver } from '@app/core/resolvers/roles.resolver';
import { UserFormComponent } from './containers/user-form/user-form.component';
import { UserGuard } from '@app/core/guards/user.guard';
import { UsersComponent } from './containers/users/users.component';
import { UsersResolver } from '@app/core/resolvers/users.resolver';

const routes: Routes = [
  {
    path: 'general-information',
    component: GeneralInformationComponent
  },
  {
    path: 'metadata-profiles',
    component: MetadataProfilesComponent
  },
  {
    path: 'metadata-profiles/:id',
    component: MetadataProfileFormComponent,
    canActivate: [MetadataProfileGuard]
  },
  {
    path: 'users',
    component: UsersComponent,
    resolve: {
      roles: RolesResolver,
      users: UsersResolver
    }
  },
  {
    path: 'users/new',
    component: UserFormComponent,
    canActivate: [AccountTrialVerifiedGuard],
    resolve: {
      roles: RolesResolver,
      users: UsersResolver
    }
  },
  {
    path: 'users/:id',
    component: UserFormComponent,
    canActivate: [UserGuard],
    resolve: {
      roles: RolesResolver,
      users: UsersResolver
    }
  },
  {
    path: 'groups',
    data: { feature: FeatureKey.UserGroups },
    canActivate: [FeatureGuard],
    component: GroupsComponent
  },
  {
    path: 'groups/new',
    data: { feature: FeatureKey.UserGroups },
    canActivate: [FeatureGuard],
    component: GroupFormComponent
  },
  {
    path: 'groups/:id',
    data: { feature: FeatureKey.UserGroups },
    canActivate: [FeatureGuard],
    component: GroupFormComponent
  },
  {
    path: 'integrations',
    canActivate: [IntegrationsGuard],
    component: IntegrationsComponent
  },
  {
    path: 'hubspot-configuration-page',
    component: HubspotConfigurationPageComponent,
    resolve: {
      hubspotSyncStatus: HubspotSyncErrorsResolver
    }
  },
  {
    path: 'marcomportal-integrations-page',
    component: MarcomPortalIntegrationsPageComponent,
  },
  {
    path: 'federation',
    canActivate: [AccountFederationGuard],
    component: AccountFederationComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [
    FeatureGuard,
    HubspotSyncErrorsResolver,
    IntegrationsGuard,
    RolesResolver,
    UsersResolver,
    UserGuard
  ]
})
export class AccountRoutingModule { }
