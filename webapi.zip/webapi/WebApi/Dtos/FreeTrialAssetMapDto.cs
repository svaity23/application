﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WebApi.Dtos
{
    public class FreeTrialAssetMapDto
    {
        [JsonPropertyName("oldAssetId")]
        public Guid OldAssetId { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("newAssetId")]
        public Guid NewAssetId { get; set; }

        [JsonPropertyName("fileExtension")]
        public string FileExtension { get; set; }
    }
}
