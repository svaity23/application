import { RenderInterceptor } from '../render-intercept/render-intercept';
import { Injectable } from "@angular/core";

@Injectable()
export class RendererExtensionInterceptor implements RenderInterceptor {
  childNodes(node: Node): NodeList {
    return node.childNodes;
  }
}
