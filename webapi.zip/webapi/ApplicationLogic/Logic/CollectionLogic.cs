﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using System;
using System.Threading.Tasks;
namespace ApplicationLogic.Logic
{
    public class CollectionLogic
    {
        private readonly CollectionFinder _collectionFinder;

        public CollectionLogic(damContext context)
        {
            _collectionFinder = new CollectionFinder(context);
        }
        public async Task<string> GetAllAsync(Guid accountId, Guid userId)
        {
            return await _collectionFinder
                .GetAllAsync(accountId, userId);
        }

        public async Task<string> GetByIdAsync(Guid accountId, Guid userId, Guid id)
        {
            return await _collectionFinder
                .GetByIdAsync(accountId, userId, id);
        }

        public async Task<string> SaveAsync(Guid accountId, Guid userId, string json)
        {
            return await _collectionFinder
                .SaveAsync(accountId, userId, json);
        }

        public async Task<string> DeleteAsync(Guid accountId, Guid userId, string json)
        {
            return await _collectionFinder
                .DeleteAsync(accountId, userId, json);
        }

        public async Task<string> GetEntitledIdsForUserAsync(Guid accountId, Guid userId)
        {
            return await _collectionFinder
                .GetIdsForUserAsync(accountId, userId);
        }

        public async Task<string> MoveCollectionAsync(Guid accountId, Guid userId, Guid collectionId, Guid parentId)
        {
            return await _collectionFinder
                .MoveCollectionAsync(accountId, userId, collectionId, parentId);
        }
    }
}
