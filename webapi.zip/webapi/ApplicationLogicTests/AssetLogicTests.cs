﻿using ApplicationLogic;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using ApplicationLogic.Models;
using Azure.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLogicTests
{
    [TestClass()]
    public class AssetLogicTests
    {
        private damContext _context;
        private Guid _sessionId = Guid.NewGuid();

        [TestInitialize]
        public void Init()
        {
            var configuration = new ConfigurationBuilder()
                       .AddJsonFile("appsettings.json", true, true)
                       .Build();

            var optionBuilder = new DbContextOptionsBuilder<damContext>();
            optionBuilder.UseSqlServer(configuration["ConnectionStrings:damDbConnection"]);

            var loggerFactory = (ILoggerFactory)new LoggerFactory();
            var logger = loggerFactory.CreateLogger<AzureAccessTokens>();

            _context = new damContext(optionBuilder.Options,
                new AzureAccessTokens(logger),
                new Microsoft.Extensions.Logging.Abstractions.NullLogger<damContext>(),
                configuration);
        }

        public AssetLogicTests()
        {

        }



        [TestMethod()]
        [Ignore]
        public async Task GetAccountAssetInfoByIdsAsync()
        {
            var accountId = Guid.Parse("D35BF9DC-A8DC-4673-ADA4-2C5C91484CBA");
            var userId = Guid.Parse("2B095E61-83D6-4233-8962-60A903C316A5");
            var zipId = Guid.NewGuid().ToString();
            var expDate = DateTime.Now.AddDays(30);
            List <Guid> assetIds = new List<Guid>();

            assetIds.Add(Guid.Parse("A8DBE4A3-0592-4732-9F8D-F06FF1332664"));
            assetIds.Add(Guid.Parse("84D63893-1D9C-480E-B557-7AC053E015B3"));
            assetIds.Add(Guid.Parse("D0BA884B-657E-4E88-8B0E-821A2F067D79"));

            var listOfDic = assetIds.ConvertAll<Dictionary<string, Guid>>(x =>
            {
                var dic = new Dictionary<string, Guid>();
                dic.Add("id", x);
                return dic;
            });

            AssetFinder _finder = new AssetFinder(_context);


            var jsonOutput = await _finder.GetAccountAssetInfoByIdsAsync(accountId, userId, _sessionId, "shareLink", assetIds, true);
            var accountAssetInfo = Newtonsoft.Json.JsonConvert.DeserializeObject<AccountAssetInfo>(jsonOutput);


            Assert.IsNotNull(accountAssetInfo);
        }

        [TestMethod()]        
        [Ignore]
        public async Task GetAccountIdsByUserIdAsyncTest()
        {
            
            var userId = Guid.Parse("D9D35045-4226-4232-AE59-F2A0DD32D041");
            var accountId = Guid.Parse("DA3CCFB3-7DCA-41ED-87A6-E70BF8A139DE");

            UserFinder _finder = new UserFinder(_context);
            var jsonOutput = await _finder.GetAccountIdsByUserIdAsync(userId);
            
            var accountIds = Newtonsoft.Json.JsonConvert.DeserializeObject<object>(jsonOutput);
            
            var json = "[\"7D6CE8F2-90D4-4BD6-95D5-9D30CC56490A\", \"DA3CCFB3-7DCA-41ED-87A6-E70BF8A139DE\"]";
            var mod = json.Replace('[', ' ').Replace(']', ' ').Replace("\"", "").Trim().Split(',');
            foreach(var id in mod)
            {
                var actId = Guid.Parse(id);
                if (actId.Equals(accountId))
                {
                    var final = actId;
                }
            }
            //var json = @"[\""7D6CE8F2-90D4-4BD6-95D5-9D30CC56490A","DA3CCFB3-7DCA-41ED-87A6-E70BF8A139DE"]";
            // string JoinedArray = "[\"" + string.Join("\", \"", ids.Ids.Select(g => g.ToString())) + "\"]";
            Assert.IsNotNull(jsonOutput);
        }
    }
}
