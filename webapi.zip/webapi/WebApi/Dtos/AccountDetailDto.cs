﻿using System;
using System.Text.Json.Serialization;

namespace WebApi.Dtos
{
    public class AccountDetailtDto
    {
        [JsonPropertyName("id")]
        public Guid Id { get; set; }
        [JsonPropertyName("active")]
        public bool Active { get; set; }
        [JsonPropertyName("created")]
        public DateTime Created { get; set; }
        [JsonPropertyName("modified")]
        public DateTime? Modified { get; set; }
        [JsonPropertyName("accountTypeName")]
        public string AccountTypeName { get; set; }
        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("netsuiteId")]
        public string NetsuiteId { get; set; }
        [JsonPropertyName("opportunityId")]
        public string OpportunityId { get; set; }
        [JsonPropertyName("error")]
        public string Error { get; set; }
        [JsonPropertyName("salesforceId")]
        public string SalesforceId { get; set; }
        [JsonPropertyName("storageAccountName")]
        public string StorageAccountName { get; set; }
        [JsonPropertyName("trialExpiration")]
        public DateTime? TrialExpiration { get; set; }
        [JsonPropertyName("trialVerified")]
        public bool? TrialVerified { get; set; }

        // Account owner information
        [JsonPropertyName("userId")]
        public Guid UserId { get; set; }
        [JsonPropertyName("userEmail")]
        public string UserEmail { get; set; }
        [JsonPropertyName("userFirstName")]
        public string UserFirstName { get; set; }
        [JsonPropertyName("userLastName")]
        public string UserLastName { get; set; }
        [JsonPropertyName("storageMaximumGb")]
        public int? StorageMaximumGb { get; set; }
        [JsonPropertyName("userIdpId")]
        public string UserIdpId { get; set; }
        [JsonPropertyName("federatedDomains")]
        public string FederatedDomains { get; set; }
        [JsonPropertyName("markedForDelete")]
        public bool MarkedForDelete { get; set; }
    }
}
