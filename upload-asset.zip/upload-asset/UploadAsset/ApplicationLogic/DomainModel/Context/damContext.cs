﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using ApplicationLogic.DomainModel;

#nullable disable

namespace ApplicationLogic.DomainModel.Context
{
    public partial class damContext : DbContext
    {
        public damContext()
        {
        }

        public damContext(DbContextOptions<damContext> options)
            : base(options)
        {
        }
                
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=tcp:sql-dam-sbx-829c.database.windows.net,1433;Initial Catalog=sqldb-dam-sbx;Persist Security Info=False;User ID=appPocoGen;Password=___________;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
