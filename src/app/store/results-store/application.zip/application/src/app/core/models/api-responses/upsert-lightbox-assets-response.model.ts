export interface UpsertLightboxAssetsResponse {
    assetCount: number;
    ids: string[];
    lightboxId: string;
}