export interface HubspotEntityResponse {
    fromCollectionId?: string;
    id: string;
}
