import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { createGuid, nullGuid } from 'src/utils/guid';

import { MetadataField } from '@app/core/models/entities/metadata-field.model';
import { MetadataFieldValue } from '@app/core/models/entities/metadata-field-value.model';

@Component({
  selector: 'app-metadata-profile-checkbox-field',
  templateUrl: './metadata-profile-checkbox-field.component.html',
  styleUrls: ['./metadata-profile-checkbox-field.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MetadataProfileCheckboxFieldComponent implements OnChanges {
  @Input() checkBoxField: MetadataField;
  checkBoxFieldToModify: MetadataField;
  @Input() checkBoxFieldValues: MetadataFieldValue[];
  checkBoxFieldValuesToModify: MetadataFieldValue[];
  @Output() fieldDeleteAttempted = new EventEmitter<MetadataField>();
  @Output() fieldUpdated = new EventEmitter<MetadataField>();
  @Output() fieldValueDeleteAttempted = new EventEmitter<MetadataFieldValue>();
  @Output() fieldValuesAdded = new EventEmitter<MetadataFieldValue[]>();
  @Output() fieldValuesSorted = new EventEmitter<MetadataFieldValue[]>();
  @Output() fieldValueUpdated = new EventEmitter<MetadataFieldValue>();
  valueToMove: MetadataFieldValue;
  valueToMoveAfter: MetadataFieldValue;

  constructor() { }

  addFieldValue(): void {
    const fieldValues = this.createFieldValues(this.checkBoxFieldToModify.id)
    this.fieldValuesAdded.emit(fieldValues);
  }

  allowDrop($event): void {
    $event.preventDefault();
  }

  deleteProfileFieldClick(): void {
    this.fieldDeleteAttempted.emit(this.checkBoxFieldToModify);
  }

  dragFieldEnd(): void {
    this.clearDragAndDropValues();
  }

  dragFieldOver(option: MetadataFieldValue): void {
    this.valueToMoveAfter = option;
  }

  dragFieldStart($event, option: MetadataFieldValue): void {
    this.clearDragAndDropValues();
    this.valueToMove = option;

    // creating a copy of the div to show whats being dragged over
    const ghostElem = $event.currentTarget.cloneNode(true);
    ghostElem.classList.add('drag-ghost');
    document.body.appendChild(ghostElem);
    $event.dataTransfer.setDragImage(ghostElem, 0, 0);
    $event.dataTransfer.setData('text', $event.target.id);
  }

  dropField($event): void {
    $event.preventDefault();
    if (this.valueToMove.id === this.valueToMoveAfter.id) {
      return; // nothing to do
    } else {
      this.reOrderValues();
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.checkBoxField) {
      this.checkBoxFieldToModify = { ...changes.checkBoxField.currentValue };
    }
    if (changes.checkBoxFieldValues) {
      const copyOfCheckBoxFieldValuesToModify = { ...changes.checkBoxFieldValues.currentValue };
      this.checkBoxFieldValuesToModify = this.getSortedProfileFieldValuesForTheField(copyOfCheckBoxFieldValuesToModify);
    }
  }

  removefieldValue(fieldValueToRemove: MetadataFieldValue): void {
    this.fieldValueDeleteAttempted.emit(fieldValueToRemove);
  }

  toggleExpandField(): void {
    this.checkBoxFieldToModify.expandField = !this.checkBoxFieldToModify.expandField;
  }

  updateFieldLabel(): void {
    this.fieldUpdated.emit(this.checkBoxFieldToModify);
  }

  updateFieldValue(event, fieldValueToUpdate: MetadataFieldValue): void {
    const updatedFieldValue = {...fieldValueToUpdate, value : event.target.value}
    this.fieldValueUpdated.emit(updatedFieldValue);
  }

  private clearDragAndDropValues(): void {
    this.valueToMove = this.valueToMoveAfter = null;
  }

  private createFieldValues(id: string): MetadataFieldValue[] {
    const listOps: MetadataFieldValue[] = [];
    let previousId = nullGuid;
    let listOp: MetadataFieldValue;
      previousId = this.checkBoxFieldValuesToModify[this.checkBoxFieldValuesToModify.length - 1].id;
      // eslint-disable-next-line prefer-const
      listOp = {
        accountId: this.checkBoxFieldToModify.accountId,
        active: true,
        id: createGuid(),
        metadataFieldId: id,
        previous: previousId,
        value: ''
      }
      listOps.push(listOp);

    return listOps;
  }

  private getSortedProfileFieldValuesForTheField(profileFieldValues: MetadataFieldValue[]): MetadataFieldValue[] {
    const filteredProfileFieldValues = Object.values(profileFieldValues).filter(fieldValue => fieldValue.metadataFieldId.toLowerCase() === this.checkBoxFieldToModify.id.toLowerCase())
    const profileFieldsToDisplay = [];
    let previousToFind = nullGuid;
    const n = filteredProfileFieldValues.length;
    for (let i = 0; i < n; i++) {
      const fieldIndex = filteredProfileFieldValues.findIndex(item => item.previous.toLocaleLowerCase() === previousToFind);
      previousToFind = filteredProfileFieldValues[fieldIndex].id.toLocaleLowerCase();
      profileFieldsToDisplay.push(filteredProfileFieldValues[fieldIndex]);
    }
    return profileFieldsToDisplay;
  }

  private reOrderValues(): void {
    // removes from old location in values array
    const itemToMoveIndex = this.checkBoxFieldValuesToModify.findIndex(item => item.id === this.valueToMove.id);
    const itemToMove = this.checkBoxFieldValuesToModify.splice(itemToMoveIndex, 1)[0];

    // adds to new location in values array
    const itemToMoveAfterIndex = this.checkBoxFieldValuesToModify.findIndex(item => item.id === this.valueToMoveAfter.id);
    this.checkBoxFieldValuesToModify.splice(itemToMoveAfterIndex + 1, 0, itemToMove);

    const tempFieldValuesToModify: MetadataFieldValue[] = [];
    this.checkBoxFieldValuesToModify.forEach(element => {
      const newElement = { ...element };
      tempFieldValuesToModify.push(newElement);
    });

    // loop from the end and update the 'previous' field to update the sort order
    for (let i = tempFieldValuesToModify.length - 1; i > 0; i--) {
      tempFieldValuesToModify[i].previous = tempFieldValuesToModify[i-1].id
    }
    tempFieldValuesToModify[0].previous = nullGuid; // first one is always a null guid
    this.clearDragAndDropValues();
    this.fieldValuesSorted.emit(tempFieldValuesToModify);
  }

}
