﻿using ApplicationLogic.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using WebApi.Authorization;
using WebApi.Dtos;
using WebApi.Dtos.Asset.Comment;
using WebApi.Dtos.Asset.Request;
using WebApi.Dtos.Asset.Response;
using WebApi.Dtos.Asset.Revision;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class AssetsController : ControllerBase
    {
        private readonly ILogger<AssetsController> _logger;
        private readonly IConfiguration _configuration;
        private readonly AssetService _assetService;
        private readonly AccountService _accountService;
        private readonly BlobService _blobService;
        private readonly DownloadService _downloadService;
        private readonly UserAccountService _userAccountService;


        public AssetsController(
            ILogger<AssetsController> logger,
            IConfiguration configuration,
            AccountService accountService,
            AssetService assetService,
            BlobService blobService,
            DownloadService downloadService,
            UserAccountService userAccountService)
        {
            _logger = logger;
            _configuration = configuration;
            _accountService = accountService;
            _assetService = assetService;
            _blobService = blobService;
            _downloadService = downloadService;
            _userAccountService = userAccountService;
        }

        /// <summary>
        /// Get account assets
        /// </summary>
        /// <remarks>    
        /// </remarks>
        /// <param name="sortField"></param>
        /// <param name="collectionId"></param>
        /// <param name="skip"></param>
        /// <param name="pageSize"></param>
        /// <param name="isOnMyFavorites"></param>
        /// <param name="expiredOnly"></param>
        /// <param name="cleanUpOnly"></param>
        /// <returns></returns>
        [HttpGet]
        [ApiExplorerSettings(IgnoreApi = false)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<AssetDto>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAccountAssets(int sortField, Guid? collectionId, int skip, int pageSize, bool? isOnMyFavorites, bool? expiredOnly, bool? cleanUpOnly)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
        
            GetEntitiesResponse<AssetDto> results =
                await _assetService.GetAccountAssetsAsync(
                        accountId, 
                        userId, 
                        sortField, 
                        collectionId, 
                        skip, 
                        pageSize, 
                        false,
                        isOnMyFavorites.HasValue ? (bool)isOnMyFavorites : false,
                        expiredOnly.HasValue ? (bool)expiredOnly : false,
                        cleanUpOnly.HasValue ? (bool)cleanUpOnly : false
                );
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entities ?? new List<AssetDto>()),
                    3 => Forbid(),// the user doesn't have admin rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }

        /// <summary>
        /// Adds sample assets and collections to account
        /// </summary>
        /// <returns></returns>
        [HttpPost("sampleassets")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> LoadSampleAssets()
        {   
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            // Create Free Trial DB Collections, Assets, Metadata and Tags
            SampleDataResponseDto sampleDataResult = await _accountService.CreateFreeTrialSampleDataAsync(accountId, userId);

            // Reindex Search
            await _assetService.ReindexAssetsAsync(accountId);

            // Copy Free Trial assets from source containers to target containers
            string sourceContainer = sampleDataResult.Accounts.SourceAccountId.ToString();
            string targetContainer = sampleDataResult.Accounts.TargetAccountId.ToString();

            await _blobService.CopyFreeTrialAssetsAsync(sourceContainer, targetContainer, sampleDataResult.AssetMap);
            return Ok();
        }

        /// <summary>
        /// Records asset usage
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("usage")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> AddAssetUsage([FromBody] UseageRequestDTO request)
        {
            if (request == null || string.IsNullOrEmpty(request.Action)) return BadRequest();
            if (request.AssetIds == null || request.AssetIds.Count == 0) return NotFound();

            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userid = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();
            
            await _assetService.RecordAssetUsage(accountId, userid, sessionId, request);
            return Ok();
        }

        /// <summary>
        /// Updates if asset is favorited
        /// </summary>
        /// <param name="asset"></param>
        /// <returns></returns>
        [HttpPost("{id}/favorite")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UpdateFavoriteResponseDto))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UpdateFavorite([FromBody] AssetDto asset)
        {   
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            var favorite = await _assetService.UpdateFavoriteAsync(accountId, userId, asset);
            return Ok(favorite);
        }

        /// <summary>
        /// Update asset
        /// </summary>
        /// <param name="id"></param>
        /// <param name="asset"></param>
        /// <returns></returns>
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UpdateAssetResponseDto))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateAsset(Guid id, [FromBody] AssetDto asset)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();

            if (id != asset.Id) return BadRequest();

            return Ok(await _assetService.UpdateAssetAsync(accountId, userId, sessionId, asset));
        }

        /// <summary>
        /// Update asset metadatum
        /// </summary>
        /// <param name="metadatum"></param>
        /// <returns></returns>
        [HttpPost("metadatum")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(MetadatumUpdateDto[]))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UpdateMetadatum([FromBody] MetadataDto metadatum)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();
            return Ok(await _assetService.UpdateMetadatumAsync(accountId, userId, sessionId, metadatum));
        }

        /// <summary>
        /// Update asset tags
        /// </summary>
        /// <param name="tag"></param>
        /// <returns></returns>
        [HttpPost("tag")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SaveTagResponseDto))]
        public async Task<IActionResult> UpdateTag([FromBody] TagDto tag)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();
            return Ok(await _assetService.UpdateTagAsync(accountId, userId, sessionId, tag));
        }

        /// <summary>
        /// Adds request to generate ai tags
        /// </summary>
        /// <param name="aiTagsRequest"></param>
        /// <returns></returns>
        [HttpPost("aiTagRequest")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateAiTags([FromBody] AiTagsRequestDTO aiTagsRequest)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            await _assetService.UpdateAiTagsAsync(accountId, aiTagsRequest);
            return Ok();
        }

        /// <summary>
        /// Gets asset comments
        /// </summary>
        /// <param name="assetId"></param>
        /// <returns></returns>
        [HttpGet("comment/{assetId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<CommentResponseDto>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public async Task<IActionResult> GetComments(Guid assetId)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            var results = await _assetService.GetCommentsAsync(accountId, userId, assetId);
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entities),
                    1 => Conflict(),    // invalid json structure
                    2 => NotFound(),    // the asset is not active or present within the database
                    3 => Forbid(),      // the user doesn't have admin or contributor role
                    _ => BadRequest(),  // invalid json input for stored procedure
                };
            }

            return NotFound();
        }

        /// <summary>
        /// Add asset comment
        /// </summary>
        /// <param name="assetId"></param>
        /// <param name="entry"></param>
        /// <returns></returns>
        [HttpPost("comment/{assetId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AssetCommentDto))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public async Task<IActionResult> AddComment(Guid assetId, [FromBody] AssetCommentDto entry)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            if (entry == null ||
                string.IsNullOrWhiteSpace(entry.Comment))
                return BadRequest();

            if (entry.Author == null) entry.Author = new CollaborationUserDto();
            entry.Author.Id = userId;

            _logger.LogWarning($"User {userId} adds a comment to asset {assetId}");
            var results = await _assetService.AddCommentAsync(accountId, userId, assetId, entry);
            if (results != null)
            {
                int err = results.Errors[0].Code;
                return err switch
                {
                    0 => Ok(results.Entity),
                    1 => Conflict(),    // invalid json structure
                    2 => NotFound(),    // the asset is not active or present within the database
                    3 => Forbid(),      // the user doesn't have admin or contributor role
                    _ => BadRequest(),  // invalid json input for stored procedure
                };
            }

            return NotFound();
        }

        /// <summary>
        /// Update asset comment
        /// </summary>
        /// <param name="assetId"></param>
        /// <param name="entry"></param>
        /// <returns></returns>
        [HttpPost("{assetId}/comment/{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AssetCommentDto))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public async Task<IActionResult> UpdateComment(Guid assetId, [FromBody] AssetCommentDto entry)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            if (entry == null ||
                string.IsNullOrWhiteSpace(entry.Comment))
                return BadRequest();

            if (entry.Author == null) entry.Author = new CollaborationUserDto();
            entry.Author.Id = userId;

            _logger.LogWarning($"User {userId} updates a comment to asset {assetId}");
            var results = await _assetService.UpdateCommentAsync(accountId, userId, assetId, entry);
            if (results != null)
            {
                int err = results.Errors[0].Code;
                return err switch
                {
                    0 => Ok(results.Entity),
                    1 => Conflict(),    // invalid json structure
                    2 => NotFound(),    // the asset is not active or present within the database
                    3 => Forbid(),      // the user doesn't have admin or contributor role
                    _ => BadRequest(),  // invalid json input for stored procedure
                };
            }

            return NotFound();
        }

        /// <summary>
        /// Get asset detail for details view
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("assetDetails/{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Dtos.Asset.DetailsView.AssetDetailDto))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public async Task<IActionResult> GetAssetDetailForDetailsViewByAssetId(Guid id)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            var result = await _assetService.GetAssetDetailForDetailsViewAsync(accountId, id, userId);
            if (result != null)
            {
                int err = result.Error.Code;
                return err switch
                {
                    0 => Ok(result.Entity),
                    1 => Conflict(),    // invalid json structure
                    3 => Forbid(),      // the user doesn't have access to the asset
                    _ => BadRequest(),  // invalid json input for stored procedure
                };
            }

            return NotFound();
        }

        /// <summary>
        /// Get asset for preview view
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("assetPreviewDetails/{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AssetPreviewDto))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAssetForPreviewAsync(Guid id)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var assetPreview = await _assetService.GetAssetForPreviewAsync(accountId, id, userId);
            if (assetPreview == null)
                return NotFound();

            return Ok(assetPreview);
        }

        /// <summary>
        /// Generates and returns a permalink for given asset id
        /// </summary>
        /// <param name="id">Asset ID</param>
        /// <param name="destination"></param>
        /// <returns></returns>
        [HttpPost("{id}/permalinks")]
        [ProducesResponseType(StatusCodes.Status201Created, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetPermalinkUri(Guid id, [FromQuery] string destination = "")
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();
            var shareUri = await _assetService.GetSharePermalinkAsync(accountId, id, userId, sessionId, destination);

            return StatusCode(StatusCodes.Status201Created, shareUri);
        }

        /// <summary>
        /// Update collection id for multiple assets
        /// </summary>
        /// <remarks>      
        /// </remarks>
        /// <param name="updateCollectionRequest"></param>
        /// <returns></returns>
        [HttpPost("bulk/collection")]
        [ApiExplorerSettings(IgnoreApi = false)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UpdateAssetsWithCollectionIdResponseDto))] 
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BulkUpdateCollectionAsync([FromBody] UpdateCollectionRequestDTO updateCollectionRequest)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();

            if (updateCollectionRequest == null) return BadRequest();

            return Ok(await _assetService.UpdateAssetsWithCollectionIdAsync(accountId, updateCollectionRequest, userId, sessionId));
        }

        /// <summary>
        /// Update metadata for multiple assets
        /// </summary>
        /// <remarks>      
        /// </remarks>
        /// <param name="updateMetadataRequest"></param>
        /// <returns></returns>
        [HttpPost("bulk/metadata")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(string))] // todo -- type this
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BulkUpdateMetadataAsync([FromBody] UpdateMetadataRequestDTO updateMetadataRequest)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();

            if (updateMetadataRequest == null) return BadRequest();

            return Ok(await _assetService.UpdateMetadataAsync(accountId, updateMetadataRequest, userId));;
        }

        /// <summary>
        /// Update tags for multiple assets
        /// </summary>
        /// <remarks>      
        /// </remarks>
        /// <param name="updateTagsRequest"></param>
        /// <returns></returns>
        [HttpPost("bulk/tags")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(TagUpdateDto[]))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BulkUpdateTagsAsync([FromBody] UpdateTagRequestDTO updateTagsRequest)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();

            if (updateTagsRequest == null) return BadRequest();

            return Ok(await _assetService.UpdateTagsAsync(accountId, updateTagsRequest, userId, sessionId));
        }

        /// <summary>
        /// Update favorite for multiple assets
        /// </summary>
        /// <remarks>      
        /// </remarks>
        /// <param name="updateFavoritesRequest"></param>
        /// <returns></returns>
        [HttpPost("bulk/favorites")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UpdateFavoriteResponseDto[]))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BulkUpdateFavoritesAsync([FromBody] UpdateFavoritesRequestDTO updateFavoritesRequest)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();

            if (updateFavoritesRequest == null) return BadRequest();

            return Ok(await _assetService.UpdateFavoritesAsync(accountId, userId, updateFavoritesRequest));
        }

        /// <summary>
        /// Delete multiple assets
        /// </summary>
        /// <remarks>      
        /// </remarks>
        /// <param name="deleteAssetsRequest"></param>
        /// <returns></returns>
        [HttpPost("bulk/deletes")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(DeleteAssetsResponseDto))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BulkDeletesAsync([FromBody] DeleteAssetsRequestDTO deleteAssetsRequest)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();

            if (deleteAssetsRequest == null) return BadRequest();

            return Ok(await _assetService.DeleteAssetsAsync(accountId, deleteAssetsRequest, userId, sessionId));
        }

        /// <summary>
        /// Complete upload session for multiple assets
        /// </summary>
        /// <remarks>      
        /// </remarks>
        /// <param name="finishUploadSessionRequest"></param>
        /// <returns></returns>
        [HttpPost("bulk/activation")] // TODO - move to upload controller?
        [ApiExplorerSettings(IgnoreApi = false)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UpdateEntitiesResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> FinishUploadAsync([FromBody] FinishUploadSessionRequestDto finishUploadSessionRequest)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();

            if (finishUploadSessionRequest == null) return BadRequest();

            return Ok(await _assetService.FinishUploadSessionAsync(accountId, finishUploadSessionRequest, userId, sessionId));
        }

        /// <summary>
        /// Get metadata fields, metadata profiles, and profile types for the current user account
        /// </summary>
        /// <returns></returns>
        [HttpGet("metadataProfileInfo")]
        [ProducesResponseType(StatusCodes.Status200OK)] // TODO - RETURN TYPE
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetMetadataFieldsMetadataProfilesAndProfileTypesAsync()
        {
            // TODO: this need to move to metadata controller
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);

            // TODO - this service needs to return a dto, so we can have the schema
            var results = await _assetService.GetMetadataFieldsMetadataProfilesAndProfileTypesAsync(accountId);
            return Ok(results);
        }

        /// <summary>
        /// Get upload summary by upload session id
        /// </summary>
        /// <param name="uploadSessionId"></param>
        /// <returns></returns>
        [HttpGet("postUploadSummary")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PostUploadSummaryRowDto[]))]
        public async Task<IActionResult> GetPostUploadSummary(Guid uploadSessionId)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var results = await _assetService.GetPostUploadSummaryAsync(accountId, uploadSessionId);
            return Ok(results);
        }

        /// <summary>
        /// Get asset history by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("history/{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AssetRevisionDto[]))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAssetHistory(Guid id)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            return Ok(await _assetService.GetAssetHistoryAsync(accountId, id));
        }

        /// <summary>
        /// Assets download request
        /// </summary>
        /// <remarks>
        /// TODO - more details
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("download")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> Download(AssetDownloadConversionRequest request)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userid = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();
            List<Guid> assetIds = new List<Guid>();
            request?.Assets.ForEach(a => assetIds.Add(a.AssetId));
            await _downloadService.QueueDownload(accountId, request);

            UseageRequestDTO usage = new UseageRequestDTO()
            {
                Action = "download",
                AssetIds = assetIds
            };
            await _assetService.RecordAssetUsage(accountId, userid, sessionId, usage);
            return Ok();
        }

        /// <summary>
        /// Get web preview image
        /// </summary>
        /// <remarks>
        /// Creates a get request for the uri to push the stream back down the client.  CORS work around?
        /// </remarks>
        /// <param name="uri"></param>
        /// <param name="imageType"></param>
        /// <returns></returns>
        [HttpGet("webImage")]
        [ApiExplorerSettings(IgnoreApi = true)]  // dont need to expose this
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetWebPreviewImage([FromQuery] string uri = "", [FromQuery] string imageType = "png")
        {
            if (uri == string.Empty)
            {
                return BadRequest();
            }
            else
            {
                return File(await new HttpClient().GetStreamAsync(HttpUtility.UrlDecode(uri)), "image/" + imageType);
            }
        }
    }
}
