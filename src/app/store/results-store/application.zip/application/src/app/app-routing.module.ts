import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import * as fromStoreKey from './core/constants/store-keys';
import { AccountsResolver } from './core/resolvers/accounts.resolver';
import { AccountTrialGuard } from './core/guards/account-trial.guard';
import { AccountUploadGuard } from './core/guards/account-upload.guard';
import { AccountUserGuard } from './core/guards/account-user.guard';
import { AnalyticsGuard } from './core/guards/analytics.guard';
import { AssetAccessDeniedComponent } from './shared/containers/asset-access-denied/asset-access-denied.component';
import { AuthGuard } from './core/guards/auth.guard';
import { CollectionsResolver } from './core/resolvers/collections.resolver';
import { ContextResolver } from './core/resolvers/context.resolver';
import { DevOnlyGuard } from './core/guards/dev-only.guard';
import { EmailVerificationErrorComponent } from './shared/containers/email-verification-error/email-verification-error.component';
import { EulaGuard } from './core/guards/eula.guard';
import { FederationErrorComponent } from './shared/containers/federation-error/federation-error.component';
import { GenericErrorComponent } from './shared/containers/generic-error/generic-error.component';
import { HubSpotOauthComponent } from './shared/containers/hubspot/hubspot-oauth.component';
import { InactiveAccountComponent } from './shared/containers/inactive-account/inactive-account.component';
import { InactiveAccountGuard } from './core/guards/inactive-account.guard';
import { IntegrationCanvaComponent } from './shared/containers/integration-canva/integration-canva.component';
import { IntegrationErrorComponent } from './shared/containers/integration-error/integration-error.component';
import { LegalDocumentsGuard } from './core/guards/legal-documents.guard';
import { LightboxesResolver } from './core/resolvers/lightboxes.resolver';
import { MultipleAccountsComponent } from './shared/containers/multiple-accounts/multiple-accounts.component';
import { MultipleAccountsGuard } from './core/guards/multiple-accounts.guard';
import { NotificationsPageComponent } from './notification/containers/notifications-page/notifications-page.component';
import { PageNotFoundComponent } from './shared/containers/page-not-found/page-not-found.component';
import { PluginGuard } from './core/guards/plugin.guard';
import { ResetStoreStateDeactivateGuard } from './core/guards/reset-store-state-deactivate.guard';
import { RoleGuard } from './core/guards/role.guard';
import { RoleKey } from './core/enums/role-key.enum';
import { SandBoxComponent } from './sand-box/sand-box.component';
import { SlackRedirectComponent } from './shared/components/slack-redirect/slack-redirect.component';
import { SysAdminGuard } from './core/guards/sys-admin.guard';
import { TermsOfUseComponent } from './eula/containers/terms-of-use/terms-of-use.component';
import { WordpressErrorComponent } from './shared/containers/wordpress-error/wordpress-error.component';
import { WordPressOauthComponent } from './shared/components/wordpress-oauth/wordpress-oauth.component';


const authorizedRoutes: Routes = [
  {
    path: 'upload',
    loadChildren: () => import('./upload/upload.module').then(m => m.UploadModule),
    canLoad: [AuthGuard],
    canActivate: [AccountUserGuard, InactiveAccountGuard, RoleGuard, AccountTrialGuard, EulaGuard, AccountUploadGuard],
    canDeactivate: [ResetStoreStateDeactivateGuard],
    data: { storeKey: fromStoreKey.UPLOAD_STORE_KEY, roles: [RoleKey.mccAdmin, RoleKey.admin, RoleKey.contributor] },
    resolve: {
      collections: CollectionsResolver
    }
  },
  {
    path: 'library',
    loadChildren: () => import('./library/library.module').then(m => m.LibraryModule),
    canLoad: [AuthGuard],
    canActivate: [InactiveAccountGuard, AccountUserGuard, EulaGuard, PluginGuard],
    canDeactivate: [ResetStoreStateDeactivateGuard],
    data: { storeKey: fromStoreKey.LIBRARY_STORE_KEY },
    resolve: {
      collections: CollectionsResolver,
      lightboxes: LightboxesResolver
    }
  },
  {
    path: 'analytics',
    loadChildren: () => import('./analytics/analytics.module').then(m => m.AnalyticsModule),
    canLoad: [AuthGuard],
    canActivate: [AccountUserGuard, InactiveAccountGuard, RoleGuard, AnalyticsGuard, AccountTrialGuard, EulaGuard],
    canDeactivate: [ResetStoreStateDeactivateGuard],
    data: { roles: [RoleKey.mccAdmin, RoleKey.admin] }
  },
  {
    path: 'account',
    loadChildren: () => import('./account/account.module').then(m => m.AccountModule),
    canLoad: [AuthGuard],
    canActivate: [AccountUserGuard, InactiveAccountGuard, RoleGuard, AccountTrialGuard, EulaGuard],
    canDeactivate: [ResetStoreStateDeactivateGuard],
    data: { storeKey: fromStoreKey.ACCOUNT_STORE_KEY, roles: [RoleKey.mccAdmin, RoleKey.admin] }
  },
  {
    path: 'profile',
    loadChildren: () => import('./profile/profile.module').then(m => m.ProfileModule),
    canLoad: [AuthGuard],
    canActivate: [InactiveAccountGuard, AccountTrialGuard, EulaGuard]
  },
  {
    path: 'admin',
    loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule),
    canLoad: [AuthGuard],
    canActivate: [SysAdminGuard],
    canDeactivate: [ResetStoreStateDeactivateGuard],
    data: { storeKey: fromStoreKey.ADMIN_STORE_KEY },
    resolve: {
      accounts: AccountsResolver
    }
  },
  {
    path: 'eula',
    component: TermsOfUseComponent,
    canActivate: [LegalDocumentsGuard]
  },
  {
    path: 'integration/canva',
    component: IntegrationCanvaComponent,
    canActivate: [AuthGuard],
  },
  {
    path: 'provision',
    loadChildren: () => import('./registration/registration.module').then(m => m.RegistrationModule),
    canLoad: [AuthGuard]
  },
  {
    path: 'notifications',
    loadChildren: () => import('./notification/notification.module').then(m => m.NotificationModule),
    component: NotificationsPageComponent,
    canLoad: [AuthGuard],
    canActivate: [RoleGuard],
    canDeactivate: [ResetStoreStateDeactivateGuard],
    data: { roles: [RoleKey.mccAdmin, RoleKey.admin, RoleKey.contributor] }
  },
  {
    path: '',
    redirectTo: 'library',
    pathMatch: 'full'
  }
];

const routes: Routes = [
  {
    path: '',
    canActivate: [AuthGuard],
    children: authorizedRoutes
  },
  {
    path: 'sandbox',
    component: SandBoxComponent,
    canActivate: [DevOnlyGuard]
  },
  {
    path: 'lb',
    loadChildren: () => import('./lightbox-public/lightbox-public.module').then(m => m.LightboxPublicModule),
    data: { storeKey: fromStoreKey.LIGHTBOX_PUBLIC_STORE_KEY }
  },
  {
    path: 'inactive-account',
    component: InactiveAccountComponent
  },
  {
    path: 'select-account',
    canActivate: [MultipleAccountsGuard],
    component: MultipleAccountsComponent
  },
  {
    path: 'page-not-found',
    component: PageNotFoundComponent
  },
  {
    path: 'error',
    component: GenericErrorComponent
  },
  {
    path: 'email-verification-error',
    component: EmailVerificationErrorComponent
  },
  {
    path: 'federation-error',
    component: FederationErrorComponent
  },
  {
    path: 'integration-error',
    component: IntegrationErrorComponent
  },
  {
    path: 'wordpress-error',
    component: WordpressErrorComponent
  },
  {
    path: 'slack-redirect',
    component: SlackRedirectComponent
  },
  {
    path: 'asset-access-denied',
    component: AssetAccessDeniedComponent
  },
  {
    path: 'hubspot/oauth',
    component: HubSpotOauthComponent
  },
  {
    path: 'wordpress/oauth',
    component: WordPressOauthComponent
  },
  {
    path: 'wordpress/oauth/callback',
    component: WordPressOauthComponent
  },
  {
    path: '**',
    component: PageNotFoundComponent
  }
]

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    scrollPositionRestoration: 'top',
    relativeLinkResolution: 'legacy',
    // enableTracing: true  // debugging locally only
  })],
  exports: [RouterModule],
  providers: [
    AccountsResolver,
    AccountUserGuard,
    AnalyticsGuard,
    AuthGuard,
    CollectionsResolver,
    ContextResolver,
    EulaGuard,
    SysAdminGuard,
    LightboxesResolver
  ]
})
export class AppRoutingModule { }
