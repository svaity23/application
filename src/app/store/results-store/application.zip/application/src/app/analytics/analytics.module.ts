import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { AnalyticsComponent } from './containers/analytics/analytics.component';
import { AnalyticsRoutingModule } from './analytics-routing.module';
import { SharedModule } from '@app/shared/shared.module';
import { SisenseComponent } from './components/sisense/sisense.component';

@NgModule({
  declarations: [
    AnalyticsComponent,
    SisenseComponent
  ],
  imports: [
    CommonModule,
    AnalyticsRoutingModule,
    SharedModule
  ]
})
export class AnalyticsModule { }
