import { FilterGroupType } from '../enums/filter-group-type.enum';

export interface FilterOption {
  args: string[];          // Used for min/max values and to/from dates or anything custom
  count: number;
  displayName: string;
  filterGroupType: FilterGroupType;
  metadataFieldId?: string;
  name: string;           // Name of the bucket
  selected: boolean;
  visible: boolean;
}
