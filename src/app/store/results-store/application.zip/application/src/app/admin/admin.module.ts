import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { AccountEditComponent } from './containers/account-edit/account-edit.component';
import { AccountFooterComponent } from './components/account-footer/account-footer.component';
import { AccountFormComponent } from './components/account-form/account-form.component';
import { AccountHeaderComponent } from './components/account-header/account-header.component';
import { AccountIntegrationsComponent } from './components/account-integrations/account-integrations.component';
import { AccountListComponent } from './components/account-list/account-list.component';
import { AccountsComponent } from './containers/accounts/accounts.component';
import { AccountSearchComponent } from './components/account-search/account-search.component';
import { AccountUserListComponent } from './components/account-user-list/account-user-list.component';
import { AdminRoutingModule } from './admin-routing.module';
import { AdminSidebarComponent } from './components/admin-sidebar/admin-sidebar.component';
import { AdminStoreModule } from '@app/store/admin-store/admin-store.module';
import { SharedModule } from '@app/shared/shared.module';
import { UtilitiesComponent } from './containers/utilities/utilities.component';
import { UtilitiesDetailsComponent } from './components/utilities-details/utilities-details.component';
import { UtilitiesHeaderComponent } from './components/utilities-header/utilities-header.component';
import { UtilitiesSidebarComponent } from './components/utilities-sidebar/utilities-sidebar.component';
// import { UserSearchComponent } from './components/user-search/user-search.component'; -- future PBI

@NgModule({
  declarations: [
    AccountEditComponent,
    AccountFooterComponent,
    AccountFormComponent,
    AccountHeaderComponent,
    AccountIntegrationsComponent,
    AccountListComponent,
    AccountsComponent,
    AccountSearchComponent,
    AccountUserListComponent,
    AdminSidebarComponent,
    UtilitiesComponent,
    UtilitiesDetailsComponent,
    UtilitiesHeaderComponent,
    UtilitiesSidebarComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    AdminStoreModule,
    SharedModule
  ]
})
export class AdminModule { }
