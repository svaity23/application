import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { OidcFacade } from 'ng-oidc-client';

import { Observable, of } from 'rxjs';
import { switchMap, take } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FederatedUserUpdateGuard implements CanActivate {

  constructor(private oidcFacade: OidcFacade, private router: Router) { }

  canActivate(
    // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
    _route: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
    _state: RouterStateSnapshot,
    ): Observable<boolean | UrlTree>  {

      return this.oidcFacade.waitForAuthenticationLoaded().pipe(
        switchMap(() => {
          return this.userDetailsChanged();
        })
      );
  }

  private isNullOrEmpty(str): boolean {
    return (!str || str.trim().length === 0 );
  }

  private userDetailsChanged(): Observable<boolean | UrlTree> {
    return this.oidcFacade.identity$.pipe(
      take(1),
      switchMap(user => {
        if (user) {
          // compare untouched user details from external idp with user details from shell user in adb2c
          if (
            user.profile.authenticationSource?.toLowerCase() === 'federatedadauthentication'
                    && ((!this.isNullOrEmpty(user.profile?.federated_given_name) && user.profile?.given_name !== user.profile?.federated_given_name)
                    || (!this.isNullOrEmpty(user.profile?.federated_family_name) && user.profile?.family_name !== user.profile?.federated_family_name)
                    || (!this.isNullOrEmpty(user.profile?.federated_email) && user.profile?.email !== user.profile?.federated_email)
                    )
          ) {
            return of(true);
          }
          else {
            return of(this.router.parseUrl('/library'));
          }
        } else {
          return of(this.router.parseUrl('/library'));
        }
      })
    );
  }
}
