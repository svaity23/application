export interface LegalDocument {
    documentType: string,
    legalId: number,
    location: string,
    version: string
}
