import { ChangeDetectionStrategy, Component, EventEmitter, Output, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-user-search',
  templateUrl: './user-search.component.html',
  styleUrls: ['./user-search.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UserSearchComponent  {

  isEnabled = false;
  @Output() searchInputChange: EventEmitter<string> = new EventEmitter<string>();
  searchText: string;
  // @Input() selectedUsers: User[];
  show = false;
  visible = false;

  constructor() { }

  filterUsers(): void {
    this.searchInputChange.emit(this.searchText);
  }

  onInputTextFocus(): void {
    this.show = true;
    this.isEnabled = false;
  }

  toggleSearchButton(): void {
    this.show = true;
    this.isEnabled = true;
  }
}
