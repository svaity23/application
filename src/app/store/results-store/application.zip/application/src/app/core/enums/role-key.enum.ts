export enum RoleKey {
    trial = 'trial',
    sysAdmin = 'sys-admin',
    mccAdmin = 'mcc-admin',
    admin = 'admin',
    contributor = 'contributor',
    viewer = 'viewer'
}