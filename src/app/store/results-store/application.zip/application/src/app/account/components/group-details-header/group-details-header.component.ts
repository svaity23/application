import { ChangeDetectionStrategy, Component, EventEmitter, HostBinding, Input, OnChanges, OnInit, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';

import { Context } from '@app/core/models/context.model';
import { Group } from '@app/core/models/entities/group.model';

@Component({
  selector: 'app-group-details-header',
  templateUrl: './group-details-header.component.html',
  styleUrls: ['./group-details-header.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush

})
export class GroupDetailsHeaderComponent implements OnInit, OnChanges {

  allGroupsButtonText: string;
  @Input() context: Context;
  @Input() group: Group;
  @Output() groupChangeEvent = new EventEmitter<Group>();
  groupName: string;
  @Input() isDisabled = true;
  @Input() isGroupFormTouched: boolean;
  @Output() navigateAllGroupsEvent = new EventEmitter();
  @HostBinding('attr.ngNoHost') noHost = '';
  @Input() searchText: string;

  constructor() { }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.group) {
      this.groupName = (changes.group.currentValue != null) ? (changes.group.currentValue.name) : '';
    }
  }

  ngOnInit(): void {
    this.allGroupsButtonText = 'All Groups';
    this.allGroupsButtonText = this.searchText ? `Back to Search Results for "${this.searchText}"` : 'All Groups'
  }
}
