﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WebApi.Dtos.Asset.Request
{
    public class ReplaceAssetDto
    {
        [JsonPropertyName("asset")]
        public AssetRevisionRequestDto Asset { get; set; }
        [JsonPropertyName("maxFileUploadSizeInBytes")]
        public long MaxFileUploadSizeInBytes { get; set; }
        [JsonPropertyName("oldAssetId")]
        public Guid OldAssetId { get; set; }

    }
}
