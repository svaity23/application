﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace UploadAsset.Dtos.Asset.Request
{
    public class ReplaceAssetDto
    {
        [JsonPropertyName("asset")]
        public AssetDto Asset { get; set; }
        [JsonPropertyName("oldAssetId")]
        public Guid OldAssetId { get; set; }
    }
}
