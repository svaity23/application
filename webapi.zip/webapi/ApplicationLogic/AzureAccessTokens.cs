﻿using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.Extensions.Logging;

namespace ApplicationLogic
{
    public class AzureAccessTokens
    {
        AzureServiceTokenProvider _azureServiceTokenProvider;
        
        public string DbAccessToken
        {
            get { return _azureServiceTokenProvider.GetAccessTokenAsync("https://database.windows.net/").Result; }
        }


        public string ManagementResourceAccessToken
        {
            get { return _azureServiceTokenProvider.GetAccessTokenAsync("https://management.azure.com/").Result; }
        }


        public AzureAccessTokens(ILogger<AzureAccessTokens> logger)
        {
            // We need to migrate to DefaultAzureCredential
            // https://docs.microsoft.com/en-us/dotnet/api/overview/azure/app-auth-migration

            logger.LogDebug("***BEGIN: create AzureServiceTokenProvider");
            // https://docs.microsoft.com/en-us/dotnet/api/overview/azure/service-to-service-authentication
            _azureServiceTokenProvider = new AzureServiceTokenProvider();
            logger.LogDebug("***End: create AzureServiceTokenProvider");
        }
    }
}
