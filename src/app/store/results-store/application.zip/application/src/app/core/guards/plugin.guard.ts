import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { filter, first, map, switchMap, tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

import { AppStoreFacade } from '@app/store/app-store/app-store.facade';

@Injectable({
  providedIn: 'root'
})
export class PluginGuard implements CanActivate {
  constructor(private appStoreFacade: AppStoreFacade, private router: Router) { }

  canActivate(
    _route: ActivatedRouteSnapshot,
    _state: RouterStateSnapshot): Observable<boolean | UrlTree> {

    if (this.isPluginName(_route, 'wordpress')) {
      return this.appStoreFacade.context.context$.pipe(
        tap(context => {
          if (!context) {
            this.appStoreFacade.loadContext();
          }
        }),
        filter(context => context != null),
        first(),
        switchMap(() => {
          return this.appStoreFacade.context.isWordpressIntegrationEnabled$;
        }),
        map((wordpressIntegrationEnabled) => {
          if (!wordpressIntegrationEnabled) {
            return this.router.parseUrl('/wordpress-error');
          }
          return true;
        })
      );
    } else {
      return of(true);
    }
  }

  private isPluginName(route: ActivatedRouteSnapshot, pluginName: string): boolean {
    // handle case variation, just the 2 most probable for now
    const queryParamVal = route.queryParams?.pluginName || route.queryParams?.pluginname || '';
    return (queryParamVal.toLocaleLowerCase() === pluginName.toLocaleLowerCase());
  }
}
