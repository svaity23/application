﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class UserFinder
    {
        public ILogger<UserFinder> Logger { get; set; }

        private damContext _context;

        public UserFinder(damContext context) {
            _context = context;
            Logger = NullLogger<UserFinder>.Instance;
        }

        public async Task<string> GetAccountIdsByUserIdAsync(Guid userId)
        {
            Logger.LogInformation($"[Finder] Getting accountIds by userId = {userId}");
            List<SqlParameter> parameters = new SpParams()
                .WithUserId(userId)
                .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("getAccountIdsByUserId", parameters);
        }
    }
}
