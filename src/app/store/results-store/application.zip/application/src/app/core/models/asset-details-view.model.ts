import { AssetForDetailsView } from './asset-for-details-view.model';
import { CommentThread } from './comment-thread.model';
import { Metadata } from './entities/metadata.model';
import { MetadataField } from './entities/metadata-field.model';
import { MetadataFieldValue } from './entities/metadata-field-value.model';
import { Tag } from './entities/tag.model';

/** View Model for Asset Details page (asset.component.html) */
export interface AssetDetailsView {
    asset: AssetForDetailsView;
    assetCommentsThreads?: CommentThread[];
    metadata: Metadata[]; // TODO - revisit if we need new metadata, metadataField, metadataFieldValue models specific for asset details view
    metadataFields: MetadataField[];
    metadataFieldValues: MetadataFieldValue[];
    tags: Tag[];
}
