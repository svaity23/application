import { FrameType } from './frame-type.enum';
import { Paragraph } from './paragraph.model';
//import { TextState } from './text-state.model';

export interface Frame {

    height?: number;
    /** HTML Content. This is initially derived from paragraphs -> runs -> text, to be used by WYSIWYG editor. */
    htmlContent?: string;
    id?: string;
    left?: number;
    pageNumber?: number;
    paragraphs?: Paragraph[];
    rotation?: number;
    top?: number;
    type?: FrameType;
    width?: number;
    x?: number;
    y?: number;

    // content: string;
    // height: number;
    // id: string;
    // left: number;
    // paragraph?: number;
    // rotationAngle?: number;
    // section?: number;
    // textState?: TextState;
    // top: number;
    // type: FrameType;
    // width: number;
}