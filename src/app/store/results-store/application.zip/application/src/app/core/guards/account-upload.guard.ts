import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable, Injector } from '@angular/core';

import { filter, first, map, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AccountTypeKey } from '@app/core/enums/account-type-key.enum';
import { APP_CONFIG, AppConfig } from '@app/app-config';
import { AppStoreFacade } from '@app/store/app-store/app-store.facade';

@Injectable({
  providedIn: 'root'
})
export class AccountUploadGuard implements CanActivate {

  accountTypeKeyEnum = AccountTypeKey;
  oneGBInBytes = 1073741824; // bytes
  private appSettings: AppConfig;

  constructor(private appStoreFacade: AppStoreFacade, private router: Router, private injector: Injector) {
    this.appSettings = this.injector.get(APP_CONFIG);
  }

  canActivate(
    // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
    _route: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
    _state: RouterStateSnapshot,
  ): Observable<boolean | UrlTree> {

    return this.isAccountStorageNotFull();
  }

  private isAccountStorageNotFull(): Observable<boolean | UrlTree> {
    return this.appStoreFacade.context.context$.pipe(
      tap(context => {
        if (!context) {
          this.appStoreFacade.loadContext();
        }
      }),
      filter(context => context != null),
      first(),
      map(context => {
        if (context.roleName !== 'Admin' && context.roleName !== 'Contributor') {
          return true
        } else {
          const accountStorageMaxGb = context.accountStorageMaximumGb; // in GB
          const accountStorageUsed = context.accountStorageUsed; // in bytes
          let accountStorageLeft = true;
          // accountStorageMaxGb could be null for trial accounts so checking for nulls
          if (accountStorageMaxGb && accountStorageUsed && (accountStorageUsed >= this.oneGBInBytes)) {
            accountStorageLeft = accountStorageMaxGb > (accountStorageUsed / this.oneGBInBytes); // converting accountStorageUsed from Bytes to GB
          }
          if (!accountStorageLeft) {

            // this will recreate the component, even if it is redirecting to itself
            this.router.routeReuseStrategy.shouldReuseRoute = () => false;
            this.router.onSameUrlNavigation = 'reload';

            this.appStoreFacade.openStorageFullModal({
              // initial setup.  this will be updated in the effects
              title: 'Storage is Full ',
              message: '',
              showUpgradeButton: context.roleName === 'Admin' ? true : false,
              upgradeButtonText: 'Contact Us',
              cancelButtonText: 'Cancel',
              upgrade: () => { window.open(this.appSettings.buyNowUrl, '_blank'); },
              cancel: () => { },
            });
            return this.router.parseUrl(this.router.url);
          } else {
            return true;
          }
        }
      })
    );
  }
}
