﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace WebApi.Dtos
{
    public class LightboxPreviewDto
    {
        [JsonPropertyName("lightboxId")]
        public Guid Id { get; set; }
        [JsonPropertyName("previewAssets")]
        public List<LightboxAssetDto> PreviewAssets { get; set; }
    }
}
