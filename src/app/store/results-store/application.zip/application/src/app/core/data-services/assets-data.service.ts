import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

import { Asset } from '../models/entities/asset.model';
import { AssetForDetailsView } from '../models/asset-for-details-view.model';
import { AssetRevisions } from '../models/asset-revisions.model';
import { AssetsAndMetadataAndTags } from '../models/assets-and-metadata-and-tags.model';
import { AssetUpdate } from '../models/asset-update.model';
import { BaseDataService } from './base-data.service';
import { Collection } from '../models/entities/collection.model';
import { Comment } from '../models/comment.model';
import { CommentsResponse } from '../models/api-responses/comments-response.model';
import { DeleteAssetsResponse } from '../models/api-responses/delete-assets-response.model';
import { Design } from '../models/designer/design.model';
import { Favorite } from '../models/favorite.model';
import { FilterRequest } from '../models/filter-request.model';
import { Frame } from '../models/designer/frame.model';
import { FrameType } from '../models/designer/frame-type.enum';
import { LibrarySidebarSelectionType } from '../enums/library-sidebar-selection.enum';
import { Metadata } from '../models/entities/metadata.model';
import { MetadataData } from '../models/metadata-data.model';
import { MetadataProfileInfo } from '../models/entities/metadata-profile-info.model';
import { MoveAssetToCollectionResponse } from '../models/api-responses/move-asset-to-collection-response.model';
import { Page } from '../models/designer/page.model';
import { Paragraph } from '../models/designer/paragraph.model';
import { PostUploadSummaryRow } from '../models/post-upload-summary-table.model';
import { SearchResults } from '../models/search-results.model';
import { SignalRSource } from '../enums/signal-r-source.enum';
import { Tag } from '../models/entities/tag.model';

export interface AssetsDataServiceInterface {
  addTag(tag: string): Observable<string>;
  deleteAssets(assets: Asset[]): Observable<DeleteAssetsResponse>;
  getAll(): Observable<Asset[]>;
  getAllCommentThreads(assetId: string): Observable<CommentsResponse[]>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  getAssetDetailsById(id: string): Observable<any>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  getAssetForPreviewById(id: string): Observable<AssetForDetailsView>;
  getAssetHistory(id: string): Observable<AssetRevisions[]>;
  getAssets(sortField: number, collectionId: string, skip: number, pageSize: number, sidebarSelection: LibrarySidebarSelectionType): Observable<Asset[]>;
  getById(id: string): Observable<Asset>;
  getPermalinkUri(assetId: string): Observable<string>;
  getPostUploadSummary(uploadSessionId: string): Observable<PostUploadSummaryRow[]>;
  loadAssetDesign(id: string, pageNumber: number): Observable<Design>;
  loadMetadataProfileInfo(): Observable<MetadataProfileInfo>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  loadSampleData(): Observable<any>;
  moveAssetsToCollection(assets: Asset[], collection: Collection): Observable<MoveAssetToCollectionResponse>;
  queryAssets(sortField: number, collectionId: string, skip: number, pageSize: number, searchTerm: string, filterRequests: FilterRequest[],
    searchFavorites: boolean, lightboxId: string, searchExpiredAssets: boolean, searchCleanupAssets: boolean): Observable<SearchResults>;
  saveAssetMetadata(assets: Asset[], tags: Tag[], metadata: Metadata[]): Observable<AssetsAndMetadataAndTags>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  saveAssetsToHistoryUsage(action: string, assetIds: string[], actionDetails?: string): Observable<any>;
  sendComment(comment: Comment, assetId: string): Observable<Comment>;
  updateAsset(asset: AssetUpdate): Observable<string>;
  updateAssets(assets: Asset[]): Observable<Asset[]>;
  updateFavorite(assetId: string, isFavorite: boolean): Observable<Favorite>;
  updateFavorites(assetsIds: string[], isFavorite: boolean): Observable<Favorite[]>;
  updateMetadatum(metadatum: MetadataData, assetId: string): Observable<MetadataData[]>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  updateTag(tag: Tag): Observable<Tag>;
}

@Injectable({ providedIn: 'root' })
export class AssetsDataService extends BaseDataService implements AssetsDataServiceInterface {
  addTag(tag: string): Observable<string> {
    return of(tag);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  aiTagRequest(asset: AssetForDetailsView, source: SignalRSource): Observable<any> {
    const url = `${this.webApiUrl}/assets/aiTagRequest`;
    const lowRestContainer = asset.attachment.results.find(item => item.containerName === 'low-resolution');
    const req = {
      assetId: asset.id,
      blobName: lowRestContainer.blobName,
      fileGroup: asset.fileGroupType.toString(),
      source
    }
    return this.createApiPost({ url, data: req });
  }

  deleteAssets(assets: Asset[]): Observable<DeleteAssetsResponse> {
    const assetIds: string[] = assets.map(u => u.id);
    const deleteAssetsRequest = {
      assetIds
    }
    const url = `${this.webApiUrl}/assets/bulk/deletes`;
    return this.createApiPost({ url, data: deleteAssetsRequest });
  }

  getAll(): Observable<Asset[]> {
    const url = `${this.webApiUrl}/assets`;
    return this.createApiGet({ url });
  }

  getAllCommentThreads(assetId: string): Observable<CommentsResponse[]> {
    const url = `${this.webApiUrl}/assets/comment/${assetId}`;
    return this.createApiGet({ url });
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  getAssetDetailsById(id: string): Observable<any> {
    const url = `${this.webApiUrl}/assets/assetDetails/${id}`;
    return this.createApiGet({ url });
  }

  getAssetForPreviewById(id: string): Observable<AssetForDetailsView> {
    const url = `${this.webApiUrl}/assets/assetPreviewDetails/${id}`;
    return this.createApiGet({ url });
  }

  getAssetHistory(id: string): Observable<AssetRevisions[]> {
    const url = `${this.webApiUrl}/assets/history/${id}`;
    return this.createApiGet({ url });
  }

  getAssets(sortField: number, collectionId: string, skip: number, pageSize: number, sidebarSelection: LibrarySidebarSelectionType): Observable<Asset[]> {
    let params = new HttpParams()
      .set('sortField', sortField.toString())
      .set('skip', skip.toString())
      .set('pageSize', pageSize.toString());

    if (collectionId) {
      params = params.set('collectionId', collectionId);
    }

    if (sidebarSelection === LibrarySidebarSelectionType.Favorites) {
      params = params.set('isOnMyFavorites', 'true');
    }

    if (sidebarSelection === LibrarySidebarSelectionType.ExpiredAssets) {
      params = params.set('expiredOnly', 'true');
    }

    if (sidebarSelection === LibrarySidebarSelectionType.AssetCleanup) {
      params = params.set('cleanUpOnly', 'true');
    }

    const url = `${this.webApiUrl}/assets`;
    return this.createApiGet({ url, params });
  }

  getById(id: string): Observable<Asset> {
    throw new Error('Method not implemented.' + id);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  getImageAssetFile(assetUri: string, imageType?: string): Observable<any> {
    let params = new HttpParams()
      .set('uri', encodeURIComponent(assetUri));
    if (imageType) {
      params = params.set('imageType', imageType);
    }
    const url = `${this.webApiUrl}/assets/webImage`;
    return this.createApiGet({ url, options: { responseType: 'blob' }, params });
  }

  getPermalinkUri(assetId: string): Observable<string> {
    const url = `${this.webApiUrl}/assets/${assetId}/permalinks`;
    return this.createApiPost({ url, options: { responseType: 'text' } });
  }

  getPostUploadSummary(uploadSessionId: string): Observable<PostUploadSummaryRow[]> {
    const params = new HttpParams()
      .append('uploadSessionId', uploadSessionId);

    const url = `${this.webApiUrl}/assets/postUploadSummary`;
    return this.createApiGet({ url, params });
  }

  getSocialPermaLinkUri(assetId: string, destination: string): Observable<string> {
    const params = new HttpParams()
      .set('destination', destination);
    const url = `${this.webApiUrl}/assets/${assetId}/permalinks`;
    return this.createApiPost({ url, options: { responseType: 'text' }, params });
  }

  loadAssetDesign(_id: string, _pageNumber: number): Observable<Design> {
    const shiftFrameBy = -7;
    const textFrames: Frame[] = [
      {
        height: this.convertInchesToPixels(.25),
        id: 'textFrame0',
        left: this.convertInchesToPixels(1) + shiftFrameBy,
        rotation: 0,
        top: this.convertInchesToPixels(.55) + shiftFrameBy,
        type: FrameType.Text,
        width: this.convertInchesToPixels(3.5),
        paragraphs: [
          {
            alignment: 'left',
            lineSpacing: 1,
            leading: 0,
            runs: [
                {
                    font: 'MinionPro-Regular',
                    pointSize: 12,
                    color: '#000000FF',
                    text: 'MARCOMGATHER&trade; End User License Agreement'
                }
            ]
          }
        ]
      },
      {
        height: this.convertInchesToPixels(1.6),
        id: 'textFrame1',
        left: this.convertInchesToPixels(1) + shiftFrameBy,
        rotation: 0,
        top: this.convertInchesToPixels(1) + shiftFrameBy,
        type: FrameType.Text,
        width: this.convertInchesToPixels(6.6),
        paragraphs: [
          {
            alignment: 'center',
            lineSpacing: 1,
            leading: 0,
            runs: [
                {
                    font: 'MinionPro-Regular',
                    pointSize: 12,
                    color: '#000000FF',
                    text: 'PLEASE CAREFULLY READ THE FOLLOWING TERMS AND CONDITIONS BEFORE USING THE MARCOMGATHER™ ("SOFTWARE”) PROVIDED BY PTI MARKETING TECHNOLOGIES, INC. dba MARCOMCENTRAL® ("MARCOMCENTRAL®”). IF CUSTOMER OR ITS END USERS (REFERRED TO HEREIN COLLECTIVELY AS “CUSTOMER” OR ‘YOU”) DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS MARCOMGATHER™ SOFTWARE END USER LICENSE AGREEMENT ("AGREEMENT” OR “EULA”), DO NOT USE THE SOFTWARE. YOUR ACCESS TO AND USE OF THE SOFTWARE OR ANY MARCOMGATHER™ ACCOUNT, ACCESS CODE OR KEY THERETO SHALL CONSTITUTE YOUR ACCEPTANCE OF THE TERMS OF THIS AGREEMENT. '
                }
            ]
          }
        ]
      },
      // {
      //   height: this.convertInchesToPixels(2.73153),
      //   id: 'textFrame1',
      //   left: this.convertInchesToPixels(1.84569) + shiftFrameBy,
      //   rotation: 0,
      //   top: this.convertInchesToPixels(1.51639) + shiftFrameBy,
      //   type: FrameType.Text,
      //   width: this.convertInchesToPixels(2.84236),
      //   paragraphs: [
      //     {
      //       alignment: 'center',
      //       lineSpacing: 1,
      //       leading: 0,
      //       runs: [
      //           {
      //               font: 'MinionPro-Regular',
      //               pointSize: 12,
      //               color: '#000000FF',
      //               text: 'Mixed-aligned:'
      //           }
      //       ]
      //     },
      //     {
      //         alignment: 'center',
      //         lineSpacing: 1,
      //         leading: 0,
      //         runs: [
      //             {
      //                 font: 'MinionPro-Regular',
      //                 pointSize: 12,
      //                 color: '#000000FF',
      //                 text: 'here is some 12 and'
      //             },
      //             {
      //                 font: 'MinionPro-Regular',
      //                 pointSize: 20,
      //                 color: '#000000FF',
      //                 text: ' 20 point text '
      //             }
      //         ]
      //     },
      //     {
      //         alignment: 'center',
      //         lineSpacing: 1,
      //         leading: 0,
      //         runs: [
      //             {
      //                 font: 'MinionPro-Regular',
      //                 pointSize: 12,
      //                 color: '#000000FF',
      //                 text: 'which can wrap to a new line if the box is small enough'
      //             }
      //         ]
      //     },
      //     {
      //         alignment: 'right',
      //         lineSpacing: 1,
      //         leading: 0,
      //         runs: [
      //             {
      //                 font: 'MinionPro-Regular',
      //                 pointSize: 20,
      //                 color: '#000000FF',
      //                 text: 'here is some 20 point text which can wrap to a new line if the box is small enough'
      //             }
      //         ]
      //     }
      //   ]
      // },
      {
          height: this.convertInchesToPixels(1.12292),
          id: '2',
          left: this.convertInchesToPixels(4.91819) + shiftFrameBy,
          rotation: 0,
          top: this.convertInchesToPixels(5.10361) + shiftFrameBy,
          type: FrameType.Text,
          width: this.convertInchesToPixels(2.59333),
          paragraphs: [
              {
                  alignment: 'right',
                  lineSpacing: 1,
                  leading: 0,
                  runs: [
                      {
                          font: 'MinionPro-Regular',
                          pointSize: 32,
                          color: 'red',
                          text: 'Right-aligned:'
                      }
                  ]
              },
              {
                  alignment: 'right',
                  lineSpacing: 1,
                  leading: 0,
                  runs: [
                      {
                          font: 'MinionPro-Regular',
                          pointSize: 10,
                          color: '#000000FF',
                          text: 'here is some 10 point text which can wrap to a new line if the box is small enough'
                      }
                  ]
              }
          ]
      },
      {
        height: this.convertInchesToPixels(3.34819),
        id: '3',
        left: this.convertInchesToPixels(2.05875) + shiftFrameBy,
        rotation: 0,
        top: this.convertInchesToPixels(4.67639) + shiftFrameBy,
        type: FrameType.Text,
        width: this.convertInchesToPixels(2.33639),
        paragraphs: [
            {
                alignment: 'left',
                lineSpacing: 1,
                leading: 0,
                runs: [
                  {
                      font: 'MinionPro-Regular',
                      pointSize: 12,
                      color: '#000000FF',
                      text: 'Left-aligned:'
                  }
              ]
            },
            {
                alignment: 'left',
                lineSpacing: 1,
                leading: 0,
                runs: [
                  {
                      font: 'MinionPro-Regular',
                      pointSize: 12,
                      color: '#000000FF',
                      text: 'here is some 12 point text which can wrap to a new line if the box is small enough'
                  }
              ]
            },
            {
                alignment: 'left',
                lineSpacing: 1.25,
                leading: 0,
                runs: [
                    {
                        font: 'MinionPro-Regular',
                        pointSize: 20,
                        color: '#000000FF',
                        text: 'here is some 20 on 30 point text which can wrap to a new line if the box is small enough'
                    }
                ]
            }
        ]
      },
    ];

    textFrames.forEach(textFrame => {
      textFrame.htmlContent = this.convertToHtml(textFrame.paragraphs);
    });

    const imageFrames: Frame[] = [
      // {
      //   content: 'jensen-logo.jpg',
      //   height: 74,
      //   id: 'imageFrame1',
      //   left: 22,
      //   top: 80,
      //   type: FrameType.Image,
      //   width: 167
      // },
      // {
      //   content: 'jensen-logo.jpg',
      //   height: 74,
      //   id: 'imageFrame2',
      //   left: 25,
      //   top: 712,
      //   type: FrameType.Image,
      //   width: 167
      // },
    ];
    const pages: Page[] = [
      {
        height: 1056, // 11 x 96
        imageFrames,
        pageIndex: 0,
        textFrames,
        url: '',
        width: 816 // 8.5 x 96
      },
      {
        height: 1056, // 11 x 96
        imageFrames: [],
        pageIndex: 1,
        textFrames: [],
        url: '',
        width: 816 // 8.5 x 96
      },
      {
        height: 1056, // 11 x 96
        imageFrames,
        pageIndex: 2,
        textFrames,
        url: '',
        width: 816 // 8.5 x 96
      },
      {
        height: 1056, // 11 x 96
        imageFrames,
        pageIndex: 3,
        textFrames,
        url: '',
        width: 816 // 8.5 x 96
      }
    ];
    const design1: Design = {
      activePage: pages[0],
      hasSubsetFonts: true,
      id: 'My Design',
      messageType: 'CUSTOMIZE_ASSET_READY',
      pageCount: 4,
      pages,
      signalRConnectionId: '93c4fd89-e4e3-4a5b-8823-99df277b7c06',
      source: 'WebapiTest'
    }
    return of(design1);
  }

  loadMetadataProfileInfo(): Observable<MetadataProfileInfo> {
    const url = `${this.webApiUrl}/assets/metadataProfileInfo`;
    return this.createApiGet({ url });
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  loadSampleData(): Observable<any> {
    const url = `${this.webApiUrl}/assets/sampleassets`;
    return this.createApiPost({ url });
  }

  moveAssetsToCollection(assets: Asset[], collection: Collection): Observable<MoveAssetToCollectionResponse> {
    const ids: string[] = assets?.map(u => u.id);
    const updateCollectionRequest = {
      ids,
      collectionId: collection?.id
    }
    const url = `${this.webApiUrl}/assets/bulk/collection`;
    return this.createApiPost({ url, data: updateCollectionRequest });
  }

  queryAssets(sortField: number, collectionId: string, skip: number, pageSize: number, searchTerm: string, filterRequests: FilterRequest[],
    searchFavorites: boolean, lightboxId: string, searchExpiredAssets: boolean, searchCleanupAssets: boolean): Observable<SearchResults> {
    const queryRequest = {
      filterRequests,
      sortField,
      collectionId,
      skip,
      pageSize,
      searchTerm,
      includeFilters: true,
      searchFavorites,
      lightboxId,
      searchExpiredAssets,
      searchCleanupAssets
    };
    const url = `${this.webApiUrl}/searchAssets`;
    return this.createApiPost({ url, data: queryRequest });
  }

  saveAssetMetadata(assets: Asset[], tags: Tag[], metadata: Metadata[]): Observable<AssetsAndMetadataAndTags> {
    const updateMetadataRequest = {
      assets,
      tags,
      metadata
    };

    const url = `${this.webApiUrl}/assets/bulk/metadata`;
    return this.createApiPost({ url, data: updateMetadataRequest });
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  saveAssetsToHistoryUsage(action: string, assetIds: string[], actionDetails?: string): Observable<any> {
    const usageRequest = {
      action,
      assetIds,
      actionDetails
    };

    const url = `${this.webApiUrl}/assets/usage`;
    return this.createApiPost({ url, data: usageRequest });
  }

  saveTags(tags: Tag[]): Observable<Tag[]> {
    const updateTagsRequest = {
      tags
    };

    const url = `${this.webApiUrl}/assets/bulk/tags`;
    return this.createApiPost({ url, data: updateTagsRequest });
  }

  sendComment(comment: Comment, assetId: string): Observable<Comment> {
    const url = `${this.webApiUrl}/assets/comment/${assetId}`;
    return this.createApiPost({ url, data: comment });
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  updateAsset(asset: AssetUpdate): Observable<any> {
    const url = `${this.webApiUrl}/assets/${asset.id}`;
    return this.createApiPut({ url, data: asset });
  }

  updateAssets(assets: Asset[]): Observable<Asset[]> {
    throw new Error('Method not implemented.' + assets.length.toString());
  }

  updateComment(comment: Comment, assetId: string): Observable<Comment> {
    const url = `${this.webApiUrl}/assets/${assetId}/comment/${comment.id}`;
    return this.createApiPost({ url, data: comment });
  }

  updateFavorite(assetId: string, isFavorite: boolean): Observable<Favorite> {
    const favorite = {
      id: assetId,
      favorite: isFavorite
    }
    const url = `${this.webApiUrl}/assets/${assetId}/favorite`;
    return this.createApiPost({ url, data: favorite });
  }

  updateFavorites(assetsIds: string[], isFavorite: boolean): Observable<Favorite[]> {
    const updateFavoritesRequest = {
      ids: assetsIds,
      isFavorite
    };
    const url = `${this.webApiUrl}/assets/bulk/favorites`;
    return this.createApiPost({ url, data: updateFavoritesRequest });
  }

  updateMetadata(assets: Asset[]): Observable<Metadata[]> {
    throw new Error('Method not implemented.' + assets.length.toString());
  }

  updateMetadatum(metadatum: MetadataData, assetId: string): Observable<MetadataData[]> {
    const metadatumDto = {
      assetId,
      metadataFieldId: metadatum.metadataFieldId,
      value: metadatum.value,
      metadataFieldValueId: metadatum.metadataFieldValueId
    }
    const url = `${this.webApiUrl}/assets/metadatum`;
    return this.createApiPost({ url, data: metadatumDto });
  }

  updateTag(tagDto: Tag): Observable<Tag> {
    const url = `${this.webApiUrl}/assets/tag`;
    return this.createApiPost({ url, data: tagDto });
  }

  private convertInchesToPixels(inches: number): number {
    return inches * 96;
  }

  private convertPointsToPixels(points: number): string {
    return (points*(96/72)).toFixed(1) + 'px';
  }

  private convertToHtml(paragraphs: Paragraph[]): string {
    let htmlString = '';
    paragraphs.forEach(paragraph => {
      htmlString += '<p style="padding-bottom:10px;'; // open paragraph tag
      htmlString += ` line-height:${paragraph.lineSpacing};`
      htmlString += ` text-align: ${paragraph.alignment};`;
      htmlString += '">'; // close style attribute and opening paragraph tag
      paragraph.runs.forEach(run => {
        htmlString += '<span'; // open span tag
        htmlString += ' style="';
        htmlString += run.font ? `font-family:'${run.font}';` : '';
        htmlString += run.pointSize ? ` font-size:${this.convertPointsToPixels(run.pointSize)};` : '';
        htmlString += run.color ? ` color:${run.color};` : '';
        htmlString += '">'; // close style attribute and opening span tag
        htmlString += run.text;
        htmlString += '</span>' // close span tag
      });
      htmlString += '</p>';
    });
    return htmlString;
  }
}
