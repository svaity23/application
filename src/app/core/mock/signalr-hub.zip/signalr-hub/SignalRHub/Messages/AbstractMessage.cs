﻿namespace SignalRHub.Messages
{
    public abstract class AbstractMessage
    {
        public string MessageType { get; set; }
    }
}
