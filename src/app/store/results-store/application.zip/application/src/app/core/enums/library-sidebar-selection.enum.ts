export enum LibrarySidebarSelectionType {
  AllAssets,
  AssetCleanup,
  Favorites,
  Lightbox,
  Hubspot,
  Collection,
  ExpiredAssets
}
