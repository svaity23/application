import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';

import { AccountDetail } from '@app/core/models/entities/account-detail.model';

@Component({
  selector: 'app-account-header',
  templateUrl: './account-header.component.html',
  styleUrls: ['./account-header.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountHeaderComponent implements OnInit, OnChanges {

  @Input() account: AccountDetail;
  @Input() accountFeaturesModified = false;
  @Input() accountFormValidAndTouched = false;
  @Output() backToAllAccountsEvent = new EventEmitter();
  @Output() cancel = new EventEmitter();
  isDisabled = true;
  @Input() isSavingChanges = false;
  navigateBackButtonText: string;
  @Output() save = new EventEmitter<string>();
  @Input() selectedTab: string;
  constructor() { }

  backToAllAccounts(): void {
    this.backToAllAccountsEvent.emit();
  }

  cancelEvent(): void {
    this.cancel.emit(this.account.id);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.isSavingChanges
      || changes.accountFormValidAndTouched
      || changes.accountFeaturesModified
      || changes.selectedTab) {
      this.evaluateDisabled();
    }
  }

  ngOnInit(): void {
    this.navigateBackButtonText = 'Back to Accounts'
  }

  saveChanges(): void {
    this.save.emit(this.account?.id);
  }

  private evaluateDisabled(): void {
    if (this.isSavingChanges) {
      this.isDisabled = true;
    } else {
      switch (this.selectedTab) {
        case 'accountdetails':
          this.isDisabled = !this.accountFormValidAndTouched;
          break;
        case 'integrations':
          this.isDisabled = !this.accountFeaturesModified;
          break;
      }
    }
  }
}
