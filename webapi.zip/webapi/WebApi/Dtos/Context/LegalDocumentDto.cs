﻿using System.Text.Json.Serialization;

namespace WebApi.Dtos.Context
{
    public class LegalDocumentDto
    {
        [JsonPropertyName("documentType")]
        public string DocumentType { get; set; }

        [JsonPropertyName("legalId")]
        public int LegalId { get; set; }

        [JsonPropertyName("version")]
        public string Version { get; set; }

        [JsonPropertyName("location")]
        public string Location { get; set; }
    }
}
