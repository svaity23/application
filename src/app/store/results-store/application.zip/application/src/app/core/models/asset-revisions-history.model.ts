import { AssetRevisionsUser } from './asset-revisions-user.model';

export interface AssetRevisionsHistory {
    action: string;
    actionDetails?: string;
    created: Date;
    user: AssetRevisionsUser;
}
