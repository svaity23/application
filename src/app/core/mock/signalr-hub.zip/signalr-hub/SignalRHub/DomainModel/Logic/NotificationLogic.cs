﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using SignalRHub.DomainModel.Context;
using SignalRHub.DomainModel.Finders;
using System;
using System.Threading.Tasks;

namespace ApplicationLogic.Logic
{
    public class NotificationLogic
    {
        public ILogger<NotificationLogic> Logger { get; set; }

        private readonly NotificationFinder _finder;

        public NotificationLogic(damContext context)
        {
            _finder = new NotificationFinder(context);
            Logger = NullLogger<NotificationLogic>.Instance;
        }

        public async Task<string> GetNotificationByAssetCommentIdAsync(Guid assetCommentId)
        {
            return await _finder.GetNotificationByAssetCommentIdAsync(assetCommentId);
        }
    }
}
