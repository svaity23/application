﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Common.Constants
{
    public static class KeyVaultSecretKey
    {
        public const string BlobStorageKey = "KeyVault:Secrets:BlobStorageKey";
        public const string GoogleRecaptchaV2 = "KeyVault:Secrets:GoogleRecaptchaV2SecretKey";
        public const string HubspotClientSecret = "KeyVault:Secrets:HubspotClientSecret";
        public const string SlackClientSecret = "KeyVault:Secrets:SlackClientSecret";
        public const string IdTokenAdb2cCert = "KeyVault:Certificates:IdTokenAdb2cCert";
        public const string CanvaClientSecret = "KeyVault:Secrets:CanvaClientSecret";
    }
}