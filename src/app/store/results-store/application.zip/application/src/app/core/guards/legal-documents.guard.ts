import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { filter, map, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AppStoreFacade } from '@app/store/app-store/app-store.facade';
import { EulaStoreFacade } from '@app/store/eula-store/eula-store.facade';

@Injectable({
  providedIn: 'root'
})
export class LegalDocumentsGuard implements CanActivate {

  constructor(private appStoreFacade: AppStoreFacade, private eulaStoreFacade: EulaStoreFacade, private router: Router) { }

  canActivate(
    // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
    _route: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
    _state: RouterStateSnapshot): Observable<boolean | UrlTree> {

      return this.hasLegalDocumentsToAccept();
    }

    private hasLegalDocumentsToAccept(): Observable<boolean| UrlTree> {
      return this.eulaStoreFacade.eulaState$.pipe(
        tap(state => {
          if (!state.loaded) {
            this.appStoreFacade.loadContext();
          }
        }),
        filter(state => state.loaded),
        map(state => {
          const legalsToAccept = state.legalDocuments.length;
          if (legalsToAccept === 0) {
            return this.router.parseUrl('/');
          } else {
            return true;
          }
        })
      );
    }
  }
