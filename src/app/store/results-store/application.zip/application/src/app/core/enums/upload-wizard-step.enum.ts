export enum UploadWizardStep {
    Upload = 'Upload',
    AddToCollection = 'Add to Collection',
    AddMetadata = 'Add Metadata',
    Customize = 'Customize'
}
