import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { AccountDetail } from '../models/entities/account-detail.model';
import { BaseDataService } from './base-data.service';
import { Feature } from '../models/feature.model';
import { FederatedDomain } from '../models/entities/federated-domain.model';
import { UpsertEntityResponse } from '../models/api-responses/upsert-entity-response.model';
import { User } from '@app/core/models/entities/user.model';

export interface AccountsDataServiceInterface {
    add(account: AccountDetail): Observable<UpsertEntityResponse<AccountDetail>>;
    deleteAccount(id: string): Observable<boolean>;
    getAccountFeatures(id: string): Observable<Feature[]>;
    getAccountUsers(id: string): Observable<User[]>;
    getAll(): Observable<AccountDetail[]>;
    getById(id: string): Observable<AccountDetail>;
    updateAccount(account: AccountDetail): Observable<UpsertEntityResponse<AccountDetail>>;
    updateAccountFeatures(id: string, features: Feature[]): Observable<Feature[]>;
}

@Injectable({ providedIn: 'root' })
export class AccountsDataService extends BaseDataService implements AccountsDataServiceInterface {
    add(account: AccountDetail): Observable<UpsertEntityResponse<AccountDetail>> {
        const dto = {
            Name: account.name,
            AccountTypeName: account.accountTypeName,
            Active: account.active,
            NetsuiteId: account.netsuiteId,
            OpportunityId: account.opportunityId,
            StorageMaximumGb: account.storageMaximumGb,
            SalesforceId: account.salesforceId,
            TrialExpiration: account.trialExpiration,
            UserEmail: account.userEmail,
            UserFirstName: account.userFirstName,
            UserLastName: account.userLastName
        };
        const url = `${this.webApiUrl}/accounts`;
        return this.createApiPost({ url, data: dto });
    }

    deleteAccount(id: string): Observable<boolean> {
      const url = `${this.webApiUrl}/accounts/${id}`;
      return this.createApiDelete({ url });
    }

    getAccountFeatures(id: string): Observable<Feature[]> {
        const url = `${this.webApiUrl}/accounts/${id}/features`;
        return this.createApiGet({ url });
    }

    getAccountUsers(id: string): Observable<User[]> {
        const url = `${this.webApiUrl}/accounts/${id}/users`;
        return this.createApiGet({ url });
    }

    getAll(): Observable<AccountDetail[]> {
        const url = `${this.webApiUrl}/accounts`;
        return this.createApiGet({ url });
    }

    getById(id: string): Observable<AccountDetail> {
        const url = `${this.webApiUrl}/accounts/${id}`;
        return this.createApiGet({ url });
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    indexAssetSearch(id: string): Observable<any> {
        const url = `${this.webApiUrl}/admin/indexSearch/${id}`;
        return this.createApiPost({ url });
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    indexAssetSearchForAllAccounts(): Observable<any> {
        const url = `${this.webApiUrl}/admin/indexSearch`;
        return this.createApiPost({ url });
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    processAssets(accoundId: string): Observable<any> {
        const url = `${this.webApiUrl}/admin/processAssets/${accoundId}`;
        return this.createApiPost({ url });
    }

    removeFederatedDomains(accoundId: string, domainIds: string[]): Observable<UpsertEntityResponse<string[]>> {
        const bulkRequest = {
            Ids: domainIds
        };
        const url = `${this.webApiUrl}/accounts/${accoundId}/federation/deletes`;
        return this.createApiPost({ url, data: bulkRequest });
    }

    saveFederatedDomain(accoundId: string, domain: string, active: boolean): Observable<UpsertEntityResponse<FederatedDomain>> {
        const dto = {
            Domain: domain,
            Active: active
        };

        const url = `${this.webApiUrl}/accounts/${accoundId}/federation`;
        return this.createApiPut({ url, data: dto });
    }

    syncAccountUsers(id: string): Observable<AccountDetail> {
        const url = `${this.webApiUrl}/admin/syncUsers/${id}`;
        return this.createApiPost({ url });
    }

    updateAccount(account: AccountDetail): Observable<UpsertEntityResponse<AccountDetail>> {
        const dto = {
            Id: account.id,
            Name: account.name,
            Active: account.active,
            AccountTypeName: account.accountTypeName,
            OpportunityId: account.opportunityId,
            NetsuiteId: account.netsuiteId,
            SalesforceId: account.salesforceId,
            StorageMaximumGb: account.storageMaximumGb,
            TrialExpiration: account.trialExpiration,
            UserID: account.userId,
            UserEmail: account.userEmail,
            UserFirstName: account.userFirstName,
            UserLastName: account.userLastName
        };
        const url = `${this.webApiUrl}/accounts/${account.id}`;
        return this.createApiPut({ url, data: dto });
    }

    updateAccountFeatures(id: string, features: Feature[]): Observable<Feature[]> {
        const url = `${this.webApiUrl}/accounts/${id}/features`;
        return this.createApiPut({ url, data: features });
    }
}
