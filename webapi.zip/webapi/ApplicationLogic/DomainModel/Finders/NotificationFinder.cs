﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class NotificationFinder
    {

        private readonly ILogger<NotificationFinder> _logger;
        private readonly damContext _context;

        public NotificationFinder(damContext context)
        {
            _context = context;
            _logger = NullLogger<NotificationFinder>.Instance;
        }

        public async Task<string> GetAllNotificationAsync(Guid accountId, Guid userId)
        {
            return await ExecuteAsync("getNotifications", accountId, userId);
        }

        private async Task<string> ExecuteAsync(string procedure, Guid accountId, Guid userId, string json = null)
        {
            SpParams paramList = new SpParams();
            paramList.WithAccountId(accountId);
            paramList.WithUserId(userId);
            if (json!=null) paramList.WithJson(json);

            List<SqlParameter> sqlParmsList = paramList.Build();
            return await _context.ExecuteNonQueryJsonOutputAsync(procedure, sqlParmsList).ConfigureAwait(false);
        }

        public async Task<string> MarkAsReadAsync(Guid accountId, Guid userId, string jsonInput)
        {
            SpParams paramList = new SpParams();
            paramList.WithAccountId(accountId);
            paramList.WithUserId(userId);
            paramList.WithJson(jsonInput);

            List<SqlParameter> sqlParmsList = paramList.Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("markNotification", sqlParmsList).ConfigureAwait(false);
        }

        public async Task<string> DeleteAsync(Guid accountId, Guid userId, Guid notificationId)
        {
            _logger.LogInformation($"[Finder] Delete one notification for" +
                $"\n\taccount = {accountId}" +
                $"\n\tuser = {userId}" +
                $"\n\tid:\n{notificationId}");

            SpParams paramList = new SpParams();
            paramList.WithAccountId(accountId);
            List<SqlParameter> sqlParamsList = paramList.Build();

            SqlParameter param = new SqlParameter("@notificationId", SqlDbType.UniqueIdentifier)
            {
                Value = notificationId
            };
            sqlParamsList.Add(param);

            return await _context.ExecuteNonQueryJsonOutputAsync("deleteNotificationById", sqlParamsList).ConfigureAwait(false);
        }

    }
}
