export enum FieldType {
    Text = 0,
    Dropdown = 1,
    Textarea = 2,
    Checkbox = 3,
    Radio = 4,
    Date = 5
}
