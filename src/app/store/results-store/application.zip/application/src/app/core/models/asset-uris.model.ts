export interface AssetUris {
  asset: string;
  'low-resolution': string;
  metadata: string;
  thumbnail: string;
  web: string;
}
