import { HubspotEntityResponse } from './hubspot-entity-response.model';
import { IdEntityResponse } from './id-entity-response.model';

export interface DeleteAssetsResponse {
    assetIds: IdEntityResponse[],
    errors?: string[];
    idsOnHubspot?: HubspotEntityResponse[]
}