
Task AzLoginMSI {
    "Logging into container registry"
    exec { az login --identity }
}