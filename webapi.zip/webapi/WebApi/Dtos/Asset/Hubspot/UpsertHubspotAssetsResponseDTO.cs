﻿using System;

namespace WebApi.Dtos.Asset.Hubspot
{
    public class UpsertHubspotAssetsResponseDTO
    {
        public Guid[] Ids { get; set; }
    }
}
