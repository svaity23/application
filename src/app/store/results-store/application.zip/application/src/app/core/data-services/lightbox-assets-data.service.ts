import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { BaseDataService } from './base-data.service';

import { Asset } from '../models/entities/asset.model';
import { Lightbox } from '../models/entities/lightbox.model';
import { UpsertLightboxAssetsResponse } from '../models/api-responses/upsert-lightbox-assets-response.model';

export interface LightboxAssetsDataServiceInterface {
  deleteAssets(assets: Asset[], lightboxId: string): Observable<string[]>;
  getAssets(sortField: number, lightboxId: string, skip: number, pageSize: number, isOnMyFavorites: boolean): Observable<Asset[]>;
  moveAssetsToLightbox(assets: Asset[], lightbox: Lightbox): Observable<UpsertLightboxAssetsResponse>;
}

@Injectable({ providedIn: 'root' })
export class LightboxAssetsDataService extends BaseDataService implements LightboxAssetsDataServiceInterface {
  deleteAssets(assets: Asset[], lightboxId: string): Observable<string[]> {
    const assetIds: string[] = assets.map(u => u.id);
    const request = {
      assetIds,
      lightboxId
    };
    const url = `${this.webApiUrl}/lightboxAssets/bulk/delete`;
    return this.createApiPost({ url, data: request });
  }

  getAssets(sortField: number, lightboxId: string, skip: number, pageSize: number, isOnMyFavorites: boolean): Observable<Asset[]> {
    let params = new HttpParams()
      .set('sortField', sortField.toString())
      .set('skip', skip.toString())
      .set('pageSize', pageSize.toString());

    if (lightboxId) {
      params = params.set('lightboxId', lightboxId);
    }

    if (isOnMyFavorites) {
      params = params.set('isOnMyFavorites', 'true');
    }

    const url = `${this.webApiUrl}/lightboxAssets`;
    return this.createApiGet({ url, params });
  }

  moveAssetsToLightbox(assets: Asset[], lightbox: Lightbox): Observable<UpsertLightboxAssetsResponse> {
    const ids: string[] = assets?.map(u => u.id);
    const upsertLightboxAssetsRequest = {
      ids,
      lightboxId: lightbox?.id
    };
    const url = `${this.webApiUrl}/lightboxAssets`;
    return this.createApiPost({ url, data: upsertLightboxAssetsRequest });
  }
}