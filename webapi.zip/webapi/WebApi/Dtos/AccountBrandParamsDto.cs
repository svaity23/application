﻿using System.Text.Json.Serialization;

namespace WebApi.Dtos
{
    public class AccountBrandParamsDto
    {
        [JsonPropertyName("logo")]
        public string Logo { get; set; }
        [JsonPropertyName("favicon")]
        public string Favicon { get; set; }
        [JsonPropertyName("theme")]
        public string Theme { get; set; }
    }
}
