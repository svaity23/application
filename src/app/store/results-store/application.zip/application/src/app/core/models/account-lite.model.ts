import { AccountTypeKey } from '@app/core/enums/account-type-key.enum';

export interface AccountLite {
    accountTypeName: AccountTypeKey;
    id: string;
    name: string;
}
