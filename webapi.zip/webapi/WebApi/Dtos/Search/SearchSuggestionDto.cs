﻿namespace WebApi.Dtos.Search
{
    public class SearchSuggestionDto
    {
        public int Count { get; set; }
        public string Name { get; set; }
    }
}
