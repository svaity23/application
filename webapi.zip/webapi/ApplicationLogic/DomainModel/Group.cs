﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ApplicationLogic.DomainModel
{
    [Table("group")]
    public partial class Group
    {
        [Key]
        [Column("id")]
        public Guid Id { get; set; }
        [Column("externalId")]
        [StringLength(64)]
        public string ExternalId { get; set; }
        [Column("accountId")]
        public Guid AccountId { get; set; }
        [Column("active")]
        public bool Active { get; set; }
        [Column("created")]
        public DateTime Created { get; set; }
        [Column("modified")]
        public DateTime? Modified { get; set; }
        [Required]
        [Column("name")]
        [StringLength(64)]
        public string Name { get; set; }
        [Column("description")]
        [StringLength(256)]
        public string Description { get; set; }
        [Column("type")]
        [StringLength(32)]
        public string Type { get; set; }

        [ForeignKey(nameof(AccountId))]
        [InverseProperty("Group")]
        public virtual Account Account { get; set; }
    }
}
