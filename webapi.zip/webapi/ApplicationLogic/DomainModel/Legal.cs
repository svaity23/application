﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ApplicationLogic.DomainModel
{
    [Table("legal")]
    public partial class Legal
    {
        public Legal()
        {
            UserLegal = new HashSet<UserLegal>();
        }

        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Required]
        [Column("active")]
        public bool? Active { get; set; }
        [Column("created")]
        public DateTime Created { get; set; }
        [Column("modified")]
        public DateTime? Modified { get; set; }
        [Column("typeId")]
        public int TypeId { get; set; }
        [Required]
        [Column("versionBreak")]
        [StringLength(11)]
        public string VersionBreak { get; set; }
        [Required]
        [Column("versionFeature")]
        [StringLength(11)]
        public string VersionFeature { get; set; }
        [Required]
        [Column("versionFix")]
        [StringLength(11)]
        public string VersionFix { get; set; }
        [Required]
        [Column("location")]
        [StringLength(512)]
        public string Location { get; set; }

        [InverseProperty("Legal")]
        public virtual ICollection<UserLegal> UserLegal { get; set; }
    }
}
