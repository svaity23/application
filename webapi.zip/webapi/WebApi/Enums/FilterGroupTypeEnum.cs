﻿namespace WebApi.Enums
{
    public enum FilterGroupTypeEnum
    {
         FileGroup = 0, // synonymous to metadataProfileType
         UploadDate = 1,
         FileSize = 2,
         Tags = 3,
         Metadata = 4
    }
}
