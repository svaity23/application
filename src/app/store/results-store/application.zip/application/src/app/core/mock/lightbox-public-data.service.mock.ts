import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { LightboxPublicDataServiceInterface } from '../data-services/lightbox-public-data.service';

import { Asset } from '../models/entities/asset.model';
import { LightboxPublic } from '../models/lightbox-public.model';
import { PublicLightboxSearchResults } from '../models/public-lightbox-search-results.model';


@Injectable({ providedIn: 'root' })
export class LightboxPublicDataServiceMock implements LightboxPublicDataServiceInterface {

	constructor() {
	}

	getLightbox(_id: string): Observable<LightboxPublic> {
		throw new Error('Method not implemented.');
	}

	loadMoreAssets(_id: string, _sortField: number, _skip: number, _pageSize: number): Observable<Asset[]> {
		throw new Error('Method not implemented.');
	}

	// tslint:disable-next-line: max-line-length
	queryAssets(_sortField: number, _skip: number, _pageSize: number, _searchTerm: string, _lightboxId: string): Observable<PublicLightboxSearchResults> {
			throw new Error('Method not implemented.');
	}
}
