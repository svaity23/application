import { FilterGroupType } from '../enums/filter-group-type.enum';

export interface FilterGroup {
  displayOrder: number;
  filterGroupType: FilterGroupType;
  metadataFieldId: string;
  name: string;
}
