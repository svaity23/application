export interface Group {
    accountId: string;
    active: boolean | true;
    description: string;
    externalId: string;
    id: string; // guid
    name: string;
    selected: boolean | false;
}
