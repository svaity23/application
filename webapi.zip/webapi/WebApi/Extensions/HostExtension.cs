﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Threading.Tasks;
using WebApi.Services;

namespace WebApi.Extensions
{
    public static class HostExtension
    {
        public static async Task<IHost> InitializeAsync(this IHost host)
        {
            var service = host.Services.GetRequiredService<ServiceBusService>();
            await service.InitializeAsync();

            return host;
        }
    }
}
