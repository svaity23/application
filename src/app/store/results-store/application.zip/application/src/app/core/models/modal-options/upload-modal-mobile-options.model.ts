import { CustomTheme } from '../custom-theme.model';
import { FileSystemFile } from '../file-system-file.model';

export interface UploadModalMobileOptions {
  onFilesSelected: (files: FileSystemFile[]) => void;
  selectedTheme?: CustomTheme;
}
