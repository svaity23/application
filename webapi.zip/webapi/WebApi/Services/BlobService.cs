﻿using ApplicationLogic.DomainModel;
using Azure.Storage;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Sas;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Common.Constants;
using WebApi.Dtos;
using WebApi.Enums;

namespace WebApi.Services
{
    public class BlobService
    {
        private readonly ILogger<BlobService> _logger;
        private readonly IConfiguration _configuration;
        private readonly BlobServiceClient _blobServiceClient;
        private readonly ServiceBusService _serviceBusService;
        private KeyVaultService _keyVaultService;
        private IHttpContextAccessor _httpContextAccessor;

        public BlobService(ILogger<BlobService> logger, IConfiguration configuration, BlobServiceClient blobServiceClient, ServiceBusService serviceBusService, KeyVaultService keyVaultService, IHttpContextAccessor httpContextAccessor)
        {
            _logger = logger;
            _configuration = configuration;
            _blobServiceClient = blobServiceClient;
            _serviceBusService = serviceBusService;
            _keyVaultService = keyVaultService;
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task CreateBlobContainerAsync(string storageAccountName, string containerName)
        {
            _logger.LogDebug("BEGIN: CreateBlobContainerAsync");

            var blobStorageUri = GetBlobStorageUri(storageAccountName);

            var blobContainerClient = _blobServiceClient.GetBlobContainerClient(containerName);

            _logger.LogDebug($"BEGIN: Create {containerName}");
            await blobContainerClient.CreateIfNotExistsAsync(PublicAccessType.None);
            _logger.LogDebug($"END: Create {containerName}");

            _logger.LogDebug("END: CreateBlobContainerAsync");
        }

        public async Task<BlobClient> UploadAsync(string containerName, string blobName, Stream stream, IProgress<long> progressHandler = null, BlobHttpHeaders blobHttpHeaders = null)
        {
            _logger.LogDebug($"BEGIN: UploadAsync {blobName}");

            BlobContainerClient blobContainerClient = _blobServiceClient.GetBlobContainerClient(containerName);
            var blobClient = blobContainerClient.GetBlobClient(blobName);

            // Upload the blob.
            try
            {
                await UploadSafeAsync(blobClient, stream, progressHandler);
            }
            catch (Azure.RequestFailedException ex)
            {
                if (ex.ErrorCode != "ContainerNotFound")
                    throw;

                // make the container
                _logger.LogDebug("BEGIN: CreateIfNotExistsAsync");
                await blobContainerClient.CreateIfNotExistsAsync(PublicAccessType.None);  // if not exists in case another instance of this code beat us here (already created it)
                _logger.LogDebug("END: CreateIfNotExistsAsync");

                // get a fresh container and blob client (to avoid file corruption I've seen without doing this)
                blobContainerClient = _blobServiceClient.GetBlobContainerClient(containerName);
                blobClient = blobContainerClient.GetBlobClient(blobName);

                // upload the blob
                await UploadSafeAsync(blobClient, stream, progressHandler: progressHandler, blobHttpHeaders: blobHttpHeaders);
            }

            _logger.LogDebug($"END: UploadAsync {blobName}");
            return blobClient;
        }

        private static async Task UploadSafeAsync(BlobClient blobClient, Stream stream, IProgress<long> progressHandler, BlobHttpHeaders blobHttpHeaders = null)
        {
            if (progressHandler != null)
            {
                await blobClient.UploadAsync(stream, new BlobUploadOptions() { ProgressHandler = progressHandler });
            }
            else if (blobHttpHeaders != null)
            {
                await blobClient.UploadAsync(stream, blobHttpHeaders);
            }
            else
            {
                await blobClient.UploadAsync(stream, true);
            }
        }

        /// <summary>
        /// Used to process ALL blobs in the sourceContainerName thru the image-converter
        /// Can be a very expensive operation
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="activeAssets"></param>
        /// <returns></returns>
        public async Task<int> ProcessAssets(Guid accountId, List<Asset> activeAssets)
        {
            string storageAccountName = _configuration["BlobStorage:StorageAccountName"];
            string sourceContainerName = GetBlobContainerName(accountId, "asset");


            // Get all blobs from source container            
            var sourceContainerClient = _blobServiceClient.GetBlobContainerClient(sourceContainerName);
            var sourceBlobs = sourceContainerClient.GetBlobs();
            var successCount = 0;

            foreach (var sourceBlob in sourceBlobs)
            {
                if (Guid.TryParse(Path.GetFileNameWithoutExtension(sourceBlob.Name), out Guid assetId))
                {
                    // Only copy active assets
                    // if (activeAssets.Contains(assetId))
                    var asset = activeAssets.Where(a => a.Id == assetId).FirstOrDefault();
                    if (asset != null && FileService.IsVideoFile(asset.FileExtension))
                    {
                        // This will be picked up by cancel-upload and image-converter
                        await _serviceBusService.SignalImageUploaded(new
                        {
                            MessageType = ServiceBusMessageType.VIDEO_UPLOADED,
                            AssetId = assetId.ToString(),
                            UploadSessionId = "NOT USED",
                            AccountId = accountId,
                            StorageAccountName = storageAccountName,
                            BlobName = sourceBlob.Name,
                            FileGroup = FileGroupType.Video,
                            ID = Guid.NewGuid(),
                            Opaque = new
                            {
                                SignalRConnectionId = "NOT USED",
                                AssetId = assetId.ToString(),
                                AccountId = accountId
                            },
                            TenantInfo = new
                            {
                                Account = new
                                {
                                    Type = "AzureBlobStorage",
                                    Details = new
                                    {
                                        AccountName = storageAccountName,
                                        ContainerName = "asset",
                                        ContainerNamePrefix = accountId.ToString()
                                    }
                                }
                            },
                            Source = new
                            {
                                FileName = assetId.ToString() + Path.GetExtension(sourceBlob.Name).ToLowerInvariant()
                            },
                            Processing = new
                            {
                                Tasks = GetImageConverterProcessingTasks()
                            }
                        });


                        successCount++;
                    }
                }
            }

            return successCount;
        }

        private static object[] GetImageConverterProcessingTasks()
        {
            return new[] {
                new {
                    Name = "web",
                    Destinations = new [] {
                        new {
                            Details = new {
                                ContainerName = "web"
                            }
                        }
                    }
                },
                new {
                    Name = "thumb",
                    Destinations = new [] {
                        new {
                            Details = new {
                                ContainerName = "thumbnail"
                            }
                        }
                    }
                },
                new {
                    Name = "meta",
                    Destinations = new [] {
                        new {
                            Details = new {
                                ContainerName = "metadata"
                            }
                        }
                    }
                },
                new {
                    Name = "low-res",
                    Destinations = new [] {
                        new {
                            Details = new {
                                ContainerName = "low-resolution"
                            }
                        }
                    }
                },
            };
        }

        public async Task<MoveAssetsDto> CopyFreeTrialAssetsAsync(string sourceContainerName, string targetContainerName, FreeTrialAssetMapDto[] assetMap)
        {

            var containerNameSuffixes = new List<string>(); // i.e. asset, web, low-resolution, etc.
            _configuration.GetSection("DefaultContainerNames").Bind(containerNameSuffixes);
            var successCount = 0;
            var errorCount = 0;

            foreach (var suffix in containerNameSuffixes) // each suffix represents a container name ('assetguid-suffix')
            {
                if (suffix == "brand")
                {
                    continue;
                }
                var fullSourceContainer = sourceContainerName + '-' + suffix;
                var fullTargetContainer = targetContainerName + '-' + suffix;
                var sourceContainerClient = _blobServiceClient.GetBlobContainerClient(fullSourceContainer);
                var targetContainerClient = _blobServiceClient.GetBlobContainerClient(fullTargetContainer);
                var sourceBlobs = sourceContainerClient.GetBlobs();
                foreach (var sourceBlob in sourceBlobs)
                {
                    var blobNameParts = sourceBlob.Name.Split('.');
                    var blobName = blobNameParts[0]; // should be guid without .ext
                    var blobExt = blobNameParts[1];
                    foreach (var mappedAsset in assetMap.Where(a => a.OldAssetId.ToString().IndexOf(blobName, StringComparison.InvariantCultureIgnoreCase) != -1))
                    {
                        var sourceBlobClient = sourceContainerClient.GetBlobClient(sourceBlob.Name);
                        var targetBlobClient = targetContainerClient.GetBlobClient(mappedAsset.NewAssetId.ToString() + '.' + blobExt);
                        var initiateCopy = targetBlobClient.StartCopyFromUri(sourceBlobClient.Uri);

                        // In order to wait for copy function to complete call WaitForCompletionAsync with time interval to know the status. 
                        // Here once in 5 seconds we are querying the storage service for copy status.

                        var response = await initiateCopy.WaitForCompletionAsync(
                            new TimeSpan(0, 0, 5),
                            new System.Threading.CancellationToken()
                        );

                        if (response.GetRawResponse().Status == 200)
                        {
                            successCount++;
                        }
                        else
                        {
                            errorCount++;
                        }
                    }
                }
            }

            return new MoveAssetsDto()
            {
                SuccessCount = successCount,
                ErrorCount = errorCount,
                TotalCount = successCount + errorCount
            };
        }

        public async Task<UserDelegationKey> GetSasKey(string storageAccountName, int minutesValid)
        {
            UserDelegationKey key = null;
            try
            {
                var blobStorageUri = GetBlobStorageUri(storageAccountName);

                // Get a user delegation key for the Blob service that's valid for 5 minutes.
                // You can use the key to generate any number of shared access signatures over the lifetime of the key.
                key = await _blobServiceClient.GetUserDelegationKeyAsync(DateTimeOffset.UtcNow, DateTimeOffset.UtcNow.AddMinutes(minutesValid));
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
#pragma warning restore CA1031 // Do not catch general exception types
            {
                Console.WriteLine("SAS user delegation key exception: '{0}'", ex.Message);
            }

            return key;
        }

        public async Task<Dictionary<string, string>> GetContainerSasTokens(string storageAccountName, Guid accountId, int minutesValid)
        {
            var containerSasTokens = new Dictionary<string, string>();

            var containerNameSuffixes = new List<string>();
            _configuration.GetSection("DefaultContainerNames").Bind(containerNameSuffixes);

            var key = await GetSasKey(storageAccountName, minutesValid);

            foreach (var containerNameSuffix in containerNameSuffixes)
            {
                var name = GetBlobContainerName(accountId, containerNameSuffix);
                var token = GetContainerSasToken(storageAccountName, name, minutesValid, key);
                containerSasTokens.Add(name, token);
            }

            return containerSasTokens;
        }

        public string GetBlobSasToken(string blobName, int daysValid, string storageAccountName, string containerName)
        {
            // if (daysValid > 7) daysValid = 7;
            // UserDelegationKey key = null;
            var now = DateTimeOffset.UtcNow.AddMinutes(-1);
            StorageSharedKeyCredential storageSharedKeyCredential;

            try
            {
                var accountKey = _keyVaultService.GetSecret(KeyVaultSecretKey.BlobStorageKey);

                // Get a user delegation key for the Blob service that's valid for maximum 7 days.
                // You can use the key to generate any number of shared access signatures over the lifetime of the key.
                // key = await _blobServiceClient.GetUserDelegationKeyAsync(now, now.AddDays(daysValid));
                storageSharedKeyCredential = new StorageSharedKeyCredential(storageAccountName, accountKey);
            }
            //catch (Azure.RequestFailedException azEx)
            //{
            //    _logger.LogError("SAS user delegation key exception: '{0}'", azEx.Message);
            //    throw;
            //}
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
#pragma warning restore CA1031 // Do not catch general exception types
            {
                //_logger.LogError("SAS user delegation key exception: '{0}'", ex.Message);
                _logger.LogError("Error getting BlobStorageKey: '{0}'", ex.Message);
                throw;
            }

            BlobContainerClient blobContainerClient = _blobServiceClient.GetBlobContainerClient(containerName);

            var sasBuilder = new BlobSasBuilder()
            {
                BlobContainerName = blobContainerClient.Name,
                BlobName = blobName,
                Resource = "b",// give access to blobs
            };

            //set the validity of the token
            sasBuilder.StartsOn = now;
            sasBuilder.ExpiresOn = now.AddDays(daysValid);
            sasBuilder.SetPermissions(BlobContainerSasPermissions.Read);

            // Use the key to get the SAS token.
            // string sasToken = sasBuilder.ToSasQueryParameters(key, storageAccountName).ToString();
            return sasBuilder.ToSasQueryParameters(storageSharedKeyCredential).ToString();
        }

        public string GetContainerSasToken(string storageAccountName, string containerName, int minutesValid, UserDelegationKey key)
        {
            var sasBuilder = new BlobSasBuilder()
            {
                BlobContainerName = containerName,
                Resource = "c"  // give access to container
            };

            //set the validity of the token
            sasBuilder.StartsOn = DateTimeOffset.UtcNow;
            sasBuilder.ExpiresOn = DateTimeOffset.UtcNow.AddMinutes(minutesValid);
            sasBuilder.SetPermissions(BlobContainerSasPermissions.Read);

            // Use the key to get the SAS token.
            string sasToken = sasBuilder.ToSasQueryParameters(key, storageAccountName).ToString();

            return sasToken;
        }

        /// <summary>
        /// Used to get the formatted container name using the accountId and default container name
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="defaultContainerName"></param>
        /// <returns>Formated container name {account-id-guid}-{containerName}</returns>
        public string GetBlobContainerName(Guid accountId, string defaultContainerName)
        {
            return $"{accountId}-{defaultContainerName}";
        }

        private Uri GetBlobStorageUri(string storageAccountName)
        {
            _logger.LogDebug($"GetBlobStorageUri(https://{storageAccountName}.blob.core.windows.net)");
            return new Uri($"https://{storageAccountName}.blob.core.windows.net");
        }
    }
}
