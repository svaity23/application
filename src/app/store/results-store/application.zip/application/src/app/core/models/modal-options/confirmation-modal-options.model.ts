export interface ConfirmationModalOptions {
  confirm: () => void;
  confirmButtonIcon: string;
  confirmButtonText: string;
  deny: () => void;
  denyButtonText: string;
  message: string;
  title: string;
  // denyButtonIcon: string;
}
