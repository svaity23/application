import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { OidcFacade } from 'ng-oidc-client';

import { map, switchMap, take } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProvisionGuard implements CanActivate {

  federatedRoute = false;
  constructor(private oidcFacade: OidcFacade, private router: Router) { }

  canActivate(
    // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
    _route: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
    _state: RouterStateSnapshot,
    ): Observable<boolean | UrlTree>  {

      this.federatedRoute = _route.routeConfig.path === 'federated';
      return this.oidcFacade.waitForAuthenticationLoaded().pipe(
        switchMap(() => {
          return this.userNeedsProvisioning();
        })
      );
  }

  private userNeedsProvisioning(): Observable<boolean | UrlTree> {
    return this.oidcFacade.identity$.pipe(
      take(1),
      map(user => {
        // make sure the user does not have userId in claims yet
        if (user && !user.profile?.extension_userId) {
            if (this.federatedRoute && user.profile?.authenticationSource !== 'federatedAdAuthentication') {
              // if user went to the federated provision route but auth is not federated, redirect to local account provision
              return this.router.parseUrl('/provision');
            }
            else if (!this.federatedRoute && user.profile?.authenticationSource === 'federatedAdAuthentication') {
              // if user went to the local account provision route but auth is federated, redirect to federated provision
              return this.router.parseUrl('/provision/federated');
            } else {
              return true;
            }
        } else {
          return this.router.parseUrl('/library');
        }
      })
    );
  }
}
