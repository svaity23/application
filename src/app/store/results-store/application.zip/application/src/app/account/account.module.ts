import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { AccountBrandDetailsComponent } from './components/account-brand-details/account-brand-details.component';
import { AccountDetailsComponent } from './components/account-details/account-details.component';
import { AccountDetailsHeaderComponent } from './components/account-details-header/account-details-header.component';
import { AccountFederationComponent } from './containers/account-federation/account-federation.component';
import { AccountRoutingModule } from './account-routing.module';
import { AccountSidebarComponent } from './components/account-sidebar/account-sidebar.component';
import { AccountStoreModule } from '@app/store/account-store/account-store.module';
import { GeneralInformationComponent } from './containers/general-information/general-information.component';
import { GroupBulkActionHeaderComponent } from './components/group-bulk-action-header/group-bulk-action-header.component';
import { GroupDetailsComponent } from './components/group-details/group-details.component';
import { GroupDetailsHeaderComponent } from './components/group-details-header/group-details-header.component';
import { GroupFormComponent } from './containers/group-form/group-form.component';
import { GroupListComponent } from './components/group-list/group-list.component';
import { GroupsComponent } from './containers/groups/groups.component';
import { GroupSearchComponent } from './components/group-search/group-search.component';
import { HubspotConfigurationContentComponent } from './components/hubspot-configuration-content/hubspot-configuration-content.component';
import { HubspotConfigurationHeaderComponent } from './components/hubspot-configuration-header/hubspot-configuration-header.component';
import { HubspotConfigurationPageComponent } from './containers/hubspot-configuration-page/hubspot-configuration-page.component';
import { IntegrationDetailsHeaderComponent } from './components/integration-details-header/integration-details-header.component';
import { IntegrationListComponent } from './components/integration-list/integration-list.component';
import { IntegrationListHeaderComponent } from './components/integration-list-header/integration-list-header.component';
import { IntegrationsComponent } from './containers/integrations/integrations.component';
import { MarcomAssetIntegrationDetailsComponent } from './components/marcom-asset-integration-details/marcom-asset-integration-details.component';
import { MarcomLibraryIntegrationDetailsComponent } from './components/marcom-library-integration-details/marcom-library-integration-details.component';
import { MarcomPortalIntegrationsPageComponent } from './containers/marcomportal-integrations-page/marcomportal-integrations-page.component';
import { MetadataProfileCheckboxFieldComponent } from './components/metadata-profile-checkbox-field/metadata-profile-checkbox-field.component';
import { MetadataProfileDropdownFieldComponent } from './components/metadata-profile-dropdown-field/metadata-profile-dropdown-field.component';
import { MetadataProfileFieldsComponent } from './components/metadata-profile-fields/metadata-profile-fields.component';
import { MetadataProfileFormComponent } from './containers/metadata-profile-form/metadata-profile-form.component';
import { MetadataProfileOptionsFieldComponent } from './components/metadata-profile-options-field/metadata-profile-options-field.component';
import { MetadataProfileRadiobuttonFieldComponent } from './components/metadata-profile-radiobutton-field/metadata-profile-radiobutton-field.component';
import { MetadataProfilesComponent } from './containers/metadata-profiles/metadata-profiles.component';
import { MetadataProfilesEditHeaderComponent } from './components/metadata-profiles-edit-header/metadata-profiles-edit-header.component';
import { MetadataProfilesHeaderComponent } from './components/metadata-profiles-header/metadata-profiles-header.component';
import { MetadataProfilesListComponent } from './components/metadata-profiles-list/metadata-profiles-list.component';
import { MetadataProfileTextFieldComponent } from './components/metadata-profile-text-field/metadata-profile-text-field.component';
import { MicrosoftLoginConfigurationModalComponent } from './containers/microsoft-login-configuration-modal/microsoft-login-configuration-modal.component';
import { SharedModule } from '../shared/shared.module';
import { UploadUsersModalComponent } from './containers/upload-users-modal/upload-users-modal.component';
import { UserBulkActionHeaderComponent } from './components/user-bulk-action-header/user-bulk-action-header.component';
import { UserDetailsComponent } from './components/user-details/user-details.component';
import { UserDetailsHeaderComponent } from './components/user-details-header/user-details-header.component';
import { UserFormComponent } from './containers/user-form/user-form.component';
import { UserListComponent } from './components/user-list/user-list.component';
import { UsersComponent } from './containers/users/users.component';
import { UserSearchComponent } from './components/user-search/user-search.component';

@NgModule({
  declarations: [
    AccountBrandDetailsComponent,
    AccountDetailsComponent,
    AccountDetailsHeaderComponent,
    AccountFederationComponent,
    AccountSidebarComponent,
    GeneralInformationComponent,
    GroupBulkActionHeaderComponent,
    GroupDetailsComponent,
    GroupDetailsHeaderComponent,
    GroupFormComponent,
    GroupListComponent,
    GroupsComponent,
    GroupSearchComponent,
    HubspotConfigurationContentComponent,
    HubspotConfigurationHeaderComponent,
    HubspotConfigurationPageComponent,
    IntegrationDetailsHeaderComponent,
    IntegrationListComponent,
    IntegrationListHeaderComponent,
    IntegrationsComponent,
    MarcomLibraryIntegrationDetailsComponent,
    MarcomAssetIntegrationDetailsComponent,
    MarcomPortalIntegrationsPageComponent,
    MetadataProfileCheckboxFieldComponent,
    MetadataProfileDropdownFieldComponent,
    MetadataProfileFieldsComponent,
    MetadataProfileFormComponent,
    MetadataProfileOptionsFieldComponent,
    MetadataProfileRadiobuttonFieldComponent,
    MetadataProfilesComponent,
    MetadataProfilesEditHeaderComponent,
    MetadataProfilesHeaderComponent,
    MetadataProfilesListComponent,
    MetadataProfileTextFieldComponent,
    MicrosoftLoginConfigurationModalComponent,
    UploadUsersModalComponent,
    UserBulkActionHeaderComponent,
    UserDetailsComponent,
    UserDetailsHeaderComponent,
    UserFormComponent,
    UserListComponent,
    UsersComponent,
    UserSearchComponent
  ],
  imports: [
    AccountRoutingModule,
    AccountStoreModule,
    CommonModule,
    SharedModule
  ],
  exports: [
    UploadUsersModalComponent
  ]
})
export class AccountModule { }
