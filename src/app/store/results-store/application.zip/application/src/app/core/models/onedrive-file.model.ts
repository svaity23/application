import { AssetFile } from './asset-file.model';

export interface OneDriveFile extends AssetFile {
	link: string;
}
