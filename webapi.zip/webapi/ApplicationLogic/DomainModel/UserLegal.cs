﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ApplicationLogic.DomainModel
{
    [Table("userLegal")]
    [Index(nameof(UserId), nameof(LegalId), Name = "uniq_userLegal_userId_legalId", IsUnique = true)]
    public partial class UserLegal
    {
        [Key]
        [Column("id")]
        public Guid Id { get; set; }
        [Column("accountId")]
        public Guid AccountId { get; set; }
        [Column("created")]
        public DateTime Created { get; set; }
        [Column("userId")]
        public Guid UserId { get; set; }
        [Column("legalId")]
        public int LegalId { get; set; }

        [ForeignKey(nameof(AccountId))]
        [InverseProperty("UserLegal")]
        public virtual Account Account { get; set; }
        [ForeignKey(nameof(UserId))]
        [InverseProperty("UserLegal")]
        public virtual User User { get; set; }
    }
}
