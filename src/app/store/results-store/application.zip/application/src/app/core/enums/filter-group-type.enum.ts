export enum FilterGroupType {
  FileGroup, // The 'Type' on the ui. Or Metadata profile.
  UploadDate, // Part of asset
  FileSize, // Part of asset
  Tags,
  Metadata
}
