import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild, ViewEncapsulation } from '@angular/core';
import { ControlContainer, NgForm } from '@angular/forms';

import { Context } from '@app/core/models/context.model';
import { CustomTheme } from '@app/core/models/custom-theme.model';

import { ThemeService } from '@app/core/services/theme.service';

@Component({
  selector: 'app-account-brand-details',
  templateUrl: './account-brand-details.component.html',
  styleUrls: ['./account-brand-details.component.scss'],
  encapsulation: ViewEncapsulation.None,
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class AccountBrandDetailsComponent implements OnInit {
  acceptableFaviconFileTypes = ['ico'];
  acceptableFileTypes = ['jpg', 'jpeg', 'png', 'svg'];
  @Input() context: Context;
  @Output() deleteCustomFavicon = new EventEmitter();
  @Output() deleteCustomLogo = new EventEmitter();
  @Output() faviconAccepted = new EventEmitter<File>();
  @ViewChild('faviconInput') faviconInput: ElementRef;
  @Output() faviconUnacceptedFileSizeError = new EventEmitter();
  @Output() faviconUnacceptedFileTypeError = new EventEmitter();
  @Input() faviconUrl: string;
  @ViewChild('fileInput') fileInput: ElementRef;
  @Output() logoAccepted = new EventEmitter<File>();
  @Output() logoUnacceptedFileSizeError = new EventEmitter();
  @Output() logoUnacceptedFileTypeError = new EventEmitter();
  @Input() logoUrl: string;
  maxFaviconHeight = 128;
  maxFaviconWidth = 128;
  maxLogoHeight = 40;
  maxLogoWidth = 230;
  @Input() selectedTheme: CustomTheme;
  selectedThemeName = '';
  themes: CustomTheme[] = [];
  @Output() themeSelected = new EventEmitter<string>();

  constructor(public themeService: ThemeService) { }

  deleteCustomFaviconClick(): void {
    this.deleteCustomFavicon.emit();
  }

  deleteCustomLogoClick(): void {
    this.deleteCustomLogo.emit();
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  faviconfileChangeEvent($event: any): void {
    this.checkIfFaviconFileSizeAndTypeAreAcceptable($event.target.files[0]);
  }

  faviconFileDropped(file: File): void {
    this.checkIfFaviconFileSizeAndTypeAreAcceptable(file[0]);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  fileChangeEvent($event: any): void {
    this.checkIfFileSizeAndTypeAreAcceptable($event.target.files[0]);
  }

  fileDropped(file: File): void {
    this.checkIfFileSizeAndTypeAreAcceptable(file[0]);
  }

  ngOnInit(): void {
    this.themes = this.themeService.getCustomThemes();
    this.selectedThemeName = this.selectedTheme.displayName;
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  openFaviconFilePicker($event: any): void {
    this.faviconInput.nativeElement.click();
    if ($event) {
      $event.stopPropagation();
    }
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  openFilePicker($event: any): void {
    this.fileInput.nativeElement.click();
    if ($event) {
      $event.stopPropagation();
    }
  }

  selectTheme(theme: CustomTheme): void {
    this.selectedThemeName = theme.displayName;
    this.themeSelected.emit(theme.title);
  }

  private checkIfFaviconFileSizeAndTypeAreAcceptable(file: File): void {
    const inputFileExtension = file.name.split('.').pop().toLowerCase();
    const isFileTypeSuccess = this.acceptableFaviconFileTypes.indexOf(inputFileExtension) > -1;  // is extension in acceptable file types
    let isFileSizeSuccess;

    if (isFileTypeSuccess) { // File Type is acceptable
      const reader = new FileReader();
      reader.onload = (event) => { // called once readAsDataURL is completed
        const img = new Image();
        img.src = event.target.result as string;
        img.onload = () => {
          isFileSizeSuccess = (img.width <= this.maxFaviconWidth && img.height <= this.maxFaviconHeight); // is File size acceptable
          if (isFileSizeSuccess) {
            this.faviconAccepted.emit(file); // File Size and Type are acceptable. ready to uplaod
          } else {
            this.faviconUnacceptedFileSizeError.emit(); // File Size unacceptable
          }
        }
      }
      reader.readAsDataURL(file); // read file as data url
    }
    else { // File Type is not acceptable
      this.faviconUnacceptedFileTypeError.emit();
    }
  }

  private checkIfFileSizeAndTypeAreAcceptable(file: File): void {
    const inputFileExtension = file.name.split('.').pop().toLowerCase();
    const isFileTypeSuccess = this.acceptableFileTypes.indexOf(inputFileExtension) > -1;  // is extension in acceptable file types
    let isFileSizeSuccess;

    if (isFileTypeSuccess) { // File Type is acceptable
      const reader = new FileReader();
      reader.onload = (event) => { // called once readAsDataURL is completed
        const img = new Image();
        img.src = event.target.result as string;
        img.onload = () => {
          isFileSizeSuccess = (img.width <= this.maxLogoWidth && img.height <= this.maxLogoHeight); // is File size acceptable
          if (isFileSizeSuccess) {
            this.logoAccepted.emit(file); // File Size and Type are acceptable. ready to uplaod
          } else {
            this.logoUnacceptedFileSizeError.emit(); // File Size unacceptable
          }
        }
      }
      reader.readAsDataURL(file); // read file as data url
    }
    else { // File Type is not acceptable
      this.logoUnacceptedFileTypeError.emit();
    }
  }
}
