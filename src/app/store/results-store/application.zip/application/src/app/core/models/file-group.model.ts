import { FileGroupType } from '../enums/file-group-type.enum';

export interface FileGroup {
  assetLastModified?: Date;
  count: number;
  selected: boolean;
  type: FileGroupType;
}
