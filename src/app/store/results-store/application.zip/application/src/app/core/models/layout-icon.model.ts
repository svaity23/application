import { LayoutIconType } from '../enums/layout-icon-type.enum';

export interface LayoutIcon {
  height: number;
  name: string;
  type: LayoutIconType;
  width: number;
}
