﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi
{
    public class AzureAdB2COptions
    {
        public const string PolicyAuthenticationProperty = "Policy";
        public const string ApiVersion = "v2.0";

        public AzureAdB2COptions()
        {  
        }

        public string ClientId { get; set; }
        public string ClientName { get; set; }
        public string Instance { get; set; }
        public string TenantName { get; set; }
        public string TenantDirectoryId { get; set; }        
        public string Policy { get; set; }

        public string Authority => $"{Instance}/{TenantName}/{Policy}/{ApiVersion}";
        public string Issuer => $"{Instance}/{TenantDirectoryId}/{ApiVersion}";        

    }
}
