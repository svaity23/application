import { Feature } from './feature.model';
import { FederatedDomain } from './entities/federated-domain.model';
import { FrontEndSettings } from './frontend-settings.model';
import { LegalDocument } from './legal-document';
import { Notification } from './notification.model';
import { Permission } from './permission.model';

export interface Context {
    accountActive?: boolean; // TODO: null for now
    accountFavicon:  string;
    accountId: string;
    accountLogo:  string;
    accountName: string;
    accountSalesforceId: string;
    accountStorageMaximumGb?: number;
    accountStorageUsed?: number;
    accountTheme: string;
    accountTrialExpiration?: Date;
    accountTrialVerified?: boolean;
    accountTypeName: string;
    accountUserEmail: string;
    email: string;
    emailVerified?: boolean;
    features: Feature[];
    federated?: boolean;
    federatedDomains?: FederatedDomain[];
    firstName: string;
    frontEndSettings: FrontEndSettings;
    groupId: string;
    id: string;
    lastName: string;
    legalDocuments: LegalDocument[];
    notifications?: Notification[];
    permissions: Permission[];
    roleKey: string;
    roleName: string;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    sasKeys: any;
    storageAccountName: string;
    totalCleanUpAssets: number;
    totalExpiredAssets: number;
    totalFavorites: number;
    userSalesforceId: string;
}
