import { Component } from '@angular/core';

import { AdminAccountStoreFacade } from '@app/store/admin-store/admin-account-store.facade';
import { AppStoreFacade } from '@app/store/app-store/app-store.facade';

@Component({
  selector: 'app-utilities',
  templateUrl: './utilities.component.html',
  styleUrls: ['./utilities.component.scss']
})
export class UtilitiesComponent  {

  constructor(private appStoreFacade: AppStoreFacade, private adminAccountStoreFacade: AdminAccountStoreFacade) { }

  indexAssetSearchAllAccounts(): void {
    this.adminAccountStoreFacade.indexAssetSearchAllAccounts();
  }

  navigateToAccounts(): void {
    this.appStoreFacade.navigate('/admin/accounts');
  }

}
