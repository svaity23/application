﻿using ApplicationLogic.Logic;
using Microsoft.Extensions.Logging;
using SignalRHub.Messages;
using System.Threading.Tasks;

namespace SignalRHub.Services
{
    public class AssetService
    {
        private readonly ILogger<AssetService> _logger;
        private AssetLogic _assetLogic;

        public AssetService(ILoggerFactory loggerFactory, IDbContextFactory dbContextFactory)
        {
            _logger = loggerFactory.CreateLogger<AssetService>();
            _assetLogic = new AssetLogic(dbContextFactory.CreateSignalRContext());
        }

        public async Task<string> StoreAttachmentsAsync(ThumbReadyDTO payload)
        {
            return await _assetLogic.StoreAttachmentsAsync(payload);
        }

        public async Task<string> StoreAiAndOcrTextAsync(TagsReadyDTO payload)
        {
            return await _assetLogic.StoreAiAndOcrTextAsync(payload);
        }
    }
}
