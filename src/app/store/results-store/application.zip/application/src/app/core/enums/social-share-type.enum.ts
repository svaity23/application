export enum SocialShareType {
  facebook = 'facebook',
  linkedin = 'linkedin',
  slack = 'slack',
  twitter = 'twitter'    
}