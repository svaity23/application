﻿using Microsoft.AspNetCore.Builder;
using WebApi.Middleware;

namespace WebApi.Extensions
{
    public static class MiddlewareExtensions
    {
        public static void ConfigureGlobalExceptionMiddleware(this IApplicationBuilder app)
        {
            app.UseMiddleware<ExceptionHandlerMiddleware>();
        }
    }
}
