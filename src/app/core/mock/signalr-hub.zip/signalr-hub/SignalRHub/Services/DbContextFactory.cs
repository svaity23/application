﻿using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SignalRHub.DomainModel.Context;

namespace SignalRHub.Services
{
    public interface IDbContextFactory
    {
        damContext CreateSignalRContext();
    }

    public class DbContextFactory : IDbContextFactory
    {
        private readonly AzureServiceTokenProvider _azureServiceTokenProvider;
        private readonly DbContextOptions<damContext> _options;
        private readonly IConfiguration _configuration;
        private readonly ILogger<DbContextFactory> _logger;
        private readonly ILoggerFactory _loggerFactory;


        public DbContextFactory(DbContextOptions<damContext> options, AzureServiceTokenProvider azureServiceTokenProvider, ILogger<DbContextFactory> logger, ILoggerFactory loggerFactory, IConfiguration configuration)
        {
            _azureServiceTokenProvider = azureServiceTokenProvider;
            _configuration = configuration;
            _logger = logger;
            _loggerFactory = loggerFactory;
            _options = options;
        }

        public damContext CreateSignalRContext()
        {
            var logger = _loggerFactory.CreateLogger<damContext>();
            var context = new damContext(_options, _azureServiceTokenProvider, logger, _configuration);
            return context;
        }
    }
}
