import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { environment } from '@environments/environment';

import { AccountsDataService } from './data-services/accounts-data.service';
import { AccountsDataServiceMock } from './mock/accounts-data.service.mock';
import { AssetsDataService } from './data-services/assets-data.service';
import { AssetsDataServiceMock } from './mock/assets-data.service.mock';
import { CollectionsDataService } from './data-services/collections-data.service';
import { CollectionsDataServiceMock } from './mock/collections-data.service.mock';
import { ContextDataService } from './data-services/context-data.service';
import { ContextDataServiceMock } from './mock/context-data.service.mock';
import { DownloadDataService } from './data-services/download-data.service';
import { DownloadDataServiceMock } from './mock/download-data.service.mock';
import { GroupsDataService } from './data-services/groups-data.service';
import { GroupsDataServiceMock } from './mock/groups-data.service.mock';
import { MetadataProfilesDataService } from './data-services/metadata-profiles-data.service';
import { MetadataProfilesDataServiceMock } from './mock/metadata-profiles-data.service.mock';
import { RolesDataService } from './data-services/roles-data.service';
import { RolesDataServiceMock } from './mock/roles-data.service.mock';
import { SearchDataService } from './data-services/search-data.service';
import { SearchDataServiceMock } from './mock/search-data.service.mock';
import { SignalRService } from './services/signal-r.service';
import { SignalRServiceMock } from './mock/signal-r.service.mock';
import { UploadDataService } from './data-services/upload-data.service';
import { UploadDataServiceMock } from './mock/upload-data.service.mock';
import { UsersDataService } from './data-services/users-data.service';
import { UsersDataServiceMock } from './mock/user-data.service.mock';
import { WordPressDataService } from './data-services/wordpress-data.service';
import { WordPressDataServiceMock } from './mock/wordpress-data.service.mock';

@NgModule({
  imports: [
    CommonModule
  ],
  providers: [
    { provide: DownloadDataService, useClass: environment.useMockService ? DownloadDataServiceMock : DownloadDataService },
    { provide: AssetsDataService, useClass: environment.useMockService ? AssetsDataServiceMock : AssetsDataService },
    { provide: SignalRService, useClass: environment.useMockService ? SignalRServiceMock : SignalRService },
    { provide: UploadDataService, useClass: environment.useMockService ? UploadDataServiceMock : UploadDataService },
    { provide: UsersDataService, useClass: environment.useMockService ? UsersDataServiceMock : UsersDataService },
    { provide: RolesDataService, useClass: environment.useMockService ? RolesDataServiceMock : RolesDataService },
    { provide: GroupsDataService, useClass: environment.useMockService ? GroupsDataServiceMock : GroupsDataService },
    { provide: AccountsDataService, useClass: environment.useMockService ? AccountsDataServiceMock : AccountsDataService },
    { provide: ContextDataService, useClass: environment.useMockService ? ContextDataServiceMock : ContextDataService },
    { provide: CollectionsDataService, useClass: environment.useMockService ? CollectionsDataServiceMock : CollectionsDataService },
    { provide: UploadDataService, useClass: environment.useMockService ? UploadDataServiceMock : UploadDataService },
    { provide: SearchDataService, useClass: environment.useMockService ? SearchDataServiceMock : SearchDataService },
    { provide: MetadataProfilesDataService, useClass: environment.useMockService ? MetadataProfilesDataServiceMock : MetadataProfilesDataService },
    { provide: WordPressDataService, useClass: environment.useMockService ? WordPressDataServiceMock : WordPressDataService },
  ]
})
export class CoreModule { }
