import { ChangeDetectionStrategy, Component, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-sisense',
  templateUrl: './sisense.component.html',
  styleUrls: ['./sisense.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SisenseComponent implements OnChanges {
  @Output() analyticsLoading = new EventEmitter<boolean>();
  loadingError: string;
  sisenseUrl: SafeResourceUrl;
  @Input() urlStr: string;

  constructor(
    private sanitizer: DomSanitizer) { }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.urlStr?.currentValue) {
      this.urlStr = changes.urlStr.currentValue;
      this.sisenseUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.urlStr);
    } else if (changes.urlStr?.currentValue === null) {
      this.loadingError = 'Unable to load Analytics...';
      this.analyticsLoading.emit(false);
    }
  }

  onIframeLoaded(): void {
    this.analyticsLoading.emit(false);
  }

}
