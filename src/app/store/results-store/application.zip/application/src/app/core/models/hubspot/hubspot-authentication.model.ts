
export interface HubspotAuthentication {
    accessCode: string;
    clientId: string;
    redirectUri: string;
}
