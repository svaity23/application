﻿using System.Text.Json.Serialization;

namespace WebApi.Dtos.Asset.Response
{
    public class UpdateAssetResponseDto
    {
        [JsonPropertyName("asset")]
        public AssetUpdateDto[] Asset { get; set; } // TODO - Denali help? - fix stored proc to unwrap array, client side code needs to be fixed as well
    }
}
