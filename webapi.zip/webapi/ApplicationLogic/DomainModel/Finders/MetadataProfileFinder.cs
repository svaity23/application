﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class MetadataProfileFinder
    {
        public ILogger<MetadataProfileFinder> Logger { get; set; }

        private damContext _context;

        public MetadataProfileFinder(damContext context)
        {
            _context = context;
            Logger = NullLogger<MetadataProfileFinder>.Instance;
        }

        public async Task<string> GetMetadataProfilesByAccountIdAsync(Guid accountId)
        {
            SpParams paramList = new SpParams();
            if (accountId != Guid.Empty)
            {
                paramList.WithAccountId((Guid)accountId);
            }
            List<SqlParameter> sqlParmsList = paramList.Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("getMetadataProfilesByAccount", sqlParmsList).ConfigureAwait(false);
        }

        public async Task<string> GetMetadataProfileFieldsByProfileIdAsync(Guid accountId, Guid profileId)
        {

            List<SqlParameter> paramList = new List<SqlParameter>();

            SqlParameter accountIdParam = new SqlParameter("@accountId", SqlDbType.UniqueIdentifier);
            accountIdParam.Value = accountId;
            paramList.Add(accountIdParam);

            SqlParameter profileIdParam = new SqlParameter("@profileId", SqlDbType.UniqueIdentifier);
            profileIdParam.Value = profileId;
            paramList.Add(profileIdParam);

            return await _context.ExecuteNonQueryJsonOutputAsync("getMetadataProfileFieldsByProfileId", paramList);
        }
        public async Task<string> SaveMetadataProfileFieldsByProfileIdAsync(Guid accountId, string jsonInput)
        {
            List<SqlParameter> paramList = new List<SqlParameter>();

            SqlParameter accountIdParam = new SqlParameter("@accountId", SqlDbType.UniqueIdentifier);
            accountIdParam.Value = accountId;
            paramList.Add(accountIdParam);

            paramList.Add(new SqlParameter("@jsonInput", jsonInput));

            return await _context.ExecuteNonQueryJsonOutputAsync("saveMetadataProfileFieldsByProfileId", paramList);

        }


    }
}
