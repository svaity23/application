﻿using System;

namespace WebApi.Dtos.Asset.Revision
{
    public class AssetRevisionHistoryDto
    {
        public string Action { get; set; }
        public string ActionDetails { get; set; }
        public DateTime? Created { get; set; }
        public AssetRevisionsUserDto User { get; set; }
    }
}
