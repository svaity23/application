// TODO: This enum seems unncesseary. I think the ToastTimeout should be an optional
// parameter when opening a toast. If none is provided use the default value.
// This just seems overkill.
export enum ToastTimeout {
  Default = 5000,
  Unicorn = 8000,
  GoogleDriveError = 10000
}
