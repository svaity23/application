/** Enum for the type of database action to perform. Some stored procedures can perform multiple operations depending on the crud parameter passed in. (i.e. 'createOrUpdateTag', 'createOrUpdateMetadata') */
export enum CrudType {
    Create = 0,
    Read = 1,
    Update = 2,
    Delete = 3,
}
