﻿using Azure.Identity;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UNIT_TEST = Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApplicationLogic.Tests
{
    //[TestClass()]
    //[UNIT_TEST.Ignore]
    public class BlobStorageTests
    {


        public BlobStorageTests()
        {
        }

        // [TestInitialize]
        // public void Init()
        // {
            //var configuration = new ConfigurationBuilder()
            //           .AddJsonFile("appsettings.json", true, true)
            //           .Build();

            //var optionBuilder = new DbContextOptionsBuilder<damContext>();
            //optionBuilder.UseSqlServer(configuration["ConnectionStrings:damDbConnection"]);

            //_context = new damContext(optionBuilder.Options,
            //    new AzureServiceTokenProvider(),
            //    new Microsoft.Extensions.Logging.Abstractions.NullLogger<damContext>(),
            //    configuration);
        // }

        [TestMethod()]
        [UNIT_TEST.Ignore]
        public async Task CreateDefaultContainers()
        {
            var storageAccountName = "8d42a5d85262410ea7c4930f";
            var blobStorageUri = GetBlobStorageUri(storageAccountName);
            var blobServiceClient = new BlobServiceClient(blobStorageUri, new DefaultAzureCredential());
            var prefix = "";
            string continuationToken = string.Empty;

            do
            {                
                var resultSegment =
                    blobServiceClient.GetBlobContainersAsync(BlobContainerTraits.Metadata, prefix, default)
                    .AsPages(continuationToken, 100);

                // These are going to come from the app settings
                var defaultContainerNames = new string[] {
                    "metadata",
                    "thumbnail",
                    "web",
                    "low-resolution",
                    "assets",
                    "test-default-container"
                };

                // Load all current containers that exist in azure and store in azureContainerItems
                var azureContainerItems = new List<BlobContainerItem>();
                await foreach (Azure.Page<BlobContainerItem> containerPage in resultSegment)
                {
                    foreach (BlobContainerItem containerItem in containerPage.Values)
                    {
                        azureContainerItems.Add(containerItem);                        
                    }

                    // Get the continuation token and loop until it is empty.
                    continuationToken = containerPage.ContinuationToken;
                }

                // Make sure all containers are created
                // Loop thru all default container names and check if they exist in the azure container items.
                // If they don't create them.
                foreach(string defaultContainerName in defaultContainerNames)
                {
                    var azureContainerItem = azureContainerItems.Where(ci => ci.Name.Equals(defaultContainerName)).FirstOrDefault();
                    if(azureContainerItem == null)
                    {
                        // Create new container and set it as private
                        await blobServiceClient.CreateBlobContainerAsync(defaultContainerName, PublicAccessType.None);
                    }
                }

                // Make sure all containers on server are set to private
                //foreach(BlobContainerItem azureContainerItem in azureContainerItems)
                //{
                //    // var containerClient = blobServiceClient.GetBlobContainerClient(azureContainerItem.Name);
                //    // var accessPolicy = containerClient.GetAccessPolicy();
                //    // var accessPolicy = await containerClient.GetAccessPolicyAsync();
                //    if (azureContainerItem.Properties.PublicAccess != PublicAccessType.None)
                //    {
                //        var containerClient = blobServiceClient.GetBlobContainerClient(azureContainerItem.Name);
                //        await containerClient.SetAccessPolicyAsync(PublicAccessType.None);
                //    }
                //}

            } while (continuationToken != string.Empty);
        }

        [TestMethod()]
        [UNIT_TEST.Ignore]
        public async Task MoveAssets()
        {
            var source = "test-source-container";
            var target = "test-target-container";

            var storageAccountName = "8d42a5d85262410ea7c4930f";
            var blobStorageUri = GetBlobStorageUri(storageAccountName);
            var blobServiceClient = new BlobServiceClient(blobStorageUri, new DefaultAzureCredential());

            // Get all blobs from source container            
            var sourceContainerClient = blobServiceClient.GetBlobContainerClient(source);
            var sourceBlobs = sourceContainerClient.GetBlobs();

            var targetContainerClient = blobServiceClient.GetBlobContainerClient(target);
            foreach(var sourceBlob in sourceBlobs)
            {
                var sourceBlobClient = sourceContainerClient.GetBlobClient(sourceBlob.Name);
                var targetBlobClient = targetContainerClient.GetBlobClient(sourceBlob.Name);

                // var destBlobDetails = new BlobUriBuilder(targetBlobClient.Uri);
                var initiateCopy = targetBlobClient.StartCopyFromUri(sourceBlobClient.Uri); //Start Copy queues copy operation to Azure Blob Storage/Emulator service and it happens in background. 
                var response = await initiateCopy.WaitForCompletionAsync(new TimeSpan(0, 0, 10), new System.Threading.CancellationToken()); //In-order to wait for copy function to complete call WaitForCompletionAsync with time interval to know the status. Here once in 10 seconds we are querying the storage service for copy status.
            }
        }
        
        private Uri GetBlobStorageUri(string storageAccountName)
        {
            return new Uri($"https://{storageAccountName}.blob.core.windows.net");
        }
    }
}
