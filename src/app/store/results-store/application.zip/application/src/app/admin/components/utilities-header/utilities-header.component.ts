import { Component, Input, OnInit } from '@angular/core';

import { cn } from 'src/utils/cn';

@Component({
  selector: 'app-utilities-header',
  templateUrl: './utilities-header.component.html',
  styleUrls: ['./utilities-header.component.scss']
})
export class UtilitiesHeaderComponent implements OnInit {
  @Input() className = '';
  visible = true;
  constructor() { }

  ngOnInit(): void {
    this.className = cn('utilities-header', this.className);
  }

}
