﻿using ApplicationLogic.DomainModel.Context;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class RoleFinder
    {
        public ILogger<RoleFinder> Logger { get; set; }

        private damContext _context;

        public RoleFinder(damContext context)
        {
            _context = context;
            Logger = NullLogger<RoleFinder>.Instance;
        }

        public async Task<Role> FindByIdAsync(Guid id)
        {
            return await _context.FindAsync<Role>(id);
        }
        
        public async IAsyncEnumerable<Role> GetByAccountIdAsync(Guid accountId, bool includeInactive = false)
        {
            Logger.LogInformation($"[Finder] Getting roles for account = {accountId}, includeInactive = {includeInactive}");

            var results = _context.Role
                .Where(role =>   
                    (role.AccountId == accountId || !role.AccountId.HasValue) &&  // role for account or global roles 
                    role.Internal == false &&
                    (includeInactive ? role.Active == role.Active : role.Active == true)
                ).AsAsyncEnumerable();
            await foreach (var result in results)
            {
                yield return result;
            }
        }

        public async Task<Role> GetByKey(string key)
        {
#pragma warning disable CA1304 // Specify CultureInfo
            return await _context.Role.FirstOrDefaultAsync(r => r.Key.ToLower() == key.ToLower());
#pragma warning restore CA1304 // Specify CultureInfo
        }
    }
}
