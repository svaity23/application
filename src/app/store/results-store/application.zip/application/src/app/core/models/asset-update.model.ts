export interface AssetUpdate {
    description: string;
    expired?: boolean;
    expireOn?: Date;
    favorite?: boolean;
    fileName?: string;
    id: string;
    modified?: Date;
    modifiedByUserFullName?: string;
    name: string;
    sharedOnHubSpot?: number;
}
