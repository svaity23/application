
import { Asset } from './entities/asset.model';
import { Metadata } from './entities/metadata.model';
import { Tag } from './entities/tag.model';

export interface AssetsAndMetadataAndTags {
    assets: Asset[];
    metadata: Metadata[];
    tags: Tag[];
}

