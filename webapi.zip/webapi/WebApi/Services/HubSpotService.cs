﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;
using WebApi.Dtos;
using WebApi.Dtos.Asset.Hubspot;
using WebApi.Dtos.Asset.Request;
using WebApi.Enums;
using WebApi.Extensions;

namespace WebApi.Services
{
    public class HubspotService
    {
        private readonly ILogger<HubspotService> _logger;
        private readonly ServiceBusService _serviceBusService;
        private readonly HubspotLogic _hubspotLogic;

        public HubspotService(ILogger<HubspotService> logger, ServiceBusService serviceBusService, damContext context)
        {
            _logger = logger;
            _serviceBusService = serviceBusService;
            _hubspotLogic = new HubspotLogic(context);
        }

        public async Task<GetEntitiesResponse<AssetDto>> GetHubspotAssets(Guid accountId, Guid userId, int sortField, int skip, int pageSize, Guid? collectionId)
        {
            var assetListParams = new AssetListParamsDto
            {
                SortField = sortField,
                CollectionId = collectionId,
                Skip = skip,
                PageSize = pageSize,
                IncludeInactive = false,
                IsOnMyFavorites = false,
                Expired = false
            };
            var jsonParams = assetListParams.ToJsonString();

            string resultJson = await _hubspotLogic.GetHubspotAssets(accountId, userId, jsonParams);
            GetEntitiesResponse<AssetDto> result = JsonConvert.DeserializeObject<GetEntitiesResponse<AssetDto>>(resultJson);

            return result;
        }

        public async Task<GetEntityResponse<HubspotSyncErrorsDTO>> GetHubspotSyncErrorsAsync(Guid accountId)
        {
            var jsonOutput = await _hubspotLogic.GetHubspotSyncErrorsAsync(accountId);
            GetEntityResponse<HubspotSyncErrorsDTO> result = JsonConvert.DeserializeObject<GetEntityResponse<HubspotSyncErrorsDTO>>(jsonOutput);
            return result;
        }

        public async Task<UpsertHubspotAssetsResponseDTO> UpsertHubspotAssetsAsync(
            Guid accountId, 
            Guid userId, 
            Guid sessionId,             
            UpsertHubspotAssetsRequestDTO updateAssetRequest)
        {
            if (updateAssetRequest is null)
            {
                throw new ArgumentNullException(nameof(updateAssetRequest));
            }

            var jsonParams = updateAssetRequest.ToJsonString();

            var jsonOutput = await _hubspotLogic.UpsertHubspotAssetsAsync(accountId, userId, sessionId, jsonParams);
            var result = JsonConvert.DeserializeObject<UpsertHubspotAssetsResponseDTO>(jsonOutput);

            await _serviceBusService.SignalHubSpot(new
            {
                MessageType = ServiceBusMessageType.ASSETS_ADDED_TO_HUBSPOT,
                AccountId = accountId.ToString(),
                SignalRConnectionId = updateAssetRequest.SignalRConnectionId,
                AssetIds = updateAssetRequest.Ids
            });
            
            return result;
        }

        public async Task<DeleteHubspotAssetsResponseDTO> DeleteHubspotAssetsAsync(
            Guid accountId, 
            Guid userId, 
            Guid sessionId, 
            DeleteHubspotAssetsRequestDTO deleteAssetsRequest)
        {
            if (deleteAssetsRequest is null)
            {
                throw new ArgumentNullException(nameof(deleteAssetsRequest));
            }

            var jsonParams = deleteAssetsRequest.ToJsonString();

            var jsonOutput = await _hubspotLogic.DeleteHubspotAssetsAsync(accountId, userId, sessionId, jsonParams);
            var result = JsonConvert.DeserializeObject<DeleteHubspotAssetsResponseDTO>(jsonOutput);

            await _serviceBusService.SignalHubSpot(new
            {
                MessageType = ServiceBusMessageType.ASSETS_REMOVED_FROM_HUBSPOT,
                AccountId = accountId.ToString(),
                SignalRConnectionId = deleteAssetsRequest.SignalRConnectionId,
                AssetIds = deleteAssetsRequest.Ids
            });
            return result;
        }

        public async Task<GetEntityResponse<SyncAllResponseDTO>> ResyncCollectionAsync(Guid accountId, Guid userId, Guid sessionId, HubspotCollectionDTO request)
        {
            var jsonOutput = await _hubspotLogic.ResyncCollectionAsync(accountId, userId, sessionId, request.CollectionId);
            GetEntityResponse<SyncAllResponseDTO> result = JsonConvert.DeserializeObject<GetEntityResponse<SyncAllResponseDTO>>(jsonOutput);

            await _serviceBusService.SignalHubSpot(new
            {
                MessageType = ServiceBusMessageType.SYNC_ALL_TO_HUBSPOT,
                AccountId = accountId.ToString(),
                SignalRConnectionId = request.SignalRConnectionId
            });

            return result;
        }

        public async Task<GetEntityResponse<SyncAllResponseDTO>> StopSyncCollectionAsync(Guid accountId, Guid userId, Guid sessionId, HubspotCollectionDTO request)
        {
            var jsonOutput = await _hubspotLogic.StopSyncCollectionAsync(accountId, userId, sessionId, request.CollectionId);
            GetEntityResponse<SyncAllResponseDTO> result = JsonConvert.DeserializeObject<GetEntityResponse<SyncAllResponseDTO>>(jsonOutput);

            await _serviceBusService.SignalHubSpot(new
            {
                MessageType = ServiceBusMessageType.ASSETS_REMOVED_FROM_HUBSPOT,
                AccountId = accountId.ToString(),
                SignalRConnectionId = request.SignalRConnectionId
            });

            return result;
        }


        public async Task<GetEntityResponse<SyncAllResponseDTO>> SyncAllAsync(Guid accountId, string signalRConnectionId)
        {
            var jsonOutput = await _hubspotLogic.SyncAllAsync(accountId);
            GetEntityResponse<SyncAllResponseDTO> result = JsonConvert.DeserializeObject<GetEntityResponse<SyncAllResponseDTO>>(jsonOutput);

            await _serviceBusService.SignalHubSpot(new
            {
                MessageType = ServiceBusMessageType.SYNC_ALL_TO_HUBSPOT,
                AccountId = accountId.ToString(),
                SignalRConnectionId = signalRConnectionId
            });

            return result;
        }

        public async Task LoginToHubspotAsync(Guid accountId, string hubspotCredentials)
        {
            dynamic credentialsObj = JsonConvert.DeserializeObject(hubspotCredentials);
            var userToken = credentialsObj.token.Value;

            await _serviceBusService.SignalHubSpot(new
            {
                MessageType = ServiceBusMessageType.LOGIN_TO_HUBSPOT,
                AccountId = accountId.ToString(),
                UserToken = userToken
            });

        }

    }
}
