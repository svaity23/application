﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WebApi.Dtos
{
    public class IntegrationDto
    {
        public Guid Id { get; set; }
        
        public Guid AccountId { get; set; }
        
        public DateTime Created { get; set; }
        
        public DateTime Modified { get; set; }
        
        public string Key { get; set; }
        
        public string Token { get; set; }
        
        public string Name { get; set; }

        public string Status { get; set; }

        public string SignalRSource { get; set; }

        public string SignalRConnectionId { get; set; }
    }
}
