﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos
{
    public class GoogleUploadRequest
    {
        public string AccessToken { get; set; }
        public Guid AssetId { get; set; }        
        public string SignalRConnectionId { get; set; }
        public string Source { get; set; }
        public string FileGroup { get; set; }
        public string FileName { get; set; }       
        public string GoogleFileId { get; set; }
        public Guid UploadSessionId { get; set; }
        public long FileSizeBytes { get; set; }
    }
}
