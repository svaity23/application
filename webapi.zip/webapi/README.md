# Introduction

The WebAPI provides all the back-end functionality needed by the Angular application.

## API Discovery / OpenAPI / Swagger

OpenApi was added to this project using the directions [here](https://www.syncfusion.com/blogs/post/automatically-generate-api-docs-for-asp-net-core.aspx).

## Build and Run as container

For Visual Studio development, there is a launch profile to run this project as a Docker container. You have the option to select Docker and run/debug with F5.

Additionally, you can build and run the image from the commandline.  Depending on which folder you are in, the commands will look a slightly different for the docker *build `<context>`*.  Read about it [here](https://docs.microsoft.com/en-us/visualstudio/containers/container-build?view=vs-2019#building-from-the-command-line)

### Examples commands

Docker build image (solution folder)

```cmd
docker build -f webapi/DockerFile -t <image-name>:<version-tag> .
```

Docker build image (project folder)

```cmd
docker build -f DockerFile -t <image-name>:<version-tag> ..
```

Docker run image

```cmd
docker run -it --rm <image-name>:<version-tag>
```

## Debugging / Service Bus targets (and no more lost messages)

Those of you already developing against the Azure Service Bus provided by Marcom may have noticed lost messages. It happens because of the Competing Consumer Pattern and the fact that fellow developers or Kubernetes (AKS) containers running the same code might grab your messages.

We've made changes so that you can get any service bus message you need for your projects running locally (dotnet run or F5) without concern that another developer or a container on SBX AKS will grab that message before you can.

As a developer, here's the supported use-cases sending an Azure Service Bus message:
1.	If I want the messages for my copies of SignalRHub, CancelUpload and UserSync running locally (F5), I will get them every single time even though other developers and SBX containers were subscribed to the same Topic
2.	SBX containers won't get the messages that I intend to consume locally and try to duplicate work (e.g. write to tables a second time).
3.	Messages I create but intend for SBX containers (e.g. because I don't want to run SignalRHub locally) arrive every time on the SBX machines for processing, and my copies of
SignalRHub, etc. won't see those messages next time I run them.

Out of the box it will just work, assuming you're not running CancelUpload and UserSync locally, but instead letting the shared SBX containers do the workk (#3 above). If you'd like to run them locally (#1 above), it's easy, and I'll explain below how to do that.

In the WebAPI's settings, there's a configuration section indicating where you'd like your Service Bus messages to be processed (e.g. locally or let SBX do it).

```json
"TargetMachines": {
"thumbnailWorker": null,
"signalRHubWorker": "local",
"cancelUploadWorker": null,
"userSyncWorker": null
},
```

You can use null (as we did above) to have SBX process the messages. "sbx" or "aks" do the same. If you want to run it locally, change it to "local" or your computer name in quotes. Then load the project (SignalRHub, Cancel-Upoad, User-Sync) and hit F5.

Valid values:

|vlaue|effect|
|-----|------|
|null, "sbx", or "aks"|the sbx environment will process the messages using containers listening there|
|"local", "<<your computer name>>"|you will process messages using projects you're running locally (F5 or dotnet run)|

What if you don't want to accidentally check that appsettings.json file in and make enemies?!? We've got you covered. Just add a file in the right place (c:/damConfig/shared/appsettings.json).

*c:/damConfig/shared/appsettings.json:*
```json
{
  "TargetMachines": {
    "thumbnailWorker": "sbx",
    "signalRHubWorker": "local",
    "cancelUploadWorker": "sbx",
    "userSyncWorker": "sbx"
  }
}
```

## Scaffolding Tables

We are standarizing on the use of Stored Procedures, favoring them over Entity Frameworks EF. 