﻿using System.Text.Json.Serialization;

namespace UploadAsset.Dtos
{
    public class AccountIdsDto
    {
        [JsonPropertyName("ids")]
        public string Ids { get; set; }
    }
}
