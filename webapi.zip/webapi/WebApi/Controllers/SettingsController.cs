﻿using ApplicationLogic.Models;
using Microsoft.ApplicationInsights;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Dtos.Setting;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{

    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class SettingsController : ControllerBase
    {
        private readonly ILogger<SettingsController> _logger;
        private readonly SettingService _settingsService;
        private readonly TelemetryClient _telemetryClient;
        private readonly UserAccountService _userAccountService;

        public SettingsController(ILogger<SettingsController> logger, SettingService settingsService, TelemetryClient telemetryClient, UserAccountService userAccountService)
        {
            _logger = logger;
            _settingsService = settingsService;
            _telemetryClient = telemetryClient;
            _userAccountService = userAccountService;
        }

        /// <summary>
        /// Returns the list of FrontEnd Settings for user
        /// </summary>
        /// <returns>Returns the list of FrontEnd Settings for user</returns>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<SettingsDto>))]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]        
        public async Task<IActionResult> GetFrontEndSettings()
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            GetEntityResponse<SettingsDto> results = await _settingsService.GetFrontEndSettings(accountId, userId);
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entity ?? new SettingsDto()),
                    3 => Forbid(),// the user doesn't have admin rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }

        /// <summary>
        /// Create or update settings for a given role.
        /// </summary>
        /// <param name="update"></param>
        /// <returns>Returns the list of updated settings for role</returns>
        [HttpPut("role")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<AreaSettingDto>))]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateRoleSetting([FromBody] AreaSettingDto update)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            UpsertResponse<AreaSettingDto> results = await _settingsService.UpdateRoleSettings(accountId, userId, update);
            if (results != null)
            {
                int err = results.Errors[0].Code;
                return err switch
                {
                    0 => Ok(results.Entity ?? new AreaSettingDto()),
                    3 => Forbid(),// the user doesn't have admin rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return Ok();
        }

        /// <summary>
        /// Create or update settings for a given account. 
        /// </summary>
        /// <param name="update"></param>
        /// <returns>Returns the list of updated settings for account</returns>
        [HttpPut("account")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<AreaSettingDto>))]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UpdateAccountSetting([FromBody] AreaSettingDto update)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            if (update == null)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }

            UpsertResponse<AreaSettingDto> results = await _settingsService.UpdateAccountSettings(accountId, userId, update);
            if (results != null)
            {
                int err = results.Errors[0].Code;
                return err switch
                {
                    0 => Ok(results.Entity ?? new AreaSettingDto()),
                    3 => Forbid(),// the user doesn't have admin rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return Ok();
        }

        /// <summary>
        /// Create or update settings for a given user.
        /// </summary>
        /// <param name="update"></param>
        /// <returns>Returns the list of updated settings</returns>
        [HttpPut("user")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<AreaSettingDto>))]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateUserSetting([FromBody] AreaSettingDto update)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            UpsertResponse<AreaSettingDto> results = await _settingsService.UpdateUserSettings(accountId, userId, update);
            if (results != null)
            {
                int err = results.Errors[0].Code;
                return err switch
                {
                    0 => Ok(results.Entity ?? new AreaSettingDto()),
                    3 => Forbid(),// the user doesn't have admin rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return Ok();
        }

    }
}
