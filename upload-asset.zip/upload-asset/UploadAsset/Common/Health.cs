﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.IO;

namespace UploadAsset.Common
{
    public class Health
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<Health> _logger;
        private const string _message = "Error adding/deleting file for health monitoring. AKS won't handle this situation properly (mark as ready or broken and replace it)";

        public Health (IConfiguration configuration, ILogger<Health> logger)
        {
            _configuration = configuration;
            _logger = logger;
        }
        public bool Live
        {
            //get
            //{
                //TODO: return true if file present on disk
            //    throw new NotImplementedException();
            //}
            set
            {
                if (value)
                {
                    if (_configuration["DotnetEnvironment"] == "local")
                    {
                        Directory.CreateDirectory("health"); // for local dev only, dockerfile makes this folder for container
                    }
                    File.WriteAllText(@"health/live", "foo");
                }
                else
                {
                    try
                    {
                        File.Delete(@"health/live");
                    }
                    catch (ArgumentException e)
                    {
                        _logger.LogError(e, _message);
                    }
                    catch (DirectoryNotFoundException e)
                    {
                        _logger.LogError(e, _message);
                    }
                    catch (IOException e)
                    {
                        _logger.LogError(e, _message);
                    }
                }

            }
        }
        public bool Ready
        {
            //get
            //{
            //TODO: return true if file present on disk
            //    throw new NotImplementedException();
            //}
            set
            {
                if (value)
                {
                    if (_configuration["DotnetEnvironment"] == "local")
                    {
                        Directory.CreateDirectory("health"); // for local dev only, dockerfile makes this folder for container
                    }
                    File.WriteAllText(@"health/ready", "foo");
                }
                else
                {
                    try
                    {
                        File.Delete(@"health/ready");
                    }
                    catch (ArgumentException e)
                    {
                        _logger.LogError(e, _message);
                    }
                    catch (DirectoryNotFoundException e)
                    {
                        _logger.LogError(e, _message);
                    }
                    catch (IOException e)
                    {
                        _logger.LogError(e, _message);
                    }
                }

            }
        }
    }
}
