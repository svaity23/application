﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ApplicationLogic.Logic
{    
    public class AssetLogic
    {
        public ILogger<AssetLogic> Logger { get; set; }

        private readonly AssetFinder _finder;

        public AssetLogic(damContext context)
        {
            _finder = new AssetFinder(context);
            Logger = NullLogger<AssetLogic>.Instance;            
        }
      
        public async Task<string> ActivateAssets(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            return await _finder.ActivateAssets(accountId, userId, sessionId, jsonInput);
        }

        public async Task<Asset> CreateAssetAsync(Asset asset)
        {
            return await _finder.CreateAsync(asset);
        }

        public async Task<string> UpdateFavoritesAsync(Guid accountId, Guid userId, string jsonInput)
        {
            return await _finder.UpdateFavoritesAsync(accountId, userId, jsonInput);
        }

        public async Task<List<Asset>> GetActiveAssets(Guid accountId)
        {
            return await _finder.GetActiveAssets(accountId);
        }

        public async Task<string> GetAssetDetailForDetailsViewAsync(Guid accountId, Guid assetId, Guid userId)
        {
            return await _finder.GetAssetDetailForDetailsViewAsync(accountId, assetId, userId);            
        }
        public async Task<string> GetAssetForPreviewAsync(Guid accountId, Guid assetId, Guid userId, string jsonInput)
        {
            return await _finder.GetAssetForPreviewAsync(accountId, assetId, userId, jsonInput);
        }
        public async Task<string> GetAccountAssetsAsync(Guid accountId, Guid userId, string jsonInput)
        {
            return await _finder.GetByAccountIdAsync(accountId, userId, jsonInput);
        }

        public async Task<string> GetAccountAssetInfoByIdsAsync(Guid accountId, Guid userId, Guid sessionid, string action, List<Guid> assetIds, bool recordUsage, DateTime? expirationDate = null, string zipId = null)
        {
            var jsonOutput = await _finder.GetAccountAssetInfoByIdsAsync(accountId, userId, sessionid, action, assetIds, recordUsage, expirationDate, zipId);
            return jsonOutput;
        }

        public async Task<string> UpdateAssetAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            return await _finder.UpdateAssetAsync(accountId, userId, sessionId, jsonInput);
        }

        public async Task<string> UpdateMetadatumAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            return await _finder.UpdateMetadatumAsync(accountId, userId, sessionId, jsonInput);
        }
        
        public async Task<string> UpdateAssetsWithCollectionIdAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            return await _finder.UpdateAssetsWithCollectionIdAsync(accountId, userId, sessionId, jsonInput);
        }

        public async Task<string> UpdateFavoriteAsync(Guid accountId, Guid userId, string jsonInput)
        {
            return await _finder.UpdateFavoriteAsync(accountId, userId, jsonInput);
        }

        public async Task<string> ValidateAndReplaceAsset(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            return await _finder.ValidateAndReplaceAsset(accountId, userId, sessionId, jsonInput);
        }

        public async Task<string> ValidateAndCreateAssets(Guid accountId, Guid userId, string jsonInput, long maxFileUploadSizeInBytes)
        {
            return await _finder.ValidateAndCreateAssets(accountId, userId, jsonInput, maxFileUploadSizeInBytes);
        }

        public async Task<string> DeleteAssetsAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            return await _finder.DeleteAssetsAsync(accountId, userId, sessionId, jsonInput);
        }

        public async Task<string> GetAccountAssetsForCleanUpAsync(Guid accountId, Guid userId, string jsonInput)
        {
            return await _finder.GetAccountAssetsForCleanUpAsync(accountId, userId, jsonInput);
        }

        public async Task<string> UpdateMetadataAsync(Guid accountId, Guid userId, string jsonInput)
        {
            return await _finder.UpdateMetadataAsync(accountId, userId, jsonInput);
        }

        public async Task<string> UpdateTagAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            return await _finder.UpdateTagAsync(accountId, userId, sessionId, jsonInput);
        }
        public async Task<string> UpdateTagsAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            return await _finder.UpdateTagsAsync(accountId, userId, sessionId, jsonInput);
        }
#pragma warning disable CA1822 // Mark members as static
#pragma warning disable CA1801 // Review unused parameters
        public bool ValidateAssetEntity(Asset asset) // remove warning(s) suppress once code implemented
#pragma warning restore CA1801 // Review unused parameters
#pragma warning restore CA1822 // Mark members as static
        {
            // todo
            return true;
        }

        public async Task<string> AddCommentAsync(Guid accountId, Guid userId, Guid assetId, string jsonInput)
        {
            return await _finder.AddCommentAsync(accountId, userId, assetId, jsonInput);
        }

        public async Task<string> UpdateCommentAsync(Guid accountId, Guid userId, Guid assetId, string jsonInput)
        {
            return await _finder.UpdateCommentAsync(accountId, userId, assetId, jsonInput);
        }

        public async Task<string> GetMetadataFieldsMetadataProfilesAndProfileTypesAsync(Guid accountId)
        {
            return await _finder.GetMetadataFieldsMetadataProfilesAndProfileTypesAsync(accountId);
        }

        public async Task<string> GetPostUploadSummaryAsync(Guid accountId, Guid uploadSessionId)
        {
            return await _finder.GetPostUploadSummaryAsync(accountId, uploadSessionId);
        }

        public async Task<List<Asset>> GetShareAssetsAsync(Guid accountId, Guid[] assetIds)
        {
            return  await _finder.GetAssetsByIdsAsync(accountId, assetIds);
        }

        public async Task<string> GetAssetHistoryAsync(Guid accountId, Guid assetId)
        {
            return await _finder.GetAssetHistoryAsync(accountId, assetId);
        }

        public async Task<string> RecordAssetUsage(Guid accountId, Guid userId, Guid? sessionId, string jsonInput)
        {
            return await _finder.RecordAssetUsage(accountId, userId, sessionId, jsonInput);
        }

        public async Task<string> GetCommentsAsync(Guid accountId, Guid userId, Guid assetId)
        {
            return await _finder.GetCommentsAsync(accountId, userId, assetId);
        }
    }
}
