export enum MobileMenuIconType  {
    AllAssets,
    Analytics,
    AssetCleanup,
    Collections,
    Lightboxes,
    ExpiredAssets,
    Help,
    Notifications,
    Favorites,
    PrivacyPolicy,
    SignOut,
    TermsOfUse,
}
