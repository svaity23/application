﻿using Marcom.Azure.ServiceBus;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using UploadAsset.Common;
using UploadAsset.Dtos;

namespace UploadAsset.Services
{
    public class UploadService
    {
        private readonly ILogger<UploadService> _logger;
        private readonly IBusServiceFactory _busServiceFactory;
        private readonly IConfiguration _configuration;
        private readonly IntegrationService _integrationService;
        private readonly BlobService _blobService;
        private readonly ServiceBusService _serviceBusService;

        public const string CANCEL_UPLOAD_SESSION = "CANCEL_UPLOAD_SESSION";
        public const string FILE_UPLOADED = "FILE_UPLOADED";
        public const string VIDEO_UPLOADED = "VIDEO_UPLOADED";
        public const string ASSETS_ADDED_TO_HUBSPOT = "ASSETS_ADDED_TO_HUBSPOT";


        public UploadService(IConfiguration configuration, ILogger<UploadService> logger, IBusServiceFactory busServiceFactory, BlobService blobService, IntegrationService integrationService, ServiceBusService serviceBusService)
        {
            _configuration = configuration;
            _logger = logger;
            _busServiceFactory = busServiceFactory;
            _blobService = blobService;
            _integrationService = integrationService;
            _serviceBusService = serviceBusService;
        }


        /// <summary>
        /// The complexity of this method is due to the fact we need to stream LARGE file uploads. Client is passing in file and sessionId as formData.
        /// Each value appended to the form must be extracted via a stream reader.
        /// 
        /// Most of this logic was copied from website below.
        /// 
        /// TODO: More security and validation needs to be done on this method. Specifically concerning reading and storing the filename.
        /// 
        /// https://docs.microsoft.com/en-us/aspnet/core/mvc/models/file-uploads?view=aspnetcore-3.1
        /// 
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="accountId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task ProcessFileUploadAsync(MultipartReader reader, Guid accountId, Guid userId)
        {
            var section = await reader.ReadNextSectionAsync();

            Guid assetId = Guid.Empty;
            Guid uploadSessionId = Guid.Empty;
            string signalRConnectionId = null;
            string blobName = null;
            string source = null;
            string fileGroup = null;
            string messageType = FILE_UPLOADED;
            string storageAccountName = _configuration["BlobStorage:StorageAccountName"];
            string defaultUploadContainerName = _configuration["BlobStorage:UploadContainerName"];
            string uploadDestinationContainerName = BlobService.GetBlobContainerName(accountId, defaultUploadContainerName);
            bool isRevision = false;

            while (section != null)
            {
                var hasContentDispositionHeader = ContentDispositionHeaderValue.TryParse(section.ContentDisposition, out var contentDisposition);

                if (hasContentDispositionHeader)
                {
                    // Current content is a file. Process the file stream.
                    if (HasFileContentDisposition(contentDisposition))
                    {
                        var untrustedFileName = contentDisposition.FileName.Value;

                        string uploadMsg = $@"
                            ******************************************************
                            * uploading file {untrustedFileName} at {DateTime.Now}
                            ******************************************************";
                        _logger.LogDebug(uploadMsg);

                        // Create the blob in storage.
                        blobName = GetBlobName(assetId, untrustedFileName);
                        await _blobService.UploadAsync(uploadDestinationContainerName, blobName, section.Body);
                    }
                    else if (HasFormDataContentDisposition(contentDisposition))
                    {
                        var key = HeaderUtilities.RemoveQuotes(contentDisposition.Name).Value;

                        using (var streamReader = new StreamReader(section.Body, detectEncodingFromByteOrderMarks: true, bufferSize: 1024, leaveOpen: true))
                        {
                            var value = await streamReader.ReadToEndAsync();
                            if (!string.IsNullOrEmpty(value))
                            {
                                switch (key)
                                {
                                    case "uploadSessionId":
                                        uploadSessionId = Guid.Parse(value);
                                        break;
                                    case "assetId":
                                        assetId = Guid.Parse(value);
                                        break;
                                    case "signalRConnectionId":
                                        signalRConnectionId = value;
                                        break;
                                    case "fileGroup":
                                        if (value == "1") messageType = VIDEO_UPLOADED;
                                        fileGroup = value;
                                        break;
                                    case "source":
                                        source = value;
                                        break;
                                    case "revision":
                                        isRevision = bool.Parse(value);
                                        break;

                                }
                            }
                        }
                    }
                }

                // Drain any remaining section body that hasn't been consumed and read the headers for the next section.
                section = await reader.ReadNextSectionAsync();
            }

            string fileExtension = Path.GetExtension(blobName);
            await SendAssetUploadedMessageAsync(
                accountId,
                userId,
                assetId,
                blobName,
                defaultUploadContainerName,
                fileExtension,
                fileGroup,
                messageType,
                signalRConnectionId,
                source,
                storageAccountName,
                uploadSessionId,
                isRevision);
        }

        public async Task UploadFileAsync(HttpResponse response, FileUploadRequest request, Guid accountId, Guid userId)
        {
            // Setting content length to 100. As in 100 bytes.
            response.ContentLength = 100;
           
            using (Stream contentStream = request.File.OpenReadStream())
            {
                // Create a progress handler to track the progress from input file to azure storage.
                var progressHandler = CreateProgressHandler(response, "File", request.File.Length);
                string uploadMsg = $@"
                            ******************************************************
                            * Processing File {request.File.FileName} at {DateTime.Now}
                            ******************************************************";
                _logger.LogDebug(uploadMsg);
                await ProcessFileUploadRequestAsync(contentStream, accountId, userId, request, request.File.FileName, progressHandler);
            }
        }

        public async Task UploadDropboxFileAsync(HttpResponse response, DropboxService dropboxService, DropboxUploadRequest request, Guid accountId, Guid userId)
        {
            // Setting content length to 100. As in 100 bytes.
            response.ContentLength = 100;

            using (Stream contentStream = await dropboxService.GetFileStreamAsync(request.DropboxLink))
            {
                // Create a progress handler to track the progress from Dropbox to azure storage.
                var progressHandler = CreateProgressHandler(response, "Dropbox", request.FileSizeBytes);
                string uploadMsg = $@"
                            ******************************************************
                            * Processing Dropbox {request.FileName} at {DateTime.Now}
                            ******************************************************";
                _logger.LogDebug(uploadMsg);
                await ProcessFileUploadRequestAsync(contentStream, accountId, userId, request, request.FileName, progressHandler);
            }
        }

        public async Task UploadGoogleFileAsync(HttpResponse response, GoogleDriveService googleDriveService, GoogleUploadRequest request, Guid accountId, Guid userId)
        {
            // Setting content length to 100. As in 100 bytes.
            response.ContentLength = 100;

            using (Stream contentStream = await googleDriveService.GetFileAsStreamAsync(request.GoogleFileId))
            {
                // Create a progress handler to track the progress from Google to azure storage.
                var progressHandler = CreateProgressHandler(response, "Google", request.FileSizeBytes);
                string uploadMsg = $@"
                            ******************************************************
                            * Processing Google {request.FileName} at {DateTime.Now}
                            ******************************************************";
                _logger.LogDebug(uploadMsg);
                await ProcessFileUploadRequestAsync(contentStream, accountId, userId, request, request.FileName, progressHandler);
            }
        }

        public async Task UploadOneDriveFileAsync(HttpResponse response, OneDriveService oneDriveService, OneDriveUploadRequest request, Guid accountId, Guid userId)
        {
            // Setting content length to 100. As in 100 bytes.
            response.ContentLength = 100;

            using (Stream contentStream = await oneDriveService.GetFileStreamAsync(request.OneDriveLink))
            {
                // Create a progress handler to track the progress from OneDrive to azure storage.
                var progressHandler = CreateProgressHandler(response, "OneDrive", request.FileSizeBytes);                
                string uploadMsg = $@"
                            ******************************************************
                            * Processing OneDrive {request.FileName} at {DateTime.Now}
                            ******************************************************";
                _logger.LogDebug(uploadMsg);
                await ProcessFileUploadRequestAsync(contentStream, accountId, userId, request, request.FileName, progressHandler);
            }
        }


        #region Private Methods
        private async Task ProcessFileUploadRequestAsync(Stream stream, Guid accountId, Guid userId, BaseFileUploadRequest request, string untrustedFileName, IProgress<long> progressHandler)
        {
            #region Setup variables
            // base file upload message variables
            Guid assetId = request.AssetId;
            Guid uploadSessionId = request.UploadSessionId;
            string signalRConnectionId = request.SignalRConnectionId;
            string source = request.Source;
            string fileGroup = request.FileGroup;

            // blob variables
            string storageAccountName = _configuration["BlobStorage:StorageAccountName"];
            string defaultUploadContainerName = _configuration["BlobStorage:UploadContainerName"];
            string uploadDestinationContainerName = BlobService.GetBlobContainerName(accountId, defaultUploadContainerName);            
            string blobName = GetBlobName(assetId, untrustedFileName);
            string fileExtension = Path.GetExtension(blobName);

            // message type will be used to filter out messages by subscribing containers
            string messageType = fileGroup == "1" ? VIDEO_UPLOADED : FILE_UPLOADED;
            #endregion

            // Upload the blob.
            await _blobService.UploadAsync(uploadDestinationContainerName, blobName, stream, progressHandler);

            await SendAssetUploadedMessageAsync(
                accountId,
                userId,
                assetId,
                blobName,
                defaultUploadContainerName,
                fileExtension,
                fileGroup,
                messageType,
                signalRConnectionId,
                source,
                storageAccountName,
                uploadSessionId
                );
        }

        private string GetBlobName(Guid assetId, string fileName)
        {
            var fileExt = Path.GetExtension(fileName);
            var blobName = assetId.ToString() + fileExt;
            return blobName.ToLowerInvariant();
        }

        /// <summary>
        /// Helper used to tell if current content in form is a file
        /// </summary>
        /// <param name="contentDisposition"></param>
        /// <returns></returns>
        private static bool HasFileContentDisposition(ContentDispositionHeaderValue contentDisposition)
        {
            // Content-Disposition: form-data; name="myfile1"; filename="Misc 002.jpg"
            return contentDisposition != null
                && contentDisposition.DispositionType.Equals("form-data")
                && (!string.IsNullOrEmpty(contentDisposition.FileName.Value)
                    || !string.IsNullOrEmpty(contentDisposition.FileNameStar.Value));
        }

        /// <summary>
        /// Helper used to tell if current content in form is form data
        /// </summary>
        /// <param name="contentDisposition"></param>
        /// <returns></returns>
        private static bool HasFormDataContentDisposition(ContentDispositionHeaderValue contentDisposition)
        {
            // Content-Disposition: form-data; name="key";
            return contentDisposition != null
                && contentDisposition.DispositionType.Equals("form-data")
                && string.IsNullOrEmpty(contentDisposition.FileName.Value)
                && string.IsNullOrEmpty(contentDisposition.FileNameStar.Value);
        }

        private static object[] GetImageConverterProcessingTasks()
        {
            return new[] {
                new {
                    Name = "web",
                    Destinations = new [] {
                        new {
                            Details = new {
                                ContainerName = "web"
                            }
                        }
                    }
                },
                new {
                    Name = "thumb",
                    Destinations = new [] {
                        new {
                            Details = new {
                                ContainerName = "thumbnail"
                            }
                        }
                    }
                },
                new {
                    Name = "meta",
                    Destinations = new [] {
                        new {
                            Details = new {
                                ContainerName = "metadata"
                            }
                        }
                    }
                },
                new {
                    Name = "low-res",
                    Destinations = new [] {
                        new {
                            Details = new {
                                ContainerName = "low-resolution"
                            }
                        }
                    }
                },
            };
        }

        private BlobUploadProgressHandler CreateProgressHandler(HttpResponse response, string uploadHandlerName, double fileSizeLength)
        {
            // Create a progress handler to track the progress from google to azure storage.
            var progressHandler = new BlobUploadProgressHandler(fileSizeLength);
            progressHandler.ProgressHandler += async (object sender, BlobUploadProgressEventArgs e) => {
                // This will get called everytime the upload progress gets updated.
                // The EventArgs will let us know how many percentage points to progress.
                // Each percentage point represents 1 byte of data that needs to be sent down to client.
                for (var i = 0; i < e.PercentagePointsToProgress; i++)
                {
                    byte[] progress = new byte[1] { 1 };
                    try
                    {
                        await response.Body.WriteAsync(progress);
                    }
                    catch (InvalidOperationException opEx)
                    {
                        _logger.LogWarning($"{uploadHandlerName} upload progress stream exceeded 100 percent. No harm done.", opEx.Message);
                    }

                    await response.Body.FlushAsync();
                }
            };

            return progressHandler;
        }

        // TODO CLEANUP make common 1 dto?
        private async Task SendAssetUploadedMessageAsync(
            Guid accountId,
            Guid userId,
            Guid assetId,
            string blobName,
            string defaultUploadContainerName,
            string fileExention,
            string fileGroup,
            string messageType,
            string signalRConnectionId,
            string source,
            string storageAccountName,
            Guid uploadSessionId,
            bool isRevision = false)
        {
            // This will be picked up by cancel-upload and image-converter
            await _serviceBusService.SignalImageUploaded(new
            {
                MessageType = messageType,
                AssetId = assetId.ToString(),
                UploadSessionId = uploadSessionId.ToString(),
                AccountId = accountId,
                StorageAccountName = storageAccountName,
                BlobName = blobName,
                FileGroup = fileGroup,
                ID = Guid.NewGuid(),
                Opaque = new
                {
                    SignalRConnectionId = signalRConnectionId,
                    AssetId = assetId.ToString(),
                    Source = source,
                    AccountId = accountId
                },
                TenantInfo = new
                {
                    Account = new
                    {
                        Type = "AzureBlobStorage",
                        Details = new
                        {
                            AccountName = storageAccountName,
                            ContainerName = defaultUploadContainerName,
                            ContainerNamePrefix = accountId.ToString()
                        }
                    }
                },
                Source = new
                {
                    FileName = assetId.ToString() + fileExention.ToLowerInvariant()
                },
                Processing = new
                {
                    Tasks = GetImageConverterProcessingTasks()
                }
            });

            // This will be picked up by the signal-r-hub
            await _serviceBusService.SignalImageProcessed(new
            {
                MessageType = FILE_UPLOADED,
                AssetId = assetId.ToString(),
                Opaque = new
                {
                    SignalRConnectionId = signalRConnectionId,
                    Source = source
                }
            });

            await _serviceBusService.SignalHubSpot(
            new
            {
                MessageType = ASSETS_ADDED_TO_HUBSPOT,
                AccountId = accountId,
                AssetIds = Array.Empty<Guid>()
            });

            if(isRevision)
            {
                var response = await _integrationService.GetIntegrationSettingsByAccountIdAsync(accountId);
                var integrationSettings = response?.Entity;

                if (integrationSettings != null)
                {
                    // marcom integration is enabled
                    var marcomSettings = integrationSettings.Where(x => x.Key == IntegrationSettingKeys.Marcom).FirstOrDefault();
                    if (marcomSettings != null && marcomSettings.BoolValue)
                    {
                        _logger.LogDebug($"Sending MARCOM_INTEGRATION_ASSET_REVISION message with accountId {accountId} assetId {assetId}");
                        await _serviceBusService.SignalDistributedMarketing(
                        new
                        {
                            Action = "MARCOM_INTEGRATION_ASSET_REVISION",
                            AccountId = accountId,
                            UserId = userId,
                            AssetId = assetId
                        });
                    }
                }
                
                
            }
        }
    }
    #endregion Private Methods

}
