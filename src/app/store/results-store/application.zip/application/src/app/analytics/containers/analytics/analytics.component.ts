import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import { AppRouterReducerState } from '@app/store/router-store/reducers/app-router.reducer';
import { AppStoreFacade } from '@app/store/app-store/app-store.facade';
import { Context } from '@app/core/models/context.model';
import { Permission } from '../../../core/models/permission.model';
import { PermissionKey } from '../../../core/enums/permission-key.enum';

@Component({
  selector: 'app-analytics',
  templateUrl: './analytics.component.html',
  styleUrls: ['./analytics.component.scss']
})
export class AnalyticsComponent implements OnInit, OnDestroy {
  context$: Observable<Context>;
  isAnalyticsLoading: boolean;
  isDesktop$: Observable<boolean>;
  isExpiredAssetsVisible$: Observable<boolean>;
  logoUrl$: Observable<string>;
  route$: Observable<AppRouterReducerState>;
  showAnalytics$: Observable<boolean>;
  showNotifications$: Observable<Permission>;
  sisenseLaunchUrl$: Observable<string>;

  constructor(
    private appStoreFacade: AppStoreFacade) { }


  ngOnDestroy(): void {
    this.appStoreFacade.clearSisenseUrl();
  }

  ngOnInit(): void {
    this.isAnalyticsLoading = true;
    this.route$ = this.appStoreFacade.route$;
    this.context$ = this.appStoreFacade.context.context$;
    this.isDesktop$ = this.appStoreFacade.isDesktop$;
    this.isExpiredAssetsVisible$ = this.appStoreFacade.isExpiredAssetsVisibleForUser$;
    this.logoUrl$ = this.appStoreFacade.logoUrl$;
    this.showAnalytics$ = this.appStoreFacade.context.showAnalytics$
    this.showNotifications$ = this.appStoreFacade.context.selectPermissionByKey(PermissionKey.ViewNotifications);
    this.sisenseLaunchUrl$ = this.appStoreFacade.sisenseLaunchUrl$;

    this.appStoreFacade.getSisenseLaunchUrl();
  }

  setAnalyticsLoading($event: boolean): void {
    this.isAnalyticsLoading = $event;
  }

}
