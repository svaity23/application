import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { BaseDataService } from './base-data.service';
import { Lightbox } from '../models/entities/lightbox.model';
import { LightboxAssetsForPreview } from '../models/entities/lightbox-assets-for-preview.model';

export interface LightboxDataServiceInterface {
  add(lightboxName: string): Observable<Lightbox>;
  delete(id: string): Observable<string>;
  getAll(): Observable<Lightbox[]>;
  getAllLightboxesAssetsForPreview(): Observable<LightboxAssetsForPreview[]>;
  getById(id: string): Observable<Lightbox>;
  update(lightbox: Lightbox): Observable<Lightbox>;
}

@Injectable({ providedIn: 'root' })
export class LightboxDataService extends BaseDataService implements LightboxDataServiceInterface {
  add(lightboxName: string): Observable<Lightbox> {
    const dto = {
      Name: lightboxName
    };
    const url = `${this.webApiUrl}/lightboxes`;
    return this.createApiPost({ url, data: dto });
  }

  delete(id: string): Observable<string> {
    const url = `${this.webApiUrl}/lightboxes/${id}`;
    return this.createApiDelete({ url });
  }

  getAll(): Observable<Lightbox[]> {
    const url = `${this.webApiUrl}/lightboxes`;
    return this.createApiGet({ url });
  }

  getAllLightboxesAssetsForPreview(): Observable<LightboxAssetsForPreview[]> {
    const url = `${this.webApiUrl}/lightboxes/previewAssets`;
    return this.createApiGet({ url });
  }

  getById(id: string): Observable<Lightbox> {
    const url = `${this.webApiUrl}/lightboxes/${id}`;
    return this.createApiGet({ url });
  }

  update(lightbox: Lightbox): Observable<Lightbox> {
    const url = `${this.webApiUrl}/lightboxes`;
    return this.createApiPost({ url, data: lightbox });
  }
}
