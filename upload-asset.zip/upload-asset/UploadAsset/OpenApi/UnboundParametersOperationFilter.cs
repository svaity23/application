﻿using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

using System.Collections.Generic;

namespace UploadAsset.OpenApi
{
    public class UnboundParametersOperationFilter : IOperationFilter
    {
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            var descriptor = context.ApiDescription.ActionDescriptor as ControllerActionDescriptor;

            if (descriptor != null && descriptor.ControllerTypeInfo == typeof(Controllers.UploadController) && descriptor.ActionName == nameof(Controllers.UploadController.Upload))
            {
                var openApiMediaType = new OpenApiMediaType
                {
                    Schema = new OpenApiSchema
                    {
                        Type = "object",
                        Required = new HashSet<string> { "assetId", "file", "fileGroup", "uploadSessionId"}, // make the parameter(s) required if needed
                        Properties = new Dictionary<string, OpenApiSchema>
                    {
                        { "assetId" , new OpenApiSchema() { Type = "string", Format = "uuid" } },
                        { "fileGroup" , new OpenApiSchema() { Type = "string", Format = "string" } },
                        { "source" , new OpenApiSchema() { Type = "string", Format = "string" } },
                        { "signalRConnectionId" , new OpenApiSchema() { Type = "string", Format = "string" } },
                        { "uploadSessionId" , new OpenApiSchema() { Type = "string", Format = "uuid" } },
                        { "file" , new OpenApiSchema() { Type = "string", Format = "binary" } },
                    }
                    }
                };

                operation.RequestBody = new OpenApiRequestBody
                {
                    Content = new Dictionary<string, OpenApiMediaType>
                {
                    { "multipart/form-data", openApiMediaType }
                }
                };
            }
        }
    }
}
