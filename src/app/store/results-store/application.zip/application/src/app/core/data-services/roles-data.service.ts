import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { BaseDataService } from './base-data.service';

import { Role } from '../models/entities/role.model';

export interface RolesDataServiceInterface {
  getAll(): Observable<Role[]>;
}

@Injectable({
  providedIn: 'root'
})
export class RolesDataService extends BaseDataService implements RolesDataServiceInterface {
  getAll(): Observable<Role[]> {
    const url = `${this.webApiUrl}/roles`;
    return this.createApiGet({ url });
  }
}
