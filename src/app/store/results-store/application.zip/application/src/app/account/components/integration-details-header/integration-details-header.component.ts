import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { Integration } from '@app/core/models/integrations/integration.model';

@Component({
  selector: 'app-integration-details-header',
  templateUrl: './integration-details-header.component.html',
  styleUrls: ['./integration-details-header.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class IntegrationDetailsHeaderComponent implements OnChanges  {
  @Output() cancelEvent = new EventEmitter();
  @Input() integration: Integration;
  @Input() saveButtonEnabled = true;
  @Output() saveEvent = new EventEmitter();  
  @Input() title: string;

  constructor( ) { }
  
  cancel(): void {
    this.cancelEvent.emit();
  }
  
  ngOnChanges(changes: SimpleChanges): void {
    if (changes.saveButtonEnabled) {
      this.saveButtonEnabled = changes.saveButtonEnabled.currentValue;
    }
  }

  saveChanges(): void {
    this.saveEvent.emit();
  }

}
