export enum AssetConversionType {
  PrintQualityJpgHighResolution,
  PrintQualityPngHighResolution,
  ScreenQualityJpgLowResolution,
  ScreenQualityPngLowResolution,
  ScreenQualityPdfLowResolution,
  OriginalQualityJpg
}
