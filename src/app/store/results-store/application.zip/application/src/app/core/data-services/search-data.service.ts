import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { BaseDataService } from './base-data.service';

import { SearchFilters } from '../models/search-filters.model';
import { SearchSuggestion } from '../models/search-suggestion.model';

export interface SearchDataServiceInterface {
  getFilters(searchTerm: string, collectionId: string, searchFavorites: boolean, lightboxId: string, searchExpiredAssets: boolean, searchCleanupAssets: boolean ): Observable<SearchFilters>;
  getSearchSuggestions(searchTerm: string, collectionId: string, searchFavorites: boolean, lightboxId: string, searchExpiredAssets: boolean, searchCleanupAssets: boolean): Observable<SearchSuggestion[]>;
  getTagsSuggestions(searchTerm: string): Observable<string[]>;
}

@Injectable({ providedIn: 'root' })
export class SearchDataService extends BaseDataService implements SearchDataServiceInterface {

  getFilters(searchTerm: string, collectionId: string, searchFavorites: boolean, lightboxId: string, searchExpiredAssets: boolean, searchCleanupAssets: boolean): Observable<SearchFilters> {

    let params = new HttpParams();

    if (searchTerm) {
      params = params.set('searchTerm', searchTerm);
    }

    if (collectionId) {
      params = params.set('collectionId', collectionId);
    }

    if (searchFavorites) {
      params = params.set('searchFavorites', 'true');
    }

    if (lightboxId) {
      params = params.set('lightboxId', lightboxId);
    }

    if (searchExpiredAssets) {
      params = params.set('searchExpiredAssets', 'true');
    }

    if (searchCleanupAssets) {
      params = params.set('searchCleanupAssets', 'true');
    }

    const url = `${this.webApiUrl}/searchassets/filters`;
    return this.createApiGet({ url, params });
  }

  getSearchSuggestions(searchTerm: string, collectionId: string, searchFavorites: boolean, lightboxId: string, searchExpiredAssets: boolean, searchCleanupAssets: boolean): Observable<SearchSuggestion[]> {
    let params = new HttpParams()
      .set('searchTerm', searchTerm);

    if (collectionId) {
      params = params.set('collectionId', collectionId);
    }

    if (searchFavorites) {
      params = params.set('searchFavorites', 'true');
    }

    // TODO: re-visit
    if (lightboxId != null) {
      params = params.set('lightboxId', lightboxId);
    }

    if (searchExpiredAssets) {
      params = params.set('searchExpiredAssets', 'true');
    }

    if (searchCleanupAssets) {
      params = params.set('searchCleanupAssets', 'true');
    }

    const url = `${this.webApiUrl}/searchassets/suggest`;
    return this.createApiGet({ url, params });
  }

  getTagsSuggestions(searchTerm: string): Observable<string[]> {
    const params = new HttpParams()
      .set('searchTerm', searchTerm);

    const url = `${this.webApiUrl}/searchassets/tags`;
    return this.createApiGet({ url, params });
  }
}
