﻿using System;

namespace WebApi.Dtos
{
    public class AssetUploadRequestDto
    {
        public Guid Id { get; set; }
        public int? FileGroup { get; set; }
        public string FileName { get; set; }
        public long? FileSize { get; set; }
        public Guid? UploadSessionId { get; set; }
    }
}
