﻿using System;

namespace WebApi.Dtos
{
    public class AssetRevisionRequestDto
    {
        public Guid Id { get; set; }
        public string FileName { get; set; }
        public long? FileSize { get; set; }
        public bool Favorite { get; set; }
        public string Name { get; set; }
    }
}
