export interface SyncError {
    code?: number;
    description?: string;
}
