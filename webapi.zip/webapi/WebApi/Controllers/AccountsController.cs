using ApplicationLogic.Models;
using Microsoft.ApplicationInsights;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Dtos;
using WebApi.Dtos.Context;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class AccountsController : ControllerBase
    {
        private readonly ILogger<AccountsController> _logger;
        private readonly AccountService _accountService;
        private readonly AzureStorageService _azureStorageService;
        private readonly TelemetryClient _telemetryClient;
        private readonly UserAccountService _userAccountService;
        private readonly UserService _userService;

        public AccountsController(ILogger<AccountsController> logger, AccountService accountService, AzureStorageService azureStorageService, TelemetryClient telemetryClient, UserAccountService userAccountService, UserService userService)
        {
            _logger = logger;
            _accountService = accountService;
            _azureStorageService = azureStorageService;
            _userAccountService = userAccountService;
            _userService = userService;
            _telemetryClient = telemetryClient;
        }

        /// <summary>
        /// Delete account by id
        /// </summary>
        /// <remarks>      
        /// </remarks>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(bool))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> DeleteAccount(Guid id)
        {
            if (id.Equals(Guid.Empty)) return BadRequest();

            var userId = this.User.GetUserId();

            // no claims tranformation yet, we need to pull user from db
            var hasAccess = await _userService.ValidateSysAdminAccess(userId);
            if (!hasAccess)
            {
                return StatusCode(StatusCodes.Status403Forbidden);
            }

            var result = await _accountService.DeleteAcount(id);            

            return Ok(result > 0);
        }

        /// <summary>
        /// Get all accounts
        /// </summary>
        /// <remarks>
        /// Get all accounts for use by sys-admin only
        /// </remarks>
        /// <returns></returns>
        [HttpGet()]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<AccountDetailtDto>))]
        public async Task<IActionResult> GetAll()
        {
            var userId = this.User.GetUserId();

            // no claims tranformation yet, we need to pull user from db
            var hasAccess = await _userService.ValidateSysAdminAccess(userId);
            if(!hasAccess)
            {   
                return StatusCode(StatusCodes.Status403Forbidden);
            }

            var results = await _accountService.GetAllAccountsAsync();
             
            return Ok(results);        
        }

        /// <summary>
        /// Get account by id
        /// </summary>
        /// <remarks>
        /// Get account by id
        /// </remarks>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AccountDetailtDto))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetById(Guid id)
        {
            var userId = this.User.GetUserId();

            var result = await _accountService.GetAccountDetailByIdAsync(id, userId);
            if (result != null)
            {   
                return Ok(result);
            }            
            return NotFound();
        }

        /// <summary>
        /// Get account users
        /// </summary>
        /// <remarks>
        /// Gets all users for an account for use by sys-admin only
        /// </remarks>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}/users")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<UserDetailDto>))]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> GetAccountUsers(Guid id)
        {
            var userId = this.User.GetUserId();
            var hasAccess = await _userService.ValidateSysAdminAccess(userId);
            if (!hasAccess)
            {
                return StatusCode(StatusCodes.Status403Forbidden);
            }

            var results = await _userService.GetByAccountIdAsync(id);
            return Ok(results);
        }

        /// <summary>
        /// Get account users
        /// </summary>
        /// <remarks>
        /// Gets all features for an account for use by sys-admin only
        /// </remarks>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}/features")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<FeatureDto[]>))]
        public async Task<IActionResult> GetAccountFeatures(Guid id)
        {
            var userId = this.User.GetUserId();
            
            // this check is redundant as the stored proc will also validate user
            // but we are raising an error right now. so until thats clean up to 
            // respond with the correct error code, lets do the forbidden here
            var hasAccess = await _userService.ValidateSysAdminAccess(userId);
            if (!hasAccess)
            {
                return StatusCode(StatusCodes.Status403Forbidden);
            }
            var results = await _accountService.GetAccountFeaturesAsync(id, userId);
            return Ok(results);
        }

        /// <summary>
        /// Get account users
        /// </summary>
        /// <remarks>
        /// Update features for an account for use by sys-admin only
        /// </remarks>
        /// <param name="id"></param>
        /// <param name="features"></param>
        /// <returns></returns>
        [HttpPut("{id}/features")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<FeatureDto[]>))]
        public async Task<IActionResult> UpdateAccountFeatures(Guid id, FeatureDto[] features)
        {
            var userId = this.User.GetUserId();

            // this check is redundant as the stored proc will also validate user
            // but we are raising an error right now. so until thats clean up to 
            // respond with the correct error code, lets do the forbidden here
            var hasAccess = await _userService.ValidateSysAdminAccess(userId);
            if (!hasAccess)
            {
                return StatusCode(StatusCodes.Status403Forbidden);
            }
            var results = await _accountService.UpdateAccountFeaturesAsync(id, userId, features);
            return Ok(results);
        }

        /// <summary>
        /// Free trial account creation
        /// </summary>
        /// <remarks>
        /// Account creation when self registering for a free trial
        /// </remarks>
        /// <param name="signalRDto"></param>
        /// <returns></returns>
        [HttpPost("selfReg")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> SelfRegUpsertAsync([FromBody] FreeTrialSignalRDto signalRDto)
        {
            _logger.LogInformation("SelfReg: Begin");

            
            var email = this.User.GetClaim("emails");
            _logger.LogInformation($"SelfReg: Processing claims for user {email}.");
            if (Guid.TryParse(this.User.GetClaim("extension_userId").Trim(), out Guid userId))
            {
                if (userId != Guid.Empty) //User already exists nothing to do here
                {
                    _logger.LogInformation($"SelfReg: User {email} already exists.");
                    return StatusCode(StatusCodes.Status400BadRequest);
                }
            }
            
            try
            {
                var idpId = this.User.GetIdpId().ToString();
                if (string.IsNullOrWhiteSpace(idpId))
                {
                    _logger.LogInformation($"SelfReg: User {email} does not have an idpId.");
                    return StatusCode(StatusCodes.Status400BadRequest);
                }

                var firstName = this.User.GetClaim("given_name");
                var lastName = this.User.GetClaim("family_name");

                if (string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(lastName))
                {
                    var fullName = this.User.GetClaim("name").Split(' ').ToList();
                    if (fullName.Count > 1)
                    {
                        firstName = fullName[0];
                        fullName.RemoveAt(0);
                        lastName = string.Join(' ', fullName);
                    }

                    if (string.IsNullOrWhiteSpace(firstName))
                    {
                        firstName = "unknown";
                    }

                    if (string.IsNullOrWhiteSpace(lastName))
                    {
                        lastName = "unknown";
                    }
                }
                //Create DTO here form this.user
                AccountDetailtDto dto = new AccountDetailtDto
                {
                    UserFirstName = firstName,
                    UserLastName = lastName,
                    Name = this.User.GetClaim("extension_companyName"),
                    UserEmail = email,
                    UserIdpId = idpId,
                    TrialExpiration = DateTime.Today.AddDays(10),
                    AccountTypeName = "Trial",
                    StorageMaximumGb = 5,
                    Active = true,
                    TrialVerified = false // self reg trial starts unverified
                };

                _logger.LogInformation($"SelfReg: Creating DB record for User {email}. {dto.ToJsonString()}");

                //Create DAM Account set selfReg flag to inidiate special case
                await _accountService.SelfRegUpsertAccountAsync(userId, dto, signalRDto);

                _logger.LogInformation($"SelfReg: end for {email}");
                //Sent a message on the bus.  No exception occured.  Send Ok status.                           
                return Ok();

            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex) // // Do not catch general exception types TODO catch specific types
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _telemetryClient.TrackException(ex);
                _telemetryClient.TrackTrace("SelfReg Error:" + ex.Message);
                _logger.LogError(ex, $"SelfReg: Failed.  Exception for user {email} - {ex.Message}");
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        /// <summary>
        /// Create new Account
        /// </summary>
        /// <remarks>
        /// Account creation from account admin screen used by sys-admin only
        /// </remarks>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost()]
        [ProducesResponseType(StatusCodes.Status201Created, Type = typeof(UpsertResponse<AccountDetailtDto>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        public async Task<IActionResult> UpsertAsync([FromBody] AccountDetailtDto dto)
        {
            var userId = this.User.GetUserId();

            // no claims tranformation yet, we need to pull user from db
            var hasAccess = await _userService.ValidateSysAdminAccess(userId);
            if (!hasAccess)
            {
                return StatusCode(StatusCodes.Status403Forbidden);
            }

            if (dto.Id != Guid.Empty)
            {
                return BadRequest();
            }


            var result = await _accountService.UpsertAccountAsync(userId, dto);

            if (result.Entity == null)
            {
                StringBuilder errorList = new StringBuilder();
                if (result.Errors != null)
                {
                    foreach (ErrorResponse error in result.Errors)
                    {
                        errorList.Append("Message: " + error.Message);
                        errorList.Append("; Code: " + error.Code);
                        errorList.Append("; ");
                    }
                    _telemetryClient.TrackTrace("WebApi Error: " + errorList.ToString());
                }

                return UnprocessableEntity(result.Errors);
            }

            // we successfully created account and user in db              
            // since all accounts use same storage acount all we need to do is create
            // the default storage containers for this account.
            // may need a process to tell UI in case of failures to retry
            // this is admin only for now and used internally to get things created
            // for Internal QA users.  We'll revisit to handle errors
            try
            {
                await _azureStorageService.CreateDefaultStorageContainers(result.Entity.Id);
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch
#pragma warning restore CA1031 // Do not catch general exception types
            {
                result.Entity.Error = "Error creating storage account"; // TODO. What format we want this error field to be? string vs json array
                result = await _accountService.UpsertAccountAsync(userId, result.Entity);
                throw; // throw for now so we can see it
            }

            // will return created, even if the storage account creation failed, client should inspect error for this case                    
            return CreatedAtAction(nameof(GetById), new { id = result.Entity.Id }, result);
        }

        /// <summary>
        /// Update account
        /// </summary>
        /// <remarks>
        /// Update account used by sys-admin only
        /// </remarks>
        /// <param name="id"></param>
        /// <param name="update"></param>
        /// <returns></returns>
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AccountDetailtDto))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateAsync(Guid id, [FromBody] AccountDetailtDto update)
        {
            var userId = this.User.GetUserId();

            // no claims tranformation yet, we need to pull user from db
            var hasAccess = await _userService.ValidateSysAdminAccess(userId);
            if (!hasAccess)
            {
                return StatusCode(StatusCodes.Status403Forbidden);
            }

            if (id != update.Id)
            {
                return BadRequest();
            }

            var result = await _accountService.UpsertAccountAsync(userId, update);
            if (result.Entity == null)
                return UnprocessableEntity(result.Errors);
            return Ok(result);
        }

        /// <summary>
        /// Update account theme
        /// </summary>
        /// <remarks>
        /// Update account theme
        /// </remarks>
        /// <param name="id"></param>
        /// <param name="theme"></param>
        /// <returns></returns>
        [HttpPut("{id}/themes/{theme}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AccountBrandUpdateResponseDto))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateThemeAsync(Guid id, string theme)
        {
            var userId = this.User.GetUserId();
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            if (id != accountId)
            {
                return StatusCode(StatusCodes.Status403Forbidden);
            }

            var result = await _accountService.UpdateThemeAsync(userId, accountId, theme);
            return Ok(result);
        }

        /// <summary>
        /// Update account federated domain
        /// </summary>
        /// <param name="id"></param>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPut("{id}/federation")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UpsertResponse<FederatedDomainDto>))]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> SaveFederatedDomain(Guid id, [FromBody] FederatedDomainDto dto)
        {
            var userId = this.User.GetUserId();
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var sessionId = this.Request.GetB2CSessionId();

            if (id != accountId)
            {
                return StatusCode(StatusCodes.Status403Forbidden);
            }

            var result = await _accountService.SaveFederatedDomainAsync(accountId, userId, sessionId, dto);
            return Ok(result);
        }

        /// <summary>
        /// Bulk delete federated domains
        /// </summary>
        /// <param name="id"></param>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("{id}/federation/deletes")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UpsertResponse<IEnumerable<Guid>>))]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> DeleteFederatedDomains(Guid id, [FromBody] BulkDeleteRequestDTO dto)
        {
            var userId = this.User.GetUserId();
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var sessionId = this.Request.GetB2CSessionId();

            if (id != accountId)
            {
                return StatusCode(StatusCodes.Status403Forbidden);
            }

            var result = await _accountService.DeleteFederatedDomainsAsync(accountId, userId, sessionId, dto);
            return Ok(result);
        }

    }
}
