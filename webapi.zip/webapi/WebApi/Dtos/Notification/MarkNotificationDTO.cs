﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace WebApi.Dtos.Notification
{
    public class MarkNotificationDTO
    {

        [JsonPropertyName("ids")]
        public List<Guid> Ids { get; set; }

        [JsonPropertyName("markAsRead")]
        public bool MarkAsRead { get; set; }
    }
}
