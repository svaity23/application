import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { filter, first, map, tap, withLatestFrom } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AppStoreFacade } from '@app/store/app-store/app-store.facade';
import { EulaStoreFacade } from '@app/store/eula-store/eula-store.facade';
import { RoleKey } from '../enums/role-key.enum';

@Injectable({
  providedIn: 'root'
})
export class EulaGuard implements CanActivate {

  public loading: Observable<boolean>;
  public notAccepted: Observable<boolean>;

  constructor(private appStoreFacade: AppStoreFacade, private eulaStoreFacade: EulaStoreFacade, private router: Router) { }

  canActivate(
    // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
    _route: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
    _state: RouterStateSnapshot): Observable<boolean | UrlTree> {

    return this.isViewer()
      .pipe(
        withLatestFrom(this.hasAcceptedEula()),
        map(([isViewer, hasAcceptedEula]) => {
          if (!isViewer || hasAcceptedEula) {
            return true;
          }
          if (isViewer && !hasAcceptedEula) {
            return this.router.parseUrl('/eula');
          }
        })
      );
  }

  private hasAcceptedEula(): Observable<boolean | UrlTree> {
    return this.eulaStoreFacade.eulaState$.pipe(
      tap(state => {
        if (!state.loaded) {
          this.appStoreFacade.loadContext();
        }
      }),
      filter(state => state.loaded),
      map(state => {
        const legalsToAccept = state.legalDocuments.length;
        // console.log(legalsToAccept + ' legal document(s) to accept');
        return legalsToAccept === 0;
      })
    );
  }

  private isViewer(): Observable<boolean> {
    return this.appStoreFacade.context.context$.pipe(
      tap(context => {
        if (!context) {
          this.appStoreFacade.loadContext();
        }
      }),
      filter(context => context != null),
      first(),
      map(context => context.roleKey === RoleKey.viewer)
    );
  }
}