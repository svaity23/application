import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { ControlContainer, NgForm } from '@angular/forms';

import { AssetSyncError } from '@app/core/models/hubspot/asset-sync-error.model';
import { HUBSPOT_CREDENTIALS_SETTINGS_KEY } from '@app/core/constants/frontend-setting-key';
import { HubspotCredentials } from '@app/core/models/hubspot/hubspot-credentials.model';
import { HubspotSyncStatus } from '@app/core/models/hubspot/hubspot-sync-status.model';
import { Setting } from '@app/core/models/setting.model';
import { SyncError } from '@app/core/models/hubspot/sync-error.model';

@Component({
  selector: 'app-hubspot-configuration-content',
  templateUrl: './hubspot-configuration-content.component.html',
  styleUrls: ['./hubspot-configuration-content.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class HubspotConfigurationContentComponent implements OnInit, OnChanges {
  @Input() accountSettings: Setting[];
  @Input() hubspotSyncStatus: HubspotSyncStatus;
  isHubspotConnected = false;
  @Output() signinToHubspotEvent = new EventEmitter();

	constructor() { }

  getErrorDescription(error: SyncError): string {
    if (error.code) {
      switch (error.code) {
        case 42:
          return 'Sync in progress'
        case 100:
          return 'Waiting for synchronization'
        case 400:
          return 'Bad Request'
        case 401:
          return 'Unauthorized'
        case 403:
          return 'Forbidden'
        case 404:
          return 'Not Found'
        case 405:
          return 'Method Not Allowed'
        case 406:
          return 'Not Acceptable'
        case 408:
          return 'Request Timeout'
        case 409:
          return 'Conflict'
        default:
          return error.description
      }
    }

    return 'Sync in progress';
  }

  getThumbnail(assetSyncError: AssetSyncError): string {
    return assetSyncError?.assetUris?.thumbnail;
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (changes.accountSettings) {
      this.refreshHubspotConnectionStatus();
    }
  }

  ngOnInit(): void {
    this.refreshHubspotConnectionStatus();
  }

  refreshHubspotConnectionStatus(): void {
    const setting = this?.accountSettings?.find(n => n.key === HUBSPOT_CREDENTIALS_SETTINGS_KEY);
    if (setting && setting.stringValue && setting.stringValue.length > 0) {
      const hubspotCredentials: HubspotCredentials = JSON.parse(setting.stringValue);
      if (hubspotCredentials.token) {
        this.isHubspotConnected = true;
        return;
      }
    }

    this.isHubspotConnected = false;
  }
}
