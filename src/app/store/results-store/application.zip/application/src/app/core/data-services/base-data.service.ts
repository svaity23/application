import { HttpClient, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Injectable, Injector } from '@angular/core';

import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';

import * as LocalStorageKey from '@app/core/constants/local-storage-keys'
import { APP_CONFIG, AppConfig } from '@app/app-config';

// import { AppInjectorService } from '../services/app-injector.service';

@Injectable({
  providedIn: 'root'
})
export class BaseDataService {
  protected appSettings: AppConfig;
	protected downloadApiUrl: string;
  protected http: HttpClient;
  protected uploadApiUrl: string;
  protected webApiUrl: string;

  constructor(private injector: Injector) {
    this.appSettings = this.injector.get(APP_CONFIG);
    this.http = this.injector.get(HttpClient);

		this.downloadApiUrl = this.appSettings?.downloadApiUrl;
		this.uploadApiUrl = this.appSettings?.uploadApiUrl;
    this.webApiUrl = this.appSettings?.webApiUrl;
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/member-ordering
  protected createApiDelete = ({ url = '', options = {}, params = {} }: { url: string, options?: any, params?: any }): Observable<any> => {
    options = this.buildOptions(options, params);
    return this.http
      .delete(url, options)
      .pipe(catchError(this.handleError));
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/member-ordering
  protected createApiGet = ({ url = '', options = {}, params = {} }: { url: string, options?: any, params?: any }): Observable<any> => {
    options = this.buildOptions(options, params);
    return this.http
      .get(url, options)
      .pipe(catchError(this.handleError));
  }

	// eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/member-ordering
	protected createAnonApiGet = ({ url = '', options = {}, params = {} }: { url: string, options?: any, params?: any }): Observable<any> => {
		const o = options || {};
    if (params) {
      o.params = params;
    }
		return this.http
			.get(url, o)
			.pipe(catchError(this.handleError));
	}

  // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/member-ordering
  protected createApiPost = ({ url = '', options = {}, params = {}, data = {} }: { url: string, options?: any, params?: any, data?: any }): Observable<any> => {
    options = this.buildOptions(options, params);
    return this.http
      .post(url, data, options)
      .pipe(catchError(this.handleError));
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/member-ordering
  protected createAnonApiPost = ({ url = '', options = {}, data = {} }: { url: string, options?: any, params?: any, data?: any }): Observable<any> => {
    return this.http
      .post(url, data, options)
      .pipe(catchError(this.handleError));
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/member-ordering
  protected createApiPostStream = ({ url = '', options = {}, params = {}, data = {} }: { url: string, options?: any, params?: any, data?: any }): Observable<HttpResponse<any>> => {
    options = this.buildOptions(options, params);
    return this.http
      .post<HttpResponse<Blob>>(url, data, { params, responseType: 'blob' as 'json', observe: 'response'})
      .pipe(catchError(this.handleError));
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/member-ordering
  protected createApiPut = ({ url = '', options = {}, params = {}, data = {} }: { url: string, options?: any, params?: any, data?: any }): Observable<any> => {
		options = this.buildOptions(options, params);
    return this.http
      .put(url, data, options)
      .pipe(catchError(this.handleError));
  }

  protected handleError = (err: HttpErrorResponse): Observable<never> => {
    console.log(err.message || 'Server error');
    return throwError(err);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  protected mergeData = (data: any, params: any) => {
    Object.assign(data, data, params);
    return data;
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private buildOptions = (options?: any, params?: any): any => {
    // TODO: this may be temp. before implementing one user multiple accounts. Just trying to send accountId to webApi
    const accountId = window.localStorage.getItem(LocalStorageKey.SELECTED_ACCOUNT_ID) ?? '';

    // get everthing nice and neat in one options map
    const o = options || {};
    if (params) {
      o.params = params;
    }
    o.headers = {
      accountId
    };
    const lcid = '1033'; // TODO: change to user lcid
    o.headers = this.mergeData({ 'X-LCID': lcid }, o.headers || {});
    return o;
  }
}
