﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ApplicationLogic.DomainModel
{
    [Table("setting")]
    [Index(nameof(AccountIdCriteria), nameof(Key), nameof(Active), Name = "ix_setting_accountIdCriteria")]
    [Index(nameof(RoleIdCriteria), nameof(Key), nameof(Active), Name = "ix_setting_roleIdCriteria")]
    [Index(nameof(UserIdCriteria), nameof(Key), nameof(Active), Name = "ix_setting_userIdCriteria")]
    [Index(nameof(Key), nameof(AccountIdCriteria), nameof(RoleIdCriteria), nameof(UserIdCriteria), Name = "uniq_setting_key_accountId", IsUnique = true)]
    public partial class Setting
    {
        [Key]
        [Column("id")]
        public Guid Id { get; set; }
        [Required]
        [Column("key")]
        [StringLength(64)]
        public string Key { get; set; }
        [Column("externalId")]
        [StringLength(64)]
        public string ExternalId { get; set; }
        [Column("accountId")]
        public Guid AccountId { get; set; }
        [Column("active")]
        public bool Active { get; set; }
        [Column("created")]
        public DateTime Created { get; set; }
        [Column("modified")]
        public DateTime? Modified { get; set; }
        [Column("type")]
        public Guid Type { get; set; }
        [Column("frontEnd")]
        public bool FrontEnd { get; set; }
        [Column("accountIdCriteria")]
        public Guid? AccountIdCriteria { get; set; }
        [Column("roleIdCriteria")]
        public Guid? RoleIdCriteria { get; set; }
        [Column("userIdCriteria")]
        public Guid? UserIdCriteria { get; set; }
        [Column("boolValue")]
        public bool? BoolValue { get; set; }
        [Column("stringValue")]
        public string StringValue { get; set; }
        [Column("intValue")]
        public int? IntValue { get; set; }
        [Column("dateValue")]
        public DateTime? DateValue { get; set; }

        [ForeignKey(nameof(AccountId))]
        [InverseProperty("SettingAccount")]
        public virtual Account Account { get; set; }
        [ForeignKey(nameof(AccountIdCriteria))]
        [InverseProperty("SettingAccountIdCriteriaNavigation")]
        public virtual Account AccountIdCriteriaNavigation { get; set; }
        [ForeignKey(nameof(RoleIdCriteria))]
        [InverseProperty(nameof(Role.Setting))]
        public virtual Role RoleIdCriteriaNavigation { get; set; }
        [ForeignKey(nameof(UserIdCriteria))]
        [InverseProperty(nameof(User.Setting))]
        public virtual User UserIdCriteriaNavigation { get; set; }
    }
}
