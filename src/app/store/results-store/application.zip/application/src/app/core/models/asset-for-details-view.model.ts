import { AssetAttachment } from './asset-attachment.model';
import { AssetRevisions } from './asset-revisions.model';
import { AssetUris } from './asset-uris.model';
import { AssetViewState } from './view-states/asset-view-state.model';

export interface AssetForDetailsView {
    assetRevisions?: AssetRevisions[];
    assetUris: AssetUris;
    attachment: AssetAttachment;
    collectionId: string;
    collectionName?: string;
    created: Date;
    createdByUserFullName: string;
    description: string;
    expired?: boolean;
    expireOn?: Date;
    favorite?: boolean;
    fileExtension: string;
    fileGroupType: number;
    fileName: string;
    fileSize: string;
    fileType: string;
    id: string;
    lightboxIds?: string[];
    mediaType?: string; // for html5 video/audio elements
    modified: Date;
    modifiedByUserFullName: string;
    name: string;
    secondaryCollectionId?: string;
    secondaryCollectionName?: string;
    viewState?: AssetViewState;
}
