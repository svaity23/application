﻿using System;

namespace WebApi.Dtos.Canva
{
    public class CanvaStateDto
    {
        public string State { get; set; }
    }
}
