export interface FederatedDomain {
    id?: string;
    domain: string;
    active: boolean | false;
}
