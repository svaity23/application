﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using WebApi.Dtos;
using WebApi.Services;
using WebApiTests.Shared;

namespace WebApiTests.Services
{
    [TestClass]
    public class DBGroupServiceTest
    {
        private static readonly Guid TEST_ACCOUNT = Guid.Parse("5189526F-642F-449F-B018-5F5027A7191B"); // marcel@saguaro.ro

        #region [Click to open] Test initialization and configuration...
        const string TEST_GROUP_PREFIX = "MSTest-group-";
        const string GROUP_DESCRIPTION = "This is a sample group";
        const string LOREM_IPSUM = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, " +
            "sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad " +
            "minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea " +
            "commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit " +
            "esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat " +
            "non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";
        private static damContext dbContext;
        private static List<UserDetailDto> _testUsers;
        private static UserDetailDto adminUser;
        private static UserDetailDto contributorUser;
        private static UserDetailDto viewerUser;
        private static readonly Random _rnd = new Random();
        private static readonly JsonSerializerOptions options = new JsonSerializerOptions()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            ReferenceHandler = ReferenceHandler.Preserve
        };


        [ClassInitialize]
        public static void BeforeClass(TestContext context)
        {
            Debug.WriteLine("Before all tests");
            dbContext = AzureSQLTools.InitializeDamContext();

            var loggerFactory = (ILoggerFactory)new LoggerFactory();
            sut = new GroupService(loggerFactory.CreateLogger<GroupService>(), dbContext);

            _testUsers = AzureSQLTools.GetAccountUsers(dbContext, TEST_ACCOUNT);
            adminUser = AzureSQLTools.GetTestUser(dbContext, "admin", TEST_ACCOUNT);
            contributorUser = AzureSQLTools.GetTestUser(dbContext, "contributor", TEST_ACCOUNT);
            viewerUser = AzureSQLTools.GetTestUser(dbContext, "viewer", TEST_ACCOUNT);

            _userLogic = new UserLogic(dbContext);

            // Prepare something in the list of groups already defined
            AddGroup(adminUser);
            AddGroup(adminUser);
            AddGroup(adminUser);
        }

        private static GroupDto AddGroup(UserDetailDto usingUser, string suffix = "", string description = null)
        {
            GroupDto group = new GroupDto()
            {
                Id = Guid.Empty,
                Name = $"{TEST_GROUP_PREFIX}{_rnd.Next(0, 9999)}{suffix}",
                Description = (description == null ? GROUP_DESCRIPTION : description),
                Active = true,
                AccountId = usingUser.AccountId
            };

            UpsertResponse<GroupDto> result = 
                sut.SaveGroupAsync((Guid)usingUser.AccountId, usingUser.Id, group).Result;
            // It failed from duplicate error or something else...
            if (result == null 
                || result.Errors.Length < 1
                || result.Errors[0].Code != 0
                || result.Entity == null) return null;

            GroupDto ret = result.Entity;
            return ret;
        }

        private static GroupDto[] GetGroups(UserDetailDto usingUser)
        {
            // Make sure the get group returns content for admin like users
            GetEntitiesResponse<GroupDto> result = 
                sut.GetAllGroupsAsync((Guid)usingUser.AccountId, usingUser.Id).Result;
            if (result == null
                || result.Error.Code != 0
                || result.Entities == null) return null;

            return result.Entities.ToArray();
        }

        [ClassCleanup]
        public static void AfterClass()
        {
            Debug.WriteLine("Clean up after all tests");
            List<Group> groupsToClean = 
                dbContext.Group.Where(g => g.Name.StartsWith(TEST_GROUP_PREFIX)).ToList();
            foreach (Group g in groupsToClean)
            {
                var x = sut.DeleteGroupAsync((Guid)adminUser.AccountId, adminUser.Id, g.Id).Result;
            }
                
            dbContext.SaveChanges();
            dbContext.Dispose();
        }

        [TestInitialize]
        public void BeforeTest()
        {
            Debug.WriteLine("...Prepare test");
        }

        [TestCleanup]
        public void AfterTest()
        {
            Debug.WriteLine("...Clear test\n");
        }
        #endregion

        // sut - Service Under Test
        private static GroupService sut;
        private static UserLogic _userLogic;
        private Guid _sessionId = Guid.NewGuid();


        [TestMethod("Retrieve all groups as an admin")]
        public void GetAllGroups_Admin()
        {
            Assert.IsNotNull(adminUser); // Make sure we have a such user first ;-)

            // Make sure the get group returns content for admin like users
            GetEntitiesResponse<GroupDto> result = 
                sut.GetAllGroupsAsync((Guid)adminUser.AccountId, adminUser.Id).Result;
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Error);
            Assert.AreEqual<int>(0, result.Error.Code);

            Assert.IsNotNull(result.Entities);
            Assert.IsTrue(result.Entities.Count > 0);
        }

        [TestMethod("Retrieve all groups as a non-admin")]
        public void GetAllGroups_NonAdmin()
        {
            Assert.IsNotNull(viewerUser); // Make sure we have a such user first ;-)
            GetEntitiesResponse<GroupDto> result = 
                sut.GetAllGroupsAsync((Guid)viewerUser.AccountId, viewerUser.Id).Result;
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Error);
            Assert.AreEqual<int>(3, result.Error.Code); // forbidden

            Assert.IsNotNull(contributorUser);
            result = 
                sut.GetAllGroupsAsync((Guid)contributorUser.AccountId, contributorUser.Id).Result;
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Error);
            Assert.AreEqual<int>(3, result.Error.Code); // forbidden
        }

        [TestMethod("Add group - basic flow")]
        public void AddGroup_SimpleCase()
        {
            Assert.IsNotNull(adminUser); // Make sure we have a such user first ;-)

            GroupDto group = new GroupDto()
            {
                Id = Guid.Empty,
                Name = $"{TEST_GROUP_PREFIX}{_rnd.Next(0, 999)}",
                Description = GROUP_DESCRIPTION,
                Active = true,
                AccountId = adminUser.AccountId
            };
            UpsertResponse <GroupDto> result = 
                sut.SaveGroupAsync((Guid)adminUser.AccountId, adminUser.Id, group).Result;
            // Let's test the response from the database 
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Errors);
            Assert.IsTrue(result.Errors.Length > 0);
            Assert.AreEqual<int>(0, result.Errors[0].Code); // ok

            Assert.IsNotNull(result.Entity);
            Assert.AreNotEqual(Guid.Empty, result.Entity.Id);
        }

        [TestMethod("Add a group with very large name")]
        public void AddGroup_VeryLargeNameAndDescription()
        {
            GroupDto g = AddGroup(adminUser, LOREM_IPSUM, LOREM_IPSUM);
            Assert.IsNotNull(g);
            Assert.AreNotEqual(Guid.Empty, g.Id);
        }

        [TestMethod("Add a group with NULL description")]
        public void AddGroup_NullDescription()
        {
            GroupDto group = new GroupDto()
            {
                Id = Guid.Empty,
                Name = $"{TEST_GROUP_PREFIX}{_rnd.Next(0, 999)}",
                Description = null,
                Active = true,
                AccountId = adminUser.AccountId
            };
            UpsertResponse<GroupDto> result =
                sut.SaveGroupAsync((Guid)adminUser.AccountId, adminUser.Id, group).Result;

            // Let's test the response from the database 
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Errors);
            Assert.IsTrue(result.Errors.Length > 0);
            Assert.AreEqual<int>(0, result.Errors[0].Code); // ok

            Assert.IsNotNull(result.Entity);
            Assert.AreNotEqual(Guid.Empty, result.Entity.Id);
        }

        [TestMethod("Add a group without a name")]
        public void AddGroup_NullName()
        {
            GroupDto group = new GroupDto()
            {
                Id = Guid.Empty,
                Name = null,
                Description = null,
                Active = true,
                AccountId = adminUser.AccountId
            };
            try
            {
                UpsertResponse<GroupDto> result =
                    sut.SaveGroupAsync((Guid)adminUser.AccountId, adminUser.Id, group).Result;
                Assert.IsNotNull(result);
                Assert.IsNotNull(result.Errors);
                Assert.IsTrue(result.Errors.Length > 0);
                Assert.AreEqual<int>(1, result.Errors[0].Code);

            }
            catch (AggregateException) 
            { 

            }
        }

        [TestMethod("Update a group that does not exists")]
        public void UpdateGroup_NonExistingGroup()
        {
            // Is important to keep the prefix, so the clean up can work
            string newName = $"{TEST_GROUP_PREFIX}{_rnd.Next(0, 999)}-updateNonExisting";
            string newDescription = $"Update on descriptions-{_rnd.Next(0, 999)}";

            GroupDto groupDto = new GroupDto()
            {
                Id = Guid.NewGuid(),
                Name = newName,
                Description = newDescription,
                AccountId = adminUser.AccountId,
                Active = true
            };
            UpsertResponse<GroupDto> result =
                sut.SaveGroupAsync((Guid)adminUser.AccountId, adminUser.Id, groupDto).Result;
            // Let's test the response from the database 
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Errors);
            Assert.IsTrue(result.Errors.Length > 0);
            Assert.AreEqual<int>(1, result.Errors[0].Code);
        }

        [TestMethod("Update a group with name and description")]
        public void UpdateGroup_VeryLargeNameAndDescription()
        {
            GroupDto g = AddGroup(adminUser);
            Assert.IsNotNull(g);
            Assert.AreNotEqual(Guid.Empty, g.Id);

            // Is important to keep the prefix, so the clean up can work
            string newName = $"{TEST_GROUP_PREFIX}{_rnd.Next(0, 999)}-updated";
            string newDescription = $"Update on descriptions-{_rnd.Next(0, 999)}";

            GroupDto groupDto = new GroupDto()
            {
                Id = g.Id,
                Name = newName,
                Description = newDescription,
                AccountId = g.AccountId,
                Active = true
            };
            UpsertResponse<GroupDto> result =
                sut.SaveGroupAsync((Guid)adminUser.AccountId, adminUser.Id, groupDto).Result;

            // Let's test the response from the database 
            Assert.IsNotNull(result);

            Assert.IsNotNull(result.Errors);
            Assert.IsTrue(result.Errors.Length > 0);
            Assert.AreEqual<int>(0, result.Errors[0].Code);

            Assert.IsNotNull(result.Entity);

            Assert.AreNotEqual(Guid.Empty, result.Entity.Id);
            Assert.AreEqual(g.Id, result.Entity.Id);
            Assert.AreEqual(newName, result.Entity.Name);
            Assert.AreEqual(newDescription, result.Entity.Description);
        }


        [TestMethod("Delete a group")]
        public void DeleteOneGroup()
        {
            GroupDto g = AddGroup(adminUser);
            Assert.IsNotNull(g);
            Assert.AreNotEqual(Guid.Empty, g.Id);

            UpsertResponse<List<Guid>> result =
                sut.DeleteGroupAsync((Guid)adminUser.AccountId, adminUser.Id, g.Id).Result;
            // Let's test the response from the database 
            Assert.IsNotNull(result);

            Assert.IsNotNull(result.Errors);
            Assert.IsTrue(result.Errors.Length > 0);
            Assert.AreEqual<int>(0, result.Errors[0].Code);

            Assert.IsNotNull(result.Entity);
            Assert.AreEqual<int>(1, result.Entity.Count);

            Assert.AreEqual<Guid>(result.Entity[0], g.Id);

            GroupDto[] activeGroups = GetGroups(adminUser);
            foreach(GroupDto activeGroup in activeGroups)
            {
                Assert.AreNotEqual<Guid>(activeGroup.Id, g.Id);
            }
        }

        [TestMethod("Delete multiple groups with one call")]
        public void DeleteBulkGroups()
        {
            GroupDto a = AddGroup(adminUser);
            GroupDto b = AddGroup(adminUser);
            GroupDto c = AddGroup(adminUser);
            Assert.IsNotNull(a);
            Assert.IsNotNull(b);
            Assert.IsNotNull(c);
            BulkDeleteRequestDTO bulkGroups = new BulkDeleteRequestDTO()
            {
                Ids = new Guid[]{ a.Id, b.Id, c.Id }
            };
            UpsertResponse<List<Guid>> result =
                sut.BulkDeleteGroupsAsync((Guid)adminUser.AccountId, adminUser.Id, bulkGroups).Result;
            // Let's test the response from the database 
            Assert.IsNotNull(result);

            Assert.IsNotNull(result.Errors);
            Assert.IsTrue(result.Errors.Length > 0);
            Assert.AreEqual<int>(0, result.Errors[0].Code);

            Assert.IsNotNull(result.Entity);
            Assert.AreEqual<int>(3, result.Entity.Count);

            GroupDto[] activeGroups = GetGroups(adminUser);
            foreach (GroupDto activeGroup in activeGroups)
            {
                Assert.AreNotEqual(activeGroup.Id, a.Id);
                Assert.AreNotEqual(activeGroup.Id, b.Id);
                Assert.AreNotEqual(activeGroup.Id, c.Id);
            }
        }


        [TestMethod("Delete a group assigned to a user")]
        public void DeleteGroup_UserIsWithoutGroupId()
        {
            // Create a new group to test with...
            GroupDto g = AddGroup(adminUser);

            // Assign the new group to the contributor user account and save it.
            User forUser = new User()
            {
                Id = adminUser.Id,
                FirstName = adminUser.FirstName,
                LastName = adminUser.LastName,
                Email = adminUser.Email,
                RoleId = adminUser.RoleId,
                AccountId = adminUser.AccountId,
                GroupId = g.Id
            };


            string jsonUser = JsonSerializer.Serialize<User>(forUser);
            string jsonUpdateUser = _userLogic.UpdateUserAsync(adminUser.Id, (Guid)adminUser.AccountId, _sessionId, jsonUser).Result;
            Assert.IsNotNull(jsonUpdateUser);
            User x = JsonSerializer.Deserialize<User>(jsonUpdateUser, options);
            Assert.AreEqual(g.Id, x.GroupId);

            // Remove the group
            UpsertResponse<List<Guid>> result =
                sut.DeleteGroupAsync((Guid)adminUser.AccountId, adminUser.Id, g.Id).Result;
            Assert.IsNotNull(result);

            Assert.IsNotNull(result.Errors);
            Assert.IsTrue(result.Errors.Length > 0);
            Assert.AreEqual<int>(0, result.Errors[0].Code);

            Assert.IsNotNull(result.Entity);
            Assert.AreEqual<int>(1, result.Entity.Count);

            Assert.AreEqual<Guid>(g.Id, result.Entity[0]);

            // Check the user now, after group delete 
            User checkUser = _userLogic.GetUserByIdAsync(adminUser.Id).Result;
            Assert.IsNotNull(checkUser);
            Assert.IsNull(checkUser.GroupId);

        }
    }
}