import { CustomTheme } from '../custom-theme.model';

export interface HubspotConfigurationModalOptions {
  selectedTheme?: CustomTheme;
  title: string;
}
