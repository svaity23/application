using ApplicationLogic.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using System;
using System.IO;
using System.Net.Mime;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Dtos;
using WebApi.Dtos.Asset.Request;
using WebApi.Dtos.Zapier;
using WebApi.Enums;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class UploadController : ControllerBase
    {
        private readonly ILogger<UploadController> _logger;
        private readonly UploadService _uploadService;
        private readonly IGoogleServiceFactory _googleServiceFactory;
        private readonly IDropboxServiceFactory _dropboxServiceFactory;
        private readonly IOneDriveServiceFactory _oneDriveServiceFactory;
        private readonly UserAccountService _userAccountService;
        private readonly AssetService _assetService;

        public UploadController(ILogger<UploadController> logger, UploadService uploadService, IGoogleServiceFactory googleServiceFactory, IDropboxServiceFactory dropboxServiceFactory, IOneDriveServiceFactory oneDriveServiceFactory, UserAccountService userAccountService, AssetService assetService)
        {
            _logger = logger;
            _uploadService = uploadService;
            _googleServiceFactory = googleServiceFactory;
            _dropboxServiceFactory = dropboxServiceFactory;
            _oneDriveServiceFactory = oneDriveServiceFactory;
            _userAccountService = userAccountService;
            _assetService = assetService;
        }

        /// <summary>
        /// Upload account logo
        /// </summary>
        /// <returns></returns>
        [HttpPost("logo")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AccountBrandUpdateResponseDto))]
        public async Task<IActionResult> UploadLogo()
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var boundary = HeaderUtilities.RemoveQuotes(MediaTypeHeaderValue.Parse(HttpContext.Request.ContentType).Boundary).Value;
            var formReader = new MultipartReader(boundary, HttpContext.Request.Body);

            var result = await _uploadService.ProcessLogoFileUploadAsync(formReader, accountId, userId);
            return Ok(result);
        }

        /// <summary>
        /// Delete account logo
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <returns></returns>
        [HttpDelete("logo")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AccountBrandUpdateResponseDto))]
        public async Task<IActionResult> ResetToDefaultLogo()
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var result = await _uploadService.ResetToDefaultLogo(accountId, userId);
            return Ok(result);
        }

        /// <summary>
        /// Upload account favicon
        /// </summary>
        /// <returns></returns>
        [HttpPost("favicon")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AccountBrandUpdateResponseDto))]
        public async Task<IActionResult> UploadFavicon()
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var boundary = HeaderUtilities.RemoveQuotes(MediaTypeHeaderValue.Parse(HttpContext.Request.ContentType).Boundary).Value;
            var formReader = new MultipartReader(boundary, HttpContext.Request.Body);

            var updatedFavicon = await _uploadService.ProcessFaviconFileUploadAsync(formReader, accountId, userId);
            return Ok(updatedFavicon);
        }

        /// <summary>
        /// Delete account favicon
        /// </summary>
        /// <returns></returns>
        [HttpDelete("favicon")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AccountBrandUpdateResponseDto))]
        public async Task<IActionResult> ResetToDefaultFavicon()
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var result = await _uploadService.ResetToDefaultFavicon(accountId, userId);
            return Ok(result);
        }

        /// <summary>
        /// Upload file from google drive
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("googleFile")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> UploadGoogleFile([FromBody] GoogleUploadRequest request)
        {
            try
            {
                if (!string.IsNullOrEmpty(request.AccessToken) && !string.IsNullOrEmpty(request.GoogleFileId))
                {
                    var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);

                    var service = _googleServiceFactory.CreateGoogleDriveService(request.AccessToken);
                    await _uploadService.UploadGoogleFile(Response, service, request, accountId);
                    await Response.CompleteAsync();

                    return Ok();
                }
                else
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "No Access token");
                }
            }
            catch (BadHttpRequestException ex)
            {
                _logger.LogWarning(ex, "BadHttpRequest");

                // Incase we can't gaurantee that BadHttpRequestException has a StatusCode of Status413PayloadTooLarge...
                // Check for it here and return appropriate status code.
                // This scenario should not really occur. The validateAndCreate sproc should reject files that are too large and this 
                // request should not occur.
                if (ex.StatusCode == StatusCodes.Status413PayloadTooLarge)
                {
                    return StatusCode(StatusCodes.Status413PayloadTooLarge);
                }

                // Let error pass threw and have ExceptionHandlerMiddleware handle it.
                throw;
            }
            catch (IOException ioEx)
            {
                // Upload cancelled.
                _logger.LogWarning(ioEx, "Upload cancelled");
                return StatusCode(StatusCodes.Status200OK);
            }

        }

        /// <summary>
        /// Upload file from dropbox
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("dropboxFile")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> UploadDropboxFile([FromBody] DropboxUploadRequest request)
        {
            try
            {
                if (!string.IsNullOrEmpty(request.DropboxLink))
                {
                    var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);

                    var service = _dropboxServiceFactory.CreateDropboxService();
                    await _uploadService.UploadDropboxFile(Response, service, request, accountId);
                    await Response.CompleteAsync();

                    return Ok();
                }
                else
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "No Access token");
                }
            }
            catch (BadHttpRequestException ex)
            {
                _logger.LogWarning(ex, "BadHttpRequest");

                // Incase we can't gaurantee that BadHttpRequestException has a StatusCode of Status413PayloadTooLarge...
                // Check for it here and return appropriate status code.
                // This scenario should not really occur. The validateAndCreate sproc should reject files that are too large and this 
                // request should not occur.
                if (ex.StatusCode == StatusCodes.Status413PayloadTooLarge)
                {
                    return StatusCode(StatusCodes.Status413PayloadTooLarge);
                }

                // Let error pass threw and have ExceptionHandlerMiddleware handle it.
                throw;
            }
            catch (IOException ioEx)
            {
                // Upload cancelled.
                _logger.LogWarning(ioEx, "Upload cancelled");
                return StatusCode(StatusCodes.Status200OK);
            }

        }

        /// <summary>
        /// Upload file from one drive
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("oneDriveFile")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> UploadOneDriveFile([FromBody] OneDriveUploadRequest request)
        {
            try
            {
                if (!string.IsNullOrEmpty(request.OneDriveLink))
                {
                    var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);

                    var service = _oneDriveServiceFactory.CreateOneDriveService();
                    await _uploadService.UploadOneDriveFile(Response, service, request, accountId);
                    await Response.CompleteAsync();

                    return Ok();
                }
                else
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "No Access token");
                }
            }
            catch (BadHttpRequestException ex)
            {
                _logger.LogWarning(ex, "BadHttpRequest");

                // Incase we can't gaurantee that BadHttpRequestException has a StatusCode of Status413PayloadTooLarge...
                // Check for it here and return appropriate status code.
                // This scenario should not really occur. The validateAndCreate sproc should reject files that are too large and this 
                // request should not occur.
                if (ex.StatusCode == StatusCodes.Status413PayloadTooLarge)
                {
                    return StatusCode(StatusCodes.Status413PayloadTooLarge);
                }

                // Let error pass threw and have ExceptionHandlerMiddleware handle it.
                throw;
            }
            catch (IOException ioEx)
            {
                // Upload cancelled.
                _logger.LogWarning(ioEx, "Upload cancelled");
                return StatusCode(StatusCodes.Status200OK);
            }

        }

        [HttpGet]
        [AllowAnonymous]
        [ApiExplorerSettings(IgnoreApi = true)]
        public IActionResult UploadGet()
        {
            string successMsg = $@"
               ******************************************************
               * /upload hit at {DateTime.Now}                      
               ******************************************************";
            //_logger.LogDebug(successMsg);
            return Content(successMsg);
            // return StatusCode(StatusCodes.Status200OK);
        }

        [HttpGet("log")]
        [AllowAnonymous]
        [ApiExplorerSettings(IgnoreApi = true)]
        public IActionResult Log()
        {
            string successMsg = $@"
                ******************************************************
                * /upload/***LOG*** hit at {DateTime.Now}                      
                ******************************************************";
            _logger.LogInformation(successMsg);
            return Content(successMsg);
        }

        /// <summary>
        /// Create an asset from zapier app like dropbox. The information from zapier should match ZapAssetDto format.
        /// </summary>
        /// <remarks>        
        /// </remarks>
        /// <param name="zapAsset"></param>
        /// <returns></returns>
        [HttpPost("zapier")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status413PayloadTooLarge)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> CreateZapierAsset(ZapAssetDto zapAsset)
        {
            _logger.LogInformation($"Zapier-Dropbox received request {zapAsset.ToJsonString()}");
            
            // 1. create the asset into the database
            var fileGroup = FileTypes.GetFileGroup(zapAsset.FileExt);
            if (fileGroup < 0) return new UnsupportedMediaTypeResult();

            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            AssetUploadRequestDto[] assets =
            {
                new AssetUploadRequestDto
                {
                    Id = Guid.NewGuid(),
                    UploadSessionId = Guid.NewGuid(),
                    FileGroup = fileGroup,
                    FileSize = zapAsset.FileSize,
                    FileName = $"{zapAsset.Name}{zapAsset.FileExt}"
                }
            };
            var response = await _uploadService.ValidateAndCreateAssets(accountId, userId, assets);
            var createdAsset = response[0];
            if (createdAsset.Error != null && createdAsset.Error.Length > 0)
            {
                return BadRequest(createdAsset);
            }

            _logger.LogInformation($"Zapier-Dropbox created asset in database {createdAsset.ToJsonString()}");

            // 2. upload the asset file in azure storage
            var dropboxRequest = new DropboxUploadRequest
            {
                AssetId = createdAsset.Id,
                DropboxLink = zapAsset.ShareLink,
                FileGroup = $"{createdAsset.FileGroup}",
                FileName = createdAsset.FileName,
                FileSizeBytes = (long)createdAsset.FileSize,
                SignalRConnectionId = Guid.Empty.ToString(),
                Source = "UPLOAD",
                UploadSessionId = (Guid)createdAsset.UploadSessionId
            };

            try
            {
                if (!string.IsNullOrEmpty(dropboxRequest.DropboxLink))
                {
                    var service = _dropboxServiceFactory.CreateDropboxService();
                    await _uploadService.UploadZapierDropboxFile(service, dropboxRequest, accountId);
                }
                else
                {
                    createdAsset.Error = new[] {
                        new ErrorResponse
                        {
                            Code = 10,
                            Message = "Invalid access file URL!"
                        }
                    };
                    return StatusCode(StatusCodes.Status500InternalServerError, createdAsset);
                }
            }
            catch (BadHttpRequestException ex)
            {
                _logger.LogWarning(ex, "BadHttpRequest");

                // Incase we can't gaurantee that BadHttpRequestException has a StatusCode of Status413PayloadTooLarge...
                // Check for it here and return appropriate status code.
                // This scenario should not really occur. The validateAndCreate sproc should reject files that are too large and this 
                // request should not occur.
                if (ex.StatusCode == StatusCodes.Status413PayloadTooLarge)
                {
                    createdAsset.Error = new[] {
                        new ErrorResponse
                        {
                            Code = 10,
                            Message = "Source file to large for Azure Blob"
                        }
                    };
                    return StatusCode(StatusCodes.Status413PayloadTooLarge, createdAsset);
                }

                // Let error pass threw and have ExceptionHandlerMiddleware handle it.
                throw;
            }
            _logger.LogInformation($"Zapier-Dropbox asset file uploaded in Azure Storage");

            // 3. assign asset to a collection
            var sessionId = this.Request.GetB2CSessionId();
            Guid collId;
            if (!string.IsNullOrEmpty(zapAsset.CollectionId) && Guid.TryParse(zapAsset.CollectionId, out collId))
            {
                UpdateCollectionRequestDTO updateCollectionRequest = new UpdateCollectionRequestDTO
                {
                    CollectionId = collId,
                    Ids = new []
                    {
                        createdAsset.Id
                    }
                };
                var resAssign = await _assetService.UpdateAssetsWithCollectionIdAsync(accountId, updateCollectionRequest, userId, sessionId);
                _logger.LogInformation($"Zapier-Dropbox assign asset to Collection: "+resAssign.ToJsonString());
            }

            // 4. Finally, activate the asset
            var finishUploadSessionRequest = new FinishUploadSessionRequestDto
            {
                UploadSessionId = (Guid) createdAsset.UploadSessionId,
                AssetIds = new [] {createdAsset.Id.ToString()}
            };
            var activateResponse = await _assetService.FinishUploadSessionAsync(accountId, finishUploadSessionRequest, userId, sessionId);
            _logger.LogInformation($"Zapier-Dropbox activated asset {activateResponse.ToJsonString()}");

            if (activateResponse.Updates.Length > 0 && activateResponse.Updates[0].Errors != null && activateResponse.Updates[0].Errors.Length > 0)
            {
                createdAsset.Error = activateResponse.Updates[0].Errors;
                return BadRequest(createdAsset);
            }

            return Ok(createdAsset);
        }


        /// <summary>
        /// Validate and create assets
        /// </summary>
        /// <remarks>        
        /// </remarks>
        /// <param name="assets"></param>
        /// <returns></returns>
        [HttpPost("assets")]
        [ApiExplorerSettings(IgnoreApi = false)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AssetValidateCreateResponseDto[]))]
        public async Task<IActionResult> ValidateAndCreateAssets(AssetUploadRequestDto[] assets)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var response = await _uploadService.ValidateAndCreateAssets(accountId, userId, assets);
            return Ok(response);
        }

        /// <summary>
        /// Validate and create asset for revision
        /// </summary>
        /// <param name="assetDto"></param>
        /// <param name="oldAssetId"></param>
        /// <returns></returns>
        [HttpPost("assetRevision/{oldAssetId}")]
        [ApiExplorerSettings(IgnoreApi = false)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AssetValidateReplaceResponseDto[]))]
        public async Task<IActionResult> ValidateAndReplaceAsset([FromBody] AssetRevisionRequestDto assetDto, Guid oldAssetId)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();
            var result = await _uploadService.ValidateAndReplaceAsset(accountId, userId, sessionId, assetDto, oldAssetId);
            return Ok(result);
        }

        /// <summary>
        /// Cancel upload session
        /// </summary>
        /// <remarks>
        /// Sends a request to cancel and clean up asset upload session
        /// </remarks>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("cancellation")]
        [Consumes(MediaTypeNames.Application.Json)]
        public async Task<IActionResult> Cancel([FromBody] CancelUploadDto dto)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            await _uploadService.CancelUploadAsync(accountId, dto.UploadSessionId);
            return Ok(dto);
        }
    }
}
