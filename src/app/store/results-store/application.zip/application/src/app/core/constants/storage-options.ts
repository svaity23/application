import { KeyValuePair } from '../models/key-value-pair.model';

export const STORAGE_OPTIONS_GB: KeyValuePair[] = [
    { key: '5 GB', value: '5' },
    { key: '250 GB', value: '250' },
    { key: '500 GB', value: '500' },
    { key: '1 TB', value: '1000' },
    { key: '2 TB', value: '2000' },
    { key: '3 TB', value: '3000' },
    { key: '4 TB', value: '4000' },
    { key: '5 TB', value: '5000' },
    { key: '6 TB', value: '6000' },
    { key: '7 TB', value: '7000' },
    { key: '8 TB', value: '8000' },
    { key: '9 TB', value: '9000' },
    { key: '10 TB', value: '10000' }
  ];