import { ChangeDetectionStrategy, Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Observable } from 'rxjs';

import { AccountRoleStoreFacade } from '@app/store/account-store/account-role-store.facade';
import { AccountUserStoreFacade } from '@app/store/account-store/account-user-store.facade';
import { AppGroupStoreFacade } from '@app/store/app-store/app-group-store.facade';
import { AppStoreFacade } from '@app/store/app-store/app-store.facade';
import { Context } from '@app/core/models/context.model';
import { Group } from '@app/core/models/entities/group.model';
import { Role } from '@app/core/models/entities/role.model';
import { User } from '@app/core/models/entities/user.model';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UsersComponent implements OnInit {
  accountTypeName$: Observable<string>;
  activeUsers$: Observable<User[]>;
  context$: Observable<Context>;
  includeInactiveUsers$: Observable<boolean>;
  includeInactiveUsersChecked = false;
  roles$: Observable<Role[]>;
  searchText$: Observable<string>;
  selectedActiveUsers$: Observable<User[]>;
  selectedUsers$: Observable<User[]>;
  showIntegrations$: Observable<boolean>;
  showUserGroups$: Observable<boolean>;
  userGroups$: Observable<Group[]>;
  users$: Observable<User[]>;

  private userToDelete: User;

  constructor(
    private appStoreFacade: AppStoreFacade,
    private accountRoleStoreFacade: AccountRoleStoreFacade,
    private accountUserStoreFacade: AccountUserStoreFacade,
    private appGroupStoreFacade: AppGroupStoreFacade) { }

  addUser(): void {
    this.appStoreFacade.evaluateAndOpenUnverifiedTrialAccountModal(
      () => { this.appStoreFacade.navigate('account/users/new') },
      () => { }
    );
  }

  downloadUsers(): void {
    this.accountUserStoreFacade.downloadAllUsers();
  }

  editUser(user: User): void {
    this.accountUserStoreFacade.setSelectedUserId(user.id);
    this.appStoreFacade.navigate(`/account/users/${user.id}`);
  }

  filterUsers(searchText: string): void {
    if (searchText !== null) {
      this.accountUserStoreFacade.filterUsers(searchText);
    }
  }

  navigateTo(pageName: string): void {
    this.accountUserStoreFacade.clearState();
    this.appStoreFacade.navigate(`account/${pageName}`);
  }

  ngOnInit(): void {
    this.appStoreFacade.setPageTitle('Users | MarcomGather');
    this.accountTypeName$ = this.appStoreFacade.accountTypeName$;
    this.activeUsers$ = this.accountUserStoreFacade.activeUsers$;
    this.context$ = this.appStoreFacade.context.context$;
    this.includeInactiveUsers$ = this.accountUserStoreFacade.includeInactiveUsers$;
    this.roles$ = this.accountRoleStoreFacade.roles$;
    this.searchText$ = this.accountUserStoreFacade.searchText$;
    this.selectedActiveUsers$ = this.accountUserStoreFacade.selectedActiveUsers$;
    this.selectedUsers$ = this.accountUserStoreFacade.selectedUsers$;
    this.showIntegrations$ = this.appStoreFacade.showIntegrations$;
    this.showUserGroups$ = this.appStoreFacade.context.isUserGroupsFeatureEnabled$;
    this.userGroups$ = this.appGroupStoreFacade.groups$;
    this.users$ = this.accountUserStoreFacade.users$;
    this.accountUserStoreFacade.loadUsers();
  }

  openConfirmationModal(user: User): void {
    this.userToDelete = user;
    this.accountUserStoreFacade.openConfirmationModal({
      title: 'Delete Users',
      message: 'Are you sure? This action cannot be undone.',
      confirmButtonText: 'Delete',
      denyButtonText: 'Cancel',
      confirm: this.delete,
      deny: () => { },
      confirmButtonIcon: 'trash'
    });
  }

  openConfirmationModalToAssignGroups(event: { selectedUsers: User[], userGroups: Group[] }): void {
    this.accountUserStoreFacade.openAssignGroupsModal({
      selectedUsers: event.selectedUsers,
      userGroups: event.userGroups,
      title: 'Assign Group',
      confirmButtonText: 'Assign',
      denyButtonText: 'Cancel',
      confirm: () => { this.assignGroup() },
      deny: () => { }
    });
  }

  openConfirmationModalToInactivateUsers(): void {
    this.accountUserStoreFacade.openConfirmationModal({
      title: 'Inactivate User(s)',
      message: 'Are you sure? The user(s) will no longer be able to login.',
      confirmButtonText: 'Save',
      denyButtonText: 'Cancel',
      confirm: this.inactivateUsers,
      deny: () => { },
      confirmButtonIcon: 'trash'
    });
  }

  openUploadUsersModal(): void {
    this.accountUserStoreFacade.openUploadUsersModal({
      title: 'Upload Users',
      confirmButtonText: 'Upload',
      confirm: () => {
        this.accountUserStoreFacade.uploadUsers();
      },
      cancelButtonText: 'Cancel',
      cancel: () => { }
    });
  }

  setIncludeInactiveUsers(isIncludeInActiveChecked: boolean): void {
    this.includeInactiveUsersChecked = isIncludeInActiveChecked;
    this.accountUserStoreFacade.setIncludeInactiveUsers(isIncludeInActiveChecked);
  }

  setUsersSelected(selected: boolean): void {
    this.accountUserStoreFacade.setUsersSelected(selected);
  }

  toggleUserSelected(user: User): void {
    this.accountUserStoreFacade.toggleUserSelected(user);
  }

  verifyTrialAndOpenUploadUsersModal(): void {
    this.appStoreFacade.evaluateAndOpenUnverifiedTrialAccountModal(
      () => { this.openUploadUsersModal() },
      () => { }
    );
  }

  private assignGroup = () => {
    this.accountUserStoreFacade.assignGroupToUsers();
  }

  private delete = () => {
    this.accountUserStoreFacade.setSelectedUserId(this.userToDelete.id);
    this.accountUserStoreFacade.deleteUser();
  }
  private inactivateUsers = () => {
    this.accountUserStoreFacade.bulkInactivate();
  }
}
