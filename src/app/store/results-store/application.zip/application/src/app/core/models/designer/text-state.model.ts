export interface TextState {
    fontSize?: number;
    fontStyle?: string;
    foregroundColor?: string;
}