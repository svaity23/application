import { ErrorResponse } from './error-response';

export interface UpsertEntityResponse<T> {
    entity: T;
    errors: ErrorResponse[];
}
