﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WebApi.Dtos.Search
{
    public class Asset
    {
        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [JsonPropertyName("externalId")]
        public string ExternalId { get; set; }

        [JsonPropertyName("accountId")]
        public Guid AccountId { get; set; }

        [JsonPropertyName("created")]
        public DateTime Created { get; set; }

        [JsonPropertyName("modified")]
        public DateTime? Modified { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("description")]
        public string Description { get; set; }

        [JsonPropertyName("displayName")]
        public string DisplayName { get; set; }

        [JsonPropertyName("fileName")]
        public string FileName { get; set; }

        [JsonPropertyName("fileExtension")]
        public string FileExtension { get; set; }

        [JsonPropertyName("fileSize")]
        public long? FileSize { get; set; }

        [JsonPropertyName("fileGroup")]
        public int FileGroup { get; set; }

        [JsonPropertyName("uploadSessionId")]
        public Guid UploadSessionId { get; set; }

        [JsonPropertyName("createdBy")]
        public Guid? CreatedBy { get; set; }

        [JsonPropertyName("createdByUserFullName")]
        public string CreatedByUserFullName { get; set; }

        [JsonPropertyName("lastModifiedBy")]
        public Guid? LastModifiedBy { get; set; }

        [JsonPropertyName("modifiedByUserFullName")]
        public string ModifiedByUserFullName { get; set; }

        [JsonPropertyName("attachment")]
        public string Attachment { get; set; }

        [JsonPropertyName("collectionId")]
        public Guid CollectionId { get; set; }

        [JsonPropertyName("collectionName")]
        public string CollectionName { get; set; }

        [JsonPropertyName("parentCollectionId")]
        public Guid? ParentCollectionId { get; set; }

        [JsonPropertyName("parentCollectionName")]
        public string ParentCollectionName { get; set; }

        [JsonPropertyName("collectionIds")]
        public string[] CollectionIds { get; set; }

        [JsonPropertyName("favoriteUserIds")]
        public string[] FavoriteUserIds { get; set; }

        [JsonPropertyName("lightboxIds")]
        public string[] LightboxIds { get; set; }

        [JsonPropertyName("expireOn")]
        public DateTime? ExpireOn { get; set; }

        [JsonPropertyName("metadata")]
        public Metadata[] Metadata { get; set; }

        [JsonPropertyName("tags")]
        public string[] Tags { get; set; }

        [JsonPropertyName("ocrText")]
        public string OcrText { get; set; }

        public string[] Suggest { get; set; }

    }
}
