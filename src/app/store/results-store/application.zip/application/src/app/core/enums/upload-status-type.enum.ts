export enum UploadStatusType {
  Uploading,
  WaitingForThumbnail,
  ThumbnailReceived,
  HasError,
  ThumbnailReady
}
