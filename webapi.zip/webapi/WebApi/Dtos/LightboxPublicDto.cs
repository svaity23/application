﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace WebApi.Dtos
{
    public class LightboxPublicDto
    {
        [JsonPropertyName("accountLogo")]
        public string AccountLogo { get; set; }
        [JsonPropertyName("accountTheme")]
        public string AccountTheme { get; set; }
        [JsonPropertyName("id")]
        public Guid Id { get; set; }
        [JsonPropertyName("accountId")]
        public Guid? AccountId { get; set; }
        [JsonPropertyName("assetCount")]
        public int AssetCount { get; set; }
        [JsonPropertyName("name")]
        public string Name { get; set; }
        public List<LightboxAssetDto> Assets { get; set; }
        public Dictionary<string, string> SasTokens { get; set; }
        public string StorageAccountName { get; set; }
        [JsonPropertyName("expirationDate")]
        public DateTime? ExpirationDate { get; set; }
    }
}
