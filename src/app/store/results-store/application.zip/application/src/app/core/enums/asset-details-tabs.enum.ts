export enum AssetDetailsTabs {
    Comments = 'comments',
    Info = 'info',
    History = 'history'
 }
