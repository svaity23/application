﻿namespace SignalRHub.Messages
{
    public abstract class AbstractAssetMessageDTO
    {
        public AbstractAssetMessageDTO(string messageType, string assetId)
        {
            this.MessageType = messageType;
            this.AssetId = assetId;
        }

        public string MessageType { get; private set; }

        public string AssetId { get; private set; }
    }
}
