﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationLogic.Models
{
    public class UserModel
    {
        public Guid Id { get; set; }
        public string ExternalId { get; set; }
        public Guid? AccountId { get; set; }
        public bool Active { get; set; }
        public Guid? RoleId { get; set; }
        public Guid? GroupId { get; set; }
        public string RoleName { get; set; }
        public string RoleKey { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public bool EmailVerified { get; set; }
    }
}
