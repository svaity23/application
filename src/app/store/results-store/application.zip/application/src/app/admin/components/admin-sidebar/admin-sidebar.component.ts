import { ChangeDetectionStrategy, Component, EventEmitter, HostBinding, Output, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-admin-sidebar',
  templateUrl: './admin-sidebar.component.html',
  styleUrls: ['./admin-sidebar.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AdminSidebarComponent  {
  @Output() navigateToUtilitiesEvent = new EventEmitter();
  @HostBinding('attr.ngNoHost') noHost = '';

  constructor() { }

  navigateToUtilities(): void {
    this.navigateToUtilitiesEvent.emit();
  }
}
