﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace WebApi.Services
{
    public interface IDropboxServiceFactory
    {
        DropboxService CreateDropboxService();
    }

    public class DropboxServiceFactory : IDropboxServiceFactory
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<DropboxServiceFactory> _logger;
        private readonly ILoggerFactory _loggerFactory;
        private readonly bool _isDevelopment; 

        public DropboxServiceFactory(IConfiguration configuration, ILogger<DropboxServiceFactory> logger, ILoggerFactory loggerFactory, IWebHostEnvironment webHostEnvironment)
        {
            _configuration = configuration;
            _logger = logger;
            _loggerFactory = loggerFactory;
            _isDevelopment = webHostEnvironment.IsDevelopment();
        }

        public DropboxService CreateDropboxService()
        {
            var logger = _loggerFactory.CreateLogger<DropboxService>();

            return new DropboxService(_configuration, logger);
        }
    }
}
