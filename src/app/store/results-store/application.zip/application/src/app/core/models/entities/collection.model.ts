// import { CollectionViewState } from '../view-states/collection-view-state.model';
import { VisibleToType } from '@app/core/enums/visible-to-type.enum';

export interface Collection {
    assetCount: number | null;
    groupIds: string[] | null;
    hubspotAssetCount: number | null;
    id: string | null;
    isFavorited: boolean | false;
    name: string;
    parentId: string | null;
    visibleTo: VisibleToType;
    // view model properties
    // readonly viewState: CollectionViewState;
}
