﻿using System;

namespace WebApi.Dtos.Asset.DetailsView
{
    public class AssetForDetailsViewDto
    {
        public AttachmentDto Attachment { get; set; }
        public Guid? CollectionId { get; set; }
        public string CollectionName { get; set; }
        public DateTime Created { get; set; }
        public string CreatedByUserFullName { get; set; }
        public string Description { get; set; }
        //public string Error { get; set; } // TODO - add this back in once we do a cleanup to the data so it matches the correct objects in the database and client model.
        public bool Expired { get; set; }
        public DateTime? ExpireOn { get; set; }
        public bool? Favorite { get; set; }
        public string FileExtension { get; set; }
        public int FileGroupType { get; set; }
        public string FileName { get; set; }
        public long? FileSize { get; set; }
        public string FileType { get; set; }
        public Guid Id { get; set; }
        public Guid[] LightBoxIds { get; set; }
        public DateTime? Modified { get; set; }
        public string ModifiedByUserFullName { get; set; }
        public string Name { get; set; }
        public Guid? SecondaryCollectionId { get; set; }
        public string SecondaryCollectionName { get; set; }

    }
}
