export interface FileMetadataTag {
    name: string;
  }