﻿using System;

namespace SignalRHub.Messages
{
    public class NotificationAuthorDTO
    {
        public Guid AuthorId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
