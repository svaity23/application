﻿using ApplicationLogic;
using WebApi.Dtos;

namespace WebApi.Services
{
    public static class HelloWorldService
    {
        public static HelloWorldDto  GetGreeting()
        {
            var hellowWorld = new HelloWorld(){
                Greeting = "Hello from DAM web api!"
            };
            return new HelloWorldDto    
            {
                Greeting = hellowWorld.Greeting
            };
        }
    }
}
