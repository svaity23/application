using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Microsoft.Extensions.Configuration;
using Nest;
using System.Linq;
using UNIT_TEST = Microsoft.VisualStudio.TestTools.UnitTesting;
using WebApi.Dtos.Search;
using System.Collections.Generic;
using WebApi.Enums;
using System.Text.RegularExpressions;
using Azure.Security.KeyVault.Secrets;
using Azure.Identity;
using System.Globalization;

namespace WebApiTests
{
    [TestClass()]
    [UNIT_TEST.Ignore]
    public class SearchAssetsTest
    {
        private ElasticClient _elasticClient;
        private string _indexName;
        private Guid _accountId;

        private const string FILE_GROUP_AGG_NAME = "fileGroup";
        private const string FILE_SIZE_MAX_AGG_NAME = "fileSizeMax";
        private const string FILE_SIZE_MIN_AGG_NAME = "fileSizeMin";
        private const string METADATA_AGG_NAME = "metadata";
        private const string TAGS_AGG_NAME = "tags";
        private const string UPLOAD_DATE_AGG_NAME = "uploadDate";

        private const string DATE_FILTER_TYPE_ALL = "all";
        private const string DATE_FILTER_TYPE_TODAY = "today";
        private const string DATE_FILTER_TYPE_WEEK = "week";
        private const string DATE_FILTER_TYPE_MONTH = "month";

        [TestInitialize]
        public void Init()
        {
            // database settings
            var configuration = new ConfigurationBuilder()
                       .AddJsonFile("appsettings.json", true, true)
                       .Build();

            // Search settings
            var esUri = configuration["Elasticsearch:Uri"];
            string env = configuration["Elasticsearch:IndexEnvironment"];
            string index = configuration["Elasticsearch:Index"];
            string multiTenantIndex = configuration["Elasticsearch:MultiTenantIndex"];


            string vaultUri = configuration["KeyVault:Uri"];
            SecretClient secretClient = new SecretClient(new Uri(vaultUri), new DefaultAzureCredential());

            // hard to make this async because its called in constructor
            var secretElasticsearchApiKey = secretClient.GetSecretAsync(configuration["KeyVault:Secrets:ElasticsearchApiKey"]).Result;
            var secretElasticsearchApiKeyId = secretClient.GetSecretAsync(configuration["KeyVault:Secrets:ElasticsearchApiKeyId"]).Result;

            var apiKey = secretElasticsearchApiKey.Value.Value;
            var apiKeyId = secretElasticsearchApiKeyId.Value.Value;
            

            _accountId = Guid.Parse("DA3CCFB3-7DCA-41ED-87A6-E70BF8A139DE"); // svaity account id
            // _accountId = Guid.Parse("d3f62a7b-4996-4d3a-9533-6fc233b63c34"); // bem account id
            
            _indexName = $"{env}.{_accountId.ToString("D")}.{multiTenantIndex}";

            var settings = new ConnectionSettings(new Uri(esUri))
               .ApiKeyAuthentication(apiKeyId, apiKey)
               .ThrowExceptions(true);
            _elasticClient = new ElasticClient(settings);            
        }
        
        [TestMethod()]
        [UNIT_TEST.Ignore]
        public void SearchAllTest()
        {
            var responseIfIndexExist = _elasticClient.Indices.GetAsync(_indexName).Result;
            
            if (responseIfIndexExist.IsValid)
            {
                var response = _elasticClient.SearchAsync<Asset>().Result.Documents.ToList();
                Assert.IsTrue(response.Count > 0);
            }
        }

        [TestMethod()]
        [UNIT_TEST.Ignore]
        public void SuggestionTest()
        {
            string searchTerm = "nasa";
            int sortField = 0;
            Guid? collectionId = Guid.Parse("0C70A5DD-0D83-456C-89E4-C34A8A19C928"); // ed602a1f-aff4-4823-85c4-73d85308f089
            int skip = 0;
            int pageSize = 20;            
            var collectionIds = new List<string>();
            // collectionIds.Add("0C70A5DD-0D83-456C-89E4-C34A8A19C928");
            collectionIds.Add("all");
            // Build & run ES query with filters
            var searchResponse = _elasticClient.SearchAsync<Asset>(s => s
                .Index(_indexName)
                .Sort(ss => GetSearchAssetsSort(ss, (SortType)sortField))
                .From(skip)  
                .Size(pageSize)                
                .Suggest(ss => ss.
                    Completion("completion-suggest", c => c
                        .Prefix(searchTerm)                        
                        .Size(pageSize)                        
                        .Field("suggest")
                        .Fuzzy(f => f
                            .Fuzziness(Fuzziness.Auto) // Generates an edit distance based on the length of the term
                        )
                        .SkipDuplicates(true)
                        .Contexts(ctxs => ctxs // Contexts with categories are used to filter in suggestors
                            .Context("collectionIds",
                                collectionIds.   // Filter collections
                                Select<string, Func<SuggestContextQueryDescriptor<Asset>, ISuggestContextQuery>>(v => cd => cd.Context(v)).ToArray())
                        )
                    )
            ));

            var suggestions = searchResponse.Result
               .Suggest["completion-suggest"]
               .SelectMany(s => s.Options)
               .Select(ss => new
               {
                   document = ss.Source,
                   text = ss.Text,
                   display = ss.Text
               })
               .ToList();

            Assert.IsTrue(suggestions.Count > 0);           
        }
        
        [TestMethod()]
        [UNIT_TEST.Ignore]
        public void SearchByCollectionId()
        {
            int totalHits = 0;
            string searchTerm = "abel";
            int sortField = 0;            
            int skip = 0;
            int pageSize = 20;
            
            // Only collection id
            var boolFilters = new List<Func<QueryContainerDescriptor<Asset>, QueryContainer>>();
            string collectionId = "dc543b02-9125-496c-a713-e00c2cedbb00"; //"0bdd41f0-6c94-4c5f-b55c-ebaff47a77df"; //"dc543b02-9125-496c-a713-e00c2cedbb00";//"0c70a5dd-0d83-456c-89e4-c34a8a19c928";
            // collectionId = "0bdd41f0-6c94-4c5f-b55c-ebaff47a77df";

            //boolFilters.Add(f => f.Terms(t => t.Field(c => c.CollectionId).Terms(collectionId?.ToString()?.ToLower()))
            //    || f.Terms(t => t.Field(c => c.ParentCollectionId).Terms(collectionId?.ToString()?.ToLower())));
            //Func<QueryContainerDescriptor<Asset>, QueryContainer> aclSearch = descriptor => descriptor.Terms(r => r.Field(f => f.CollectionId).Terms(collectionId));
            //boolFilters.Add(aclSearch);
            boolFilters.Add(f => f.Terms(t => t.Field(c => c.CollectionId).Terms(collectionId)));

            // add metadata            
            var boolFiltersMetadata = new List<Func<QueryContainerDescriptor<Asset>, QueryContainer>>();
            boolFiltersMetadata.Add(f => f.Terms(t => t.Field("Metadata.Value.autocomplete").Terms(searchTerm)));

            // Build & run ES query with filters and paging
            var from = skip;
            var searchResponse = _elasticClient.SearchAsync<Asset>(s => s
                 .Index(_indexName)
                 .From(from)
                 .Size(pageSize) 
                 .Sort(ss => GetSearchAssetsSort(ss, (SortType)sortField))
                 .Query(q => q
                     .Bool(b => b
                         .Should(
                            dn => dn.Match(m => m.Field(f => f.DisplayName.Suffix("autocomplete")).Query(searchTerm)),
                            des => des.Match(m => m.Field(f => f.Description.Suffix("autocomplete")).Query(searchTerm)),
                            tag => tag.Match(m => m.Field("Tags.keyword").Query(searchTerm)),
                            met => met.Nested(n => n
                                     .Path(p => p.Metadata)
                                     .Query(nq => nq
                                         .Bool(nb => nb
                                             .Must(
                                                 boolFiltersMetadata
                                             )
                                         )
                                     )
                                 )
                             )
                         .Filter(boolFilters)
                         )
                     &&                    
                     q.QueryString(qd => qd.
                        Query(searchTerm)
                        .Fuzziness(Fuzziness.Auto)
                        .AllowLeadingWildcard()
                        .DefaultOperator(Operator.Or)
                        .Lenient()
                        .AnalyzeWildcard()
                        .Fields(fs => fs
                            .Field(p => p.DisplayName.Suffix("autocomplete"))
                            .Field(p => p.Description.Suffix("autocomplete"))
                         )
                     )
                 )
             );
           
            if (searchResponse.Result.IsValid)
            {
                totalHits = (int)searchResponse.Result.Total;
                var assets = new List<Asset>();
                //searchResponse.Result.Documents.
                foreach (var document in searchResponse.Result.Documents)
                {
                    assets.Add(document);
                }
                Assert.IsTrue(assets.Count > 0);
            }           
        }
                
        [TestMethod()]
        [UNIT_TEST.Ignore]
        public void FilterTagsSearchResultsTest()
        {
            int totalHits = 0;
            string searchTerm = "planes";
            int sortField = 0;
            int skip = 0;
            int pageSize = 20;
            var boolFilters = new List<Func<QueryContainerDescriptor<Asset>, QueryContainer>>();
            var tagValues = new string[] { "planes", "red" };
            var newTags = new List<string>();
            foreach(var tag in tagValues)
            {
                boolFilters.Add(f => f.Match(m => m.Field(mf => mf.Tags.Suffix("keyword")).Query(tag)));                               
            }
            // tagValues.Concat(newTags).ToArray();
            // boolFilters.Add(f => f.Terms(t => t.Field(c => c.Tags.Suffix("keyword")).Terms(tagValues)));
            // boolFilters.Add(f => f.Match(m => m.Field(mf => mf.Tags.Suffix("keyword")).Query("planes")));
            // boolFilters.Add(f => f.Match(m => m.Field(mf => mf.Tags.Suffix("keyword")).Query("red")));
            // boolFilters.Add(f => f.Terms(t => t.Field(c => c.Tags.Suffix("keyword")).Terms(newTags.ToArray())));
            // Build & run ES query with filters and paging                       
            var searchResponse = _elasticClient.SearchAsync<Asset>(s => s
                .Index(_indexName)
                .From(skip)
                .Size(pageSize)
                .Sort(ss => GetSearchAssetsSort(ss, (SortType)sortField))
                .Query(q =>
                    q.Bool(b => b
                        .Filter(
                                boolFilters
                               )
                        )
                    &&
                    q.Bool(b => b
                        .Should(
                            bs => bs.SimpleQueryString(d => d
                                        .Fields(fs => fs
                                                .Field(f => f.DisplayName)
                                                .Field(f => f.DisplayName.Suffix("autocomplete"))
                                                .Field(f => f.Description)
                                                .Field(f => f.Description.Suffix("autocomplete"))
                                                .Field(f => f.Tags)
                                                .Field(f => f.Tags.Suffix("autocomplete"))
                                        )
                                        .DefaultOperator(Operator.Or)
                                        .Query(searchTerm)
                                        .Lenient()
                                        .AnalyzeWildcard(true)
                            ),
                             bs => bs.Nested(bsn => bsn
                                         .Path(bsnp => bsnp.Metadata)
                                         .Query(bsnq => bsnq
                                             .Match(m => m
                                                 .Field(f => f.Metadata.Suffix("value.autocomplete"))
                                                 .Query(searchTerm)
                                             )
                                         )
                             )
                        )
                    )
                )
            );
            if (searchResponse.Result.IsValid)
            {
                totalHits = (int)searchResponse.Result.Total;
                var assets = new List<Asset>();
                foreach (var document in searchResponse.Result.Documents)
                {
                    assets.Add(document);
                }
                Assert.IsTrue(assets.Count > 0);
            }
        }
        
        [TestMethod()]
        [UNIT_TEST.Ignore]
        public void SearchAllAssets()
        {
            int totalHits = 0;
            string searchTerm = "abel";
            int sortField = 0;
            int skip = 0;
            int pageSize = 20;

            // add metadata            
            var boolFiltersMetadata = new List<Func<QueryContainerDescriptor<Asset>, QueryContainer>>();
            boolFiltersMetadata.Add(f => f.Terms(t => t.Field(ff => ff.Metadata.First().Value.Suffix("autocomplete")).Terms(searchTerm)));

            // q.Match(m => m.Field("Tags.keyword").Query(searchTerm))
            // Build & run ES query with filters and paging
            var from = skip;
            var searchResponse = _elasticClient.SearchAsync<Asset>(s => s
                .Index(_indexName)
                .From(from)
                .Take(pageSize) // or Size(pageSize)
                .Sort(ss => GetSearchAssetsSort(ss, (SortType)sortField))
                .Query(q => q
                    .Match(m => m.Field("Tags.keyword").Query(searchTerm))
                    ||
                    q.Nested(n => n
                            .Path(p => p.Metadata)
                            .Query(nq => nq
                                .Bool(nb => nb
                                    .Must(
                                        boolFiltersMetadata
                                    )
                                )
                            )
                        )
                    ||
                    q.QueryString(qd => qd.
                       Query(searchTerm)
                       .Fuzziness(Fuzziness.Auto)
                       .AllowLeadingWildcard()
                       .DefaultOperator(Operator.Or)
                       .Lenient()
                       .AnalyzeWildcard()
                       .Fields(fs => fs
                           .Field(p => p.DisplayName.Suffix("autocomplete"))
                           .Field(p => p.Description.Suffix("autocomplete"))
                        )
                    )
                )
            );

            if (searchResponse.Result.IsValid)
            {
                totalHits = (int)searchResponse.Result.Total;
                var assets = new List<Asset>();
                foreach (var document in searchResponse.Result.Documents)
                {
                    assets.Add(document);
                }
                Assert.IsTrue(assets.Count > 0);
            }
        }
        
        [TestMethod()]
        [UNIT_TEST.Ignore]
        public void FilterFileGroupSearchResultsTest()
        {
            int totalHits = 0;
            string searchTerm = "nasa"; //  "black"
            int sortField = 0;
            int skip = 0;
            int pageSize = 20;
            var boolFilters = new List<Func<QueryContainerDescriptor<Asset>, QueryContainer>>();

            //filegroup
            //boolFilters.Add(f => f.Term(t => t.Field(c => c.FileGroup).Value(5))); // searchTerm - "black"

            // fileSize
            // boolFilters.Add(f => f.Range(r => r.Field(f => f.FileSize).GreaterThanOrEquals(1662).LessThanOrEquals(98362)));
            boolFilters.Add(bf => bf.TermRange(dr => dr.Field(f => f.FileSize).GreaterThanOrEquals("1662")));
            boolFilters.Add(bf => bf.TermRange(dr => dr.Field(f => f.FileSize).LessThanOrEquals("21299")));

            // today            
            // boolFilters.Add(f => f.DateRange(t => t.Field(c => c.Created).GreaterThanOrEquals(DateMath.FromString("2021-01-12")).LessThanOrEquals(DateMath.Now)));

            //this week                            
            // boolFilters.Add(bf => bf.DateRange(dr => dr.Field(f => f.Created).GreaterThanOrEquals(DateMath.Now.RoundTo(DateMathTimeUnit.Week)).LessThanOrEquals(DateMath.Now.RoundTo(DateMathTimeUnit.Day))));

            // this month                           
            // boolFilters.Add(bf => bf.DateRange(dr => dr.Field(f => f.Created).GreaterThanOrEquals(DateMath.Now.RoundTo(DateMathTimeUnit.Month)).LessThanOrEquals(DateMath.Now.RoundTo(DateMathTimeUnit.Day))));


            // all time            
            boolFilters.Add(bf => bf.DateRange(dr => dr.Field(f => f.Created).GreaterThanOrEquals(DateMath.FromString("2020-01-01"))));

            // Build & run ES query with filters and paging                       
            var searchResponse = _elasticClient.SearchAsync<Asset>(s => s
                .Index(_indexName)
                .From(skip)
                .Size(pageSize)
                .Sort(ss => GetSearchAssetsSort(ss, (SortType)sortField))
                .Query(q =>
                    q.Bool(b => b
                        .Filter(
                                boolFilters
                               )
                        )
                    &&
                    q.Bool(b => b
                        .Should(
                            bs => bs.SimpleQueryString(d => d
                                        .Fields(fs => fs
                                                .Field(f => f.DisplayName)
                                                .Field(f => f.DisplayName.Suffix("autocomplete"))
                                                .Field(f => f.Description)
                                                .Field(f => f.Description.Suffix("autocomplete"))
                                                .Field(f => f.Tags)
                                                .Field(f => f.Tags.Suffix("autocomplete"))
                                        )
                                        .DefaultOperator(Operator.Or)
                                        .Query(searchTerm)
                                        .Lenient()
                                        .AnalyzeWildcard(true)
                            ),
                             bs => bs.Nested(bsn => bsn
                                         .Path(bsnp => bsnp.Metadata)
                                         .Query(bsnq => bsnq
                                             .Match(m => m
                                                 .Field(f => f.Metadata.Suffix("value.autocomplete"))
                                                 .Query(searchTerm)
                                             )
                                         )
                             )
                        )
                    )
                )
            );
            if (searchResponse.Result.IsValid)
            {
                totalHits = (int)searchResponse.Result.Total;
                var assets = new List<Asset>();
                foreach (var document in searchResponse.Result.Documents)
                {
                    assets.Add(document);
                }
                Assert.IsTrue(assets.Count > 0);
            }
        }

        [TestMethod()]
        [UNIT_TEST.Ignore]
        public void SearchAggregationTest()
        {
            int totalHits = 0;
            string searchTerm = "desserts";
           // int sortField = 0;
           // int skip = 0;
           // int pageSize = 20;

            var boolFilters = new List<Func<QueryContainerDescriptor<Asset>, QueryContainer>>();

            Guid.TryParse("63977233-3216-408a-91dc-79289092728c", out var collectionId);

            // filter collection and subcollections 
            if (collectionId != Guid.Empty)
            {
                boolFilters.Add(f => f.Terms(t => t.Field(c => c.CollectionId).Terms(collectionId.ToString()))
                || f.Terms(t => t.Field(c => c.ParentCollectionId).Terms(collectionId.ToString())));
            }
         

            // Build & run ES query with filters -- This must match the original Query in GetSearchResultsFromElasticsearchAsync
            var searchResponse = _elasticClient.SearchAsync<Asset>(s => s
                .Index(_indexName)
                .Size(0)
                .Query(q =>
                    q.Bool(b => b
                        .Filter(
                            boolFilters
                        )
                    )
                    &&
                    q.Bool(b => b
                        .Should(
                            bs => bs.QueryString(qd => qd.
                                        Query(searchTerm)
                                        .Fuzziness(Fuzziness.Auto)
                                        .AllowLeadingWildcard()
                                        .DefaultOperator(Operator.And)
                                        .Lenient()
                                        .AnalyzeWildcard()
                                        .Fields(fs => fs
                                            .Field(p => p.DisplayName)
                                            .Field(p => p.DisplayName.Suffix("autocomplete"))
                                        )
                            ),
                            bs => bs.QueryString(qd => qd.
                                        Query(searchTerm)
                                        .Fuzziness(Fuzziness.Auto)
                                        .AllowLeadingWildcard()
                                        .DefaultOperator(Operator.Or)
                                        .Lenient()
                                        .AnalyzeWildcard()
                                        .Fields(fs => fs
                                            .Field(p => p.Description.Suffix("autocomplete"))
                                        )
                            ),
                            bs => bs.Match(d => d
                                        .Field(f => f.Tags.Suffix("keyword"))
                                        .Query(searchTerm)

                            ),
                            bs => bs.Nested(bsn => bsn
                                        .Path(bsnp => bsnp.Metadata)
                                        .Query(bsnq => bsnq
                                            .Match(m => m
                                                .Field(f => f.Metadata.Suffix("value.autocomplete"))
                                                .Query(searchTerm)
                                            )
                                        )
                            )
                        )
                    )
                )
                .Aggregations(a => a
                    .Terms("tags", t => t
                        .Field(p => p.Tags.Suffix("keyword"))
                        .Size(50)
                    )
                    .Terms("fileGroup", t => t
                        .Field(p => p.FileGroup)
                        .Size(10)
                    )
                    .DateRange("uploadDate", dr => dr
                        .Field(p => p.Created)
                        .Ranges(
                            r => r.Key("today").From(DateMath.Now.RoundTo(DateMathTimeUnit.Day)),
                            r => r.Key("week").From(DateMath.Now.RoundTo(DateMathTimeUnit.Week)),
                            r => r.Key("month").From(DateMath.Now.RoundTo(DateMathTimeUnit.Month)),
                            r => r.Key("all").From(DateMath.FromString("2020-01-01"))
                        )
                    )
                    .Nested("metadata", n => n
                        .Path("metadata")
                        .Aggregations(na => na
                             //.Terms("metadataField", t => t.Field(p => p.Metadata.Suffix("metadataFieldId"))
                             //    .Aggregations(childAggs => childAggs
                             //        .Terms("metadataValues", avg => avg
                             //            .Field(p => p.Metadata.Suffix("value.keyword"))
                             //            .Size(20)
                             //        )
                             //    )
                             //)
                             //.Filters("metadataFields", fieldType => fieldType
                             //    .NamedFilters(filters => filters
                             //        .Filter("stringFields", f=>f.Term(p=> p.Metadata.Suffix("metadataFieldTypeId"), 0))
                             //        .Filter("dateFields", f => f.Term(p => p.Metadata.Suffix("metadataFieldTypeId"), 5))
                             //    )
                             //    .Aggregations(a => a
                             //        .Terms("metadataField", t => t.Field(p => p.Metadata.Suffix("metadataFieldId"))
                             //            .Aggregations(childAggs => childAggs
                             //                .Terms("metadataValues", avg => avg
                             //                    .Field(p => p.Metadata.Suffix("value.keyword"))
                             //                    .Size(20)
                             //                )
                             //            )
                             //        )
                             //    )
                             //)
                             .Filter("metadataFields", fieldType => fieldType
                                .Filter(f => f
                                    .Term(p => p.Metadata.Suffix("metadataFieldTypeId"), 0)
                                )
                                .Aggregations(a => a
                                    .Terms("metadataField", t => t.Field(p => p.Metadata.Suffix("metadataFieldId"))
                                        .Aggregations(childAggs => childAggs
                                            .Terms("metadataValues", avg => avg
                                                .Field(p => p.Metadata.Suffix("value.keyword"))
                                                .Size(20)
                                            )
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            );

            if (searchResponse.Result.IsValid)
            {
                totalHits = (int)searchResponse.Result.Total;

                var uploadDateAgg = searchResponse.Result.Aggregations.DateRange("uploadDate");
                var metadataAgg = searchResponse.Result.Aggregations.Nested("metadata");
                var tagAgg = searchResponse.Result.Aggregations.Terms("tags");
                var fileGroupAgg = searchResponse.Result.Aggregations.Terms("fileGroup");

                Assert.IsTrue(totalHits > 0);

            }
        }

        [TestMethod()]
        [UNIT_TEST.Ignore]
        public void GetSearchResponseAsync()
#pragma warning restore CA1801 // Review unused parameters
        {
            string searchTerm = "roadster";
            int sortField = 4;
            int skip = 0;
            int pageSize = 20;
            bool includeFilters = false;
            Guid? collectionId = null;
            FilterRequest[] filterRequests = null;


            var boolFilters = new List<Func<QueryContainerDescriptor<Asset>, QueryContainer>>();

            // filter collection and subcollections 
            if (collectionId != null)
            {
                boolFilters.Add(
                    f => f.Terms(t => t.Field(c => c.CollectionId).Terms(collectionId?.ToString()))
                    || f.Terms(t => t.Field(c => c.ParentCollectionId).Terms(collectionId?.ToString()))
                );
            }

            if (filterRequests != null)
            {
                boolFilters = BuildBoolFilters(filterRequests, boolFilters);
            }

            var queryShouldDescriptors = BuildSearchShouldFunctions(searchTerm);
            var aggregationFunctions = includeFilters ? BuildSearchAggregationFunctions() : new List<Func<AggregationContainerDescriptor<Asset>, IAggregationContainer>>();

            var searchResponse = _elasticClient.SearchAsync<Asset>(s => s
                .Index(_indexName)
                .From(skip)
                .Size(pageSize)
                .Sort(ss => GetSearchAssetsSort(ss, (SortType)sortField))
                .Query(q =>
                    q.Bool(b => b
                        .Filter(
                            boolFilters
                        )
                    )
                    &&
                    q.Bool(b => b
                        .Should(queryShouldDescriptors)
                    )
                )
                .Aggregations(a =>
                {
                    aggregationFunctions.ForEach(agg => agg(a));
                    return a;
                })
            );

            if (searchResponse.Result.IsValid)
            {
                var totalHits = (int)searchResponse.Result.Total;
                var assets = new List<Asset>();
                foreach (var document in searchResponse.Result.Documents)
                {
                    assets.Add(document);
                }
                Assert.IsTrue(assets.Count > 0);
            }
        }

        private static List<Func<QueryContainerDescriptor<Asset>, QueryContainer>> BuildBoolFilters(FilterRequest[] filterRequests, List<Func<QueryContainerDescriptor<Asset>, QueryContainer>> boolFilters)
        {
            if (filterRequests.Length > 0)
            {
                foreach (var filterRequest in filterRequests)
                {
                    var values = filterRequest.Values;
                    FilterGroupTypeEnum filterGroupType = filterRequest.FilterGroupType;
                    // FileGroup
                    if (filterGroupType == FilterGroupTypeEnum.FileGroup)
                    {
                        boolFilters.Add(f => f.Terms(t => t.Field(c => c.FileGroup).Terms(filterRequest.Values)));
                    }
                    // fileSize -  range
                    if (filterGroupType == FilterGroupTypeEnum.FileSize)
                    {
                        if (values[0].ToLower(CultureInfo.InvariantCulture).StartsWith("min"))
                        {
                            var minSize = values[0].Split(':')[1].Trim();
                            if (!string.IsNullOrEmpty(minSize))
                            {
                                boolFilters.Add(bf => bf.TermRange(dr => dr.Field(f => f.FileSize).GreaterThanOrEquals(minSize)));
                            }
                        }
                        if (values[1].ToLower(CultureInfo.InvariantCulture).StartsWith("max"))
                        {
                            var maxSize = values[1].Split(':')[1].Trim();
                            if (!string.IsNullOrEmpty(maxSize))
                            {
                                boolFilters.Add(bf => bf.TermRange(dr => dr.Field(f => f.FileSize).LessThanOrEquals(maxSize)));
                            }
                        }
                    }
                    // UploadDate
                    if (filterGroupType == FilterGroupTypeEnum.UploadDate)
                    {
                        if (values?.Length > 0)
                        {
                            var value = values[0].ToLower(CultureInfo.InvariantCulture).Trim();
                            switch (value)
                            {
                                case DATE_FILTER_TYPE_TODAY:
                                    boolFilters.Add(f => f.DateRange(t => t.Field(c => c.Created).GreaterThanOrEquals(DateMath.Now.RoundTo(DateMathTimeUnit.Day))));
                                    break;
                                case DATE_FILTER_TYPE_WEEK:
                                    boolFilters.Add(bf => bf.DateRange(dr => dr.Field(f => f.Created).GreaterThanOrEquals(DateMath.Now.RoundTo(DateMathTimeUnit.Week)).LessThanOrEquals(DateMath.Now.RoundTo(DateMathTimeUnit.Week))));
                                    break;
                                case DATE_FILTER_TYPE_MONTH:
                                    boolFilters.Add(bf => bf.DateRange(dr => dr.Field(f => f.Created).GreaterThanOrEquals(DateMath.Now.RoundTo(DateMathTimeUnit.Month)).LessThanOrEquals(DateMath.Now.RoundTo(DateMathTimeUnit.Month))));
                                    break;
                                case DATE_FILTER_TYPE_ALL:
                                    boolFilters.Add(bf => bf.DateRange(dr => dr.Field(f => f.Created).GreaterThanOrEquals(DateMath.FromString("2020-01-01"))));
                                    break;
                                default:
                                    break;
                            }
                        }

                        // custom - date range 
                        // values: [
                        //   'from:somedate',
                        //   'to:someotherdate'
                        // ] 
                        if (values?.Length > 1)
                        {
                            if (values[0].ToLower(CultureInfo.InvariantCulture).StartsWith("from"))
                            {
                                var fromDateValue = values[0].Split(':')[1];
                                if (!string.IsNullOrEmpty(fromDateValue))
                                {
                                    boolFilters.Add(bf => bf.DateRange(dr => dr.Field(f => f.Created).GreaterThanOrEquals(DateMath.FromString(fromDateValue.Trim()))));
                                }
                            }
                            if (values[1].ToLower(CultureInfo.InvariantCulture).StartsWith("to"))
                            {
                                var toDateValue = values[1].Split(':')[1];
                                if (!string.IsNullOrEmpty(toDateValue))
                                {
                                    boolFilters.Add(bf => bf.DateRange(dr => dr.Field(f => f.Created).LessThanOrEquals(DateMath.FromString(toDateValue.Trim()))));
                                }
                            }

                        }
                    }

                    // tags             
                    if (filterGroupType == FilterGroupTypeEnum.Tags)
                    {
                        foreach (var tag in filterRequest.Values)
                        {
                            boolFilters.Add(f => f.Match(m => m.Field(mf => mf.Tags.Suffix("keyword")).Query(tag)));
                        }
                    }
                    // Metadata 
                    if (filterGroupType == FilterGroupTypeEnum.Metadata)
                    {

                    }
                }
            }
            return boolFilters;
        }

        private static List<Func<QueryContainerDescriptor<Asset>, QueryContainer>> BuildSearchShouldFunctions(string searchTerm)
        {
            if (string.IsNullOrEmpty(searchTerm))
            {
                return new List<Func<QueryContainerDescriptor<Asset>, QueryContainer>>();
            }

            var queryShouldDescriptors = new List<Func<QueryContainerDescriptor<Asset>, QueryContainer>>();
            queryShouldDescriptors.Add(q => q
                .SimpleQueryString(d => d
                    .Fields(fs => fs
                            //.Field(f => f.DisplayName)
                            //.Field(f => f.DisplayName.Suffix("autocomplete"))
                            //.Field(f => f.Description)
                            //.Field(f => f.Description.Suffix("autocomplete"))
                            //.Field(f => f.FileExtension)
                            //.Field(f => f.FileName)
                            //.Field(f => f.FileName.Suffix("autocomplete"))
                            //.Field(f => f.Tags)
                            //.Field(f => f.Tags.Suffix("autocomplete"))
                            .Field(f => f.DisplayName, boost: 5)
                            .Field(f => f.DisplayName.Suffix("autocomplete"))
                            .Field(f => f.Description)
                            .Field(f => f.Description.Suffix("autocomplete"))
                            .Field(f => f.FileExtension)
                            .Field(f => f.FileName, boost: 2)
                            .Field(f => f.FileName.Suffix("autocomplete"))
                            .Field(f => f.Tags, boost: 4)
                            .Field(f => f.Tags.Suffix("autocomplete"))
                    )
                    .DefaultOperator(Operator.Or)
                    .Query(searchTerm)
                    .Lenient()
                    .AnalyzeWildcard(true)
                )
            );

            queryShouldDescriptors.Add(q => q
                .Nested(n => n
                    .Path(np => np.Metadata)
                        .Query(npq => npq
                            .Match(m => m
                                .Field(f => f.Metadata.Suffix("value.autocomplete"))
                                .Query(searchTerm)
                            )
                        )
                )
            );

            return queryShouldDescriptors;
        }
        private static List<Func<AggregationContainerDescriptor<Asset>, IAggregationContainer>> BuildSearchAggregationFunctions()
        {
            var aggregations = new List<Func<AggregationContainerDescriptor<Asset>, IAggregationContainer>>
            {
               a => a
                .Terms(FILE_GROUP_AGG_NAME, t => t
                    .Field(p => p.FileGroup)
                    .Size(10)
                ),
               a => a
                .Max(FILE_SIZE_MAX_AGG_NAME, m => m
                    .Field(p => p.FileSize)
                ),
               a => a
                .Min(FILE_SIZE_MIN_AGG_NAME, m => m
                            .Field(p => p.FileSize)
                ),
               a => a
                .DateRange(UPLOAD_DATE_AGG_NAME, dr => dr
                    .Field(p => p.Created)
                    .Ranges(
                        r => r.Key(DATE_FILTER_TYPE_TODAY).From(DateMath.Now.RoundTo(DateMathTimeUnit.Day)),
                        r => r.Key(DATE_FILTER_TYPE_WEEK).From(DateMath.Now.RoundTo(DateMathTimeUnit.Week)),
                        r => r.Key(DATE_FILTER_TYPE_MONTH).From(DateMath.Now.RoundTo(DateMathTimeUnit.Month)),
                        r => r.Key(DATE_FILTER_TYPE_ALL).From(DateMath.FromString("2020-01-01"))
                    )
                ),
               a => a
                .Terms(TAGS_AGG_NAME, t => t
                    .Field(p => p.Tags.Suffix("keyword"))
                    .Size(50)
                ),
               a => a
                .Nested(METADATA_AGG_NAME, n => n
                    .Path("metadata")
                    .Aggregations(na => na
                        .Terms("metadataField", t => t.Field(p => p.Metadata.Suffix("metadataFieldId"))
                            .Aggregations(childAggs => childAggs
                                .Terms("metadataValues", avg => avg
                                    .Field(p => p.Metadata.Suffix("value.keyword"))
                                    .Size(50)
                                )
                            )
                        )
                    )
                )
            };

            return aggregations;
        }


        private static SortDescriptor<Asset> GetSearchAssetsSort(SortDescriptor<Asset> s, SortType sortType)
        {
            switch (sortType)
            {
                case SortType.NameAscending:
                    return s.Field(f => f.Field("displayName.keyword").Order(SortOrder.Ascending).Missing(-1));
                case SortType.NameDescending:
                    return s.Field(f => f.Field("displayName.keyword").Order(SortOrder.Descending).Missing(-1));
                case SortType.CreatedDescending:
                    return s.Field(f => f.Field(p => p.Created).Order(SortOrder.Descending).Missing(-1));
                case SortType.ModifiedDescending:
                    return s.Field(f => f.Field(p => p.Modified).Order(SortOrder.Descending).Missing(-1));
                case SortType.Relevance:
                    return s.Descending(SortSpecialField.Score);
                default:
                    return s.Field(f => f.Field(p => p.Created).Order(SortOrder.Descending).Missing(-1));
            }
        }
    }
}
