import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { BaseDataService } from './base-data.service';

import { HubspotCollectionActionResponse } from '../models/api-responses/hubspot-collection-action-response';

export interface HubspotCollectionDataServiceInterface {
  collectionStopSyncToHubspot(collectionId: string): Observable<HubspotCollectionActionResponse>;
  collectionResyncToHubspot(collectionId: string): Observable<HubspotCollectionActionResponse>;
}

@Injectable({ providedIn: 'root' })
export class HubspotCollectionDataService extends BaseDataService implements HubspotCollectionDataServiceInterface {
  collectionResyncToHubspot(scollectionId: string): Observable<HubspotCollectionActionResponse> {
    const params = {
      collectionId: scollectionId
    };
    
    const url = `${this.webApiUrl}/hubspot/resync`;
    return this.createApiPost({ url, data: params });
  }

  collectionStopSyncToHubspot(scollectionId: string): Observable<HubspotCollectionActionResponse> {
    const params = {
      collectionId: scollectionId
    };
    
    const url = `${this.webApiUrl}/hubspot/stopsync`;
    return this.createApiPost({ url, data: params });
  }

}