import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { cn } from 'src/utils/cn';

import { Context } from '@app/core/models/context.model';
import { Group } from '@app/core/models/entities/group.model';
import { User } from '@app/core/models/entities/user.model';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UserListComponent implements OnInit, OnChanges {
  @Input() className = '';
  @Input() context: Context;
  @Output() editUserEvent = new EventEmitter<User>();
  includeInactive = false;
  @Output() includeInActiveEvent = new EventEmitter<boolean>();
  masterSelected = false;
  @Output() setMasterSelected = new EventEmitter<boolean>();
  show = false;
  @Input() showUserGroups = false;
  sortField = 'firstName';
  sortOrder = 'desc';
  @Input() userGroups: Group[];
  @Input() users: User[] = [];
  @Output() userSelected = new EventEmitter<User>();
  usersToDisplay: User[]; // we need this because we do a sort, and do not want to modify state itself

  constructor() { }

  editUser(user: User): void {
    this.editUserEvent.emit(user);
  }

  getGroupName(user: User): string {
    const group = this.userGroups.find(x => x.id.toLocaleLowerCase() === user.groupId?.toLocaleLowerCase());

    return (group && group.name) ? group.name : '';
  }

  getRoleName(user: User): string {
    let roleName;
    let accountOwnerSubTitle = '';
    // eslint-disable-next-line prefer-const
    roleName = user.roleName;
    if (user.email === this.context.accountUserEmail) {
      accountOwnerSubTitle = ' - Account Owner';
    }

    return roleName + accountOwnerSubTitle;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.users) {
      this.usersToDisplay = [...changes.users.currentValue];
      const userSelectedCount = this.usersToDisplay.filter((item) => {
        if (this.context.id.toLocaleLowerCase() !== item.id.toLocaleLowerCase() &&
          this.context.accountUserEmail?.toLocaleLowerCase() !== item.email.toLocaleLowerCase())
          return item.selected === true;
      }).length;

      const accountOwnerAndUser = [...changes.users.currentValue].filter((user) => {
        return (this.context.id.toLocaleLowerCase() === user.id.toLocaleLowerCase() ||
          this.context.accountUserEmail?.toLocaleLowerCase() === user.email.toLocaleLowerCase())
      })?.length;

      this.masterSelected = userSelectedCount === this.usersToDisplay.length - accountOwnerAndUser ?? true;

      if (!changes.users.isFirstChange()) {
        this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
        this.sort(this.sortField);
      }
    }
  }

  ngOnInit(): void {
    this.className = cn('user-list', this.className);
    this.sort('firstName');
  }

  selectUser(user: User): void {
    this.userSelected.emit(user);
  }

  sort(columnName: string): void {
    // toggle sort order if already selected
    if (this.sortField === columnName) {
      this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortField = columnName;
      this.sortOrder = 'asc';
    }

    // setup the evalution
    const v1 = this.sortOrder === 'asc' ? 1 : -1;
    const v2 = this.sortOrder === 'asc' ? -1 : 1;


    switch (this.sortField) {
      case 'lastName':
        this.usersToDisplay.sort((s1, s2) => s1.lastName.toLocaleLowerCase() > s2.lastName.toLocaleLowerCase() ? v1 : v2);
        break;
      case 'firstName':
        this.usersToDisplay.sort((s1, s2) => s1.firstName.toLocaleLowerCase() > s2.firstName.toLocaleLowerCase() ? v1 : v2);
        break;
      case 'email':
        this.usersToDisplay.sort((s1, s2) => s1.email.toLocaleLowerCase() > s2.email.toLocaleLowerCase() ? v1 : v2);
        break;
      case 'role':
        this.usersToDisplay.sort((s1, s2) => this.getRoleName(s1) > this.getRoleName(s2) ? v1 : v2); // need to modify this based on role name
        break;
      case 'group':
        this.usersToDisplay.sort((s1, s2) => this.getGroupName(s1).toLocaleLowerCase() > this.getGroupName(s2).toLocaleLowerCase() ? v1 : v2);
        break;
      case 'active':
        this.usersToDisplay.sort((s1, s2) => s1.active > s2.active ? v1 : v2);
        break;
      case 'lastLoginDate':
        this.usersToDisplay.sort((s1, s2) => s1.lastLoginDate > s2.lastLoginDate ? v1 : v2);
        break;
      default:
    }
  }

  toggleDropDown(): void {
    this.show = !this.show;
  }

  toggleIncludeInActiveChange(): void {
    this.includeInactive = !this.includeInactive;
    this.includeInActiveEvent.emit(this.includeInactive);
  }

  toggleMasterSelected(): void {
    this.setMasterSelected.emit(!this.masterSelected);
  }
}
