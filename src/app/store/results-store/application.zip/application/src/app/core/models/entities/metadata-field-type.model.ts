
export interface MetadataFieldType {
    id: number;
    name: string;
}
