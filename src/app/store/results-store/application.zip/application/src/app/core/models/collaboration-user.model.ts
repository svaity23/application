export interface CollaborationUser {
    email: string;
    firstName: string;
    id: string;
    lastName: string;
}
