import { Lightbox } from '../entities/lightbox.model';

export interface CopyLightboxUrlModalOptions {
    copy: (url: string) => void;
    copyButtonText: string;
    lightbox: Lightbox;
    setExpirationDate: (lightbox: Lightbox) => void;
    title: string;
    urlToCopy: string;
}
