
export interface AccordionCollection {
    assetCount: number | null;
    id: string | null;
    name: string;
    selected: boolean | false;
}
