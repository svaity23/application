import { ChangeDetectionStrategy, EventEmitter, HostBinding, SimpleChanges, ViewChild, ViewEncapsulation } from '@angular/core';
import { Component, Input, OnChanges, OnInit, Output } from '@angular/core';
import { ControlContainer, NgForm } from '@angular/forms';
import { DatePipe } from '@angular/common';

import { cn } from 'src/utils/cn';

import { ACCOUNT_TYPE_DEFAULT_STORAGE } from '@app/core/constants/account-type-default-storage';
import { AccountDetail } from '@app/core/models/entities/account-detail.model';
import { AccountTypeKey } from '@app/core/enums/account-type-key.enum';
import { KeyValuePair } from '@app/core/models/key-value-pair.model';
import { STORAGE_OPTIONS_GB } from '@app/core/constants/storage-options';

@Component({
  selector: 'app-account-form',
  templateUrl: './account-form.component.html',
  styleUrls: ['./account-form.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class AccountFormComponent implements OnInit, OnChanges {
  @Input() account: AccountDetail;
  @Output() accountChange: EventEmitter<AccountDetail> = new EventEmitter<AccountDetail>();
  @ViewChild('accountForm') accountForm: NgForm;
  @Output() accountFormChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  accountToModify: AccountDetail;
  accountTypeKeyEnum = AccountTypeKey;
  accountTypes: string[];
  checkBoxDisabled = false;
  @Input() className = '';
  dateCreated: string;
  datePipe = new DatePipe('en-US');
  formIsValidAndTouched = false;
  @HostBinding('attr.ngNoHost') noHost = '';
  selectedAccountType: number;
  selectedStorageMaxOptionIndex: number;
  storageMaxOptionKeys: string[];
  storageMaxOptionKeyValues: KeyValuePair[] = STORAGE_OPTIONS_GB;
  trialExpirationDateString: string;
  trialTypeSelected: boolean;

  private accountTypeDefaultMaxStorage: KeyValuePair[] = ACCOUNT_TYPE_DEFAULT_STORAGE;

  constructor() {
    this.accountTypes = Object.values(this.accountTypeKeyEnum);
    this.storageMaxOptionKeys = this.storageMaxOptionKeyValues.map(item => item.key);
  }

  accountActiveChange(): void {
    this.accountForm.form.markAsTouched();
    this.evaluateFormIsTouchedAndValid();
    this.accountToModify.active = !this.accountToModify.active;
    this.accountChange.emit(this.accountToModify);
  }

  accountTypeChange(selectedIndex: number): void {
    this.selectedAccountType = selectedIndex;
    this.accountForm.form.markAsTouched();
    this.evaluateFormIsTouchedAndValid();
    this.accountToModify.accountTypeName = (this.accountTypes[selectedIndex] as AccountTypeKey);
    this.trialTypeSelected = this.accountToModify.accountTypeName === this.accountTypeKeyEnum.Trial;

    const defaultMaxStorage = this.getStorageMaxDefault(this.accountToModify.accountTypeName);
    this.accountToModify.storageMaximumGb = defaultMaxStorage;
    this.setStorageMaxOptionIndex(this.accountToModify.storageMaximumGb);
    this.accountChange.emit(this.accountToModify);
  }

  accountValueChange(): void {
    this.accountForm.form.markAsTouched();
    this.evaluateFormIsTouchedAndValid();
    this.accountChange.emit(this.accountToModify);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.account) {
      if (changes.account.currentValue) {
        this.accountToModify = { ...changes.account.currentValue };
      }
      else {
        this.accountToModify = {
          active: true,
          created: null,
          id: null,
          name: null,
          accountTypeName: null,
          userId: null,
          userEmail: null,
          userFirstName: null,
          userLastName: null
        }
      }

      this.initUi();
    }
  }

  ngOnInit(): void {
    this.className = cn('account-details', this.className);
  }

  storageMaxValueChange(selectedIndex: number): void {
    this.selectedStorageMaxOptionIndex = selectedIndex; // need to make sure this changes
    this.accountForm.form.markAsTouched();
    this.evaluateFormIsTouchedAndValid();
    this.accountToModify.storageMaximumGb = Number(this.storageMaxOptionKeyValues[selectedIndex].value);
    this.accountChange.emit(this.accountToModify);
  }

  trialExpirationChange(inputDate: string): void {
    this.evaluateFormIsTouchedAndValid();
    this.accountToModify.trialExpiration = new Date(inputDate);
    this.trialExpirationDateString = inputDate;
    this.accountChange.emit(this.accountToModify);
  }

  private evaluateFormIsTouchedAndValid(): void {
    this.formIsValidAndTouched = this.accountForm.touched && this.accountForm.valid;
    this.accountFormChange.emit(this.formIsValidAndTouched);
  }

  private getStorageMaxDefault(accountTypeName: string): number {
    const defaultMaxStorage = this.accountTypeDefaultMaxStorage.find(k => k.key === accountTypeName);
    return defaultMaxStorage?.value;
  }

  private initUi() {
    this.selectedAccountType = Object.values(AccountTypeKey).indexOf(this.accountToModify.accountTypeName);
    this.trialTypeSelected = this.accountToModify.accountTypeName === this.accountTypeKeyEnum.Trial;
    this.setStorageMaxOptionIndex(this.accountToModify.storageMaximumGb);

    // Set default Trial Expiration to 30 days from today
    if (this.accountToModify.trialExpiration != null) {
      this.trialExpirationDateString = this.datePipe.transform(this.accountToModify.trialExpiration, 'M/d/yy');
    }
    else {
      const today = new Date();
      const futureDate = new Date(today.setDate(today.getDate() + 30));
      this.trialExpirationDateString = this.datePipe.transform(futureDate, 'M/d/yy');
      this.accountToModify.trialExpiration = futureDate;
    }
  }

  private setStorageMaxOptionIndex(selectedMaxStorageValue: number): void {
    this.selectedStorageMaxOptionIndex = this.storageMaxOptionKeyValues.findIndex(item => item.value === String(selectedMaxStorageValue));
  }
}
