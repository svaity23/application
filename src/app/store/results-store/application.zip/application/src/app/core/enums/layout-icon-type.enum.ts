export enum LayoutIconType {
    Grid,
    Masonry,
    List
}
