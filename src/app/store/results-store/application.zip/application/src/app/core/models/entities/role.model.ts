export interface Role {
    accountId: string; // guid
    active: boolean | true;
    description: string;
    externalId: string;
    id: string;
    key: string;
    name: string;
}
