export enum FileProviderType {
	google = 'google',
	'file-system' = 'file-system',
	dropbox =  'dropbox',
	oneDrive = 'oneDrive'
}
