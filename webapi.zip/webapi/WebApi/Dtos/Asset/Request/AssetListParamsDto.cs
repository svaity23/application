﻿using System;
using System.Text.Json.Serialization;

namespace WebApi.Dtos.Asset.Request
{
    public class AssetListParamsDto
    {
        [JsonPropertyName("sortField")]
        public int SortField { get; set; }
        [JsonPropertyName("collectionId")]
        public Guid? CollectionId { get; set; }
        [JsonPropertyName("skip")]
        public int Skip { get; set; }
        [JsonPropertyName("pageSize")]
        public int PageSize { get; set; }
        [JsonPropertyName("includeInactive")]
        public bool IncludeInactive { get; set; }
        [JsonPropertyName("isOnMyFavorites")]
        public bool IsOnMyFavorites { get; set; }
        [JsonPropertyName("expired")]
        public bool Expired { get; set; }
    }
}
