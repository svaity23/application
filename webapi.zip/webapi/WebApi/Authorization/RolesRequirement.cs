﻿using Microsoft.AspNetCore.Authorization;
using System;

namespace WebApi.Authorization
{
    public class RolesRequirement : IAuthorizationRequirement, IIdentifiable
    {
        public Guid Identifier { get; set; }
        public string Roles { get; }

        public RolesRequirement(string roles, Guid identifier)
        {
            Roles = roles;
            Identifier = identifier;
        }
    }
}
