import { Comment } from './comment.model';

export interface CommentThread {
    comments: Comment[];
    modified: Date;
    threadId: number;
}
