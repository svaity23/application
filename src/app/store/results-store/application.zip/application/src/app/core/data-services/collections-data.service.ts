import { Injectable } from '@angular/core';

import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { Asset } from '../models/entities/asset.model';
import { BaseDataService } from './base-data.service';
import { Collection } from '../models/entities/collection.model';
import { VisibleToType } from '../enums/visible-to-type.enum';

export interface CollectionsDataServiceInterface {
    add(collectionName: string, parentId: string): Observable<Collection>;
    delete(id: string): Observable<string>;
    deleteIncludeSubs(id: string): Observable<string[]>;
    filterCollections(searchText: string, collections: Collection[]): Observable<Collection[]>;
    getAll(): Observable<Collection[]>;
    getById(id: string): Observable<Collection>;
    loadCollectionsWithAssets(assets: Asset[], collections: Collection[]): Observable<Collection[]>;
    move(collectionId: string, parentId: string): Observable<Collection[]>;
    update(collection: Collection): Observable<Collection>;
}


@Injectable({ providedIn: 'root' })
export class CollectionsDataService extends BaseDataService implements CollectionsDataServiceInterface {

    add(collectionName: string, parentId: string): Observable<Collection> {
        const dto = {
            Name: collectionName,
            ParentId: parentId,
            VisibleTo: VisibleToType.None
        };
        const url = `${this.webApiUrl}/collections`;
        return this.createApiPost({ url, data: dto });
    }

    delete(id: string): Observable<string> {
        const url = `${this.webApiUrl}/collections/${id}`;
        return this.createApiDelete({ url, options: { observe: 'response' } });
        // .pipe(
        // eslint-disable-next-line @typescript-eslint/dot-notation
        //     map((data) => data['body'] as Collection)
        // );
    }

    deleteIncludeSubs(id: string): Observable<string[]> {
        const url = `${this.webApiUrl}/collections/${id}`;
        return this.createApiDelete({ url, options: { observe: 'response' } }).pipe(
            // eslint-disable-next-line @typescript-eslint/dot-notation
            map((data) => data['body'])
        );
    }

    filterCollections(searchText: string, collections: Collection[]): Observable<Collection[]> {
        return new Observable(observer => {
            const temp: Collection[] = [];

            collections.forEach((item) => {
                temp.push(item);
            });
            temp.slice();
            const items =
                collections.filter(c => {
                    return c.name.toString().toLocaleLowerCase().includes(searchText.toLocaleLowerCase());
                });

            // Yield a single value and complete
            const clone = JSON.parse(JSON.stringify(items));
            observer.next(clone);
            observer.complete();
        });
    }
    getAll(): Observable<Collection[]> {
        const url = `${this.webApiUrl}/collections`;
        return this.createApiGet({ url });
    }
    getById(id: string): Observable<Collection> {
        const url = `${this.webApiUrl}/collections/${id}`;
        return this.createApiGet({ url });
    }
    loadCollectionsWithAssets(assets: Asset[], collections: Collection[]): Observable<Collection[]> {
        throw new Error('Method not implemented.' + collections.length.toString() + assets.length.toString());
    }
    move(collectionId: string, newParentId: string): Observable<Collection[]> {
        const dto = {
            collectionId,
            parentId: newParentId
        };
        const url = `${this.webApiUrl}/collections/move`;
        return this.createApiPost({ url, data: dto });
    }
    update(collection: Collection): Observable<Collection> {
        const url = `${this.webApiUrl}/collections/${collection.id}`;
        return this.createApiPut({ url , data: collection});
    }
}
