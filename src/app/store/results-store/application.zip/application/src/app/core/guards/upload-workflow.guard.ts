import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { UploadStoreFacade } from '@app/store/upload-store/upload-store.facade';

@Injectable({
  providedIn: 'root'
})
export class UploadWorkflowGuard implements CanActivate {

  constructor(private uploadStoreFacade: UploadStoreFacade, private router: Router) { }

  canActivate(
    // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
    _route: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
    _state: RouterStateSnapshot): Observable<boolean | UrlTree> {

    return this.uploadStoreFacade.assetStoreFacade.assets$.pipe(
      map(assets => {
        if (assets && assets.length > 0) {
          return true;
        }
        return this.router.parseUrl('/upload');
      })
    );
  }
}
