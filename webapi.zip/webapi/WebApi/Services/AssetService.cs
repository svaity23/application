﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Marcom.Azure.ServiceBus;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Common.Constants;
using WebApi.Dtos;
using WebApi.Dtos.Asset.Comment;
using WebApi.Dtos.Asset.DetailsView;
using WebApi.Dtos.Asset.Request;
using WebApi.Dtos.Asset.Response;
using WebApi.Dtos.Asset.Revision;
using WebApi.Enums;
using WebApi.Extensions;

namespace WebApi.Services
{
    public class AssetService
    {
        private readonly AssetLogic _assetLogic;
        private readonly BlobService _blobService;
        private readonly ServiceBusService _serviceBusService;
        private readonly IConfiguration _configuration;
        private readonly ILogger<AssetService> _logger;
        private readonly PermalinkService _permalinkService;

        public AssetService(IConfiguration configuration, ILogger<AssetService> logger, BlobService blobService, ServiceBusService serviceBusService, damContext context, PermalinkService permalinkService)
        {
            _configuration = configuration;
            _logger = logger;

            _assetLogic = new AssetLogic(context);
            _blobService = blobService;
            _serviceBusService = serviceBusService;
            _permalinkService = permalinkService;
        }

        public async Task<DeleteAssetsResponseDto> DeleteAssetsAsync(Guid accountId, DeleteAssetsRequestDTO deleteAssetsRequest, Guid userId, Guid sessionId)
        {
            var jsonString = deleteAssetsRequest.ToJsonString();
            var jsonOutput = await _assetLogic.DeleteAssetsAsync(accountId, userId, sessionId, jsonString);
            
            await _serviceBusService.SignalIndexAsset(new
            {
                MessageType = ServiceBusMessageType.ASSETS_DELETED,
                AccountId = accountId.ToString(),
                AssetIds = deleteAssetsRequest.AssetIds
            });

            return JsonConvert.DeserializeObject<DeleteAssetsResponseDto>(jsonOutput);
        }

        public async Task<UpdateEntitiesResponse> FinishUploadSessionAsync(Guid accountId, FinishUploadSessionRequestDto finishUploadSessionRequest, Guid userId, Guid sessionId)
        {
            var jsonString = finishUploadSessionRequest.ToJsonString();
            var jsonOutput = await _assetLogic.ActivateAssets(accountId, userId, sessionId, jsonString);

            await _serviceBusService.SignalIndexAsset(new
            {
                MessageType = ServiceBusMessageType.ASSETS_ADDED,
                AccountId = accountId.ToString(),
                UploadSessionId = finishUploadSessionRequest.UploadSessionId
            });

            var response = JsonConvert.DeserializeObject<ActivateAssetsForFinishUploadResponseDto>(jsonOutput);
            var integrationSettings = response?.IntegrationSettings;

            if (integrationSettings != null)
            {
                // marcom integration is enabled
                var marcomSettings = integrationSettings.Where(x => x.Key == IntegrationSettingKeys.Marcom).FirstOrDefault();
                if(marcomSettings != null && marcomSettings.BoolValue)
                {
                    _logger.LogDebug($"Sending MARCOM_INTEGRATION_ASSET_UPLOAD message with uploadSessionId {finishUploadSessionRequest.UploadSessionId}");
                    object message = new
                    {
                        Action = "MARCOM_INTEGRATION_ASSET_UPLOAD",
                        AccountId = accountId,
                        UserId = userId,
                        UploadSessionId = finishUploadSessionRequest.UploadSessionId
                    };
                    await _serviceBusService.SignalDistributedMarketing(message);                    
                }
            }

            // no need to return integration data
            return new UpdateEntitiesResponse() { Updates = response.Updates };
        }

        public async Task<GetEntitiesResponse<AssetDto>> GetAccountAssetsAsync(
                Guid accountId,
                Guid userId,
                int sortField,
                Guid? collectionId,
                int skip,
                int pageSize,
                bool includeInactive = false,
                bool isOnMyFavorites = false,
                bool expired = false,
                bool cleanUp = false)
        {
            var assetListParams = new AssetListParamsDto
            {
                SortField = sortField,
                CollectionId = collectionId,
                Skip = skip,
                PageSize = pageSize,
                IncludeInactive = includeInactive,
                IsOnMyFavorites = isOnMyFavorites,
                Expired = expired
            };
            var jsonString = assetListParams.ToJsonString();
            string jsonOutput;
            if (cleanUp)
            {
                jsonOutput = await _assetLogic.GetAccountAssetsForCleanUpAsync(accountId, userId, jsonString);
            }
            else
            {
                jsonOutput = await _assetLogic.GetAccountAssetsAsync(accountId, userId, jsonString);
            }

            return JsonConvert.DeserializeObject<GetEntitiesResponse<AssetDto>>(jsonOutput);
        }

        public async Task<UpsertResponse<AssetCommentDto>> AddCommentAsync(Guid accountId, Guid userId, Guid assetId, AssetCommentDto commentDto)
        {
            var jsonInput = commentDto.ToJsonString();
            var jsonOutput = await _assetLogic.AddCommentAsync(accountId, userId, assetId, jsonInput);
            var response = JsonConvert.DeserializeObject<UpsertResponse<AssetCommentDto>>(jsonOutput);

            // TODO: I don't like this check, seems out of place.
            // These null and error code checks are duplicated in the controller,
            // but we need to check if the response is valid before pushing a notification out.
            if (response != null && response.Errors[0].Code == 0 && response?.Entity.Id != null)
            {
                await _serviceBusService.SignalNotificationInitiated(new
                {
                    MessageType = ServiceBusMessageType.NOTIFICATION_INITIATED,
                    UserIds = commentDto.TaggedUserIds,           // UserIds of the users who will be notified
                    AssetCommentId = response.Entity.Id         // Needed so we can construct the notification dto in signalRHub
                });
            }

            return response;
        }

        public async Task<UpsertResponse<AssetCommentDto>> UpdateCommentAsync(Guid accountId, Guid userId, Guid assetId, AssetCommentDto commentDto)
        {
            var jsonInput = commentDto.ToJsonString();
            var jsonOutput = await _assetLogic.UpdateCommentAsync(accountId, userId, assetId, jsonInput);

            return JsonConvert.DeserializeObject<UpsertResponse<AssetCommentDto>>(jsonOutput);
        }

        public async Task<AccountAssetInfo> GetAccountAssetInfoByIdsAsync(Guid accountId, Guid userId, Guid sessionId, string action, List<Guid> assetIds, bool recordUsage, DateTime? expirationDate = null, string blobName = null)
        {
            var strAccountAssetInfo = await _assetLogic.GetAccountAssetInfoByIdsAsync(accountId, userId, sessionId, action, assetIds, recordUsage, expirationDate, blobName);
            return JsonConvert.DeserializeObject<AccountAssetInfo>(strAccountAssetInfo);
        }

        public async Task<List<Asset>> GetActiveAssets(Guid accountId)
        {
            return await _assetLogic.GetActiveAssets(accountId);
        }

        public async Task<GetEntityResponse<AssetDetailDto>> GetAssetDetailForDetailsViewAsync(Guid accountId, Guid assetId, Guid userId)
        {
            var jsonOutput = await _assetLogic.GetAssetDetailForDetailsViewAsync(accountId, assetId, userId);
            return JsonConvert.DeserializeObject<GetEntityResponse<AssetDetailDto>>(jsonOutput);
        }

        public async Task<AssetPreviewDto> GetAssetForPreviewAsync(Guid accountId, Guid assetId, Guid userId, bool excludeExpired = false)
        {
            var input = new
            {
                ExcludeExpired = excludeExpired
            };

            var jsonInput = input.ToJsonString();
            var jsonOutput = await _assetLogic.GetAssetForPreviewAsync(accountId, assetId, userId, jsonInput);
            return JsonConvert.DeserializeObject<AssetPreviewDto>(jsonOutput);
        }

        // TODO - Deserialize to DTO or correct primitive
        public async Task<string> GetMetadataFieldsMetadataProfilesAndProfileTypesAsync(Guid accountId)
        {
            return await _assetLogic.GetMetadataFieldsMetadataProfilesAndProfileTypesAsync(accountId);
        }

        public async Task<PostUploadSummaryRowDto[]> GetPostUploadSummaryAsync(Guid accountId, Guid uploadSessionId)
        {
            var jsonOutput = await _assetLogic.GetPostUploadSummaryAsync(accountId, uploadSessionId);
            return JsonConvert.DeserializeObject<PostUploadSummaryRowDto[]>(jsonOutput);
        }

        public async Task<GetEntitiesResponse<CommentResponseDto>> GetCommentsAsync(Guid accountId, Guid userId, Guid assetId)
        {
            var jsonOutput = await _assetLogic.GetCommentsAsync(accountId, userId, assetId);
            return JsonConvert.DeserializeObject<GetEntitiesResponse<CommentResponseDto>>(jsonOutput);
        }

        public async Task<string> GetSharePermalinkAsync(Guid accountId, Guid assetId, Guid userId, Guid sessionId, string destination = "")
        {
            _logger.LogDebug("Begin: GetSharePermalinkAsync");

            var assets = await _assetLogic.GetShareAssetsAsync(accountId, new Guid[] { assetId });

            // todo - when we need the storage account name from database, we'll need this call to get account            
            // var account = await _accountLogic.FindByIdAsync(accountId);
            string storageAccountName = _configuration["BlobStorage:StorageAccountName"];
            string uploadContainerName = _configuration["BlobStorage:UploadContainerName"];
            string storageContainerName = _blobService.GetBlobContainerName(accountId, uploadContainerName);

            // This will be configurable in the future.  Depends how long we want to keep it alive before we have to gen a new one.
            // Should also sync with whats in permalink app.
            var daysValid = 90;

            //BlobName is the assetId
            var blobName = GetBlobName(assets[0].Id, assets[0].FileName);

            // GetBlobSasToken uses -1 minute offset, so we'll do the same here before the call to create the sas token
            var now = DateTime.UtcNow.AddMinutes(-1);
            var sasToken = _blobService.GetBlobSasToken(blobName, daysValid, storageAccountName, storageContainerName);

            var request = new PermalinkRequest()
            {
                AssetId = assetId,
                Resolution = uploadContainerName, // "asset" to match container?
                Sas = sasToken,
                SasExpiration = now.AddDays(daysValid),
                Destination = destination
            };

            var permalinkResponse = await _permalinkService.SavePermalinkAsync(accountId, userId, sessionId, request);
            string url = _permalinkService.GetPermalinkUri(permalinkResponse);
            _logger.LogDebug("Permalink created: " + url);

            return url;
        }

        public async Task ReindexAssetsAsync(Guid accountId)
        {
            await _serviceBusService.SignalIndexAsset(new
            {
                MessageType = ServiceBusMessageType.REINDEX,
                AccountId = accountId.ToString()
            });
        }

        public async Task<UpdateAssetResponseDto> UpdateAssetAsync(Guid accountId, Guid userId, Guid sessionId, AssetDto updateAssetRequest)
        {
            var jsonString = updateAssetRequest.ToJsonString();
            var jsonOutput = await _assetLogic.UpdateAssetAsync(accountId, userId, sessionId, jsonString);

            await _serviceBusService.SignalIndexAsset(new
            {
                MessageType = ServiceBusMessageType.ASSETS_MODIFIED,
                AccountId = accountId.ToString(),
                AssetIds = new Guid[] { updateAssetRequest.Id }
            });

            return JsonConvert.DeserializeObject<UpdateAssetResponseDto>(jsonOutput);
        }

        public async Task<UpdateAssetsWithCollectionIdResponseDto> UpdateAssetsWithCollectionIdAsync(Guid accountId, UpdateCollectionRequestDTO updateCollectionRequest, Guid userId, Guid sessionId)
        {
            var jsonString = updateCollectionRequest.ToJsonString();
            var jsonOutput = await _assetLogic.UpdateAssetsWithCollectionIdAsync(accountId, userId, sessionId, jsonString);

            await _serviceBusService.SignalIndexAsset(new
            {
                MessageType = ServiceBusMessageType.ASSETS_MODIFIED,
                AccountId = accountId.ToString(),
                AssetIds = updateCollectionRequest.Ids
            });

            return JsonConvert.DeserializeObject<UpdateAssetsWithCollectionIdResponseDto>(jsonOutput);
        }

        public async Task<UpdateFavoriteResponseDto[]> UpdateFavoritesAsync(Guid accountId, Guid userId, UpdateFavoritesRequestDTO updateFavoritesRequest)
        {
            var jsonString = updateFavoritesRequest.ToJsonString();
            var jsonOutput = await _assetLogic.UpdateFavoritesAsync(accountId, userId, jsonString);

            await _serviceBusService.SignalIndexAsset(new
            {
                MessageType = ServiceBusMessageType.ASSETS_MODIFIED,
                AccountId = accountId.ToString(),
                AssetIds = updateFavoritesRequest.Ids
            });

            return JsonConvert.DeserializeObject<UpdateFavoriteResponseDto[]>(jsonOutput);
        }

        public async Task<UpdateFavoriteResponseDto> UpdateFavoriteAsync(Guid accountId, Guid userId, AssetDto asset)
        {
            var jsonString = asset.ToJsonString();
            var jsonOutput = await _assetLogic.UpdateFavoriteAsync(accountId, userId, jsonString);

            await _serviceBusService.SignalIndexAsset(new
            {
                MessageType = ServiceBusMessageType.ASSETS_MODIFIED,
                AccountId = accountId.ToString(),
                AssetIds = new Guid[] { asset.Id }
            });

            return JsonConvert.DeserializeObject<UpdateFavoriteResponseDto>(jsonOutput);
        }

        // TODO - Deserialize to DTO or correct primitive
        public async Task<string> UpdateMetadataAsync(Guid accountId, UpdateMetadataRequestDTO updateMetadataRequest, Guid userId)
        {
            var jsonString = updateMetadataRequest.ToJsonString();
            var result = await _assetLogic.UpdateMetadataAsync(accountId, userId, jsonString);

            var ids = updateMetadataRequest.Assets.ToList().Select(a => a.Id).ToArray();
            var tagsAssetIds = updateMetadataRequest.Tags?.ToList().Select(a => a.AssetId).ToArray();
            var metadataAssetIds = updateMetadataRequest.Metadata?.ToList().Select(a => a.AssetId).ToArray();
            var assetIds = ids?.Union(tagsAssetIds?.Union(metadataAssetIds)).ToArray();

            if (assetIds.Length > 0)
            {
                await _serviceBusService.SignalIndexAsset(new
                {
                    MessageType = ServiceBusMessageType.ASSETS_MODIFIED,
                    AccountId = accountId.ToString(),
                    AssetIds = assetIds
                });
            }

            return result;
        }

        public async Task<MetadatumUpdateDto[]> UpdateMetadatumAsync(Guid accountId, Guid userId, Guid sessionId, MetadataDto updateMetadataRequest)
        {
            var jsonString = updateMetadataRequest.ToJsonString();
            var jsonOutput = await _assetLogic.UpdateMetadatumAsync(accountId, userId, sessionId, jsonString);

            await _serviceBusService.SignalIndexAsset(new
            {
                MessageType = ServiceBusMessageType.ASSETS_MODIFIED,
                AccountId = accountId.ToString(),
                AssetIds = new Guid[] { updateMetadataRequest.AssetId }
            });

            // TODO - Denali help? - fix stored proc to unwrap array, client side code needs to be fixed as well
            return JsonConvert.DeserializeObject<MetadatumUpdateDto[]>(jsonOutput);
        }

        public async Task<SaveTagResponseDto> UpdateTagAsync(Guid accountId, Guid userId, Guid sessionId, TagDto updateRequest)
        {
            var jsonString = updateRequest.ToJsonString();
            var jsonOutput = await _assetLogic.UpdateTagAsync(accountId, userId, sessionId, jsonString);

            await _serviceBusService.SignalIndexAsset(new
            {
                MessageType = ServiceBusMessageType.ASSETS_MODIFIED,
                AccountId = accountId.ToString(),
                AssetIds = new Guid[] { updateRequest.AssetId }
            });

            return JsonConvert.DeserializeObject<SaveTagResponseDto>(jsonOutput);
        }

        public async Task UpdateAiTagsAsync(Guid accountId, AiTagsRequestDTO updateRequest)
        {
            var messageType = ServiceBusMessageType.AI_TAGS_REQUESTED;
            var storageAccountName = _configuration["BlobStorage:StorageAccountName"];
            string defaultUploadContainerName = _configuration["BlobStorage:UploadContainerName"];
            var blobName = updateRequest.BlobName;

            await _serviceBusService.SignalAITags(new
            {
                MessageType = messageType,
                AssetId = updateRequest.AssetId.ToString(),
                AccountId = accountId,
                StorageAccountName = storageAccountName,
                ID = Guid.NewGuid(),
                Opaque = new
                {
                    SignalRConnectionId = updateRequest.SignalRConnectionId,
                    AssetId = updateRequest.AssetId.ToString(),
                    Source = updateRequest.Source
                },
                TenantInfo = new
                {
                    Account = new
                    {
                        Type = "AzureBlobStorage",
                        Details = new
                        {
                            AccountName = storageAccountName,
                            ContainerName = defaultUploadContainerName,
                            ContainerNamePrefix = accountId.ToString()
                        }
                    }
                },
                Source = new
                {
                    FileName = blobName
                },
                ProcessorInfo = new
                {
                    Tasks = GetProcessingTask(storageAccountName, blobName, accountId.ToString())
                }
            });
        }

        public async Task<TagUpdateDto[]> UpdateTagsAsync(Guid accountId, UpdateTagRequestDTO updateTagRequest, Guid userId, Guid sessionId)
        {
            var jsonString = updateTagRequest.ToJsonString();
            var jsonOutput = await _assetLogic.UpdateTagsAsync(accountId, userId, sessionId, jsonString);

            var assetIds = updateTagRequest.Tags.ToList().Select(t => t.AssetId).ToArray();

            await _serviceBusService.SignalIndexAsset(new
            {
                MessageType = ServiceBusMessageType.ASSETS_MODIFIED,
                AccountId = accountId.ToString(),
                AssetIds = assetIds
            });

            return JsonConvert.DeserializeObject<TagUpdateDto[]>(jsonOutput);
        }

        public async Task<SaveAssetUsageResponseDto> RecordAssetUsage(Guid accountId, Guid userId, Guid? sessionId, UseageRequestDTO usage)
        {
            var jsonInput = usage.ToJsonString();
            var jsonOutput = await _assetLogic.RecordAssetUsage(accountId, userId, sessionId, jsonInput);
            return JsonConvert.DeserializeObject<SaveAssetUsageResponseDto>(jsonOutput);
        }

        public async Task<AssetRevisionDto[]> GetAssetHistoryAsync(Guid accountId, Guid assetId)
        {
            string jsonOutput = await _assetLogic.GetAssetHistoryAsync(accountId, assetId);
            return JsonConvert.DeserializeObject<AssetRevisionDto[]>(jsonOutput);
        }

        #region Private Methods

        // todo: put this under shared utility
        private string GetBlobName(Guid assetId, string fileName)
        {
            var fileExt = Path.GetExtension(fileName);
            var blobName = assetId.ToString() + fileExt;
            return blobName.ToLowerInvariant();
        }


        private static object[] GetProcessingTask(string accountName, string location, string containerNamePrefix)
        {
            return new[] {
                new {
                    Name = "low-res",
                    Destinations = new [] {
                        new {
                            Details = new {
                                ContainerName = "low-resolution",
                                AccountName = accountName,
                                Location = location,
                                ContainerNamePrefix = containerNamePrefix
                            }
                        }
                    },
                    StatusCode = 200
                }
            };
        }

        #endregion

    }
}

