﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace WebApi.Dtos.Asset.Hubspot
{
    public class HubspotSyncErrorsDTO
    {
        [JsonPropertyName("lastSync")]
        public DateTime? LastSync { get; set; }

        [JsonPropertyName("assetSyncErrors")]
        public List<HubspotAssetErrorDTO> AssetSyncErrors { get; set; }
    }
}
