import { ChangeDetectionStrategy, Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { cn } from 'src/utils/cn';

@Component({
  selector: 'app-account-details-header',
  templateUrl: './account-details-header.component.html',
  styleUrls: ['./account-details-header.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountDetailsHeaderComponent implements OnInit {
  @Input() className = '';
  visible = true;

  constructor() { }

  ngOnInit(): void {
    this.className = cn('account-details-header is-visible', this.className);
  }

}
