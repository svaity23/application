
import { Lightbox } from '../entities/lightbox.model';

export interface RenameLightboxModalOptions {
    confirm: (lightbox: Lightbox) => void;
    confirmButtonText: string;
    deny: () => void;
    denyButtonText: string;
    lightboxInfo: { lightboxes: Lightbox[], selectedLightbox: Lightbox };
    title: string;
}
