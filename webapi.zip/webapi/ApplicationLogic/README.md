# Application Logic

The ApplicationLogic assembly will implement the WebApi's business logic. It's not a re-use point; it won't  be shared across teams, services, or repositories.

For up-to-date details, see [the SharePoint page](https://pticorp.sharepoint.com/sites/Engineering/SitePages/Application-logic.aspx?Mode=Edit).

## Responsibilities

The assembly will:

- House Application Logic ([a type of business logic](https://pticorp.sharepoint.com/sites/Engineering/SitePages/Business-logic-in-database.aspx))
- Back the WebApi so that layer can be thinner.

## Running the tests

From the Test Explorer pane, click the green arrow to Run All tests.

## Scaffolding Tables/POCOs

We are standarizing on the use of Stored Procedures, favoring them over Entity Frameworks EF. That said, if you need to update an existing POCO via scaffolding, see the solution-level readme.md.


