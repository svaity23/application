﻿using System;
using System.Text.Json.Serialization;

namespace WebApi.Dtos.Asset.Hubspot
{
    public class HubspotCollectionDTO
    {
        [JsonPropertyName("collectionId")]
        public Guid? CollectionId { get; set; }

        [JsonPropertyName("signalRConnectionId")]
        public string SignalRConnectionId { get; set; }
    }
}
