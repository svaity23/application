﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Newtonsoft.Json;
using SignalRHub.DomainModel.Context;
using SignalRHub.DomainModel.Extensions;
using SignalRHub.Messages;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SignalRHub.DomainModel.Finders
{
    public class AssetFinder
    {
        public ILogger<AssetFinder> Logger { get; set; }

        private damContext _context;
        private const string ASSET_ID = "@assetId";
        private const string JSON_INPUT = "@jsonInput";
        private const string SAVE_ATTACHMENTS_PROCEDURE = "setAssetAttachments";        
        private const string SAVE_AI_TAGS_OCR_TEXT_PROCEDURE = "saveAiTagsAndOcrText";

        public AssetFinder(damContext context)
        {
            _context = context;
            Logger = NullLogger<AssetFinder>.Instance;
        }

        public async Task<string> StoreAttachmentsAsync(ThumbReadyDTO payload)
        {
            Logger.LogInformation(payload.ToString());
            var assetId = payload.AssetId;

            var json = payload.ToJsonString();

            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter(ASSET_ID, assetId));
            parameters.Add(new SqlParameter(JSON_INPUT, json));
            return await _context.ExecuteNonQueryJsonOutputAsync(SAVE_ATTACHMENTS_PROCEDURE, parameters);
        }
               
        public async Task<string> StoreAiAndOcrTextAsync(TagsReadyDTO payload)
        {
            if (payload == null) return "";
            Logger.LogInformation("Store tags: " + payload.ToString());

            var assetId = payload.AssetId;
            var json = payload.ToJsonString();

            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter(ASSET_ID, assetId));
            parameters.Add(new SqlParameter(JSON_INPUT, json));
            return await _context.ExecuteNonQueryJsonOutputAsync(SAVE_AI_TAGS_OCR_TEXT_PROCEDURE, parameters);
        }
    }
}
