export enum FrameType {
    Text = 'Text',
    Image = 'Image'
}