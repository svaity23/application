import { Injectable } from '@angular/core';

import * as faker from 'faker/locale/en_US';
import { Observable, of } from 'rxjs';

import { Asset } from '../models/entities/asset.model';
import { AssetDetails } from '../models/asset-details.model';
import { AssetForDetailsView } from '../models/asset-for-details-view.model';
import { AssetRevisions } from '../models/asset-revisions.model';
import { AssetRevisionsHistory } from '../models/asset-revisions-history.model';
import { AssetsAndMetadataAndTags } from '../models/assets-and-metadata-and-tags.model';
import { AssetsDataServiceInterface } from '../data-services/assets-data.service';
import { AssetUpdate } from '../models/asset-update.model';
import { AssetViewState } from '../models/view-states/asset-view-state.model';
import { Collection } from '../models/entities/collection.model';
import { Comment } from '../models/comment.model';
import { CommentsResponse } from '../models/api-responses/comments-response.model';
import { DeleteAssetsResponse } from '../models/api-responses/delete-assets-response.model';
import { Design } from '../models/designer/design.model';
import { Favorite } from '../models/favorite.model';
import { FieldType } from '../enums/field-type.enum';
import { FileGroupType, UploadStatusType } from '../enums';
import { FileTypeService } from '../services/file-type.service';
import { Frame } from '../models/designer/frame.model';
// import { FrameType } from '../models/designer/frame-type.enum';
import { IdEntityResponse } from '../models/api-responses/id-entity-response.model';
import { LibrarySidebarSelectionType } from '../enums/library-sidebar-selection.enum';
import { Metadata } from '../models/entities/metadata.model';
import { MetadataField } from '../models/entities/metadata-field.model';
import { MetadataFieldAndValue } from '../models/metadata-field-and-value.model';
import { MetadataProfile } from '../models/entities/metadata-profile.model';
import { MetadataProfileInfo } from '../models/entities/metadata-profile-info.model';
import { MetadataProfileType } from '../models/entities/metadata-profile-type.model';
import { MoveAssetToCollectionResponse } from '../models/api-responses/move-asset-to-collection-response.model';
import { Page } from '../models/designer/page.model';
import { PostUploadSummaryFileGroup, PostUploadSummaryRow } from '../models/post-upload-summary-table.model';
import { SearchResults } from '../models/search-results.model';
import { Tag } from '../models/entities/tag.model';

@Injectable({ providedIn: 'root' })
export class AssetsDataServiceMock implements AssetsDataServiceInterface {
  private internalAssetList: Asset[] = [];
  private internalMetadataFields: MetadataField[] = [];
  private internalMetadataProfiles: MetadataProfile[] = [];
  private internalMetadataTypes: MetadataProfileType[] = [];

  constructor(private fileTypeService: FileTypeService) {
    //#region asset files
    const files = [
      'assets/img/thumbs/academic-degree-accomplishment-adult-2408471.jpg',
      'assets/img/thumbs/image_thumb-3x1.png',
      'assets/img/thumbs/erica-thomas-1653389-unsplash.jpg',
      'assets/img/thumbs/academic-regalia-accomplishment-alumni-2495232.jpg',
      'assets/img/thumbs/mimi-thian-jxUuXxUFfp4-unsplash.jpg',
      'assets/img/thumbs/stemshare-nsw-CFfoGuhptok-unsplash.jpg',
      'assets/img/thumbs/emilio-takas-1504072-unsplash.jpg',
      'assets/img/thumbs/cap-celebrate-celebration-1205651.jpg',
      'assets/img/thumbs/fake-video.mp4',
      'assets/img/thumbs/fake-audio.mp3',
      'assets/img/thumbs/fake-design.ai',
      'assets/img/thumbs/fake-presentation.ppt',
      'assets/img/thumbs/fake-document.txt',
      'assets/video/2020-8-18-Catalina-Dive1.mp4',
      // 'assets/audio/horse.ogv',
      'assets/img/thumbs/87629877-3583-4154-930f-487fd98fd5f3.png',
      'assets/img/thumbs/academic-degree-accomplishment-adult-2408471.jpg',
      'assets/img/thumbs/academic-regalia-accomplishment-alumni-2495232.jpg',
      'assets/img/thumbs/academic-regalia-accomplishment-beautiful-woman-2408443.jpg',
      'assets/img/thumbs/academy-celebrate-celebration-267885.jpg',
      'assets/img/thumbs/action-energy-active-adult-2335298.jpg',
      'assets/img/thumbs/adult-books-campus-159775.jpg',
      'assets/img/thumbs/adult-classroom-college-256401.jpg',
      'assets/img/thumbs/ahnaf-tahsin-rafi-1354551-unsplash.jpg',
      'assets/img/thumbs/alex-sorto-1148692-unsplash.jpg',
      'assets/img/thumbs/alexis-brown-85793-unsplash.jpg',
      'assets/img/thumbs/allison-griffith-Q76DPRQ3Ix0-unsplash.jpg',
      'assets/img/thumbs/aranxa-esteve-pOXHU0UEDcg-unsplash.jpg',
      'assets/img/thumbs/braden-collum-87874-unsplash.jpg',
      'assets/img/thumbs/caleb-woods-275754-unsplash.jpg',
      'assets/img/thumbs/cap-celebrate-celebration-1205651.jpg',
      'assets/img/thumbs/charles-deloye-660433-unsplash.jpg',
      'assets/img/thumbs/cole-keister-vEgVWRBr2VY-unsplash.jpg',
      'assets/img/thumbs/davis-sanchez-BbXdRuGse9I-unsplash.jpg',
      'assets/img/thumbs/delfi-de-la-rua-140752-unsplash.jpg',
      'assets/img/thumbs/document.txt',
      'assets/img/thumbs/element5-digital-352046-unsplash.jpg',
      'assets/img/thumbs/emilio-takas-1504072-unsplash.jpg',
      'assets/img/thumbs/emma-dau-140010-unsplash.jpg',
      'assets/img/thumbs/erica-thomas-1653389-unsplash.jpg',
      'assets/img/thumbs/ET0130101-S.jpg',
      'assets/img/thumbs/good-free-photos-773344-unsplash.jpg',
      'assets/img/thumbs/Graduation_065.png',
      'assets/img/thumbs/hannah-gibbs-595336-unsplash.jpg',
      'assets/img/thumbs/helena-lopes-UZe35tk5UoA-unsplash.jpg',
      'assets/img/thumbs/honey-yanibel-minaya-cruz-laORtJZaieU-unsplash.jpg',
      'assets/img/thumbs/humberto-chavez-FVh_yqLR9eA-unsplash.jpg',
      'assets/img/thumbs/hunter-newton-1120359-unsplash.jpg',
      'assets/img/thumbs/image_thumb-3x1.png',
      'assets/img/thumbs/jason-leung-Xaanw0s0pMk-unsplash.jpg',
      'assets/img/thumbs/jeffrey-f-lin-1080548-unsplash.jpg',
      'assets/img/thumbs/jeffrey-f-lin-1113534-unsplash.jpg',
      'assets/img/thumbs/jodyhongfilms-274059-unsplash.jpg',
      'assets/img/thumbs/jonathan-daniels-kxgMWWVbvcw-unsplash.jpg',
      'assets/img/thumbs/juan-ramos-97385-unsplash.jpg',
      'assets/img/thumbs/leslie-jones-1415632-unsplash.jpg',
      'assets/img/thumbs/logan-isbell-672551-unsplash.jpg',
      'assets/img/thumbs/loic-furhoff-qeIaMQP_xQE-unsplash.jpg',
      'assets/img/thumbs/marvin-meyer-SYTO3xs06fU-unsplash.jpg',
      'assets/img/thumbs/max-nelson-vbj1mKlJBzg-unsplash.jpg',
      'assets/img/thumbs/md-duran-628456-unsplash.jpg',
      'assets/img/thumbs/mikael-kristenson-242070-unsplash.jpg',
      'assets/img/thumbs/mimi-thian-jxUuXxUFfp4-unsplash.jpg',
      'assets/img/thumbs/muhammad-rizwan-270301-unsplash.jpg',
      'assets/img/thumbs/naassom-azevedo-541451-unsplash.jpg',
      'assets/img/thumbs/nathan-shively-51777-unsplash.jpg',
      'assets/img/thumbs/omar-lopez-1633686-unsplash.jpg',
      'assets/img/thumbs/philippe-bout-1057368-unsplash.jpg',
      'assets/img/thumbs/princess-684298-unsplash.jpg',
      'assets/img/thumbs/priscilla-du-preez-623040-unsplash.jpg',
      'assets/img/thumbs/rochelle-nicole-84911-unsplash.jpg',
      'assets/img/thumbs/ronny-sison-LUdelQ2EO2g-unsplash.jpg',
      'assets/img/thumbs/ryan-jacobson-687814-unsplash.jpg',
      'assets/img/thumbs/samantha-gades-XkBYYlZ4Ono-unsplash.jpg',
      'assets/img/thumbs/shakira-derteano-1412784-unsplash.jpg',
      'assets/img/thumbs/stemshare-nsw-CFfoGuhptok-unsplash.jpg',
      'assets/img/thumbs/tamarcus-brown-T3uKisfmABY-unsplash.jpg',
      'assets/img/thumbs/thought-catalog-UyRq7_wSeLI-unsplash.jpg',
      'assets/img/thumbs/tim-gouw-ScWvHUtQca4-unsplash.jpg',
      'assets/img/thumbs/tra-nguyen-459276-unsplash.jpg',
      'assets/img/thumbs/U-Seal-3.jpg',
      'assets/img/thumbs/U-Seal-3.png',
      'assets/img/thumbs/vasily-koloda-620886-unsplash.jpg',
      'assets/img/thumbs/victoria-heath-367304-unsplash.jpg',
      'assets/img/thumbs/yassine-khalfalli-1339668-unsplash.jpg',
      'assets/img/thumbs/yingchou-han-241463-unsplash.jpg',
      'assets/img/thumbs/you-x-ventures-1439463-unsplash.jpg',
      'assets/img/thumbs/yvette-de-wit-NYrVisodQ2M-unsplash.jpg'
    ];
    //#endregion

    const collectionPaths = [];
    let i = 0;
    while (i < files.length) {
      collectionPaths.push(faker.random.word() + '/' + faker.random.word());
      i++;
    }

    const assets: Asset[] = [];
    i = 0;
    for (const file of files) {
      const fileName = file.substring(file.lastIndexOf('/')).replace('/', '');
      const fileType = this.fileTypeService.getFileTypeFromFileName(fileName);
      const fileGroupType = this.fileTypeService.getFileGroupType(fileType);
      // TODO:  WIP.  The Webapi will most likely not be sending
      // back a viewState object.  This should be created as part
      // of the mapping in the asset.service.  Will hack it below
      // until we sort this out.
      const assetViewState: AssetViewState = {
        assetUris: { 'low-resolution': null, asset: null, metadata: null, thumbnail: null, web: null },
        collectionPath: collectionPaths[i],
        file: null,
        selected: false,
        uploadProgressPercentage: 0, // really only applies during the upload process
        uploadStatus: UploadStatusType.ThumbnailReceived // really only applies during the upload process
      };
      const asset: Asset = {
        collectionId: faker.random.number({ min: 1, max: 10 }).toString(),
        createdByUserName: '',
        created: faker.date.between('01/01/2020', '06/30/2020'),
        createdByUserId: faker.random.number().toString(),
        description: faker.random.words(5),
        error: null,
        fileGroup: fileGroupType,
        fileName,
        fileSize: 14900,
        fileExtension: fileType,
        id: i.toString(),
        lastModifiedByUserId: faker.random.number().toString(),
        modified: faker.date.recent(60),
        modifiedByUserName: '',
        name: fileName,
        viewState: assetViewState
      };

      // HACK to match what the webapi is sending back
      // TODO: Need to update how images work in mock data.
      // eslint-disable-next-line @typescript-eslint/dot-notation
      // asset['thumbnailUri'] = file;
      // eslint-disable-next-line @typescript-eslint/dot-notation
      asset['uploadStatus'] = UploadStatusType.ThumbnailReceived;
      // asset-card is dependent on upload status.  The thumbnail
      // logic needs to be revisited and we break this dependency in a refactor
      // end hack -- bem

      assets.push(asset);
      i++;
    }
    this.internalAssetList = assets;
    // may use faker
    const metadataProfileTypes: MetadataProfileType[] = [
      { id: 0, name: 'Image' },
      { id: 1, name: 'Video' },
      { id: 2, name: 'Audio' },
      { id: 3, name: 'Design File' },
      { id: 4, name: 'Presentation' },
      { id: 5, name: 'Document' }
    ];
    this.internalMetadataTypes = metadataProfileTypes;
    const accountId = faker.random.number().toString();
    const defaultMetadataProfiles: MetadataProfile[] = [
      { accountId, id: '1', name: 'Image', metadataProfileTypeId: 0 },
      { accountId, id: '2', name: 'Video', metadataProfileTypeId: 1 },
      { accountId, id: '3', name: 'Audio', metadataProfileTypeId: 2 }
    ];

    // const metadataFieldTypes: MetadataFieldType[] = [
    //   { id: '0', name: 'Text box' },
    //   { id: '5', name: 'Daterime' }
    // ];

    this.internalMetadataProfiles = defaultMetadataProfiles;
    const metadataFields: MetadataField[] = [
      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '1', label: 'Photographer', previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Photographer', metadataFieldTypeId: 0 },
      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '1', label: 'Date image taken', previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Date image taken', metadataFieldTypeId: 5 },
      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '1', label: 'Location', previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Location', metadataFieldTypeId: 0 },
      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '1', label: 'Camera', previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Camera', metadataFieldTypeId: 0 },

      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '2', label: 'Videographer', previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Videographer', metadataFieldTypeId: 0 },
      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '2', label: 'Date video recorded', previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Date video recorded', metadataFieldTypeId: 5 },
      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '2', label: 'Location', previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Location', metadataFieldTypeId: 0 },

      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '3', label: 'Author', previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Author', metadataFieldTypeId: 0 },
      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '3', label: 'Date audio recorded', previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Date audio recorded', metadataFieldTypeId: 5 },
      { id: faker.random.number().toString(), expandField: false, accountId: faker.random.number().toString(), metadataProfileId: '3', label: 'Location', previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Location', metadataFieldTypeId: 0 }
    ];
    this.internalMetadataFields = metadataFields;
  }

  addTag(tag: string): Observable<string> {
    return of(tag);
  }
  deleteAssets(assets: Asset[]): Observable<DeleteAssetsResponse> {
    return of({
      assetIds: assets.map(a => {
        const b: IdEntityResponse = { id: a.id };
        return b;
      })
    });
  }

  deleteTag(tag: string): Observable<string> {
    // deleteTag is really just an update tags
    console.log('tag in assets-data.service.mock', tag);
    return of(tag);
  }

  getAll(): Observable<Asset[]> {
    return new Observable(observer => {
      // clone this internal list because store-freeze will make it immutable later in the dispatch pipeline
      const clone = JSON.parse(JSON.stringify(this.internalAssetList));

      // Yield a single value and complete
      observer.next(clone);
      observer.complete();
    });
  }

  getAllCommentThreads(_assetId: string): Observable<CommentsResponse[]> {
    return new Observable<CommentsResponse[]>(observer => {
      const commentThreadsUsers = new Array<CommentsResponse>();
      const mockThread: CommentsResponse = {
        threads: [
          {
            threadId: 1,
            modified: new Date(),
            comments: [{
              author: {
                id: '123',
                email: 'aa.bb@email.com',
                firstName: 'Aaa',
                lastName: 'Bbbb'
              },
              comment: 'hello there',
              created: new Date(),
              id: '111-111-111',
              isAnnotation: false,
              positionLeft: 0,
              positionTop: 0,
              resolved: false,
              taggedUserIds: ['3213', '43223'],
              threadId: 1,
            }]
          }],
        users: [
          {
            id: '123',
            email: 'aa.bb@email.com',
            firstName: 'Aaa',
            lastName: 'Bbbb'
          }
        ]
      };
      commentThreadsUsers.push(mockThread);

      observer.next(commentThreadsUsers);
      observer.complete();
    });
  }

  getAssetDetailsById(id: string): Observable<AssetDetails> {
    return new Observable(observer => {
      const item = this.internalAssetList.find(x => x.id === id);
      const assetDetails: AssetDetails = {
        asset: item,
        createdByUserFullName: 'Kate Contributor',
        fileGroups: this.getFileGroups(),
        metadataFieldsAndValues: new Array<MetadataFieldAndValue>(),
        metadata: this.getMockMetadata(id),
        metadataFields: this.getMockMetadataFields(),
        modifiedByUserFullName: 'Kate Contributor',
        tags: this.getMockTags()
      };
      assetDetails.metadataFields.forEach(field => {
        let metadatum = assetDetails.metadata.filter(element =>
          element.metadataFieldId === field.id
        );
        metadatum = metadatum !== undefined ? metadatum : null;
        const metadatumToModify = metadatum;
        assetDetails.metadataFieldsAndValues.push({ metadata: metadatum, metadataField: field, metadataToModify: metadatumToModify, metadataFieldValues: [] });
      });
      // Yield a single value and complete
      observer.next(assetDetails);
      observer.complete();
    });
  }

  getAssetForPreviewById(id: string): Observable<AssetForDetailsView> {
    return new Observable(observer => {
      const assetDetails: AssetForDetailsView = {
        attachment: null,
        name: 'Kate Contributor',
        description: '',
        id: faker.random.number().toString(),
        fileExtension: 'JPG',
        fileGroupType: 0,
        fileName: 'cap-celebrate-celebration-1205651.jpg',
        fileSize: '5 MB',
        fileType: 'JPG',
        assetUris: {
          'low-resolution': 'assets/img/thumbs/cap-celebrate-celebration-1205651.jpg',
          asset: 'assets/img/thumbs/cap-celebrate-celebration-1205651.jpg',
          metadata: 'assets/img/thumbs/cap-celebrate-celebration-1205651.jpg',
          thumbnail: 'assets/img/thumbs/cap-celebrate-celebration-1205651.jpg',
          web: 'assets/img/thumbs/cap-celebrate-celebration-1205651.jpg'
        },
        created: faker.date.between('01/01/2020', '06/30/2020'),
        createdByUserFullName: 'Kate Contributor',
        modified: faker.date.between('01/01/2020', '06/30/2020'),
        modifiedByUserFullName: '',
        collectionId: id,
        collectionName: 'Parent',
        secondaryCollectionId: faker.random.number().toString(),
        secondaryCollectionName: 'Child'
      };
      // Yield a single value and complete
      observer.next(assetDetails);
      observer.complete();
    });
  }

  getAssetHistory(id: string): Observable<AssetRevisions[]> {
    return new Observable<AssetRevisions[]>(observer => {
      const historyRevisions = new Array<AssetRevisionsHistory>();
      const mockUser = {
        id,
        name: 'Mock User',
        role: 'Contributor'
      };
      historyRevisions.push({
        action: 'create',
        created: new Date(),
        user: mockUser
      });

      const assetHistory: AssetRevisions = {
        created: new Date(),
        history: historyRevisions,
        user: mockUser
      };
      observer.next([
        assetHistory
      ]);
      observer.complete();
    });
  }

  getAssets(sortField: number, collectionId: string, skip: number, pageSize: number, _sidebarSelection: LibrarySidebarSelectionType): Observable<Asset[]> {
    let assets = collectionId ?
      this.internalAssetList.filter(c => {
        return c.collectionId === collectionId;
      }) : this.internalAssetList.slice();

    switch (sortField) {
      case 0: // 'Recently Uploaded':
        assets.sort((s1, s2) => new Date(s2.created).getTime() - new Date(s1.created).getTime());
        break;
      case 1: // 'Last Modified':
        assets.sort((s1, s2) => new Date(s2.modified).getTime() - new Date(s1.modified).getTime());
        break;
      case 2: // 'A to Z':
        assets.sort((s1, s2) => s1.name.toLocaleLowerCase() > s2.name.toLocaleLowerCase() ? 1 : -1);
        break;
      case 3: // 'Z to A':
        assets.sort((s1, s2) => s1.name.toLocaleLowerCase() > s2.name.toLocaleLowerCase() ? -1 : 1);
        break;
      default:
    }

    // let assetSlice;
    if (assets.length < skip + pageSize) {
      assets = assets.slice(skip);
    } else {
      assets = assets.slice(skip, skip + pageSize);
    }

    return new Observable(observer => {
      // clone this internal list because store-freeze will make it immutable later in the dispatch pipeline
      const clone = JSON.parse(JSON.stringify(assets));

      // Yield a single value and complete
      observer.next(clone);
      observer.complete();
    });
  }

  getById(id: string): Observable<Asset> {
    return new Observable(observer => {
      const item = this.internalAssetList.find(x => x.id === id);
      // Yield a single value and complete
      observer.next(item);
      observer.complete();
    });
  }

  getPermalinkUri(_assetId: string): Observable<string> {
    throw new Error('Method not implemented.');
  }

  // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
  getPostUploadSummary(_uploadSessionId: string): Observable<PostUploadSummaryRow[]> {
    return new Observable(observer => {

      const rows = new Array<PostUploadSummaryRow>();
      const numCollections = faker.random.number({ min: 1, max: 4 });

      for (let i = 0; i < numCollections; i++) {

        const postUploadSummaryFileGroups = new Array<PostUploadSummaryFileGroup>();

        const numGroups = faker.random.number({ min: 1, max: 7 });
        for (let j = 0; j < numGroups; j++) {
          postUploadSummaryFileGroups.push({
            fileGroupType: FileGroupType[FileGroupType[j]],
            count: faker.random.number({ min: 1, max: 10 })
          });
        }

        rows.push({
          // TODO: The following two fields do not reflect the actually collections mock data. Some actions will not work correctly.
          collectionId: (i + 1).toString(),
          collectionName: faker.commerce.productName(),
          postUploadSummaryFileGroups
        });
      }

      observer.next(rows);
      observer.complete();
    });
  }

  loadAssetDesign(_id: string, _pageNumber: number): Observable<Design> {
    const textFrames: Frame[] = [
      // {
      //   content: 'Welcome to Jensen Rewards',
      //   height: 50,
      //   id: 'textFrame1',
      //   left: 200,
      //   top: 30,
      //   type: FrameType.Text,
      //   width: 400,
      //   textState: {
      //     fontSize: 24,
      //     fontStyle: 'Bold',
      //     foregroundColor: '#0000ff'
      //   }
      // },
      // {
      //   content: 'Michael Jordan',
      //   height: 24,
      //   id: 'textFrame2',
      //   left: 22,
      //   top: 180,
      //   type: FrameType.Text,
      //   width: 250,
      //   textState: {
      //     fontSize: 20,
      //     fontStyle: 'Bold',
      //     foregroundColor: '#ff0000'
      //   }
      // }
    ];
    const imageFrames: Frame[] = [
      // {
      //   content: 'jensen-logo.jpg',
      //   height: 74,
      //   id: 'imageFrame1',
      //   left: 22,
      //   top: 80,
      //   type: FrameType.Image,
      //   width: 167
      // },
      // {
      //   content: 'jensen-logo.jpg',
      //   height: 74,
      //   id: 'imageFrame2',
      //   left: 25,
      //   top: 712,
      //   type: FrameType.Image,
      //   width: 167
      // },
    ];
    const pages: Page[] = [
      {
        height: 500,
        // id: 'page1',
        imageFrames,
        textFrames,
        url: '',
        width: 500
      }
    ];
    const design: Design = {
      activePage: pages[0],
      hasSubsetFonts: true,
      id: 'My Design',
      pages
    }
    return of(design);
  }

  loadMetadataProfileInfo(): Observable<MetadataProfileInfo> {
    return new Observable(observer => {
      const metadataProfileInfo: MetadataProfileInfo = {
        metadataFields: this.internalMetadataFields,
        metadataFieldValues: [],
        metadataProfiles: this.internalMetadataProfiles,
        metadataProfileTypes: this.internalMetadataTypes
      };

      const clone = JSON.parse(JSON.stringify(metadataProfileInfo));
      // Yield a single value and complete
      observer.next(clone);
      observer.complete();
    });
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  loadSampleData(): Observable<any> {
    return of();
  }

  moveAssetsToCollection(assets: Asset[], collection: Collection): Observable<MoveAssetToCollectionResponse> {
    const ids: string[] = assets.map(u => u.id);
    const moveAssetToCollectionResponse: MoveAssetToCollectionResponse = {
      toCollectionId: collection.id,
      assetIds: ids.map(a => {
        const b: IdEntityResponse = { id: a };
        return b;
      })
    };
    return of(moveAssetToCollectionResponse);
    // return new Observable(observer => {
    //     const newArray: Asset[] = [];
    //     assets.forEach((asset: Asset) => {
    //         if (asset.viewState.selected) {
    //             const modifiedAsset: Asset = { ...asset };
    //             const itemToModify = this.internalAssetList.find(x => x.id === asset.id);
    //             const indexToModify = this.internalAssetList.indexOf(itemToModify);
    //             modifiedAsset.collectionId = collection.id;
    //             modifiedAsset.viewState = {
    //                 ...asset.viewState,
    //                 selected: false
    //             };
    //             this.internalAssetList.splice(indexToModify, 1, { ...modifiedAsset });
    //             newArray.push(modifiedAsset);
    //         }
    //     });
    //     const clone = JSON.parse(JSON.stringify(newArray));

    //     // Yield a single value and complete
    //     observer.next(clone);
    //     observer.complete();
    // });
  }

  queryAssets(sortField: number, collectionId: string, skip: number, pageSize: number, searchTerm: string): Observable<SearchResults> {

    let assets = collectionId ?
      this.internalAssetList.filter(c => {
        return c.collectionId === collectionId;
      }) : this.internalAssetList.slice();

    switch (sortField) {
      case 0: // 'Recently Uploaded':
        assets.sort((s1, s2) => new Date(s2.created).getTime() - new Date(s1.created).getTime());
        break;
      case 1: // 'Last Modified':
        assets.sort((s1, s2) => new Date(s2.modified).getTime() - new Date(s1.modified).getTime());
        break;
      case 2: // 'A to Z':
        assets.sort((s1, s2) => s1.name.toLocaleLowerCase() > s2.name.toLocaleLowerCase() ? 1 : -1);
        break;
      case 3: // 'Z to A':
        assets.sort((s1, s2) => s1.name.toLocaleLowerCase() > s2.name.toLocaleLowerCase() ? -1 : 1);
        break;
      default:
    }

    // let assetSlice;
    if (assets.length < skip + pageSize) {
      assets = assets.slice(skip);
    } else {
      assets = assets.slice(skip, skip + pageSize);
    }

    return new Observable(observer => {
      // clone this internal list because store-freeze will make it immutable later in the dispatch pipeline
      let clone = JSON.parse(JSON.stringify(assets));

      if (searchTerm?.length > 0) {
        const items = assets.filter(a => {
          return a.name.toString().toLocaleLowerCase().includes(searchTerm.toLocaleLowerCase());
        });
        // clone = JSON.parse(JSON.stringify(items));
        const searchResponse: SearchResults = {
          assetCount: items.length,
          assets: [...items],
          filters: null
        };
        clone = JSON.parse(JSON.stringify(searchResponse));
      }
      // Yield a single value and complete
      observer.next(clone);
      observer.complete();
    });
  }

  saveAssetMetadata(assets: Asset[], tags: Tag[], metadata: Metadata[]): Observable<AssetsAndMetadataAndTags> {
    return of({ assets, metadata, tags });
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  saveAssetsToHistoryUsage(action: string, assetIds: string[], actionDetails?: string): Observable<any> {
    return of({ action, assetIds, actionDetails });
  }

  sendComment(comment: Comment, _assetId: string): Observable<Comment> {
    return of(comment)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  updateAsset(asset: AssetUpdate): Observable<any> {
    throw new Error('Method not implemented.' + asset.id);
    // return new Observable(observer => {
    //     const itemToModify = this.internalAssetList.find(x => x.id === asset.id);
    //     const indexToModify = this.internalAssetList.indexOf(itemToModify);

    //     this.internalAssetList.splice(indexToModify, 1, { ...asset });

    //     // Yield a single value and complete
    //     observer.next(asset);
    //     observer.complete();
    // });
  }

  updateAssets(assets: Asset[]): Observable<Asset[]> {
    return new Observable(observer => {
      assets.forEach((asset: Asset) => {
        const itemToModify = this.internalAssetList.find(x => x.id === asset.id);
        const indexToModify = this.internalAssetList.indexOf(itemToModify);

        this.internalAssetList.splice(indexToModify, 1, { ...asset });
      });
      const clone = JSON.parse(JSON.stringify(this.internalAssetList));

      // Yield a single value and complete
      observer.next(clone);
      observer.complete();
    });
  }


    updateFavorite(assetId: string, isFavorite: boolean): Observable<Favorite> {
        const favorite = {
            assetId: assetId,
            favorite: isFavorite,
            fileName: 'IMG.jpg',
            name: 'IMG.jpg',
            totalFavorites: 5
        }
        return of(favorite);
    }

  updateFavorites(assetsIds: string[], isFavorite: boolean): Observable<Favorite[]> {
        const favorites = [];
        assetsIds.forEach((id) => {
            const favorite = {
              assetId: id,
              favorite: isFavorite,
              fileName: '',
              name: '',
              totalFavorites: 5
            }
            favorites.push(favorite)
        })
      return of(favorites);
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    updateMetadatum(metadatumDto: any): Observable<any> {
        return of(metadatumDto);
    }

  updateTag(tagDto: Tag): Observable<Tag> {
    return of(tagDto);
  }

  private getFileGroups(): string[] {
    return [
      FileGroupType[0].toString(),
      FileGroupType[1].toString(),
      FileGroupType[2].toString(),
      FileGroupType[3].toString(),
      FileGroupType[4].toString(),
      FileGroupType[5].toString(),
      FileGroupType[6].toString(),
      FileGroupType[7].toString(),
      FileGroupType[8].toString()
    ];
    // 7 is Error, not sure I need this in mock data
  }

  private getMockMetadata(assetId): Array<Metadata> {
    const metadata: Metadata[] = [
      { id: '1', assetId, metadataFieldId: '1', metadataFieldValueId: '1', value: 'Photo Mcgrapher' },
      { id: '2', assetId, metadataFieldId: '2', metadataFieldValueId: '1', value: 'August 05, 2020' },
      { id: '3', assetId, metadataFieldId: '3', metadataFieldValueId: '1', value: 'La Jolla Cove' },
      { id: '4', assetId, metadataFieldId: '4', metadataFieldValueId: '1', value: '' },
    ];
    return metadata;
  }

  private getMockMetadataFields(): Array<MetadataField> {
    const fields: MetadataField[] = [
      { id: '1', accountId: faker.random.number().toString(), expandField: false, metadataProfileId: '1', label: 'Photographer', previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Photographer', metadataFieldTypeId: FieldType.Text },
      { id: '2', accountId: faker.random.number().toString(), expandField: false, metadataProfileId: '1', label: 'Date image taken', previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Date image taken', metadataFieldTypeId: FieldType.Date },
      { id: '3', accountId: faker.random.number().toString(), expandField: false, metadataProfileId: '1', label: 'Location', previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Location', metadataFieldTypeId: FieldType.Text },
      { id: '4', accountId: faker.random.number().toString(), expandField: false, metadataProfileId: '1', label: 'Camera', previous: faker.random.number().toString(), fileGroup: null, placeholder: 'Camera', metadataFieldTypeId: FieldType.Text }
    ];
    return fields;
  }

  private getMockTags(): string[] {
    return ['Graduation', 'Fresno State', 'Bulldogs'];
  }
}
