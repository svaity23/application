﻿using ApplicationLogic.Logic;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace SignalRHub.Services
{
    public class NotificationService
    {
        private readonly ILogger<AssetService> _logger;
        private NotificationLogic _notificationLogic;

        public NotificationService(ILoggerFactory loggerFactory, IDbContextFactory dbContextFactory)
        {
            _logger = loggerFactory.CreateLogger<AssetService>();
            _notificationLogic = new NotificationLogic(dbContextFactory.CreateSignalRContext());
        }

        public async Task<string> GetNotificationByAssetCommentIdAsync(Guid assetCommentId)
        {
            return await _notificationLogic.GetNotificationByAssetCommentIdAsync(assetCommentId);
        }
    }
}
