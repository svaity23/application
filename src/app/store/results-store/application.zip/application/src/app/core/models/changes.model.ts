export interface Changes {
    newValue?: string;
    previousValue?: string;
}
