﻿using System;

namespace WebApi.Dtos.Notification
{
    public class NotificationAuthorDto
    {
        public Guid AuthorId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
