﻿using System;

namespace UploadAsset.Dtos
{
    public class AttachmentDto
    {
        public string AccountName { get; set; }
        public string AssetBlob { get; set; }
        public Guid AssetId { get; set; }
        public string ContainerName { get; set; }
        public AttachmentEntryDto[] Results { get; set; }
        public int StatusCode { get; set; }
    }
}
