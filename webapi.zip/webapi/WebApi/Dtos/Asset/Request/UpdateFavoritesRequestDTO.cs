﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos.Asset.Request
{
    public class UpdateFavoritesRequestDTO
    {
        public Guid[] Ids { get; set; }

        public bool IsFavorite { get; set; }
    }
}
