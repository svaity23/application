import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

import { cn } from 'src/utils/cn';

@Component({
  selector: 'app-utilities-details',
  templateUrl: './utilities-details.component.html',
  styleUrls: ['./utilities-details.component.scss']
})
export class UtilitiesDetailsComponent implements OnInit {
  @Input() className = '';
  @Output() indexAssetSearchAllAccountsEvent = new EventEmitter();

  constructor() { }

  index(): void {
    this.indexAssetSearchAllAccountsEvent.emit();
  }

  ngOnInit(): void {
    this.className = cn('utilities-details', this.className);
  }
}
