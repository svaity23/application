export const ACCOUNT_STORE_KEY = 'account-store';
export const ADMIN_STORE_KEY = 'admin-store';
export const EULA_STORE_KEY = 'eula-store';
export const LIBRARY_STORE_KEY = 'library-store';
export const LIGHTBOX_PUBLIC_STORE_KEY = 'lightbox-public-store';
export const ROUTER_STORE_KEY = 'app-router';
export const UPLOAD_STORE_KEY = 'upload-store';