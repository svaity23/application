﻿using System;
using System.Text.Json.Serialization;

namespace ApplicationLogic.Models
{
    public class HubspotEntity
    {
        [JsonPropertyName("fromCollectionId")]
        public Guid? FromCollectionId { get; set; }

        [JsonPropertyName("id")]
        public Guid Id { get; set; }
    }
}
