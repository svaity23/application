﻿using System;

namespace SignalRHub.Messages
{
    public class NotificationDTO
    {
        public Guid Id { get; set; }
        public DateTime Created { get; set; }
        public bool Read { get; set; }
        public string Type { get; set; }
        public NotificationCommentDTO Comment { get; set; }
    }
}
