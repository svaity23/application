﻿using System;

namespace WebApi.Dtos
{
    // Dto for response of stored procs:
    //          getAssetAndMetadataAndTagsByAssetId
    //          getAssetForPreview
    public class AssetPreviewDto
    {        
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime Created { get; set; }        
        public DateTime? Modified { get; set; }
        public Guid? CollectionId { get; set; }
        public int FileGroupType { get; set; } // todo standardize in stored proc these to match AssetDto?
        public string FileName { get; set; }
        public long? FileSize { get; set; }
        public string FileType { get; set; } // todo standardize in stored proc these to match AssetDto?
        public AttachmentDto Attachment { get; set; }
        public string CreatedByUserFullName { get; set; }  // todo standardize in stored proc these to match AssetDto?
        public string ModifiedByUserFullName { get; set; }  // todo standardize in stored proc these to match AssetDto?
        public string CollectionName { get; set; }
        public string SecondaryCollectionName { get; set; }
        public bool? Favorite { get; set; }
    }
}
