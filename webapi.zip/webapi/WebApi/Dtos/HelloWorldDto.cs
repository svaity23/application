﻿namespace WebApi.Dtos
{
    public class HelloWorldDto
    {
        public string Greeting { get; set; }
    }
}