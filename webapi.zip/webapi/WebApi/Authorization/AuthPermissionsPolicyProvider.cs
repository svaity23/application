﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Authorization
{
    public class AuthPermissionsPolicyProvider : DefaultAuthorizationPolicyProvider
    {
        public AuthPermissionsPolicyProvider(IOptions<AuthorizationOptions> options = null): base(options)
        {          
        }

        public override  async Task<AuthorizationPolicy> GetPolicyAsync(string policyName)
        {       
            // allows us to handle static policies still if defined
            var policy = await base.GetPolicyAsync(policyName);
            if (policy != null)
                return policy;

            var policyTokens = policyName.Split(';', StringSplitOptions.RemoveEmptyEntries);

            if (policyTokens?.Any() != true)
            {
                return await base.GetPolicyAsync(policyName);
            }

            var dynamicPolicy = new AuthorizationPolicyBuilder();
            var identifier = Guid.NewGuid(); // to group all requirements so we can succeed them together (OR evaluation)

            foreach (var token in policyTokens)
            {
                var pair = token.Split('$', StringSplitOptions.RemoveEmptyEntries);

                if (pair?.Any() != true || pair.Length != 2)
                {
                    return await base.GetPolicyAsync(policyName);
                }

                IAuthorizationRequirement requirement = (pair[0]) switch
                {
                    AuthorizePermissionsAttribute.RolesGroup => new RolesRequirement(pair[1], identifier),
                    AuthorizePermissionsAttribute.ScopesGroup => new ScopesRequirement(pair[1], identifier),
                    _ => null,
                };

                if (requirement == null)
                {
                    return await base.GetPolicyAsync(policyName);
                }

                dynamicPolicy.AddRequirements(requirement);
            }

            return await Task.FromResult(dynamicPolicy.Build());
        }
    }
}
