import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { Asset } from '../models/entities/asset.model';
import { BaseDataService } from './base-data.service';
import { DeleteHubspotAssetsResponse } from '../models/api-responses/delete-hubspot-assets-response';
import { HubspotSyncStatus } from '../models/hubspot/hubspot-sync-status.model';
import { UpsertHubspotAssetsResponse } from '../models/api-responses/upsert-hubspot-assets-response';

export interface HubspotAssetsDataServiceInterface {
  getAssets(sortField: number, lightboxId: string, skip: number, pageSize: number): Observable<Asset[]>;
  getHubspotSyncStatus(): Observable<HubspotSyncStatus>
  stopSyncToHubspotAssets(assets: Asset[]): Observable<DeleteHubspotAssetsResponse>;
  syncAllHubspotAssets(): Observable<boolean>;
  syncToHubspot(assets: Asset[]): Observable<UpsertHubspotAssetsResponse>;
}

@Injectable({ providedIn: 'root' })
export class HubspotAssetsDataService extends BaseDataService implements HubspotAssetsDataServiceInterface {
  getAssets(sortField: number, collectionId: string, skip: number, pageSize: number): Observable<Asset[]> {
    let params = new HttpParams()
      .set('sortField', sortField.toString())
      .set('skip', skip.toString())
      .set('pageSize', pageSize.toString());

    if (collectionId) {
      params = params.set('collectionId', collectionId);
    }

    const url = `${this.webApiUrl}/hubspot`;
    return this.createApiGet({ url, params });
  }

  getHubspotSyncStatus(): Observable<HubspotSyncStatus> {
    const url = `${this.webApiUrl}/hubspot/syncErrors`;
    return this.createApiGet({ url });
  }

  stopSyncToHubspotAssets(assets: Asset[]): Observable<DeleteHubspotAssetsResponse> {
    const ids: string[] = assets.map(u => u.id);
    const deleteHubspotAssetsRequest = {
      ids
    };
    const url = `${this.webApiUrl}/hubspot/bulk/deletes`;
    return this.createApiPost({ url, data: deleteHubspotAssetsRequest });
  }

  syncAllHubspotAssets(): Observable<boolean> {
    const url = `${this.webApiUrl}/hubspot/syncAll`;
    return this.createApiPost({ url }).pipe(
      map(() => {
        return true;
      }
      ));
  }

  syncToHubspot(assets: Asset[]): Observable<UpsertHubspotAssetsResponse> {
    const ids: string[] = assets.map(u => u.id);
    const upsertHubspotAssetsRequest = {
      ids
    };
    const url = `${this.webApiUrl}/hubspot/bulk/adds`;
    return this.createApiPost({ url, data: upsertHubspotAssetsRequest });
  }
}