﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ApplicationLogic.DomainModel
{
    [Table("accountType")]
    [Index(nameof(Name), Name = "uniq_accountType_accountId_name", IsUnique = true)]
    public partial class AccountType
    {
        public AccountType()
        {
            Account = new HashSet<Account>();
        }

        [Key]
        [Column("id")]
        public Guid Id { get; set; }
        [Column("active")]
        public bool Active { get; set; }
        [Column("created")]
        public DateTime Created { get; set; }
        [Column("modified")]
        public DateTime? Modified { get; set; }
        [Required]
        [Column("name")]
        [StringLength(64)]
        public string Name { get; set; }

        [InverseProperty("TypeNavigation")]
        public virtual ICollection<Account> Account { get; set; }
    }
}
