﻿using ApplicationLogic;
using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using WebApi.Dtos;

namespace WebApiTests.Shared
{
    public static class AzureSQLTools
    {
        /// <summary>
        /// Initialize the context using the VS credentials
        /// </summary>
        /// <returns></returns>
        public static damContext InitializeDamContext()
        {
            var configuration = new ConfigurationBuilder()
                                       .AddJsonFile("appsettings.json", true, true)
                                       .Build();

            var optionBuilder = new DbContextOptionsBuilder<damContext>();
            optionBuilder.UseSqlServer(configuration["ConnectionStrings:damDbConnection"]);

            var loggerFactory = (ILoggerFactory)new LoggerFactory();
            var logger = loggerFactory.CreateLogger<AzureAccessTokens>();

            damContext context = new damContext(optionBuilder.Options,
                            new AzureAccessTokens(logger),
                            new Microsoft.Extensions.Logging.Abstractions.NullLogger<damContext>(),
                            configuration);

            return context;
        }

        private static List<UserDetailDto> accountUsers;
        public static Guid AccountId = Guid.Empty;

        public static List<UserDetailDto> AccountUsers { get => accountUsers; }

        /// <summary>
        /// Returns the test user with the specified role and accountId
        /// </summary>
        /// <param name="context"></param>
        /// <param name="roleKey">one of the following: admin, contributor, viewer</param>
        /// <param name="accountId">the accountId for this test user</param>
        /// <returns></returns>
        public static UserDetailDto GetTestUser(damContext context, string roleKey, Guid accountId)
        {
            InitializeAccountUsers(context, accountId);

            var testUser = accountUsers
                            .Where(u => u.FirstName == "Test" && u.AccountId == accountId && u.Active && u.RoleKey == roleKey)
                            .First();

            return testUser;
        }

        private static void InitializeAccountUsers(damContext context, Guid accountId)
        {
            if (AccountId.Equals(accountId) && AccountUsers != null) return;

            AccountId = accountId;
            SimplifiedUserService userService = new SimplifiedUserService(context);
            accountUsers = userService.GetByAccountIdAsync(accountId).Result;
        }

        /// <summary>
        /// Returns the list of users of a specified account
        /// </summary>
        /// <param name="context"></param>
        /// <param name="roleKey">one of the following: admin, contributor, viewer</param>
        /// <returns></returns>
        public static List<UserDetailDto> GetAccountUsers(damContext context, Guid accountId)
        {
            var testUser = accountUsers
                            .Where(u => 
                                u.AccountId == accountId 
                                && u.Active
                                && u.FirstName == "Test")
                            .ToList();

            return testUser;
        }

    }
}
