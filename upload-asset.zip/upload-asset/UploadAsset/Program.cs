using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using System.Threading.Tasks;
using UploadAsset.Extensions;

namespace UploadAsset
{
    public static class Program
    {
        public static async Task Main(string[] args)
        {
            var host = CreateHostBuilder(args).Build();
            await host.InitializeAsync();
            host.Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder
                    .UseStartup<Startup>();
                })
                .ConfigureAppConfiguration(c =>
                {
                    c.AddJsonFile("ConfigMaps/appsettings.json", optional: true, reloadOnChange: false);
                    c.AddJsonFile("c:/damConfig/shared/appsettings.json", optional: true, reloadOnChange: true);
                });
    
    }
}
