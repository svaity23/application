import { Observable } from 'rxjs';

import { Asset } from '../entities/asset.model';
import { AssetForDetailsView } from '../asset-for-details-view.model';

export interface DownloadModalOptions {
    assetFile?: Observable<File>;
    assets: Asset[] | AssetForDetailsView[];
    cancel: () => void;
    download: (asset: Asset[] | AssetForDetailsView[], converstionType: number) => void;
  }
