﻿using System;

namespace WebApi.Dtos
{
    public class OneDriveUploadRequest
    {
        public Guid AssetId { get; set; }
        public string SignalRConnectionId { get; set; }
        public string Source { get; set; }
        public string FileGroup { get; set; }
        public string FileName { get; set; }
        public string OneDriveLink { get; set; }
        public Guid UploadSessionId { get; set; }
        public long FileSizeBytes { get; set; }
    }
}
