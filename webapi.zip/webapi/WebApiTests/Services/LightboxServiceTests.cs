﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Models;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Diagnostics;
using WebApi.Dtos;
using WebApi.Services;
using WebApiTests.Shared;

namespace WebApiTests.Services
{
    [TestClass]
    public class LightboxServiceTests
    {
        private static damContext dbContext;
        private static LightboxService _sut;

        private static readonly Guid TEST_ACCOUNT = Guid.Parse("5189526F-642F-449F-B018-5F5027A7191B"); // marcel@saguaro.ro
        private static readonly Guid TEST_USER = Guid.Parse("C42E63D8-383F-4BF2-9264-5FFE1767C931"); // marcel@saguaro.ro


        [ClassInitialize]
        public static void BeforeClass(TestContext context)
        {
            Debug.WriteLine("Before all tests");
            dbContext = AzureSQLTools.InitializeDamContext();

            var logger = LoggerFactory.Create(logConfig =>
            {
                logConfig.AddConsole();
            }).CreateLogger<LightboxService>();
            _sut = new LightboxService(
                        null,
                        logger,
                        null,
                        dbContext
                    );
        }

        [ClassCleanup]
        public static void AfterClass()
        {
            dbContext.Dispose();
        }


        [TestMethod("Test preview assets for account lightboxes")]
        public void TestPreviewAssets()
        {
            GetEntitiesResponse<LightboxPreviewDto> result = _sut.GetPreviewAssetsAsync(TEST_ACCOUNT, TEST_USER).Result;
            Assert.IsNotNull(result, "No result");
            Assert.IsNotNull(result.Entities, "No entities");
            Assert.IsNotNull(result.Error, "No error within result");
            Assert.IsTrue(result.Entities.Count > 0, "No error entries");

            foreach (LightboxPreviewDto dto in result.Entities) {
                Assert.IsNotNull(dto.Id, "No lightbox id");
                Assert.AreNotEqual(Guid.Empty, dto.Id, "Invalid lightbox id");
                Assert.IsNotNull(dto.PreviewAssets, "Null preview asset list");
                foreach (LightboxAssetDto asset in dto.PreviewAssets) {
                    Assert.IsTrue(asset.Active, "Wrong asset");
                }
            }

        }
    }
}
