﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos.Zapier
{
    public class ZapAssetInfo
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string FileName { get; set; }
        public int FileGroup { get; set; }
        public DateTime? ExpireOn { get; set; }
        public DateTime UploadDate { get; set; }
        public string UploadBy { get; set; }
        public TagDto Tags { get; set; }
        public string Author { get; set; }
        public string DateCreated { get; set; }
    }
}
