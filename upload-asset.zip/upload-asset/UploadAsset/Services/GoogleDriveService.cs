﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

using Google.Apis.Auth.OAuth2;
using Google.Apis.Drive.v3;
using Google.Apis.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace UploadAsset.Services
{
    public class GoogleDriveService
    {
        private readonly ILogger<GoogleDriveService> _logger;
        private readonly IConfiguration _configuration;
        private DriveService _driveService;

        public GoogleDriveService(IConfiguration configuration, ILogger<GoogleDriveService> logger, string accessToken) {
            
            _configuration = configuration;
            _logger = logger;
            _driveService = CreateClient(accessToken);
        }

        private DriveService CreateClient(string accessToken)
        {
            var credentials = GoogleCredential.FromAccessToken(accessToken);
            if (credentials != null)
            {
                var service = new DriveService(new BaseClientService.Initializer()
                {
                    HttpClientInitializer = credentials,
                    ApplicationName = "MarcomGather", // <- change
                });

                return service;
            }

            return null;
        }

        public async Task<Stream> GetFileAsStreamAsync(string fileId)
        {
            if (_driveService != null && !string.IsNullOrWhiteSpace(fileId))
            {   
                string uri = $"https://www.googleapis.com/drive/v3/files/{fileId}?alt=media";
                return await _driveService.HttpClient.GetStreamAsync(new Uri(uri));
            }

            await Task.CompletedTask;
            return null;
        }


        #region TEST METHODS ONLY --- TO BE DELETED

        public async Task<Google.Apis.Download.IDownloadProgress> DownloadFileAsync(string fileId, Stream stream)
        {
            if (_driveService != null && !string.IsNullOrWhiteSpace(fileId))
            {
                FilesResource.GetRequest request = _driveService.Files.Get(fileId);
                return await request.DownloadAsync(stream);
            }

            await Task.CompletedTask;
            return null;

        }

        public async Task DownloadFileToStreamAsync(string fileId, FileStream fileStream)
        {
            if (_driveService != null && !string.IsNullOrWhiteSpace(fileId))
            {
                FilesResource.GetRequest request = _driveService.Files.Get(fileId);

                // Add a handler which will be notified on progress changes.
                // It will notify on each chunk download and when the
                // download is completed or failed.   
                request.MediaDownloader.ProgressChanged += (Google.Apis.Download.IDownloadProgress progress) =>
                {
                    switch (progress.Status)
                    {
                        case Google.Apis.Download.DownloadStatus.Downloading:
                            {
                                Console.WriteLine(progress.BytesDownloaded);
                                break;
                            }
                        case Google.Apis.Download.DownloadStatus.Completed:
                            {
                                Console.WriteLine("Download complete.");
                                fileStream.Flush();
                                fileStream.Close();
                                break;
                            }
                        case Google.Apis.Download.DownloadStatus.Failed:
                            {
                                Console.WriteLine("Download failed.");
                                break;
                            }
                    }
                };
                await request.DownloadAsync(fileStream);

            }

            await Task.CompletedTask;
        }

        #endregion
    }

  
}
