﻿namespace WebApi.Enums
{
    public enum AccountTypeEnum
    {
        Basic,
        Evaluation,
        Trial,
        MCCInternal
    }
}
