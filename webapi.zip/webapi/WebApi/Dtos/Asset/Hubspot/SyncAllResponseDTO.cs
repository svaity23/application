﻿using System.Text.Json.Serialization;

namespace WebApi.Dtos.Asset.Hubspot
{
    public class SyncAllResponseDTO
    {
        [JsonPropertyName("assetCount")]
        public int AssetCount { get; set; }
    }
}
