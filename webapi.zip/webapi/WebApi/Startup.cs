using ApplicationLogic;
using ApplicationLogic.DomainModel.Context;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Azure.Storage.Blobs;
using Marcom.Azure.ServiceBus;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Common;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi
{
    public class Startup
    {
        const string AllowedOriginsPolicy = "AllowedOriginsPolicy";

        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IConfiguration _configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //IdentityModelEventSource.ShowPII = true;

            services.AddSwaggerGen(c => {
                c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo { Title = "Gather WebApi Documentation", Version = "v1" });
                c.IncludeXmlComments(XmlCommentsFilePath);
            });

            // setup the authentication from configuration
            services.AddAuthenticationAndAuthorizationPolicies(_configuration);

            AddCorsPolicy(services);
            services.AddControllers();

            services.AddDbContext<damContext>(
                options => options.UseSqlServer(_configuration["ConnectionStrings:damDbConnection"],
                o => o.EnableRetryOnFailure()),
                ServiceLifetime.Scoped
            );

            // FYI (https://stackoverflow.com/questions/38138100/addtransient-addscoped-and-addsingleton-services-differences)
            // Transient objects are always different; a new instance is provided to every controller and every service.
            // Scoped objects are the same within a request, but different across different requests.
            // Singleton objects are the same for every object and every request.
            services.AddSingleton<ServiceBusService>();
            services.AddScoped<CanvaService>();
            services.AddScoped<AccountService, AccountService>();
            services.AddScoped<AdminService, AdminService>();
            services.AddScoped<AssetService, AssetService>();
            services.AddScoped<AzureStorageService, AzureStorageService>();
            services.AddScoped<BlobService, BlobService>();
            services.AddScoped<DownloadService, DownloadService>();
            services.AddScoped<CollectionService, CollectionService>();
            services.AddScoped<LegalService, LegalService>();
            services.AddScoped<MetadataProfileService, MetadataProfileService>();
            services.AddScoped<PermalinkService, PermalinkService>();            
            services.AddScoped<RoleService, RoleService>();
            services.AddScoped<UploadService, UploadService>();
            services.AddScoped<UserAccountService, UserAccountService>();
            services.AddScoped<UserService, UserService>();
            services.AddScoped<GroupService, GroupService>();
            services.AddScoped<NotificationService, NotificationService>();
            services.AddScoped<SisenseService, SisenseService>();
            services.AddScoped<GoogleRecaptchaService, GoogleRecaptchaService>();
            services.AddScoped<LightboxService, LightboxService>();
            services.AddScoped<LightboxAssetService, LightboxAssetService>();
            services.AddScoped<HubspotService, HubspotService>();
            services.AddScoped<SettingService, SettingService>();
            services.AddScoped<IntegrationService, IntegrationService>();
            services.AddScoped<AzureAdB2cService, AzureAdB2cService>();
            services.AddScoped<ZapierService>();

            var defaultAzureCredential = new DefaultAzureCredential();
            if (_configuration["DotnetEnvironment"] != "local")  // the retry options makes getting the token the first time really slow.  Shows itself on keyvault service.
            {
                // DefaultAzureCredential with explicit retry and random retry delay               
                var defaultAzureCredentialOptions = new DefaultAzureCredentialOptions();
                defaultAzureCredentialOptions.Retry.Mode = Azure.Core.RetryMode.Exponential;
                defaultAzureCredentialOptions.Retry.MaxRetries = 5;
                defaultAzureCredentialOptions.Retry.MaxDelay = TimeSpan.FromSeconds(60);
                defaultAzureCredentialOptions.Retry.Delay = TimeSpan.FromSeconds(2);
                defaultAzureCredential = new DefaultAzureCredential(defaultAzureCredentialOptions);
            }

            // singletons
            services.AddSingleton<AzureAccessTokens, AzureAccessTokens>();
            services.AddSingleton<BlobServiceClient>(bsc => new BlobServiceClient(GetBlobStorageUri(_configuration["BlobStorage:StorageAccountName"]), defaultAzureCredential));
            services.AddSingleton<SecretClient>(sc => new SecretClient(new Uri(_configuration["KeyVault:Uri"]), defaultAzureCredential));
            services.AddSingleton<IBusServiceFactory, BusServiceFactory>();
            services.AddSingleton<Common.Health, Common.Health>();
            services.AddSingleton<ISearchAssetsServiceFactory, SearchAssetsServiceFactory>();
            services.AddSingleton<ITelemetryInitializer>(telemetry => new CloudRoleNameTelemetryInitializer("webapi"));
            services.AddApplicationInsightsTelemetry();
            services.AddSingleton<IGoogleServiceFactory, GoogleServiceFactory>();
            services.AddSingleton<IDropboxServiceFactory, DropboxServiceFactory>();
            services.AddSingleton<IOneDriveServiceFactory, OneDriveServiceFactory>();
            services.AddSingleton<KeyVaultService, KeyVaultService>();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            // global handler
            app.ConfigureGlobalExceptionMiddleware();

            app.UseSwagger();
            app.UseSwaggerUI(s =>
            {
                s.SwaggerEndpoint("swagger/v1/swagger.json", "OpenApi V1");
                s.RoutePrefix = string.Empty;
                s.DocumentTitle = "Gather WebApi Documentation";                
            });

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseCors(AllowedOriginsPolicy);

            app.UseAuthentication();

            app.UseAuthorization();

            // HttpContext.Request.ContentLength will give you how many bytes are being sent. This contains file as well as other form data.
            // Other form data is negligible (maybe 100 bytes give or take).
            // Setting maxRequestBodySize to null allows for any upload size. Without setting this the default is 30MBs.
            // The validateAndCreate stored proc should reject files that are too large before this container gets hit with the upload request.
            app.Use(async (context, next) =>
            {
                // MaxRequestBodySize is a nullable long. Setting it to null disables the limit like MVC's [DisableRequestSizeLimit]
                context.Features.Get<IHttpMaxRequestBodySizeFeature>().MaxRequestBodySize = null;
                await next.Invoke();
            });

            app.UseEndpoints(endpoints =>
            {
                // Configure the Health Check endpoint and require an authorized user.
                //endpoints.MapHealthChecks("/healthz").RequireAuthorization();

                endpoints.MapControllers();

                // Configure another endpoint, no authorization requirements.
                endpoints.MapGet("/", async context =>
                {
                    await context.Response.WriteAsync("{\"status\": \"OK\"}");
                });
            });
        }

        // Gets file upload size from app.settings. If entry is empty there will be no limit on upload size.

        private Task AuthenticationFailed(AuthenticationFailedContext arg)
        {
            if (arg.Exception.GetType() == typeof(SecurityTokenExpiredException))
            {
                // additional header, should already be additional info the WWW-Authenticate header field
                arg.Response.Headers["Token-Expired"] = "true";
            }

            // Should be removed from production code:
            //var s = $"AuthenticationFailed: {arg.Exception.Message}";
            //arg.Response.ContentLength = s.Length;
            //arg.Response.Body.WriteAsync(Encoding.UTF8.GetBytes(s), 0, s.Length);

            return Task.CompletedTask;
        }

        private void AddCorsPolicy(IServiceCollection services)
        {
            var origins = new List<string>();
            _configuration.GetSection("CorsOriginsEnabled").Bind(origins);

            if (origins.Count == 0 || !origins.Any(o => !string.IsNullOrWhiteSpace(o)))
            {
                throw new ApplicationException("CORS is not configured");
            }

            // NOTE: Some CORS errors happen because the CORS pre-flight gets a 500 server error.  Look for those before you assume this code or its config is wrong.
            services.AddCors(options =>
            {
                options.AddPolicy(AllowedOriginsPolicy,
                    builder =>
                    {
                        builder.WithOrigins(origins.ToArray())
                        .AllowAnyMethod()
                        .AllowAnyHeader()
                        .WithExposedHeaders("Content-Disposition") // Need this so content-disposition gets sent back to client on download. Used so client knows name of file being saved
                        .WithExposedHeaders("Token-Expired"); 
                    });
            });
        }
        
        private Uri GetBlobStorageUri(string storageAccountName)
        {
            return new Uri($"https://{storageAccountName}.blob.core.windows.net");
        }

        private string XmlCommentsFilePath
        {
            get
            {
                var basePath = AppContext.BaseDirectory;
                var fileName = typeof(Startup).GetTypeInfo().Assembly.GetName().Name + ".xml";
                return System.IO.Path.Combine(basePath, fileName);
            }
        }
    }
}
