﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class AdminController : ControllerBase
    {
        private readonly ILogger<AdminController> _logger;
        private readonly AccountService _accountService;
        private readonly AdminService _adminService;
        private readonly AssetService _assetService;
        private readonly UserService _userService;


        public AdminController(ILogger<AdminController> logger, AccountService accountService, AdminService adminService, AssetService assetService, UserService userService)
        {
            _accountService = accountService;
            _adminService = adminService;
            _assetService = assetService;
            _logger = logger;
            _userService = userService;
        }

        [HttpPost("deleteOldStorage")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> DeleteOldStorage()
        {
            var userId = this.User.GetUserId();

            // no claims tranformation yet, we need to pull user from db
            var hasAccess = await _userService.ValidateSysAdminAccess(userId);
            if (!hasAccess)
            {
                return StatusCode(StatusCodes.Status403Forbidden);
            }


            await _adminService.DeleteOldStorage();
            return Ok();

        }

        [HttpPost("syncUsers/{accountId}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> SendUserToSync(Guid accountId)
        {
            var userId = this.User.GetUserId();

            // no claims tranformation yet, we need to pull user from db
            var hasAccess = await _userService.ValidateSysAdminAccess(userId);
            if (!hasAccess)
            {
                return StatusCode(StatusCodes.Status403Forbidden);
            }


            var results = await _userService.GetByAccountIdAsync(accountId);
            foreach (var result in results)
            {
                await _userService.SyncUser(result.Id, accountId, result.Active);
            }
            return Ok();

        }

        /// <summary>
        /// Used for thumbnail generation
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        [HttpPost("processAssets/{accountId}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> ProcessAssets(Guid accountId)
        {
            var userId = this.User.GetUserId();

            // no claims tranformation yet, we need to pull user from db
            var hasAccess = await _userService.ValidateSysAdminAccess(userId);
            if (!hasAccess)
            {
                return StatusCode(StatusCodes.Status403Forbidden);
            }

            var assets = await _assetService.GetActiveAssets(accountId);
            var response = await _adminService.ProcessAssetsAsync(assets);

            return Ok(new { SuccessCount = response.Item1, ErrorCount = response.Item2 }); ;
        }

        [HttpPost("indexSearch/{accountId}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> IndexAssets(Guid accountId)
        {
            var userId = this.User.GetUserId();

            // no claims tranformation yet, we need to pull user from db
            var hasAccess = await _userService.ValidateSysAdminAccess(userId);
            if (!hasAccess)
            {
                return StatusCode(StatusCodes.Status403Forbidden);
            }


            await _assetService.ReindexAssetsAsync(accountId);
            return Ok();
        }

        [HttpPost("indexSearch")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> IndexAssetsForAllAccounts()
        {
            var userId = this.User.GetUserId();

            // no claims tranformation yet, we need to pull user from db
            var hasAccess = await _userService.ValidateSysAdminAccess(userId);
            if (!hasAccess)
            {
                return StatusCode(StatusCodes.Status403Forbidden);
            }


            // get all accounts and put a message on the bus to re-index it
            var results = await _accountService.GetAllAccountsAsync(false);
            foreach (var account in results)
            {
                await _assetService.ReindexAssetsAsync(account.Id);
            }
            return Ok();
        }
    }
}
