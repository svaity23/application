import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { DownloadDataServiceInterface } from '../data-services/download-data.service';

import { Asset } from '../models/entities/asset.model';
import { AssetDownloadRequest } from '../models/asset-download-request.model';
import { SignalRSource } from '../enums/signal-r-source.enum';

@Injectable({ providedIn:  'root' })
export class DownloadDataServiceMock implements DownloadDataServiceInterface {
  // To do:  Convert pdf to blob and return.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  downloadAssets(_ids: Array<AssetDownloadRequest>): Observable<any> {
    const url = '/assets/img/AwesomeDownload.pdf';
    return new Observable(observer => {
      // Yield a single value and complete
      console.log('url' + url);
      observer.complete();
    });
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  downloadFile(fileUrl: string): Observable<any> {
    throw new Error('Method not implemented.' + fileUrl);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  downloadFromContainer(containerName: string): Observable<any> {
    throw new Error('Method not implemented.' + containerName);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  downloadFromLightbox(_accountId: string, _assetDownloadRequests: AssetDownloadRequest[]): Observable<any> {
    throw new Error('Method not implemented.');
  }

	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	downloadLightboxPublicAssets(_accountId: string, _ids: string[]): Observable<any> {
		throw new Error('Method not implemented.');
	}

	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	downloadSharedAssets(_assetDownloadRequests: AssetDownloadRequest[], _daysValid: number): Observable<any> {
		throw new Error('Method not implemented.');
	}

	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	getSharedAccessTokenUri(_assets: Asset[], _daysValid: number): Observable<any> {
		throw new Error('Method not implemented.');
	}

	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	queueAssetDownload(_assetRequests: AssetDownloadRequest[], _source: SignalRSource, _conversionType?: number): Observable<any> {
		throw new Error('Method not implemented.');
	}
}
