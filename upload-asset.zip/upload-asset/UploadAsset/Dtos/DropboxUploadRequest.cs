﻿namespace UploadAsset.Dtos
{
    public class DropboxUploadRequest: BaseFileUploadRequest
    {
        public string DropboxLink { get; set; }
        public string FileName { get; set; }
        public long FileSizeBytes { get; set; }
    }
}
