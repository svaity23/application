import { AssetAttachment } from './asset-attachment.model';
import { AssetUris } from './asset-uris.model';
import { FileGroupType } from '../enums';

export interface NotificationAsset {
    assetUris?: AssetUris;
    attachment:AssetAttachment;
    fileGroup: FileGroupType;
    id: string;
    name: string;
}
