export interface ImageTag {
  confidence: number;
  name: string;
}
