import { LightboxAsset } from './lightbox-asset.model';

export interface LightboxAssetsForPreview {
  previewAssets: LightboxAsset[];
  lightboxId: string;
}
