export interface UpsertHubspotAssetsResponse {
    ids: string[];
 }