﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class IntegrationFinder
    {
        public ILogger<UserFinder> Logger { get; set; }

        private damContext _context;

        public IntegrationFinder(damContext context) {
            _context = context;
            Logger = NullLogger<UserFinder>.Instance;
        }

        public async Task<string> GetIntegrationSettingsByAccountIdAsync(Guid accountId)
        {
            Logger.LogInformation($"[Finder] Getting integration settings by accountId = {accountId}");
            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("getIntegrationSettingsByAccountId", parameters);
        }
    }
}
