import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { LightboxAssetsForPreview } from '../models/entities/lightbox-assets-for-preview.model';
import { LightboxDataServiceInterface } from '../data-services/lightbox-data.service';

import { Lightbox } from '../models/entities/lightbox.model';

@Injectable({ providedIn: 'root' })
export class LightboxDataServiceMock implements LightboxDataServiceInterface {

	constructor() {
	}

	add(_lightboxName: string): Observable<Lightbox> {
		throw new Error('Method not implemented.');
	}

	delete(_id: string): Observable<string> {
		throw new Error('Method not implemented.');
	}

	getAll(): Observable<Lightbox[]> {
		throw new Error('Method not implemented.');
  }

  getAllLightboxesAssetsForPreview(): Observable<LightboxAssetsForPreview[]> {
    throw new Error('Method not implemented.');
  }

	getById(_id: string): Observable<Lightbox> {
		throw new Error('Method not implemented.');
	}

	update(_lightbox: Lightbox): Observable<Lightbox> {
		throw new Error('Method not implemented.');
	}
}
