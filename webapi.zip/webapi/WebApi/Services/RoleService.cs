﻿using ApplicationLogic;
using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi.Dtos;

namespace WebApi.Services
{
    public class RoleService
    {
        private readonly ILogger<RoleService> _logger;
        private RoleLogic _roleLogic;

#pragma warning disable CA1801 // Review unused parameters
        public RoleService(IConfiguration configuration, ILogger<RoleService> logger, damContext context)
#pragma warning restore CA1801 // Review unused parameters
        {
            _logger = logger;
            _roleLogic = new RoleLogic(context);            
        }

        public async IAsyncEnumerable<Role> GetAccountRolesAsync(Guid accountId)
        {
            _logger.LogInformation($"[Service] Getting roles for account = {accountId}");

            var roles = _roleLogic.GetAccountRolesAsync(accountId);
            await foreach (var role in roles)
            {
                yield return role;
            }
        }

        public async Task<Role> GetRoleByIdAsync(Guid id)
        {
            return await _roleLogic.FindByIdAsync(id);
        }

        public async Task<Role> GetRoleByKeyAsync(string key)
        {
            return await _roleLogic.GetByKey(key);
        }

        public static RoleDto ToDto(Role role)
        {
            if (role == null)
            {
                return null;
            }

            return new RoleDto()
            {
                Id = role.Id,
                Key = role.Key,
                AccountId = role.AccountId,
                ExternalId = role.ExternalId,
                Active = role.Active,                
                Name = role.Name,
                Description = role.Description
            };
        }
    }
}
