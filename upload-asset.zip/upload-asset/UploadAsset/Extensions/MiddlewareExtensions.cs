﻿using Microsoft.AspNetCore.Builder;
using UploadAsset.Middleware;

namespace UploadAsset.Extensions
{
    public static class MiddlewareExtensions
    {
        public static void ConfigureGlobalExceptionMiddleware(this IApplicationBuilder app)
        {
            app.UseMiddleware<ExceptionHandlerMiddleware>();
        }
    }
}
