﻿using System;

namespace WebApi.Dtos
{
    public class MoveAssetsDto
    {
        public int TotalCount { get; set; }
        public int SuccessCount { get; set; }
        public int ErrorCount { get; set; }
    }
}
