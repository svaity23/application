﻿using System;

namespace WebApi.Dtos
{
    public class CollectionDto
    {
        public Guid Id { get; set; }        
        public string Name { get; set; }        
        public Guid? AccountId { get; set; }        
        public bool Active { get; set; }        
        public int AssetCount { get; set; }
        public int HubspotAssetCount { get; set; }
        public Guid? ParentId { get; set; }        
        public bool? Favorite { get; set; }
        public string VisibleTo { get; set; }
        public Guid[] GroupIds { get; set; }
    }
}
