import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { cn } from 'src/utils/cn';

@Component({
  selector: 'app-account-search',
  templateUrl: './account-search.component.html',
  styleUrls: ['./account-search.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountSearchComponent implements OnInit, OnChanges {
  @Output() addNewAccount = new EventEmitter();
  @Input() className = '';
  isEnabled = false;
  @Output() searchInputChange: EventEmitter<string> = new EventEmitter<string>();
  searchText: string;
  show = false;
  visible = true;

  constructor() { }

  create(): void {
    this.addNewAccount.emit();
  }

  filterAccounts(): void {
    this.searchInputChange.emit(this.searchText);
  }

  ngOnChanges(changes: SimpleChanges): void {
    // eslint-disable-next-line no-empty
    if (changes.className) {
    }

  }
  ngOnInit(): void {
    this.className = cn('account-search', this.className);
  }

  onInputTextFocus(): void {
    this.show = true;
    this.isEnabled = false;
  }

  toggleSearchButton(): void {
    this.show = true;
    this.isEnabled = true;
  }

}

