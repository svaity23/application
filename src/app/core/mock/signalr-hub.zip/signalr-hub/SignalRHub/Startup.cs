using Azure.Identity;
using Marcom.Azure.ServiceBus;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Logging;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using SignalRHub.Common;
using SignalRHub.DomainModel.Context;
using SignalRHub.Hub;
using SignalRHub.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SignalRHub
{
    public class Startup
    {
        const string AllowedOriginsPolicy = "AllowedOriginsPolicy";

        private IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            #region Auth

            IdentityModelEventSource.ShowPII = true;

            var azureAdB2COptions = new AzureAdB2COptions();
            Configuration.GetSection("AzureAdB2C").Bind(azureAdB2COptions);

            services.AddAuthentication(options =>
            {
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(jwtOptions =>
            {
                jwtOptions.Authority = azureAdB2COptions.Authority;
                jwtOptions.RequireHttpsMetadata = false;
                jwtOptions.Audience = azureAdB2COptions.Audience;

                jwtOptions.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidIssuer = azureAdB2COptions.Issuer, // NOTE: doesn't seem that it's checked, but new versions of middleware might so this line of code remains

                    ValidateAudience = true, // switch back to true once we plug in the Angular client id
                    ValidAudience = azureAdB2COptions.Audience,

                    ValidateIssuerSigningKey = true,
                    //IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:Key"])) // NOTE: is retrieved from well-known (discovery) endpoint

                    RequireExpirationTime = false,
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.Zero
                };

                jwtOptions.Events = new JwtBearerEvents
                {
                    OnAuthenticationFailed = AuthenticationFailed
                };
            });

            #endregion

            JsonConvert.DefaultSettings = () =>
            {
                var settings = new JsonSerializerSettings();
                settings.Converters.Add(new StringEnumConverter());
                settings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                settings.Formatting = Formatting.Indented;
                return settings;
            };
            
            // disables mapping on jwt claims to microsofts defaults
            System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.DefaultMapInboundClaims = false;

            services.AddSingleton<IUserIdProvider, UserIdProvider>();
            AddCorsPolicy(services);
            services.AddSignalR().AddAzureSignalR(Configuration["AzureSignalR:ConnectionString"]);
            
            services.AddHostedService<Worker>();

            services.AddDbContext<damContext>(
                options => options.UseSqlServer(
                    Configuration["ConnectionStrings:damDbConnection"], 
                    o => o.EnableRetryOnFailure()
                ), 
                ServiceLifetime.Singleton);

            services.AddSingleton(typeof(AzureServiceTokenProvider));
            services.AddSingleton<IDbContextFactory, DbContextFactory>();
            services.AddSingleton<IAssetServiceFactory, AssetServiceFactory>();
            services.AddSingleton<INotificationServiceFactory, NotificationServiceFactory>();
            services.Configure<ReceiveServiceBusesConfig>(Configuration.GetSection(ReceiveServiceBusesConfig.ReceiveServiceBusesSection));

            // FYI (https://stackoverflow.com/questions/38138100/addtransient-addscoped-and-addsingleton-services-differences)
            // Transient objects are always different; a new instance is provided to every controller and every service.
            // Scoped objects are the same within a request, but different across different requests.
            // Singleton objects are the same for every object and every request.
            services.AddSingleton<IBusServiceFactory, BusServiceFactory>();
            services.AddSingleton<ITelemetryInitializer>(telemetry => new CloudRoleNameTelemetryInitializer("signalr-hub"));
            services.AddApplicationInsightsTelemetry();

            // DefaultAzureCredential with explicit retry options
            var defaultAzureCredentialOptions = new DefaultAzureCredentialOptions();
            defaultAzureCredentialOptions.Retry.Mode = Azure.Core.RetryMode.Exponential;
            defaultAzureCredentialOptions.Retry.MaxRetries = 5;
            defaultAzureCredentialOptions.Retry.MaxDelay = TimeSpan.FromSeconds(60);
            defaultAzureCredentialOptions.Retry.Delay = TimeSpan.FromSeconds(2);
            services.AddSingleton<DefaultAzureCredential>(_ => new DefaultAzureCredential(defaultAzureCredentialOptions));

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseCors(AllowedOriginsPolicy);

            // Needed for mapping hub endpoint.
            app.UseRouting();

            // Need both for auth.
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHub<UploadHub>("/hubs/upload");
                endpoints.MapGet("/", async context =>
                {
                    await context.Response.WriteAsync("Status:OK");
                });
            });
        }

        private Task AuthenticationFailed(AuthenticationFailedContext arg)

        {
            if (arg.Exception.GetType() == typeof(SecurityTokenExpiredException))
            {
                // additional header, should already be additional info the WWW-Authenticate header field
                arg.Response.Headers.Add("Token-Expired", "true");
            }

            // Should be removed from production code:
            //var s = $"AuthenticationFailed: {arg.Exception.Message}";
            //arg.Response.ContentLength = s.Length;
            //arg.Response.Body.WriteAsync(Encoding.UTF8.GetBytes(s), 0, s.Length);

            return Task.CompletedTask;
        }

        private void AddCorsPolicy(IServiceCollection services)
        {
            var origins = new List<string>();
            Configuration.GetSection("CorsOriginsEnabled").Bind(origins);

            if (origins.Count > 0 && origins.Any(o => !string.IsNullOrWhiteSpace(o)))
            {
                services.AddCors(options =>
                {
                    options.AddPolicy(AllowedOriginsPolicy,
                        builder =>
                        {
                            builder
                            .WithOrigins(origins.ToArray())
                            .AllowAnyMethod()
                            .AllowAnyHeader()
                            .AllowCredentials();
                        });
                });
            }
            else
            {
                // good for dev environment.  Production/QA environments will require the app setting
                services.AddCors(options =>
                {
                    options.AddPolicy(AllowedOriginsPolicy,
                        builder =>
                        {
                            builder
                            .AllowAnyOrigin()
                            .AllowAnyMethod()
                            .AllowAnyHeader()
                            .AllowCredentials();
                        });
                });
            }
        }
    }
}
