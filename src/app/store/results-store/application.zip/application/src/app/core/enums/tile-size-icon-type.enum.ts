export enum TileSizeIconType {
    Small,
    Medium,
    Large
}
