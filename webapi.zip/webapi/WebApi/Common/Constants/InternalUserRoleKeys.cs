﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Common.Constants
{
    public static class InternalUserRoleKeys
    {
        public const string SystemAdmin = "sys-admin";
        public const string MccAdmin = "mcc-admin";
        public const string TrialUser = "trial";
    }
}
