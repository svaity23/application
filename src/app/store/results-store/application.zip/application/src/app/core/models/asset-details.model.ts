import { Asset } from './entities/asset.model';
import { AssetRevisionsHistory } from './asset-revisions-history.model';
import { Metadata } from './entities/metadata.model';
import { MetadataField } from './entities/metadata-field.model';
import { MetadataFieldAndValue } from './metadata-field-and-value.model';
// import { Tag } from './entities/tag.model';

/** View Model for Asset Details page (asset.component.html) */
export interface AssetDetails {
    asset: Asset;
    assetRevisions?: AssetRevisionsHistory[];
    createdByUserFullName: string;
    fileGroups: string[];
    metadata: Metadata[];
    metadataFields: MetadataField[];
    metadataFieldsAndValues: MetadataFieldAndValue[];
    modifiedByUserFullName: string;
    tags: string[]; // Tag[];
}

// export interface FieldAndValue {
//     metadata: Metadata;
//     metadataField: MetadataField;
//     metadataToModify: Metadata;
// }
