import { ChangeDetectionStrategy, Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Observable } from 'rxjs';

import { AppStoreFacade } from '@app/store/app-store/app-store.facade';
import { Context } from '@app/core/models/context.model';
import { CustomTheme } from '@app/core/models/custom-theme.model';
import { ToastIcon, ToastSeverity, ToastTimeout } from '@app/core/enums';

@Component({
  selector: 'app-general-information',
  templateUrl: './general-information.component.html',
  styleUrls: ['./general-information.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class GeneralInformationComponent implements OnInit {
  accountTypeName$: Observable<string>;
  context$: Observable<Context>;
  faviconUrl$: Observable<string>;
  logoUrl$: Observable<string>;
  selectedTheme$: Observable<CustomTheme>;
  showBrandedUx$: Observable<boolean>;
  showIntegrations$: Observable<boolean>;
  showUserGroups$: Observable<boolean>;

  constructor(private appStoreFacade: AppStoreFacade) { }

  navigateTo(pageName: string): void {
    this.appStoreFacade.navigate(`account/${pageName}`);
  }

  ngOnInit(): void {
    this.appStoreFacade.setPageTitle('Account Information | MarcomGather');
    this.accountTypeName$ = this.appStoreFacade.accountTypeName$;
    this.context$ = this.appStoreFacade.context.context$;
    this.faviconUrl$ = this.appStoreFacade.faviconUrl$;
    this.logoUrl$ = this.appStoreFacade.logoUrl$;
    this.selectedTheme$ = this.appStoreFacade.selectedTheme$;
    this.showBrandedUx$ = this.appStoreFacade.context.isBrandedUxFeatureEnabled$;
    this.showIntegrations$ = this.appStoreFacade.showIntegrations$;
    this.showUserGroups$ = this.appStoreFacade.context.isUserGroupsFeatureEnabled$;
  }

  resetToDefaultFavicon(): void {
    this.appStoreFacade.resetToDefaultFavicon();
  }

  resetToDefaultLogo(): void {
    this.appStoreFacade.resetToDefaultLogo();
  }

  showFaviconSizeErrorToast(): void {
    this.appStoreFacade.showToast({ message: 'Supported Favicon Max height is 128px and Max width is 128px', icon: ToastIcon.InfoCircle, severity: ToastSeverity.Warning, timeout: ToastTimeout.Default });
  }

  showFaviconTypeErrorToast(): void {
    this.appStoreFacade.showToast({ message: 'Supported file type is ICO', icon: ToastIcon.InfoCircle, severity: ToastSeverity.Warning, timeout: ToastTimeout.Default });
  }

  showFileSizeErrorToast(): void {
    this.appStoreFacade.showToast({ message: 'Supported Logo Max height is 40px and Max width is 230px', icon: ToastIcon.InfoCircle, severity: ToastSeverity.Warning, timeout: ToastTimeout.Default });
  }

  showFileTypeErrorToast(): void {
    this.appStoreFacade.showToast({ message: 'Supported file types are PNG or JPG', icon: ToastIcon.InfoCircle, severity: ToastSeverity.Warning, timeout: ToastTimeout.Default });
  }

  updateTheme(theme): void {
    this.appStoreFacade.updateTheme(theme);
  }
  uploadFavicon(file: File): void {
    this.appStoreFacade.uploadFavicon(file);
  }

  uploadLogo(file: File): void {
    this.appStoreFacade.uploadLogo(file);
  }
}
