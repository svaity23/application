﻿namespace WebApi.Enums
{
    // This Enum seems a little dumb. Could this maybe be split up into resolution type and conversion file type?
    public enum DownloadConversionType
    {
        PrintQualityJpgHighResolution,
        PrintQualityPngHighResolution,
        ScreenQualityJpgLowResolution,
        ScreenQualityPngLowResolution,
        ScreenQualityPdfLowResolution,
        OriginalQualityJpg
    }
}
