import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { BaseDataService } from './base-data.service';

import { HUBSPOT_CREDENTIALS_SETTINGS_KEY } from '../constants/frontend-setting-key';
import { HubspotAuthentication } from '../models/hubspot/hubspot-authentication.model';
import { HubspotCredentials } from '../models/hubspot/hubspot-credentials.model';
import { Setting } from '../models/setting.model';

export interface HubSpotDataServiceInterface {
  getTokens(hubspotConfig: HubspotAuthentication): Observable<string>;
  resetHubspotCredentials(): Observable<Setting>
  saveHubspotCredentials(hubspotCredentials: HubspotCredentials): Observable<Setting>;
}

@Injectable({ providedIn: 'root' })
export class HubSpotDataService extends BaseDataService implements HubSpotDataServiceInterface {
  getTokens(hubspotAuthentication: HubspotAuthentication): Observable<string> {
    const formData: FormData = new FormData();
    formData.append('code', hubspotAuthentication.accessCode);
    formData.append('grant_type', 'authorization_code');
    formData.append('client_id', hubspotAuthentication.clientId);
    formData.append('redirect_uri', hubspotAuthentication.redirectUri);

    const url = `${this.webApiUrl}/integration/hubspot/tokens`;
    return this.createApiPost({ url, data: formData });
  }

  resetHubspotCredentials(): Observable<Setting> {
    const hubspotCredentialsDto = {
        key: HUBSPOT_CREDENTIALS_SETTINGS_KEY,
        valueType: 3,
        stringValue: ''
    };
    const url = `${this.webApiUrl}/settings/account`;

    return this.createApiPut({ url, data: hubspotCredentialsDto });
  }

  saveHubspotCredentials(hubspotCredentials: HubspotCredentials): Observable<Setting> {
    const hubspotCredentialsDto = {
        key: HUBSPOT_CREDENTIALS_SETTINGS_KEY,
        valueType: 3,
        stringValue: JSON.stringify(hubspotCredentials)
    };
    const url = `${this.webApiUrl}/hubspot/login`;

    return this.createApiPut({ url, data: hubspotCredentialsDto });
  }
}
