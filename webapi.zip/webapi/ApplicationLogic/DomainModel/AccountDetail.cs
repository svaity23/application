﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ApplicationLogic.DomainModel
{
    [Keyless]
    public partial class AccountDetail
    {
        [Column("id")]
        public Guid Id { get; set; }
        [Column("externalId")]
        [StringLength(64)]
        public string ExternalId { get; set; }
        [Column("active")]
        public bool Active { get; set; }
        [Column("created")]
        public DateTime Created { get; set; }
        [Column("modified")]
        public DateTime? Modified { get; set; }
        [Column("type")]
        public Guid Type { get; set; }
        [Required]
        [Column("name")]
        [StringLength(64)]
        public string Name { get; set; }
        [Column("userId")]
        public Guid? UserId { get; set; }
        [Column("storageAccountName")]
        [StringLength(24)]
        public string StorageAccountName { get; set; }
        [Column("error")]
        public string Error { get; set; }
        [Column("salesforceId")]
        [StringLength(64)]
        public string SalesforceId { get; set; }
        [Column("trialExpiration")]
        public DateTime? TrialExpiration { get; set; }
        [Required]
        [Column("userFirstName")]
        [StringLength(64)]
        public string UserFirstName { get; set; }
        [Column("userLastName")]
        [StringLength(64)]
        public string UserLastName { get; set; }
        [Required]
        [Column("userEmail")]
        [StringLength(320)]
        public string UserEmail { get; set; }
        [Required]
        [Column("accountTypeName")]
        [StringLength(64)]
        public string AccountTypeName { get; set; }
        [Column("netsuiteId")]
        [StringLength(64)]
        public string NetsuiteId { get; set; }
        [Column("opportunityId")]
        [StringLength(64)]
        public string OpportunityId { get; set; }
        [Column("storageMaximumGb")]
        public int? StorageMaximumGb { get; set; }
        [Column("trialVerified")]
        public bool? TrialVerified { get; set; }
        [Column("federatedDomains")]
        public string FederatedDomains { get; set; }
    }
}
