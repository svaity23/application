﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using SignalRHub.DomainModel.Context;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SignalRHub.DomainModel.Finders
{
    public class NotificationFinder
    {
        public ILogger<NotificationFinder> Logger { get; set; }

        private damContext _context;
        private const string ASSET_COMMENT_ID = "@assetCommentId";
        private const string GET_NOTIFICATION_BY_ASSET_COMMENT_ID = "getNotificationByAssetCommentId";

        public NotificationFinder(damContext context)
        {
            _context = context;
            Logger = NullLogger<NotificationFinder>.Instance;
        }

        public async Task<string> GetNotificationByAssetCommentIdAsync(Guid assetCommentId)
        {
            Logger.LogInformation(assetCommentId.ToString()); 
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter(ASSET_COMMENT_ID, assetCommentId));
            return await _context.ExecuteNonQueryJsonOutputAsync(GET_NOTIFICATION_BY_ASSET_COMMENT_ID, parameters);
        }      
    }
}
