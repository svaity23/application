import { Asset } from './entities/asset.model';

// Used to update the upload progress of an Asset during the upload workflow.
export interface AssetUploadProgress {
  asset: Asset;
  error?: Error;
  progress: number;
}
