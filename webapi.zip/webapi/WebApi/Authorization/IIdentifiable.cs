﻿using System;

namespace WebApi.Authorization
{
    public interface IIdentifiable
    {
        Guid Identifier { get; }
    }
}
