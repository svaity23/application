﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.IO;
using System.Threading.Tasks;
using UploadAsset.Dtos;
using UploadAsset.Extensions;
using UploadAsset.Services;

namespace UploadAsset.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class DropboxFileController : ControllerBase
    {
        private readonly ILogger<DropboxFileController> _logger;
        private readonly IDropboxServiceFactory _dropboxServiceFactory;
        private readonly UploadService _uploadService;
        private readonly UserAccountService _userAccountService;        

        public DropboxFileController(ILogger<DropboxFileController> logger, IDropboxServiceFactory dropboxServiceFactory, UploadService uploadService, UserAccountService userAccountService)
        {
            _logger = logger;
            _dropboxServiceFactory = dropboxServiceFactory;
            _uploadService = uploadService;
            _userAccountService = userAccountService;

            logger.LogDebug("Unconditional debug line");
        }

        /// <summary>
        /// Upload file from dropbox
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task Upload([FromBody] DropboxUploadRequest request)
        {
            try
            {
                if (!string.IsNullOrEmpty(request.DropboxLink))
                {
                    var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
                    var userId = this.User.GetUserId();

                    var service = _dropboxServiceFactory.CreateDropboxService();
                    await _uploadService.UploadDropboxFileAsync(Response, service, request, accountId, userId);
                    await Response.CompleteAsync();
                }
                else
                {
                    Response.StatusCode = StatusCodes.Status500InternalServerError;
                }
            }
            catch (BadHttpRequestException ex)
            {
                _logger.LogWarning(ex, "BadHttpRequest");

                // Incase we can't gaurantee that BadHttpRequestException has a StatusCode of Status413PayloadTooLarge...
                // Check for it here and return appropriate status code.
                // This scenario should not really occur. The validateAndCreate sproc should reject files that are too large and this 
                // request should not occur.
                if (ex.StatusCode == StatusCodes.Status413PayloadTooLarge)
                {
                    Response.StatusCode = StatusCodes.Status500InternalServerError;
                }

                // Let error pass threw and have ExceptionHandlerMiddleware handle it.
                throw;
            }
            catch (IOException ioEx)
            {
                // Upload cancelled.
                _logger.LogWarning(ioEx, "Upload cancelled");
            }

        }
    }
}
