﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos
{
    public class MetadataDto
    {
        public Guid? Id { get; set; }        
        public Guid? AccountId { get; set; }
        public bool Active { get; set; }
        public DateTime Created { get; set; }
        public DateTime? Modified { get; set; }
        public string Value { get; set; }
        public Guid AssetId { get; set; }
        public Guid MetadataFieldId { get; set; }
        public Guid? MetadataFieldValueId { get; set; }
    }
}
