import { FileProviderType } from '@app/core/enums/file-provider-type.enum';

import { CustomTheme } from '../custom-theme.model';
import { FileSystemFile } from '../file-system-file.model';

export interface UploadModalOptions {
  onDropboxClicked: () => void;
  onFilesSelected: (files: FileSystemFile[]) => void;
  onGoogleDriveClicked: () => void;
  onOneDriveClicked: () => void;
  selectedTheme?: CustomTheme;
  visibleFileProviders?: FileProviderType[];
}
