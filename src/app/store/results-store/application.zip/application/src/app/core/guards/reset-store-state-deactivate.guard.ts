import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';

import { AppStoreFacade } from '@app/store/app-store/app-store.facade';

@Injectable({
  providedIn: 'root'
})
export class ResetStoreStateDeactivateGuard implements CanDeactivate<unknown> {

  constructor(private appStoreFacade: AppStoreFacade) { }

  canDeactivate(
    _component: unknown,
    currentRoute: ActivatedRouteSnapshot,
    _currentState: RouterStateSnapshot,
    _nextState?: RouterStateSnapshot): boolean {

    this.appStoreFacade.resetStoreState(currentRoute.data.storeKey);
    return true;
  }

}
