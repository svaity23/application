﻿using System;
using System.Text.Json.Serialization;

namespace WebApi.Dtos.Asset.Response
{
    public class AssetUpdateDto
    {
        [JsonPropertyName("description")]
        public string Description { get; set; }

        [JsonPropertyName("expired")]
        public bool? Expired { get; set; }

        [JsonPropertyName("expireOn")]
        public DateTime? ExpireOn { get; set; }

        [JsonPropertyName("favorite")]
        public bool? Favorite { get; set; }

        [JsonPropertyName("fileName")]
        public string FileName { get; set; }

        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [JsonPropertyName("modified")]
        public DateTime? Modified { get; set; }

        [JsonPropertyName("modifiedByUserFullName")]
        public string ModifiedByUserFullName { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("sharedOnHubSpot")]
        public int? SharedOnHubSpot { get; set; }

    }
}
