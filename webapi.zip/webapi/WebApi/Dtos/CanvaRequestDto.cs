﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WebApi.Dtos
{
    public class CanvaRequestDto
    {
        [JsonPropertyName("user")]
        public string User { get; set; }
        [JsonPropertyName("brand")] 
        public string Brand { get; set; }
        [JsonPropertyName("limit")] 
        public int Limit { get; set; }
        [JsonPropertyName("types")] 
        public string[] Types { get; set; }
        [JsonPropertyName("continuation")] 
        public string Continuation { get; set; }
        [JsonPropertyName("containerId")] 
        public string ContainerId { get; set; }

    }
}
