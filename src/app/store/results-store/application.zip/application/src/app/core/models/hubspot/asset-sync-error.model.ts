import { AssetAttachment } from '../asset-attachment.model';
import { AssetUris } from '../asset-uris.model';
import { SyncError } from './sync-error.model';


export interface AssetSyncError {
    assetUris?: AssetUris;
    attachment?: AssetAttachment;
    collection?: string;
    error: SyncError;
    id: string; // guid
    name: string;
}
