import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { SearchDataServiceInterface } from '../data-services/search-data.service';

import { FilterGroupType } from '../enums/filter-group-type.enum';
import { SearchFilters } from '../models/search-filters.model';
import { SearchSuggestion } from '../models/search-suggestion.model';

@Injectable({ providedIn: 'root' })
export class SearchDataServiceMock implements SearchDataServiceInterface {

  constructor() {
  }

  getFilters(): Observable<SearchFilters> {
    return new Observable(observer => {

      const searchFilters: SearchFilters = {
        aggregations: [],
        groups: []
      };

      searchFilters.groups.push({ filterGroupType: FilterGroupType.FileGroup, metadataFieldId: null, name: 'Type', displayOrder: 0 });
      searchFilters.groups.push({ filterGroupType: FilterGroupType.UploadDate, metadataFieldId: null, name: 'Upload Date', displayOrder: 1 });
      searchFilters.groups.push({ filterGroupType: FilterGroupType.FileSize, metadataFieldId: null, name: 'File Size', displayOrder: 2 });
      searchFilters.groups.push({ filterGroupType: FilterGroupType.Tags, metadataFieldId: null, name: 'Tags', displayOrder: 3 });

      searchFilters.aggregations.push({
        filterGroupType: FilterGroupType.FileGroup, name: 'fileGroup',
        buckets: [
          { count: 66, name: '0' },
          { count: 232, name: '5' }
        ]
      });
      searchFilters.aggregations.push({
        filterGroupType: FilterGroupType.FileSize, name: 'fileSize',
        buckets: [
          { count: 0, name: 'Min:209' },
          { count: 0, name: 'Max:1258331' }
        ]
      });
      searchFilters.aggregations.push({
        filterGroupType: FilterGroupType.UploadDate, name: 'uploadDate',
        buckets: [
          { count: 6487, name: 'all' },
          { count: 454, name: 'month' },
          { count: 300, name: 'week' },
          { count: 23, name: 'today' },
          { count: 0, name: 'custom' }  // TODO: Add this in the service or have it come back from webapi
        ]
      });
      searchFilters.aggregations.push({
        filterGroupType: FilterGroupType.Tags, name: 'tags',
        buckets: [
          { count: 66, name: 'Dog' },
          { count: 232, name: 'Cat' }
        ]
      });
      searchFilters.aggregations.push({
        filterGroupType: FilterGroupType.Metadata, name: '38196b0f-4109-4085-bc24-ab71d9bea577',
        buckets: [
          { count: 2, name: 'test' }
        ]
      });
      searchFilters.aggregations.push({
        filterGroupType: FilterGroupType.Metadata, name: '4da08138-80d1-47ef-9d64-c56ec7a4431b',
        buckets: [
          { count: 2, name: 'fri dec 04 2020' }
        ]
      });

      // clone this internal list because store-freeze will make it immutable later in the dispatch pipeline
      const clone = JSON.parse(JSON.stringify(searchFilters));

      // Yield a single value and complete
      observer.next(clone);
      observer.complete();
    });
  }

  getSearchSuggestions(_searchTerm: string): Observable<SearchSuggestion[]> {
    return new Observable(observer => {

      let items: SearchSuggestion[] = [
        { name: 'Study', count: 100 },
        { name: 'Administration', count: 110 },
        { name: 'Students', count: 200 },
        { name: 'General Studies', count: 2500 },
        { name: 'Stadium', count: 5 },
        { name: 'Art History', count: 3 },
        { name: 'Chemistry', count: 44 },
        { name: 'Student Council', count: 2 },
        { name: 'History', count: 234 }
      ];

      items = items.filter(i => i.name.toLowerCase().indexOf(_searchTerm.toLowerCase()) > -1);

      // clone this internal list because store-freeze will make it immutable later in the dispatch pipeline
      const clone = JSON.parse(JSON.stringify(items));

      // Yield a single value and complete
      observer.next(clone);
      observer.complete();
    });
  }
  getTagsSuggestions(_searchTerm: string): Observable<string[]> {
    return new Observable(observer => {

      let items: string[] = [
        'Classroom',
        'Dark',
        'Design',
        'Digital Marketing',
        'Marked for Distribution',
        'Students'
      ];

      items = items.filter(i => i.toLowerCase().indexOf(_searchTerm.toLowerCase()) > -1);

      // clone this internal list because store-freeze will make it immutable later in the dispatch pipeline
      const clone = JSON.parse(JSON.stringify(items));

      // Yield a single value and complete
      observer.next(clone);
      observer.complete();
    });
  }
}
