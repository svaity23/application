﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Dtos;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class IntegrationController : ControllerBase
    {
        private readonly ILogger<IntegrationController> _logger;
        private readonly IConfiguration _configuration;
        private readonly IntegrationService _integrationService;
        private readonly KeyVaultService _keyVaultService;
        private readonly UserAccountService _userAccountService;
        private HttpClient _httpClient = new HttpClient();

        private readonly Dictionary<string, string> _secretKeys = new Dictionary<string, string>()
        {
            { "hubspot", "KeyVault:Secrets:HubspotClientSecret" },
            { "slack", "KeyVault:Secrets:SlackClientSecret" }
        };
        private readonly Dictionary<string, string> _tokenUrlKeys = new Dictionary<string, string>()
        {
            { "hubspot", "Integration:Hubspot:TokensUrl" },
            { "slack", "Integration:Slack:TokensUrl" }
        };

        public IntegrationController(ILogger<IntegrationController> logger, IConfiguration configuration, IntegrationService integrationService, KeyVaultService keyVaultService, UserAccountService userAccountService)
        {
            _logger = logger;
            _configuration = configuration;
            _keyVaultService = keyVaultService;
            _integrationService = integrationService;
            _userAccountService = userAccountService;
        }

        [HttpPost("{client}/tokens")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetTokens(string client)
        {
            _logger.LogInformation($"GetTokens for {client}.");
             var clientSecret = GetClientSecret(client);

            List<KeyValuePair<string, string>> formContent = new List<KeyValuePair<string, string>>();
            foreach(var e in this.Request.Form)
            {
                formContent.Add(KeyValuePair.Create<string, string>(e.Key, e.Value));
            }
            formContent.Add(KeyValuePair.Create<string, string>("client_secret", clientSecret));
            HttpContent content = new FormUrlEncodedContent(formContent);

            var tokensUrl = _configuration[$"{_tokenUrlKeys.GetValueOrDefault(client)}"];
            HttpResponseMessage response = await _httpClient.PostAsync(tokensUrl, content);
            if (response.IsSuccessStatusCode)
            {
                string body = await response.Content.ReadAsStringAsync();
                _logger.LogDebug("Response: " + body);
                return Ok(body);
            }
            else
            {
                var errCode = ((int)response.StatusCode);
                string body = await response.Content.ReadAsStringAsync();
                _logger.LogError($"Received HTTP ERROR: {errCode}\r\n{body}");
                
                return new StatusCodeResult(errCode);
            }
        }

        private string GetClientSecret(string client)
        {
            Dictionary<string, string> localSecretKeys = new Dictionary<string, string>()
            {
                { "hubspot", "Integration:Hubspot:ClientSecret" },
                { "slack", "Integration:Slack:ClientSecret" }
            };

            var env = _configuration["DotnetEnvironment"];
            bool isLocal = env.ToLowerInvariant() == "local";
            var localKey = localSecretKeys[client];
            if (isLocal && !string.IsNullOrEmpty(_configuration.GetValue<string>(localKey)))
            {
                _logger.LogInformation("Dev mode: Get local client secret: " + localKey);
                return _configuration[localKey];
            }
            else
                return _keyVaultService.GetSecret(_secretKeys.GetValueOrDefault(client));

        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IntegrationDto))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UpsertIntegration([FromBody] IntegrationDto integrationDto)
        {

            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            if (integrationDto == null) return BadRequest();

            if (string.IsNullOrEmpty(integrationDto.Token))
            {
                ModelState.AddModelError("Token", "Missing Token");
            }
            if (string.IsNullOrEmpty(integrationDto.Key))
            {
                ModelState.AddModelError("Key", "Missing Key");
            }
            if (ModelState.ErrorCount > 0)
                return BadRequest(ModelState);
            var results = await _integrationService.UpsertIntegrationAsync(accountId, userId, integrationDto);
            //TODO: review error codes
            if (results != null)
            {
                int err = results.Errors[0].Code;
                return err switch
                {
                    0 => StatusCode(StatusCodes.Status201Created, results.Entity),
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }

            return Ok();
        }


        [HttpGet("marcom")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<IntegrationDto>))]
        public async Task<IActionResult> GetMarcomIntegrations()        
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);

            var integrations = await _integrationService.GetMarcomIntegrations(accountId);

            return Ok(integrations);
        }

    }
}
