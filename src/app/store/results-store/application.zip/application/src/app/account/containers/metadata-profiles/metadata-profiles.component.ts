import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import { AccountMetadataProfilesStoreFacade } from '@app/store/account-store/account-metadata-profile.facade';
import { AppRouterReducerState } from '@app/store/router-store/reducers/app-router.reducer';
import { AppStoreFacade } from '@app/store/app-store/app-store.facade';
import { Context } from '@app/core/models/context.model';
import { MetadataProfileView } from '@app/core/models/metadata-profile-view.model';
import { Role } from '@app/core/models/entities/role.model';

@Component({
  selector: 'app-metadata-profiles',
  templateUrl: './metadata-profiles.component.html',
  styleUrls: ['./metadata-profiles.component.scss']
})
export class MetadataProfilesComponent implements OnInit {
  accountTypeName$: Observable<string>;
  context$: Observable<Context>;
  profiles$: Observable<MetadataProfileView[]>;
  roles$: Observable<Role[]>;
  route$: Observable<AppRouterReducerState>;
  showIntegrations$: Observable<boolean>;
  showUserGroups$: Observable<boolean>;

  constructor(private appStoreFacade: AppStoreFacade,
    private accountMetadataProfilesStoreFacade: AccountMetadataProfilesStoreFacade) { }

  editProfile(profile: MetadataProfileView): void {
    this.appStoreFacade.navigate(`account/metadata-profiles/${profile.id}`);
  }

  navigateTo(pageName): void {
    this.appStoreFacade.navigate(`account/${pageName}`);
  }

  ngOnInit(): void {
    this.appStoreFacade.setPageTitle('Metadata Profiles | MarcomGather');
    this.accountTypeName$ = this.appStoreFacade.accountTypeName$;
    this.context$ = this.appStoreFacade.context.context$;
    this.profiles$ = this.accountMetadataProfilesStoreFacade.metadataProfiles$;
    this.route$ = this.appStoreFacade.route$;
    this.showIntegrations$ = this.appStoreFacade.showIntegrations$;
    this.showUserGroups$ = this.appStoreFacade.context.isUserGroupsFeatureEnabled$;

    this.accountMetadataProfilesStoreFacade.loadAll();
  }

}
