﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using System;
using System.Threading.Tasks;
using WebApi.Dtos;
using WebApi.Dtos.Setting;

namespace WebApi.Services
{
    public class SettingService
    {
        private readonly ILogger<SettingService> _logger;
        private readonly SettingLogic _settingLogic;
        private readonly JsonSerializer _jsonSerializer;
        private readonly ServiceBusService _serviceBusService;

        public SettingService(ILogger<SettingService> logger, damContext context, ServiceBusService serviceBusService)
        {
            _logger = logger;
            _settingLogic = new SettingLogic(context);
            _logger.LogInformation("SettingService initialized");
            _jsonSerializer = JsonSerializer.Create(new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() });
            _serviceBusService = serviceBusService;
        }


        public async Task<GetEntityResponse<SettingsDto>> GetFrontEndSettings(Guid accountId, Guid userId)
        {
            string resultJson = await _settingLogic.GetFrontEndSettings(accountId, userId);
            GetEntityResponse<SettingsDto> settings = JsonConvert.DeserializeObject<GetEntityResponse<SettingsDto>>(resultJson);
            return settings;
        }

        public async Task<UpsertResponse<AreaSettingDto>> UpdateAccountSettings(Guid accountId, Guid userId, AreaSettingDto update)
        {

            string jsonInput = PrepareJsonInput("onAccount", update);

            string resultJson = await _settingLogic.UpdateFrontEndSettings(accountId, userId, jsonInput);

            UpsertResponse<AreaSettingDto> result = JsonConvert.DeserializeObject<UpsertResponse<AreaSettingDto>>(resultJson);
            return result;
        }

        public async Task<UpsertResponse<AreaSettingDto>> UpdateRoleSettings(Guid accountId, Guid userId, AreaSettingDto update)
        {
            string jsonInput = PrepareJsonInput("onRole", update);

            string resultJson = await _settingLogic.UpdateFrontEndSettings(accountId, userId, jsonInput);

            UpsertResponse<AreaSettingDto> result = JsonConvert.DeserializeObject<UpsertResponse<AreaSettingDto>>(resultJson);
            return result;
        }

        public async Task<UpsertResponse<AreaSettingDto>> UpdateUserSettings(Guid accountId, Guid userId, AreaSettingDto update)
        {
            string jsonInput = PrepareJsonInput("onUser", update);

            string resultJson = await _settingLogic.UpdateFrontEndSettings(accountId, userId, jsonInput);

            UpsertResponse<AreaSettingDto> result = JsonConvert.DeserializeObject<UpsertResponse<AreaSettingDto>>(resultJson);
            return result;
        }

        private string PrepareJsonInput(string area, AreaSettingDto settingEntry)
        {
            var json = JObject.FromObject(settingEntry, _jsonSerializer);
            json["criteria"] = area;
            string jsonInput = json.ToString(Newtonsoft.Json.Formatting.None, null);
            return jsonInput;
        }

    }
}
