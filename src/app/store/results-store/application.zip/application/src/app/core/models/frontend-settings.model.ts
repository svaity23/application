import { Setting } from './setting.model';

export interface FrontEndSettings {
    onAccount: Setting[];
    onRole: Setting[];
    onUser: Setting[];
}