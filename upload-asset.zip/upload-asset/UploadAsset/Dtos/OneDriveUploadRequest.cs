﻿namespace UploadAsset.Dtos
{
    public class OneDriveUploadRequest: BaseFileUploadRequest
    {
        public string FileName { get; set; }
        public long FileSizeBytes { get; set; }
        public string OneDriveLink { get; set; }
    }
}
