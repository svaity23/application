﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using System;
using System.Threading.Tasks;

namespace ApplicationLogic.Logic
{
    public class LightboxLogic
    {
        private readonly LightboxFinder _lightboxFinder;

        public LightboxLogic(damContext damContext)
        {
            _lightboxFinder = new LightboxFinder(damContext);
        }

        public async Task<string> DeleteAsync(Guid accountId, Guid userId, string json) {
            return await _lightboxFinder.DeleteAsync(accountId, userId, json);
        }

        public async Task<string> DeleteByIdAsync(Guid accountId, Guid userId, Guid id)
        {
            return await _lightboxFinder.DeleteByIdAsync(accountId, userId, id);
        }

        public async Task<string> GetAllAsync(Guid accountId, Guid userId)
        {
            return await _lightboxFinder.GetAllAsync(accountId, userId);
        }
        public async Task<string> GetPreviewAssetsAsync(Guid accountId, Guid userId)
        {
            return await _lightboxFinder.GetPreviewAssetsAsync(accountId, userId);
        }


        public async Task<string> GetByIdAsync(Guid accountId, Guid userId, Guid id)
        {
            return await _lightboxFinder.GetByIdAsync(accountId, userId, id);
        }

        public async Task<string> GetByIdAsync(Guid id)
        {
            return await _lightboxFinder.GetByIdAsync(id);
        }

        public async Task<string> UpsertLightboxAsync(Guid accountId, Guid userId, string json)
        {
            return await _lightboxFinder.UpsertLightboxAsync(accountId, userId, json);
        }

    }
}
