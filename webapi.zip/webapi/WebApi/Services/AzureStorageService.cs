﻿using Microsoft.Azure.Management.Storage;
using Microsoft.Azure.Management.Storage.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Rest;
using System.Collections.Generic;
using System.Threading.Tasks;
using ApplicationLogic;
using System;

namespace WebApi.Services
{
    public class AzureStorageService
    {
        private readonly ILogger<AzureStorageService> _logger;
        private readonly IConfiguration _configuration;
        private readonly BlobService _blobService;

        private StorageManagementClient _managementClient;

        public AzureStorageService(IConfiguration configuration, ILogger<AzureStorageService> logger, BlobService blobService, AzureAccessTokens azureAccessTokens)
        {
            _logger = logger;
            _configuration = configuration;
            _blobService = blobService;

            var accessToken = azureAccessTokens.ManagementResourceAccessToken;
            ServiceClientCredentials credentials = new TokenCredentials(accessToken);
            _managementClient = new StorageManagementClient(credentials)
            {
                SubscriptionId = _configuration["AzureResourceManagement:SubscriptionId"]
            };
        }

        public async Task<StorageAccount> CreateStorageAsync(string storageAccountName)
        {
            SkuTier skuTier = _configuration["AccountStorageParameters:Sku"] == "Premium" ? SkuTier.Premium : SkuTier.Standard;

            var options = new StorageAccountCreateParameters()
            {
                Sku = new Sku(_configuration["AccountStorageParameters:Sku"], skuTier),
                Location = _configuration["AccountStorageParameters:Location"],
                Kind = _configuration["AccountStorageParameters:Kind"],
                AllowBlobPublicAccess = bool.Parse(_configuration["AccountStorageParameters:AllowBlobPublicAccess"])
            };

            var storageAccount = await _managementClient.StorageAccounts.CreateAsync(
                _configuration["AzureResourceManagement:ResourceGroupName"],
                storageAccountName,
                options
            );

            return storageAccount;
        }

        public async Task CreateDefaultStorageContainers(Guid accountId)
        {
            var containerNameSuffixes = new List<string>();
            _configuration.GetSection("DefaultContainerNames").Bind(containerNameSuffixes);

            var storageAccountName = _configuration["BlobStorage:StorageAccountName"];
            foreach (var containerNameSuffix in containerNameSuffixes)
            {
                var containerName = _blobService.GetBlobContainerName(accountId, containerNameSuffix);
                await _blobService.CreateBlobContainerAsync(storageAccountName, containerName);
            }
        }

        public async Task<Microsoft.Rest.Azure.IPage<StorageAccount>> GetStorageAccountsAsync()
        {
            return await _managementClient.StorageAccounts.ListAsync();
        }

        public async Task<StorageAccountListKeysResult> GetStorageAccountKeysAsync(string accountName)
        {
            return await _managementClient.StorageAccounts.ListKeysAsync(
                _configuration["AzureResourceManagement:ResourceGroupName"],
                accountName);
        }
    }
}
