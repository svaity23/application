import { SocialAuthUser } from '../models/social-auth-user';

export interface AuthProvider {
    authenticate(): Promise<SocialAuthUser>;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    getAuthUser(options?: any): Promise<SocialAuthUser>;
    isSignedIn(): Promise<boolean>;
    signOut(revoke?: boolean): Promise<void>
}