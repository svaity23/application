import { FileGroupType } from '@app/core/enums';

export interface MetadataField {
    accountId: string;
    active?: boolean;
    default?: boolean;
    expandField?:boolean;
    fileGroup?: FileGroupType; // this is align to asset model fileGroup
    id: string;
    label: string;
    metadataFieldTypeId: number;
    metadataProfileId: string;
    placeholder?: string;
    previous: string;
    required?: boolean;
}

