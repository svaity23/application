﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos.Search
{
    public class PublicLightboxSearchResultsDto
    {
        public int AssetCount { get; set; }
        public IEnumerable<LightboxAssetDto> Assets { get; set; }        
    }
}
