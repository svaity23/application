import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, ViewEncapsulation } from '@angular/core';

import { BsModalRef } from 'ngx-bootstrap/modal';

import { Context } from '@app/core/models/context.model';
import { MicrosoftLoginConfigurationModalOptions } from '@app/core/models/modal-options/microsoft-login-configuration-modal-options.model';

@Component({
  selector: 'app-microsoft-login-configuration-modal',
  templateUrl: './microsoft-login-configuration-modal.component.html',
  styleUrls: ['./microsoft-login-configuration-modal.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MicrosoftLoginConfigurationModalComponent implements OnInit {
  context: Context;
  modalRef: BsModalRef;
  options: MicrosoftLoginConfigurationModalOptions;
  title: string;
  userId: string;

  constructor(private ref: ChangeDetectorRef) { }

  closeModal(): void {
    this.modalRef.hide();
    this.modalRef = null;
  }

  ngOnInit(): void {
    this.title = this.options.title;
    this.userId = this.options.context?.id;
    this.context = this.options.context;
  }

  redirectToMicrosoftLogin(): void {
    const params = new Map<string, string>();
    params.set('userId', this.userId);
    params.set('accountId', this.context.accountId);

    this.options.redirectToMicrosoftLogin(params);
  }

  removeDomain(id: string): void {
    if (confirm('Are you sure you want to delete this domain?')) {
      this.options.removeFederatedDomain(id);
    }
  }

  updateContext(context: Context) {
    this.context = context;
    this.ref.markForCheck();
  }
}
