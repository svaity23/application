import { AssetFile } from './asset-file.model';

export interface FileSystemFile extends AssetFile {
	file: File;
}
