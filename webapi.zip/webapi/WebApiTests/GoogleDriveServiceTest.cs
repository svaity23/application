﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Drive.v3;
using Google.Apis.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using WebApi.Services;

namespace WebApiTests
{
    [TestClass()]
    public class GoogleDriveServiceTest
    {
        private GoogleDriveService _driveService;


        [TestInitialize]
        public void Init()
        {
            var loggerFactory = (ILoggerFactory)new LoggerFactory();
            var configuration = new ConfigurationBuilder()
                                      .AddJsonFile("appsettings.json", true, true)
                                      .Build();
            //var accessToken = "ya29.a0ARrdaM9doaygdKIgQfh7SiNXAFkipTSZYJwPKeEeI5kuYpPl7siv5hG0sw99bI0NPeSMGKMvvf4v7HN0oJm0MB3_a-1RsCECJOJOaZPd936oSQzolSqPFrIz8xXAaWbh0tT3mUPyDQ2p_agD8tL9-dNXp2aX";
            var accessToken = "bad token";



            _driveService = new GoogleDriveService(configuration, loggerFactory.CreateLogger<GoogleDriveService>(), accessToken);
        }

        [TestMethod()]
        public async Task TestDownloadToFile()
        {
            var fileId = "0B6Qw2M2vr7RtTlJiVjY1MzdhaTQ";
            var saveTo = Path.Combine(Path.GetTempPath(), "bemtest.jpg");

            using (FileStream fileStream = new FileStream(saveTo, FileMode.OpenOrCreate, FileAccess.Write))
            {
                await _driveService.DownloadFileToStreamAsync(fileId, fileStream);
            }
        }

        [TestMethod()]
        public async Task TestGetStream()
        {
            //var fileId = "0B6Qw2M2vr7RtTlJiVjY1MzdhaTQ"; // jpg
            var videoFileId = "1plodRF6fB6jGK4TaTvIhAH6YcaQQlqBH"; // mp4

            try
            {
                using (var stream = await _driveService.GetFileAsStreamAsync(videoFileId))
                {
                    var saveTo = Path.Combine(Path.GetTempPath(), "the_stream_bem_2.mp4");

                    using (FileStream outputFileStream = new FileStream(saveTo, FileMode.Create))
                    {
                        stream.CopyTo(outputFileStream);
                    }
                }
            }
            catch(Exception ex)
            {
                Console.Write(ex.Message);
                // throw (ex);
            }           
        }        

    }
}
