/** Custom account level metadata profiles. Each file group (image, video, audio, etc.) has a unique metadata profile. */
export interface MetadataProfile {
    accountId: string; // if null then a default
    id: string;
    metadataProfileTypeId: number;
    name: string; // (custom images profile, default video profile,document)
}
