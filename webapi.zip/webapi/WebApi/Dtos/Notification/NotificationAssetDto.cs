﻿using System;

namespace WebApi.Dtos.Notification
{
    public class NotificationAssetDto
    {        
        public Guid Id { get; set; }        
        public AttachmentDto Attachment { get; set; }
        public string Name { get; set; }
        public int? FileGroup { get; set; }
    }
}
