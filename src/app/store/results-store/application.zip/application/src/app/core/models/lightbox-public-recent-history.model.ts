import { RecentViewedAsset } from './recent-viewed-asset.model';

export interface LightboxPublicRecentHistory {  
  assets: RecentViewedAsset[];
  id: string;
  searchTerms: string[];
}