﻿using System;

namespace WebApi.Dtos.Canva
{
    public class ContentDto
    {
        public string Type { get; set; }
        public string ErrorCode { get; set; }
    }
}
