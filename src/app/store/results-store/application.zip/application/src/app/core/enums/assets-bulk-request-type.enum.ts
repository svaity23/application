export enum AssetsBulkRequestType {
    Create = 0,
    Delete = 1,
    UpdateCollection = 2,
    UpdateMetadata = 3,
    FinishUploadSession = 4,
    ShareAssets = 5, // Not using anymore as of 12/09/2021
    DownloadAssets = 6,
    UpdateTags = 7,
    AddToLightbox = 8,	// Not used.
    RemoveFromLightbox = 9,
    UpdateFavorites = 10,
    AddToHubspot = 11,
    RemoveFromHubspot = 12
}
