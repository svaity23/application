export enum VisibleToType {
  All='all',
  Groups='groups',
  None='none'
}
