import { Injectable } from '@angular/core';

import * as faker from 'faker/locale/en_US';
import { Observable, of } from 'rxjs';

import { AccountDetail } from '../models/entities/account-detail.model';
import { Context } from '@app/core/models/context.model';
import { ContextDataServiceInterface } from '../data-services/context-data.service';
import { UpsertEntityResponse } from '../models/api-responses/upsert-entity-response.model';

@Injectable({ providedIn: 'root' })
export class ContextDataServiceMock implements ContextDataServiceInterface {

    getApplicationContext(pluginName: string): Observable<Context> {

        const permissions = [
            { key: 'download-assets' },
            { key: 'upload-assets' },
            { key: 'view-analytics' },
            { key: 'view-asset-history' }
        ];

        if (!pluginName) {
            permissions.concat([
                { key: 'create-admin' },
                { key: 'create-collections' },
                { key: 'create-contributor' },
                { key: 'create-mcc-admin' },
                { key: 'create-viewer' },
                { key: 'deactivate-user' },
                { key: 'delete-assets' },
                { key: 'delete-collections' },
                { key: 'edit-assets' },
                { key: 'edit-collections' },
                { key: 'edit-user' },
                { key: 'manage-metadata-profiles' },
                { key: 'manage-notifications' },
                { key: 'share-assets' },
                { key: 'transform-assets' },
            ]);
        }

        const json = {
            accountId: `${faker.random.number()}`,
            accountName: faker.company.companyName(),
            email: faker.internet.email(),
            firstName: faker.name.firstName(),
            id: `${faker.random.number()}`,
            lastName: faker.name.lastName(),
            permissions,
            roleKey: 'trial',
            roleName: 'trial',
            eulaAccepted: `${faker.random.boolean()}`,
            sasKeys: {
                assets: 'assets_key',
                'low-resolution': 'low-resolution_key',
                thumbnail: 'thumbnail_key',
                metadata: 'metadata_key',
                web: 'web_key',
            }
        };
        return new Observable(observer => {
            const context: Context = JSON.parse(JSON.stringify(json));

            // Yield a single value and complete
            observer.next(context);
            observer.complete();
        });

    }
    getSisenseLaunchUrl(): Observable<string> {
        return;
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    resetToDefaultFavicon(): Observable<any> {
        return;
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    resetToDefaultLogo(): Observable<any> {
        return;
    }

    updateAccountTheme(_accountId: string, theme: string): Observable<string> {
        return of(theme);
    }

    uploadFavicon(file: File): Observable<string> {
        return of(file.name);
    }

    uploadLogo(file: File): Observable<string> {
        return of(file.name);
    }

    userSelfReg(): Observable<UpsertEntityResponse<AccountDetail>> {
        // const url = `${this.webApiUrl}/accounts/selfReg`;
        // return this.createApiPost({ url });
        return;
    }
    verifyScopeAccess(scope: string): Observable<boolean> {
        switch (scope) {
            case 'sys':
                return of(true);
            case 'nada':
                return of(false);
        }
    }
}
