import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { BaseDataService } from './base-data.service';

import { HttpParams } from '@angular/common/http';

export interface IntegrationCanvaDataServiceInterface {
  setCanvaCredentials(user: string, state: string): Observable<string>;
}

@Injectable({ providedIn: 'root' })
export class IntegrationCanvaDataService extends BaseDataService implements IntegrationCanvaDataServiceInterface {
  setCanvaCredentials(user: string, state: string): Observable<string> {
    // eslint-disable-next-line prefer-const
    let params = new HttpParams()
    .set('user', user)
    .set('state', state);

    const url = `${this.webApiUrl}/canvaIntegration/signin`;
    return this.createApiGet({ url, params });
  }

}
