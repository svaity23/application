﻿using System.Text.Json.Serialization;

namespace UploadAsset.Dtos
{
    public class GetEntityResponse<T>
    {
        [JsonPropertyName("entity")]
        public T Entity { get; set; }

        [JsonPropertyName("error")]
        public ErrorResponse Error { get; set; }
    }
}
