﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using ApplicationLogic.DomainModel;

#nullable disable

namespace ApplicationLogic.DomainModel.Context
{
    public partial class damContext : DbContext
    {
        public damContext()
        {
        }

        public damContext(DbContextOptions<damContext> options)
            : base(options)
        {
        }
                
        public virtual DbSet<Account> Account { get; set; }
        public virtual DbSet<AccountDetail> AccountDetail { get; set; }
        public virtual DbSet<AccountType> AccountType { get; set; }
        public virtual DbSet<Asset> Asset { get; set; }
        public virtual DbSet<Group> Group { get; set; }
        public virtual DbSet<Metadata> Metadata { get; set; }
        public virtual DbSet<Role> Role { get; set; }
        public virtual DbSet<Setting> Setting { get; set; }
        public virtual DbSet<User> User { get; set; }
        public virtual DbSet<UserContext> UserContext { get; set; }
        public virtual DbSet<UserLegal> UserLegal { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=tcp:sql-dam-sbx-829c.database.windows.net,1433;Initial Catalog=sqldb-dam-sbx;Persist Security Info=False;User ID=appPocoGen;Password=___________;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Account>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("pk_account")
                    .IsClustered(false);

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.TypeNavigation)
                    .WithMany(p => p.Account)
                    .HasForeignKey(d => d.Type)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_account_accountType");
            });

            modelBuilder.Entity<AccountDetail>(entity =>
            {
                entity.ToView("accountDetail");

                entity.Property(e => e.AccountTypeName).IsUnicode(false);
            });

            modelBuilder.Entity<AccountType>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("pk_accountType_id")
                    .IsClustered(false);

                entity.Property(e => e.Id).ValueGeneratedNever();
                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");
                entity.Property(e => e.Name).IsUnicode(false);
            });

            modelBuilder.Entity<Asset>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("pk_asset")
                    .IsClustered(false);

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Account)
                    .WithMany(p => p.Asset)
                    .HasForeignKey(d => d.AccountId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_asset_account");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.AssetCreatedByNavigation)
                    .HasForeignKey(d => d.CreatedBy)
                    .HasConstraintName("fk_asset_createdBy");

                entity.HasOne(d => d.LastModifiedByNavigation)
                    .WithMany(p => p.AssetLastModifiedByNavigation)
                    .HasForeignKey(d => d.LastModifiedBy)
                    .HasConstraintName("fk_asset_lastModifiedBy");
            });

            modelBuilder.Entity<Group>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("pk_group_id")
                    .IsClustered(false);

                entity.HasIndex(e => new { e.AccountId, e.Active }, "ix_group_accountId")
                    .IsClustered();

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Account)
                    .WithMany(p => p.Group)
                    .HasForeignKey(d => d.AccountId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_group_accountId");
            });

            modelBuilder.Entity<Metadata>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("df_metadata")
                    .IsClustered(false);

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Account)
                    .WithMany(p => p.Metadata)
                    .HasForeignKey(d => d.AccountId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_metadata_account");

                entity.HasOne(d => d.Asset)
                    .WithMany(p => p.Metadata)
                    .HasForeignKey(d => d.AssetId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_metadata_asset");
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("pk_role_id")
                    .IsClustered(false);

                entity.HasIndex(e => new { e.AccountId, e.Active }, "ix_role_accountId")
                    .IsClustered();

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Key).IsUnicode(false);

                entity.HasOne(d => d.Account)
                    .WithMany(p => p.Role)
                    .HasForeignKey(d => d.AccountId)
                    .HasConstraintName("fk_role_account");
            });

            modelBuilder.Entity<Setting>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("pk_setting_id")
                    .IsClustered(false);

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Key).IsUnicode(false);

                entity.HasOne(d => d.Account)
                    .WithMany(p => p.SettingAccount)
                    .HasForeignKey(d => d.AccountId)
                    .HasConstraintName("fk_setting_accountId");

                entity.HasOne(d => d.AccountIdCriteriaNavigation)
                    .WithMany(p => p.SettingAccountIdCriteriaNavigation)
                    .HasForeignKey(d => d.AccountIdCriteria)
                    .HasConstraintName("fk_setting_accountIdCriteria");

                entity.HasOne(d => d.RoleIdCriteriaNavigation)
                    .WithMany(p => p.Setting)
                    .HasForeignKey(d => d.RoleIdCriteria)
                    .HasConstraintName("fk_setting_roleIdCriteria");

                entity.HasOne(d => d.UserIdCriteriaNavigation)
                    .WithMany(p => p.Setting)
                    .HasForeignKey(d => d.UserIdCriteria)
                    .HasConstraintName("fk_setting_userIdCriteria");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("pk_user_id")
                    .IsClustered(false);

                entity.HasIndex(e => new { e.AccountId, e.Active }, "ix_user_accountId")
                    .IsClustered();

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Account)
                    .WithMany(p => p.User)
                    .HasForeignKey(d => d.AccountId)
                    .HasConstraintName("fk_user_accountId");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.User)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("fk_user_roleId");
            });

            modelBuilder.Entity<UserContext>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("userContext");

                entity.Property(e => e.AccountTypeName).IsUnicode(false);

                entity.Property(e => e.RoleKey).IsUnicode(false);
            });

            modelBuilder.Entity<UserLegal>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("pk_userLegal")
                    .IsClustered(false);

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
                entity.Property(e => e.Created).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Account)
                    .WithMany(p => p.UserLegal)
                    .HasForeignKey(d => d.AccountId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_userLegal_accountId");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.UserLegal)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_userLegal_userId");
            });            

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
