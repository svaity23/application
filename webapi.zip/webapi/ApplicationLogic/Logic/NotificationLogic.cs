﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Threading.Tasks;

namespace ApplicationLogic.Logic
{
    public class NotificationLogic
    {
        private readonly NotificationFinder _finder;
        private readonly NullLogger<NotificationLogic> _logger;

        public NotificationLogic(damContext context)
        {
            _finder = new NotificationFinder(context);
            _logger = NullLogger<NotificationLogic>.Instance;
        }

        public async Task<string> GetAllNotificationsAsync(Guid accountId, Guid userId)
        {
            return await _finder.GetAllNotificationAsync(accountId, userId);
        }
        public async Task<string> DeleteAsync(Guid accountId, Guid userId, Guid notificationId)
        {
            return await _finder
                .DeleteAsync(accountId, userId, notificationId);
        }

        public async Task<string> MarkNotificationAsync(Guid accountId, Guid userId, string jsonInput)
        {
            return await _finder
                .MarkAsReadAsync(accountId, userId, jsonInput);
        }
    }
}
