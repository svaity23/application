﻿using System.Text.Json.Serialization;

namespace WebApi.Dtos.Asset.Hubspot
{
    public class SyncAllRequestDTO
    {
        public string SignalRConnectionId { get; set; }
    }
}
