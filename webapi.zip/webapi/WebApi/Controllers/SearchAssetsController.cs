﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Dtos;
using WebApi.Dtos.Search;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class SearchAssetsController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<AssetsController> _logger;
        private readonly CollectionService _collectionService;
        private readonly ISearchAssetsServiceFactory _searchAssetsServiceFactory;
        private readonly UserAccountService _userAccountService;

        public SearchAssetsController(IConfiguration configuration, ILogger<AssetsController> logger, CollectionService collectionService, ISearchAssetsServiceFactory searchAssetsServiceFactory, UserAccountService userAccountService)
        {
            _configuration = configuration;
            _logger = logger;
            _collectionService = collectionService;
            _searchAssetsServiceFactory = searchAssetsServiceFactory;
            _userAccountService = userAccountService;
        }

        /// <summary>
        /// Query assets
        /// </summary>        
        /// <param name="query"></param>
        /// <returns></returns>
        [HttpPost]
        [ApiExplorerSettings(IgnoreApi = false)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SearchResultsDto))]        
        public async Task<IActionResult> QueryAssets(QueryRequestDto query)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            
            _logger.LogDebug($"[SearchAssetsController] Querying assets for account = {accountId}, sortField = {query.SortField}, collectionId = {query.CollectionId}, skip = {query.Skip}, " +
                                $"pageSize = {query.PageSize}, searchTerm = {query.SearchTerm}, searchFavorites = {query.SearchFavorites}, lightboxId = {query.LightboxId}, " +
                                $"searchExpiredAssets = {query.SearchExpiredAssets}" + $"searchExpiredAssets = {query.SearchCleanupAssets}");
            _logger.LogDebug("BEGIN: queryAssets");

            var searchAssetsService = await _searchAssetsServiceFactory.CreateSearchAssetServiceAsync(accountId, userId, _collectionService);
            var results = await searchAssetsService.GetSearchResultsFromElasticsearchAsync(query.SearchTerm, query.SortField, query.Skip, query.PageSize, query.IncludeFilters, 
                                                            query.CollectionId, query.FilterRequests, query.LightboxId, query.SearchFavorites, query.SearchExpiredAssets, query.SearchCleanupAssets);

            _logger.LogDebug("END: queryAssets");

            return Ok(results);            
        }

        /// <summary>
        /// Get search suggestions
        /// </summary>
        /// <param name="searchTerm"></param>
        /// <param name="collectionId"></param>
        /// <param name="lightboxId"></param>
        /// <param name="searchFavorites"></param>
        /// <param name="searchExpiredAssets"></param>
        /// <param name="searchCleanupAssets"></param>
        /// <returns></returns>
        [HttpGet("suggest")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<SearchSuggestionDto>))]        
        public async Task<IActionResult> GetSearchSuggestions(string searchTerm, Guid? collectionId, Guid? lightboxId, bool searchFavorites = false, bool searchExpiredAssets = false, bool searchCleanupAssets = false)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            _logger.LogDebug($"[SearchAssetController] Getting search suggestions for account = {accountId}, searchTerm = {searchTerm}");
            _logger.LogDebug("BEGIN: Suggestion");

            var searchAssetsService = await _searchAssetsServiceFactory.CreateSearchAssetServiceAsync(accountId, userId, _collectionService);
            var results = await searchAssetsService.GetSearchSuggestionsAsync(searchTerm, collectionId, searchFavorites, lightboxId, searchExpiredAssets, searchCleanupAssets);

            _logger.LogDebug("END: Suggestion");

            return Ok(results);
        }

        /// <summary>
        /// Get tags
        /// </summary>
        /// <param name="searchTerm"></param>
        /// <returns></returns>
        [HttpGet("tags")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<string>))]
        public async Task<IActionResult> GetTagsSuggestions(string searchTerm)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            _logger.LogDebug($"[SearchAssetController] Getting tags for account = {accountId}, searchTerm = {searchTerm}");
            _logger.LogDebug("BEGIN: Tags Suggestion");

            var searchAssetsService = await _searchAssetsServiceFactory.CreateSearchAssetServiceAsync(accountId, userId, _collectionService);
            var results = await searchAssetsService.GetTagsSuggestionsAsync(searchTerm);

            _logger.LogDebug("END: Tags Suggestion");

            return Ok(results);
        }

        /// <summary>
        /// Get search filters
        /// </summary>
        /// <param name="searchTerm"></param>
        /// <param name="collectionId"></param>
        /// <param name="searchFavorites"></param>
        /// <param name="lightboxId"></param>
        /// <param name="searchExpiredAssets"></param>
        /// <param name="searchCleanupAssets"></param>
        /// <returns></returns>
        [HttpGet("filters")]        
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SearchFilters))]
        public async Task<IActionResult> GetFilters(string searchTerm, Guid? collectionId, bool? searchFavorites, Guid? lightboxId, bool searchExpiredAssets = false, bool searchCleanupAssets = false)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();            
           
            _logger.LogDebug($"[SearchAssetController] Getting search Filters for account = {accountId}");
            _logger.LogDebug("BEGIN: Filters");

            var searchAssetsService = await _searchAssetsServiceFactory.CreateSearchAssetServiceAsync(accountId, userId, _collectionService);
            var results = await searchAssetsService.GetSearchFiltersAsync(searchTerm, collectionId, searchFavorites, lightboxId, searchExpiredAssets, searchCleanupAssets);

            _logger.LogDebug("END: Filters");

            return Ok(results);           
        }
    }
}
