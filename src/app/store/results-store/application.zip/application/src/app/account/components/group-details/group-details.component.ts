import { ChangeDetectionStrategy, Component, EventEmitter, HostBinding, Input, OnChanges, OnInit, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { ControlContainer, NgForm } from '@angular/forms';

import { cn } from 'src/utils/cn';

import { Group } from '@app/core/models/entities/group.model';

@Component({
  selector: 'app-group-details',
  templateUrl: './group-details.component.html',
  styleUrls: ['./group-details.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class GroupDetailsComponent implements OnInit, OnChanges {

  allGroupsButtonText = 'All Groups';
  @Input() className = '';
  @Input() group: Group;
  @Output() groupChange: EventEmitter<Group> = new EventEmitter<Group>();
  @Input() groupForm: NgForm;
  groupToModify: Group;
  @Input() invalidGroup = false;
  @HostBinding('attr.ngNoHost') noHost = '';
  @Output() validateGroup: EventEmitter<Group> = new EventEmitter<Group>();
  validationMessage = 'This group name already exists, please update to continue.'

  constructor() {
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  enter($event: any): void {
    $event.preventDefault();
  }

  groupValueChange(): void {
    this.groupForm.form.markAsTouched();
    this.groupChange.emit(this.groupToModify);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.group) {
      this.groupToModify = { ...changes.group.currentValue };
    }
  }

  ngOnInit(): void {
    this.className = cn('group-details', this.className);
  }

  validateGroupChange(): void {
    this.groupForm.form.markAsTouched();
    this.validateGroup.emit(this.groupToModify);
  }
}
