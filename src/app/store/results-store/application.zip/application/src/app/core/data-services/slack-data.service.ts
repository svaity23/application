/* eslint-disable  @typescript-eslint/no-explicit-any */
import { Injectable } from '@angular/core';
import {  Observable } from 'rxjs';

import { BaseDataService } from './base-data.service';

export interface SlackDataServiceInterface {
    authenticate(code: string, redirectUri: string, clientId: string): Observable<any>;
    getChannels(token: string): Observable<any>;
    postMessage(token: string, channelId: string, message: string): Observable<any>;
}

@Injectable({ providedIn: 'root' })
export class SlackAssetsDataService extends BaseDataService implements SlackDataServiceInterface {

    authenticate(code: string, redirectUri: string, clientId: string): Observable<any> {
        const data = new FormData();
        data.append('code', code);
        data.append('client_id', clientId);
        data.append('redirect_uri', redirectUri);
        const url = `${this.webApiUrl}/integration/slack/tokens`;
        return this.createApiPost({url, data})
    }

    getChannels(token: string): Observable<any> {
        const url = 'https://slack.com/api/conversations.list';
        const data = new FormData();
        data.append('token', token);
        return this.createAnonApiPost({ url, data});
    }

    postMessage(token: string, channelId: string, message: string): Observable<any> {
        const url = 'https://slack.com/api/chat.postMessage';
        const data = new FormData();
        data.append('token', token);
        data.append('channel', channelId);
        data.append('text', message);
        return this.createAnonApiPost({ url, data});
    }

    uploadFile(token: string, channelId: string, file: File, comment: string): Observable<any> {
        const url = 'https://slack.com/api/files.upload';
        const data = new FormData();
        data.append('token', token);
        data.append('channels', channelId);
        data.append('file', file);
        data.append('initial_comment', comment);
        return this.createAnonApiPost({ url, data});
    }

}
