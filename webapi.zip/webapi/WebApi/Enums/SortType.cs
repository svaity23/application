﻿namespace WebApi.Enums
{
    // matches sort-options-type.enum in client
    public enum SortType
    {
        CreatedDescending = 0,
        ModifiedDescending = 1,
        NameAscending = 2,
        NameDescending = 3,
        DescriptionAscending = 4,
        DescriptionDescending = 5,
        FileSizeAscending = 6,
        FileSizeDescending = 7,
        TypeAscending = 8,
        TypeDescending = 9,
        ModifiedAscending = 10,
        CreatedByAscending = 11,
        CreatedByDescending = 12,
        ExtensionAscending = 13,
        ExtensionDescending = 14,
        Relevance = 15
    }
}
