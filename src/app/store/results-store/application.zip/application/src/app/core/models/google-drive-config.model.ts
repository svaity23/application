export interface GoogleDriveConfig {
	appId: string,
	clientId: string,
	developerApiKey: string,
	maxItems: number,
	type: string
}
