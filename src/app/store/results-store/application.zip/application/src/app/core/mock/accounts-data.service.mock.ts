import { Injectable } from '@angular/core';

import * as faker from 'faker/locale/en_US';
import { Observable } from 'rxjs';

import { AccountDetail } from '../models/entities/account-detail.model';
import { AccountsDataServiceInterface } from '../data-services/accounts-data.service';
import { AccountTypeKey } from '../enums/account-type-key.enum';
import { Feature } from '../models/feature.model';
import { UpsertEntityResponse } from '../models/api-responses/upsert-entity-response.model';
import { User } from '../models/entities/user.model';

@Injectable({ providedIn: 'root' })
export class AccountsDataServiceMock implements AccountsDataServiceInterface {
    private internalAccountList: AccountDetail[] = [];

    constructor() {
        const oneAccount = (id: string): AccountDetail => {
            const account: AccountDetail = {
                active: true,
                id,
                name: faker.commerce.productName(),
                accountTypeName: AccountTypeKey.Trial, // todo, we could randomize this
                created: faker.date.recent(),
                modified: null,
                salesforceId: faker.random.alphaNumeric(15),
                trialExpiration: faker.date.recent(),
                userId: faker.random.alphaNumeric(15),
                userFirstName: faker.name.firstName(),
                userLastName: faker.name.lastName(),
                userEmail: faker.internet.email(),
                federatedDomains: faker.internet.url() + ',' + faker.internet.url()
            };
            return account;
        };

        const randomAccounts = (count = faker.random.number({ min: 5, max: 10 }), startId = 1) => {
            const results = [];
            for (let i = startId; i < startId + count; i++) {
                results.push(oneAccount(i.toString()));
            }
            return results;
        };

        this.internalAccountList = randomAccounts();
    }
    
    add(account: AccountDetail): Observable<UpsertEntityResponse<AccountDetail>> {
        throw new Error('Method not implemented.' + account.name + ' ' + account.accountTypeName);
    }
    
    deleteAccount(_id: string): Observable<boolean> {
      throw new Error('Method not implemented.');
    }
    
    getAccountFeatures(_id: string): Observable<Feature[]> {
        throw new Error('Method not implemented.');
    }

    getAccountUsers(id: string): Observable<User[]> {
        throw new Error('Method not implemented.' + id);
    }

    getAll(): Observable<AccountDetail[]> {
        return new Observable(observer => {
            // clone this internal list because store-freeze will make it immutable later in the dispatch pipeline
            const clone = JSON.parse(JSON.stringify(this.internalAccountList));

            // Yield a single value and complete
            observer.next(clone);
            observer.complete();
        });
    }
    getById(id: string): Observable<AccountDetail> {
        throw new Error('Method not implemented.' + id);
    }

    updateAccount(account: AccountDetail): Observable<UpsertEntityResponse<AccountDetail>> {
        throw new Error('Method not implemented.' + account.id.toString());
    }

    updateAccountFeatures(_id: string, _features: Feature[]): Observable<Feature[]> {
        throw new Error('Method not implemented.');
    }
}
