﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using WebApi.Dtos;
using WebApi.Extensions;
using WebApi.Services;
using WebApiTests.Shared;

namespace WebApiTests.Services
{
    [TestClass]
    public class DBCanvaServiceTest
    {
        private static readonly Guid TEST_ACCOUNT = Guid.Parse("BBDA5AD0-664F-4B89-9F4E-5C82140AF39C"); // piri@saguaro.ro
        private static readonly Guid TEST_USER = Guid.Parse("79DB0E4E-F9C0-4A8B-86F2-70441663FB0D"); // piri@saguaro.ro
        private static readonly string CANVA_USER = "AWyj5TLLRl9GLTGd1MovTipn_5WFCSwubb9QzTHM830=";
        private static readonly Guid ALL_COLLECTION = Guid.Parse("979AB42B-E975-45CE-845F-3D4E13F1C752");
        private static readonly Guid SUB_COLLECTION = Guid.Parse("86BE3659-5593-42FF-ADFE-0A50CD2F6786");
        private static readonly string DOWNLOAD_URL = "https://webapi-sbx.gather.marcom.com";

        #region [Click to open] Test initialization and configuration...
        private static damContext dbContext;
        private static readonly JsonSerializerOptions options = new JsonSerializerOptions()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            ReferenceHandler = ReferenceHandler.Preserve
        };


        [ClassInitialize]
        public static void BeforeClass(TestContext context)
        {
            Debug.WriteLine("Before all tests");
            dbContext = AzureSQLTools.InitializeDamContext();

            var loggerFactory = (ILoggerFactory)new LoggerFactory();
            
            string basePath = System.AppContext.BaseDirectory;
            IConfiguration config = new ConfigurationBuilder()
                .SetBasePath(basePath)
                .AddJsonFile("appsettings.json")
                .Build();
            sut = new CanvaService(config, loggerFactory.CreateLogger<CanvaService>(), dbContext);
        }


        [ClassCleanup]
        public static void AfterClass()
        {
            Debug.WriteLine("Clean up after all tests");
                
//            dbContext.SaveChanges();
            dbContext.Dispose();
        }

        [TestInitialize]
        public void BeforeTest()
        {
            Debug.WriteLine("...Prepare test");
        }

        [TestCleanup]
        public void AfterTest()
        {
            Debug.WriteLine("...Clear test\n");
        }
        #endregion

        // sut - Service Under Test
        private static CanvaService sut;

        [TestMethod("Retrieve all collections, containers for logged in canva user")]
        public void GetAllCollections()
        {
            CanvaRequestDto reqDto = new CanvaRequestDto()
            {
                User = CANVA_USER,
                Types = new[] { "CONTAINER" }
            };
            string respJson = sut.GetAssetsAsync(reqDto).Result.ToJsonString();
            Debug.WriteLine(respJson);
            dynamic respObj = JsonConvert.DeserializeObject(respJson);

            Assert.AreEqual<string>("SUCCESS", respObj.type.Value);
            int colls = respObj.resources.Count;
            Assert.IsTrue(colls > 0);
            for (int i = 0; i < colls; i++)
            {
                dynamic coll = respObj.resources[i];
                Assert.AreEqual<string>("CONTAINER", coll.type.Value);
                Assert.IsTrue(Guid.TryParse(coll.id.Value, out Guid _));
                Assert.IsFalse(string.IsNullOrEmpty(coll.name.Value));
            }

        }

        [TestMethod("Try to get assets from root, no collection")]
        public void GetRootAssets()
        {
            CanvaRequestDto reqDto = new CanvaRequestDto()
            {
                User = CANVA_USER,
                Types = new[] { "IMAGE" },
                Limit = 8
            };
            string respJson = sut.GetAssetsAsync(reqDto).Result.ToJsonString();
            Debug.WriteLine(respJson);
            dynamic respObj = JsonConvert.DeserializeObject(respJson);

            Assert.AreEqual<string>("SUCCESS", respObj.type.Value);
            int colls = respObj.resources.Count;
            Assert.IsTrue(colls == 0);

        }

        [TestMethod("Retrieve assets and subbcollections from specified collection")]
        public void GetAssetsFromColllection()
        {
            CanvaRequestDto reqDto = new CanvaRequestDto()
            {
                User = CANVA_USER,
                ContainerId = ALL_COLLECTION.ToString()
            };
            string respJson = sut.GetAssetsAsync(reqDto).Result.ToJsonString();
            Debug.WriteLine(respJson);
            dynamic respObj = JsonConvert.DeserializeObject(respJson);

            Assert.AreEqual<string>("SUCCESS", respObj.type.Value);
            int colls = respObj.resources.Count;
            Assert.IsTrue(colls > 0);
            int containers = 0;
            int images = 0;
            for (int i = 0; i < colls; i++)
            {
                dynamic resource = respObj.resources[i];
                if ("CONTAINER".Equals(resource.type.Value)) containers++;
                Assert.IsTrue(Guid.TryParse(resource.id.Value, out Guid _));
                Assert.IsFalse(string.IsNullOrEmpty(resource.name.Value));
                if ("IMAGE".Equals(resource.type.Value))
                {
                    images++;
                    Assert.IsFalse(string.IsNullOrEmpty(resource.url.Value));
                    Assert.IsTrue(((string)resource.url.Value).StartsWith(DOWNLOAD_URL));
                    Assert.IsFalse(string.IsNullOrEmpty(resource.contentType.Value));
                    Assert.IsTrue(((string)resource.contentType.Value).StartsWith("image"));
                    Assert.IsFalse(string.IsNullOrEmpty(resource.thumbnail.url.Value));
                    Assert.IsTrue(((string)resource.thumbnail.url.Value).StartsWith(DOWNLOAD_URL));
                }
            }
            Assert.AreNotEqual<int>(containers, 0);
            Assert.AreNotEqual<int>(images, 0);
        }

        [TestMethod("Retrieve assets from sub-collection")]
        public void GetAssetsFromSubColllection()
        {
            CanvaRequestDto reqDto = new CanvaRequestDto()
            {
                User = CANVA_USER,
                ContainerId = SUB_COLLECTION.ToString(),
                Types = new[] { "IMAGE", "VIDEO"}
            };
            string respJson = sut.GetAssetsAsync(reqDto).Result.ToJsonString();
            Debug.WriteLine(respJson);
            dynamic respObj = JsonConvert.DeserializeObject(respJson);

            Assert.AreEqual<string>("SUCCESS", respObj.type.Value);
            int colls = respObj.resources.Count;
            Assert.IsTrue(colls > 0);
            int containers = 0;
            int images = 0;
            for (int i = 0; i < colls; i++)
            {
                dynamic resource = respObj.resources[i];
                if ("CONTAINER".Equals(resource.type.Value)) containers++;
                Assert.IsTrue(Guid.TryParse(resource.id.Value, out Guid _));
                Assert.IsFalse(string.IsNullOrEmpty(resource.name.Value));
                if ("IMAGE".Equals(resource.type.Value))
                {
                    images++;
                    Assert.IsFalse(string.IsNullOrEmpty(resource.url.Value));
                    Assert.IsFalse(string.IsNullOrEmpty(resource.contentType.Value));
                    Assert.IsTrue(((string)resource.contentType.Value).StartsWith("image"));
                    Assert.IsFalse(string.IsNullOrEmpty(resource.thumbnail.url.Value));
                }
            }
            Assert.AreEqual<int>(containers, 0);
            Assert.AreNotEqual<int>(images, 0);
        }


        [TestMethod("Try get collections for unknown canva user")]
        public void GetAllCollectionsUnknownUser()
        {
            CanvaRequestDto reqDto = new CanvaRequestDto()
            {
                User = "Unknown canva user id"
            };
            string respJson = sut.GetAssetsAsync(reqDto).Result.ToJsonString();
            Debug.WriteLine(respJson);
            dynamic respObj = JsonConvert.DeserializeObject(respJson);

            Assert.AreEqual<string>("ERROR", respObj.type.Value);
            Assert.AreEqual<string>("CONFIGURATION_REQUIRED", respObj.errorCode.Value);
        }
    }
}