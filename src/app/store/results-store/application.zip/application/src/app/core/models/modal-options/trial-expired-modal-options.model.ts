import { CustomTheme } from '../custom-theme.model';

export interface TrialExpiredModalOptions {
  buyNow: (buyNowUrl: string) => void;
  buyNowButtonText: string;
  message: string;
  selectedTheme?: CustomTheme;
  showBuyNow?: boolean;
  signOut: () => void;
  signOutButtonText: string;
  title: string;
}
