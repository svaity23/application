import { CollaborationUser } from './collaboration-user.model';

export interface Comment {
    active?: boolean;
    annotationNumber?: number;
    author: CollaborationUser;
    comment: string;
    created: Date;
    id: string;
    isAnnotation: boolean;
    positionLeft: number;
    positionTop: number;
    resolved: boolean;
    revisionId?: string;
    taggedUserIds?: string[];
    threadId?: number;
}
