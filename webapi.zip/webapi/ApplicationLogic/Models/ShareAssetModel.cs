﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationLogic.Models
{
    public class ShareAssetModel
    {
        public string StorageAccountName { get; set; }

        public Guid AccountId { get; set; }

        public Guid ZipId { get; set; }
        public AccountAssetInfo[] Assets { get; set; }
    }
}
