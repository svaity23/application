﻿using System;

namespace WebApi.Dtos
{
    public class BulkAssignGroupDto
    {
        public Guid? groupId { get; set; }
        public Guid[] userIds { get; set; }
    }
}
