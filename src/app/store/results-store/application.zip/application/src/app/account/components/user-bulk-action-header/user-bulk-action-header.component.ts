import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { cn } from 'src/utils/cn';

import { Group } from '@app/core/models/entities/group.model';
import { User } from '@app/core/models/entities/user.model';
@Component({
  selector: 'app-user-bulk-action-header',
  templateUrl: './user-bulk-action-header.component.html',
  styleUrls: ['./user-bulk-action-header.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UserBulkActionHeaderComponent implements OnInit {
  @Output() assignGroupsClickedEvent = new EventEmitter<{ selectedUsers: User[], userGroups: Group[] }>();
  @Input() className = '';
  @Output() inactivateClickedEvent = new EventEmitter();
  @Input() includeInactiveUsers = false;
  @Input() selectedUsers: User[];
  @Input() showUserGroups = false;
  @Input() userGroups: Group[];

  constructor() { }

  assignGroupsClick(): void {
    this.assignGroupsClickedEvent.emit({ selectedUsers: this.selectedUsers, userGroups: this.userGroups });
  }

  ngOnInit(): void {
    this.className = cn('user-bulk-action-header', this.className);
  }
}
