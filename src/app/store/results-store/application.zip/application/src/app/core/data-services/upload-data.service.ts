import { Injectable, Injector } from '@angular/core';
import { Observable, of } from 'rxjs';

import { Asset } from '../models/entities/asset.model';
import { AssetValidateCreateResponse } from '../models/entities/asset-validate-create-response.model';
import { BaseDataService } from './base-data.service';
import { DropboxFile } from '../models/dropbox-file.model';
import { FileSystemFile } from '../models/file-system-file.model';
import { GoogleDriveFile } from '@app/core/models/google-drive-file.model';
import { MetadataField } from '../models/entities/metadata-field.model';
import { MetadataProfile } from '../models/entities/metadata-profile.model';
import { MetadataProfileType } from '../models/entities/metadata-profile-type.model';
import { OneDriveFile } from '../models/onedrive-file.model';
import { SignalRSource } from '../enums/signal-r-source.enum';
import { Tag } from '../models/entities/tag.model';
import { UpdateEntitiesResponse } from '../models/api-responses/update-entities-response.model';

export interface UploadDataServiceInterface {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  cancelUploadWizard(uploadSessionId: string): Observable<any>;

  finishUploadSession(assets: Asset[], uploadSessionId: string): Observable<UpdateEntitiesResponse>;

  // add metadata related
  getAllMetadataFields(): Observable<MetadataField[]>;
  getFilesForUpload(files: File[]): Observable<File[]>;

  loadMetadataProfiles(): Observable<MetadataProfile[]>;
  loadMetadataProfileTypes(): Observable<MetadataProfileType[]>;

  saveTags(assets: Asset[], tags: string[]): Observable<Tag[]>;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  uploadAsset(asset: Asset, source: SignalRSource): Observable<any>;
  validateAndCreateAssets(assets: Asset[]): Observable<AssetValidateCreateResponse[]>;
}

@Injectable({
  providedIn: 'root'
})
export class UploadDataService extends BaseDataService implements UploadDataServiceInterface {

  constructor(injector: Injector) {
    super(injector);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  cancelUploadWizard(uploadSessionId: string): Observable<any> {
    const url = `${this.webApiUrl}/upload/cancellation`;
    const data = {
      uploadSessionId
    };
    return this.createApiPost({ url, data });
  }

  finishUploadSession(assets: Asset[], uploadSessionId: string): Observable<UpdateEntitiesResponse> {
    const assetIds: string[] = assets?.map(a => a.id);
    const finishUploadSessionRequest = {
      assetIds,
      uploadSessionId
    };
    const url = `${this.webApiUrl}/assets/bulk/activation`;
    return this.createApiPost({ url, data: finishUploadSessionRequest });
  }

  // Add metadata related
  getAllMetadataFields(): Observable<MetadataField[]> {
    throw new Error('Method not implemented.');
  }

  getFilesForUpload(files: File[]): Observable<File[]> {
    return of(files);
  }

  loadMetadataProfiles(): Observable<MetadataProfile[]> {
    throw new Error('Method not implemented.');
  }

  loadMetadataProfileTypes(): Observable<MetadataProfileType[]> {
    throw new Error('Method not implemented.');
  }

  saveTags(assets: Asset[], tags: string[]): Observable<Tag[]> {
    throw new Error('Method not implemented.' + assets.length.toString() + tags.length.toString());
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  uploadAsset(asset: Asset, source: SignalRSource): Observable<any> {
    // TODO: This casting seems wrong.
    // If this upload method could be interface based that would be better.
    const fileSystemFile = asset.viewState.file as FileSystemFile;

    const data = new FormData();
    // Ordering of this data is important. Make sure file is at end.
    data.append('assetId', asset.id);
    data.append('uploadSessionId', asset.uploadSessionId);
    data.append('source', source);
    data.append('fileGroup', asset.fileGroup.toString());
    data.append('file', fileSystemFile.file, fileSystemFile.fileName);

    const options = {
      reportProgress: true,
      observe: 'events'
    };

    const url = `${this.uploadApiUrl}/upload`;
    return this.createApiPost({ url, data, options });
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  uploadAssetFromDropbox(asset: Asset, source: SignalRSource): Observable<any> {
    // TODO: This casting seems wrong.
    // If this upload method could be interface based that would be better.
    const dropboxFile = asset.viewState.file as DropboxFile;

    const data = {
      AssetId: asset.id,
      FileGroup: asset.fileGroup.toString(),
      FileName: asset.fileName,
      DropboxLink: dropboxFile.link,
      Source: source,
      UploadSessionId: asset.uploadSessionId,
      FileSizeBytes: dropboxFile.fileSizeBytes
    };

    const options = {
      reportProgress: true,
      observe: 'events',
      responseType: 'blob'
    };

    const url = `${this.uploadApiUrl}/dropboxFile`;
    return this.createApiPost({ url, data, options });
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  uploadAssetFromGoogle(asset: Asset, source: SignalRSource): Observable<any> {
    // TODO: This casting seems wrong.
    // If this upload method could be interface based that would be better.
    const googleFile = asset.viewState.file as GoogleDriveFile;

    const data = {
      AccessToken: asset.viewState.fileProviderAccessToken,
      AssetId: asset.id,
      FileGroup: asset.fileGroup.toString(),
      FileName: asset.fileName,
      GoogleFileId: googleFile.googleFileId,
      Source: source,
      UploadSessionId: asset.uploadSessionId,
      FileSizeBytes: googleFile.fileSizeBytes
    };

    const options = {
      reportProgress: true,
      observe: 'events',
      responseType: 'blob'
    };

    const url = `${this.uploadApiUrl}/googleFile`;
    return this.createApiPost({ url, data, options });
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  uploadAssetFromOneDrive(asset: Asset, source: SignalRSource): Observable<any> {
    // TODO: This casting seems wrong.
    // If this upload method could be interface based that would be better.
    const oneDriveFile = asset.viewState.file as OneDriveFile;

    const data = {
      AccessToken: asset.viewState.fileProviderAccessToken,
      AssetId: asset.id,
      FileGroup: asset.fileGroup.toString(),
      FileName: asset.fileName,
      OneDriveLink: oneDriveFile.link,
      Source: source,
      UploadSessionId: asset.uploadSessionId,
      FileSizeBytes: oneDriveFile.fileSizeBytes
    };

    const options = {
      reportProgress: true,
      observe: 'events',
      responseType: 'blob'
    };

    const url = `${this.uploadApiUrl}/oneDriveFile`;
    return this.createApiPost({ url, data, options });
  }

  validateAndCreateAssets(assets: Asset[]): Observable<AssetValidateCreateResponse[]> {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const assetsToPost: any[] = assets.map((asset: Asset) => {
      return {
        id: asset.id,
        fileSize: asset.fileSize,
        fileName: asset.fileName,
        uploadSessionId: asset.uploadSessionId,
        fileGroup: asset.fileGroup
      };
    });

    const url = `${this.webApiUrl}/upload/assets`;
    return this.createApiPost({ url, data: assetsToPost });
  }
}
