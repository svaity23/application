﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class LightboxAssetFinder
    {
        private const string AssetIdParam = "@assetId";
        private const string JsonInputParam = "@jsonInput";
        private const string AccountIdParam = "@accountId";        
        private const string UserIdParam = "@userId";
        private const string LightboxIdParam = "@lightboxId";

        public ILogger<LightboxAssetFinder> Logger { get; set; }

        private damContext _context;

        public LightboxAssetFinder(damContext context)
        {
            _context = context;
            Logger = NullLogger<LightboxAssetFinder>.Instance;
        }

        public async Task<string> GetByAccountIdAsync(Guid accountId, Guid userId, string jsonInput)
        {
            List<SqlParameter> paramList = getParameterList(accountId, userId, jsonInput);
            return await _context.ExecuteNonQueryJsonOutputAsync("getLightboxAssetsByAccountId", paramList);
        }

        public async Task<string> GetShareAssetsAsync(Guid accountId, Guid userId, string jsonInput)
        {
            // TODO: this can be in open controller for share lightbox assets
            List<SqlParameter> paramList = getParameterList(accountId, userId, jsonInput);
            return await _context.ExecuteNonQueryJsonOutputAsync("getAssetsByLightboxIdForShare", paramList);
        }


        public async Task<string> GetAssetForPreviewAsync(Guid accountId, Guid assetId, Guid lightboxId)
        {
            List<SqlParameter> paramList = new SpParams()
                .WithAccountId(accountId)                
                .WithAssetId(assetId)      
                .WithGuid("lightboxId", lightboxId)
                .Build();

            return await _context.ExecuteNonQueryJsonOutputAsync("getLightboxAssetByIdForPreview", paramList);
        }

        public async Task<string> UpsertLightboxAssetsAsync(Guid accountId, Guid userId, string jsonInput)
        {
            List<SqlParameter> paramList = getParameterList(accountId, userId, jsonInput);
            return await _context.ExecuteNonQueryJsonOutputAsync("upsertLightboxAssets", paramList);
        }

        public async Task<string> GetLightboxAssetsById(Guid lightboxId, string jsonInput)
        {
            List<SqlParameter> paramList = new List<SqlParameter>();

            SqlParameter lightboxIdParam = new SqlParameter(LightboxIdParam, SqlDbType.UniqueIdentifier);
            lightboxIdParam.Value = lightboxId;

            paramList.Add(lightboxIdParam);

            paramList.Add(new SqlParameter(JsonInputParam, jsonInput));

            return await _context.ExecuteNonQueryJsonOutputAsync("getLightboxAssetsById", paramList);
        }

        public async Task<string> DeleteAssetsAsync(Guid accountId, Guid userId, string jsonInput)
        {
            List<SqlParameter> paramList = getParameterList(accountId, userId, jsonInput);
            return await _context.ExecuteNonQueryJsonOutputAsync("deleteLightboxAssetsByIdList", paramList);
        }

        private List<SqlParameter> getParameterList(Guid accountId, Guid userId, string jsonInput)
        {
            List<SqlParameter> paramList = new List<SqlParameter>();

            SqlParameter accountIdParam = new SqlParameter(AccountIdParam, SqlDbType.UniqueIdentifier);
            accountIdParam.Value = accountId;
            paramList.Add(accountIdParam);

            SqlParameter userIdparam = new SqlParameter(UserIdParam, SqlDbType.UniqueIdentifier);
            userIdparam.Value = userId;
            paramList.Add(userIdparam);

            paramList.Add(new SqlParameter(JsonInputParam, jsonInput));

            return paramList;
        }
    }
}
