import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { ContextService } from '../services/context.service';

@Injectable({
  providedIn: 'root'
})
export class SysAdminGuard implements CanActivate {

  constructor(private contextService: ContextService, private router: Router) { }

  canActivate(
    // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
    _route: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
    _state: RouterStateSnapshot): Observable<boolean | UrlTree> {

    return this.isSysAdmin();
  }

  private isSysAdmin(): Observable<boolean | UrlTree> {
    return this.contextService.verifyScopeAccess('sys').pipe(
      map(hasAccess => {
        if (hasAccess === false) {
          return this.router.parseUrl('/page-not-found');
        }
        return true;
      })
    );
  }
}
