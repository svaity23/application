import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AccountEditComponent } from './containers/account-edit/account-edit.component';
import { AccountsComponent } from './containers/accounts/accounts.component';
import { UtilitiesComponent } from './containers/utilities/utilities.component';


const routes: Routes = [
  { path: 'accounts', component: AccountsComponent },
  { path: 'accounts/new', component: AccountEditComponent },
  { path: 'accounts/:id', component: AccountEditComponent }, // todo revisit account.guard
  { path: 'utilities', component: UtilitiesComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
