﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;


namespace SignalRHub.Services
{
    public interface IAssetServiceFactory
    {
        AssetService CreateAssetService();
    }

    public class AssetServiceFactory : IAssetServiceFactory
    {
        private readonly IConfiguration _configuration;
        private readonly IDbContextFactory _dbContextFactory;
        private readonly ILogger<AssetServiceFactory> _logger;
        private readonly ILoggerFactory _loggerFactory;


        public AssetServiceFactory(
            ILogger<AssetServiceFactory> logger, 
            ILoggerFactory loggerFactory, 
            IConfiguration configuration, 
            IDbContextFactory dbContextFactory)
        {
            _configuration = configuration;
            _dbContextFactory = dbContextFactory;
            _logger = logger;
            _loggerFactory = loggerFactory;
        }

        public AssetService CreateAssetService()
        {
            return new AssetService(_loggerFactory, _dbContextFactory);
        }
    }
}
