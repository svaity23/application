import { LightboxAsset } from './lightbox-asset.model';
import { LightboxViewState } from '../view-states/lightbox-view-state.model';

export interface Lightbox {
  assetCount: number | null;
  assetsForPreview?: LightboxAsset[];
    createdBy?: string | null;
    createdByUserFullName?: string | null;
    id: string | null;
    expirationDate?: Date;
    isFavorited: boolean | false;
    name: string;
    viewState: LightboxViewState;
}
