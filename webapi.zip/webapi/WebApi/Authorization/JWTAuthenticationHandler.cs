﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text.Encodings.Web;
using System.Threading.Tasks;

namespace WebApi.Authorization
{
    /// <summary>
    /// Multiple Auth scheme solution for skipping auth when audience is different.
    /// Address misleading IDX10501 logs.
    /// https://oliviervaillancourt.com/posts/Fixing-IDX10501-MultipleAuthScheme
    /// </summary>
    public class JWTAuthenticationHandler : JwtBearerHandler
    {
        public JWTAuthenticationHandler(IOptionsMonitor<JwtBearerOptions> options, ILoggerFactory logger, UrlEncoder encoder, ISystemClock clock)
               : base(options, logger, encoder, clock)
        { }

        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            var authorityConfig = await this.Options.ConfigurationManager.GetConfigurationAsync(this.Context.RequestAborted);
            var authorityIssuer = authorityConfig.Issuer;
            
            var audience = this.Options.Audience ?? this.Options.TokenValidationParameters?.ValidAudience;

            var jwtToken = this.ReadTokenFromHeader();
            var jwtHandler = new JwtSecurityTokenHandler();

            if (jwtHandler.CanReadToken(jwtToken))
            {
                var token = jwtHandler.ReadJwtToken(jwtToken);
                var validIssuer = string.Equals(token.Issuer, authorityIssuer, StringComparison.OrdinalIgnoreCase);
                var matchingAudience = token.Audiences?.ToList().Find(a => a.Equals(audience, StringComparison.OrdinalIgnoreCase));
                if (validIssuer && matchingAudience != null)
                {
                    // means the token was issued by this authority and has matching audience,
                    // we make sure full validation runs as normal
                    return await base.HandleAuthenticateAsync();
                }
                else
                {
                    var audiences = string.Join(',', token.Audiences.ToArray());
                    // Skip validation since the token as issued by a an issuer that this instance doesn't know about
                    // That has zero of success, so we will not issue a "fail" since it crowds the logs with failures of type IDX10501 
                    // which are not really true and certainly not useful.
                    this.Logger.LogDebug($"Skipping {this.Scheme.Name} token validation. Issuer or audience does not match. " +
                        $"Token issuer:{token.Issuer}. Authority issuer: {authorityIssuer}. Token audiences: {audiences}. Authority audience: {audience}");
                    return AuthenticateResult.NoResult();
                }
            }

            // fall back let base do its thing
            return await base.HandleAuthenticateAsync();
        }

        private string ReadTokenFromHeader()
        {
            string token = null;

            string authorization = Request.Headers["Authorization"];

            // If no authorization header found, nothing to process further
            if (string.IsNullOrEmpty(authorization))
            {
                return null;
            }

            if (authorization.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            {
                token = authorization.Substring("Bearer ".Length).Trim();
            }

            return token;
        }
    }
}
