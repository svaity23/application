﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WebApi.Dtos.Setting
{
    public class SettingsDto
    {
        [JsonPropertyName("onAccount")]
        public List<AreaSettingDto> OnAccount { get; set; }
        [JsonPropertyName("onRole")]
        public List<AreaSettingDto> OnRole { get; set; }
        [JsonPropertyName("onUser")]
        public List<AreaSettingDto> OnUser { get; set; }
    }
}
