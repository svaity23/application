import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { filter, first, map, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AppStoreFacade } from '@app/store/app-store/app-store.facade';
import { RoleKey } from '../enums/role-key.enum';

@Injectable({
  providedIn: 'root'
})
export class InactiveAccountGuard implements CanActivate {
  roleKeyEnum = RoleKey;
  constructor(private appStoreFacade: AppStoreFacade, private router: Router) { }

  canActivate(
    _route: ActivatedRouteSnapshot,
    _state: RouterStateSnapshot): Observable<boolean | UrlTree> {

    return this.isAccountActive();
  }

  private isAccountActive(): Observable<boolean | UrlTree> {
    return this.appStoreFacade.context.context$.pipe(
      tap(context => {
        if (!context) {
          this.appStoreFacade.loadContext();
        }
      }),
      filter(context => context != null),
      first(),
      map(context => {
        if (context.accountActive || context.roleKey === this.roleKeyEnum.sysAdmin) {
          return true;
        } else {
          return this.router.parseUrl('/inactive-account');
        }
      })
    );
  }
}
