import { CommentThread } from './comment-thread.model';

export interface AssetRevisionThreads {
    threads: CommentThread[];
}