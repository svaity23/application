import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { OidcFacade } from 'ng-oidc-client';

import { Observable, of } from 'rxjs';
import { switchMap, take } from 'rxjs/operators';

import * as LocalStorageKey from '@app/core/constants/local-storage-keys'

@Injectable({
  providedIn: 'root'
})
export class MultipleAccountsGuard implements CanActivate {

  constructor(private oidcFacade: OidcFacade, private router: Router) { }

  canActivate(
    _route: ActivatedRouteSnapshot,
    _state: RouterStateSnapshot): Observable<boolean | UrlTree> | boolean | UrlTree {
    return this.oidcFacade.waitForAuthenticationLoaded().pipe(
      switchMap(() => {
        return this.hasAuthenticatedUser(_state.url);
      })
    );
  }

  // Check to see oidc identity exists in state
  hasAuthenticatedUser(url: string): Observable<boolean | UrlTree> {
    return this.oidcFacade.identity$.pipe(
      take(1),
      switchMap(user => {
        if (user && !user.expired) {
          // set to local storage selectedAccountId
          const extensionAccountId: string = user.profile?.extension_accountId;
          return this.hasMultipleAccounts(extensionAccountId);
        } else {
          // initiate sign in
          this.oidcFacade.signinRedirect(
            {
              state: { redirect_url: url }
            }
          );
          return of(false);
        }
      })
    );
  }

  private hasMultipleAccounts(extensionAccountId: string): Observable<boolean | UrlTree> {
    if (extensionAccountId == null) {
      return of(this.router.parseUrl('/admin/accounts'));
    }
    const accountIds: string[] = extensionAccountId.split(',');
    if (accountIds.length > 0) {
      const selectedAccountId = window.localStorage.getItem(LocalStorageKey.SELECTED_ACCOUNT_ID);
      if (selectedAccountId) {
        const additionalAccounts = accountIds.length > 6 // we save trailing comma for more than 6 accounts
        if (accountIds.find(a => a.toLocaleLowerCase() === selectedAccountId.toLocaleLowerCase())
          || additionalAccounts // additional accounts, also let through - webapi will be checking for accounts against db call
        ) {
          return of(this.router.parseUrl('/library'));
        }
      } else {
        return of(true);
      }
    }
  }

}
