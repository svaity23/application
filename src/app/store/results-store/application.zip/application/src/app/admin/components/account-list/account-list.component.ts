import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { cn } from 'src/utils/cn';

import { AccountDetail } from '@app/core/models/entities/account-detail.model';

@Component({
  selector: 'app-account-list',
  templateUrl: './account-list.component.html',
  styleUrls: ['./account-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class AccountListComponent implements OnInit, OnChanges {
  @Input() accounts: AccountDetail[] = [];
  accountsToDisplay: AccountDetail[]; // we need this because we do a sort, and do not want to modify state itself
  @Input() className = '';
  @Output() editAccountEvent = new EventEmitter<AccountDetail>();
  includeInactive = false;
  @Output() includeInActiveEvent = new EventEmitter<boolean>();
  searchAccountIDText = '';
  searchAccountNameText = '';
  searchAccountTypeText = '';
  searchFederatedDomainText = '';
  sortField = 'name';
  sortOrder = 'desc';

  editAccount(account: AccountDetail): void {
    this.editAccountEvent.emit(account);
  }

  filterAccountsToDisplay(): void {
    this.resetAccountsToDisplay();
    this.accountsToDisplay = this.accountsToDisplay.filter((item) => {
      if (item.name.toString().toLocaleLowerCase().includes(this.searchAccountNameText.toLocaleLowerCase())
          && item.id.toString().toLocaleLowerCase().includes(this.searchAccountIDText.toLocaleLowerCase())
          && item.accountTypeName.toString().toLocaleLowerCase().includes(this.searchAccountTypeText.toLocaleLowerCase())
          && item.federatedDomains.toString().toLocaleLowerCase().includes(this.searchFederatedDomainText.toLocaleLowerCase()))
        return item;
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.accounts) {
      this.resetAccountsToDisplay();
    }
  }

  ngOnInit(): void {
    this.className = cn('account-list', this.className);
  }

  resetAccountsToDisplay(): void {
    this.accountsToDisplay = [...this.accounts];
  }

  sort(columnName: string): void {
    // toggle sort order if already selected
    if (this.sortField === columnName) {
      this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortField = columnName;
      this.sortOrder = 'asc';
    }

    // setup the evalution
    const v1 = this.sortOrder === 'asc' ? 1 : -1;
    const v2 = this.sortOrder === 'asc' ? -1 : 1;

    switch (this.sortField) {
      case 'id':
        this.accountsToDisplay.sort((s1, s2) => s1.id > s2.id ? v1 : v2); // need to modify this based on role name
        break;
      case 'name':
        this.accountsToDisplay.sort((s1, s2) => s1.name.toLocaleLowerCase() > s2.name.toLocaleLowerCase() ? v1 : v2);
        break;
      case 'type':
        this.accountsToDisplay.sort((s1, s2) => s1.accountTypeName > s2.accountTypeName ? v1 : v2); // need to modify this based on role name
        break;
      case 'active':
        this.accountsToDisplay.sort((s1, s2) => s1.active > s2.active ? v1 : v2);
        break;
      default:
    }
  }

  toggleIncludeInActiveChange(): void {
    this.includeInactive = !this.includeInactive;
    this.includeInActiveEvent.emit(this.includeInactive);
  }

}
