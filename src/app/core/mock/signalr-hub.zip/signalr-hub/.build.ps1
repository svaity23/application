param(
   $Variant = 'web/dam/signalrhub',
   $TerragrunVersion = 'v0.23.20',
    $Tag = "$($Variant):$($TerragrunVersion)",
    $ContainerUser = "terragrunt",
    $ACRRegistry = "acrmcc002hub979c",
    $CommitHash = $Env:BUILD_SOURCE_VERSION,
    $HasDocker = $null -ne $(Get-Command Docker -ErrorAction Ignore).Source,
    $App = "dam-signalrhub",
    $DeployEnv = $Env:DEPLOY_ENV,
    $DeployTimeout = $Env:DEPLOY_TIMEOUT,
    $Port = 5090,
    $DockerName = "dam_signalrhub",
    $ProjectPath = "SignalRHub"

)


. ./.tasks/functions/support.ps1
. ./.tasks/azure.build.ps1

# Synopsis: Generates the version
Task Version {
    $branch = (Get-Env -EnvVarValue $CommitHash -exec { (git rev-parse HEAD) })
    if ( $branch -eq "" ) { $branch = $(exec { git branch --show-current} ) }

    $script:BranchHash = "$branch".substring(0,7)
    $script:Version = "$Variant`:$script:BranchHash"
    $script:ACRPath = "$ACRRegistry.azurecr.io/$($script:Version)"

}

Task LocalBuild -If ($HasDocker)  Version,  {
    "Running docker image $ACRPath"
    exec { docker build . -f $ProjectPath/Dockerfile -t "$ACRPath"  }
}

# Synopsis: Runs the application in the container
Task Run -If ($HasDocker) Version, LocalBuild, {
    "Running image"
    exec { docker rm $DockerName -f  } -ExitCode @(0,1)
    exec { docker run --name=$DockerName -p ${Port}:${Port} -d $ACRPath }
    Start-Process "http://localhost:$Port/status"
}

# Synopsis: Will build the container in this project
Task Build  LocalBuild, Version, {
    if ($HasDocker) { break; }

    "Building container $ACRPath"
    Write-Debug "Docker is installed."

   exec { az acr build -f ./$ProjectPath/Dockerfile --registry $ACRRegistry  . -t $Version --subscription "MarcomCentral Infrastructure"}
}

# Synopsis: Build Manifests
Task BuildKustomize Version, {
    # how to specify working directory??
    Set-Location "./manifests/base"
    exec { kustomize edit set image IMAGE_NAME=$ACRPath }
}

# Synopsis: Apply Kustomize Manifests
Task DeployKustomize Version, {
    # how to specify working directory??
    # Set-Location "$PSScriptRoot/manifests/$DeployEnv"
    Set-Location "./manifests/$DeployEnv"
    exec { kustomize build . | kubectl apply -f - }
    "about to ----> exec  { kubectl rollout status deployment/dam-$DeployEnv-signalrhub-deployment --timeout=$DeployTimeout -nazdo -w }"
    exec { kubectl rollout status "deployment/dam-$DeployEnv-signalrhub-deployment" --timeout=$DeployTimeout -nazdo -w }
}

