export const INTEGRATION_SLACK_ENABLE_SETTING_KEY = 'integration-slack-enabled';
export const INTEGRATION_HUBSPOT_ENABLE_SETTING_KEY = 'integration-hubspot-enabled';
export const HUBSPOT_CREDENTIALS_SETTINGS_KEY = 'hubspot-credentials';
export const INTEGRATION_MICROSOFT_SSO_ENABLE_SETTING_KEY = 'integration-microsoft-login-enabled';
export const INTEGRATION_WORDPRESS_ENABLE_SETTING_KEY = 'integration-wordpress-enabled';
export const INTEGRATION_MARCOMCENTRAL_ENABLE_SETTING_KEY = 'integration-marcomcentral-enabled';
export const MARCOM_CREATE_ASSET_CREDENTIALS_SETTINGS_KEY = 'marcom-create-asset-credentials';


