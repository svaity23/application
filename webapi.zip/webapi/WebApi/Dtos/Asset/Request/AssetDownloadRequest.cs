﻿using System;

namespace WebApi.Dtos.Asset.Request
{
    public class AssetDownloadRequest
    {
        public Guid AssetId { get; set; }
        public string SourceFileName { get; set; }
        public string SaveAsFileName { get; set; }
    }
}
