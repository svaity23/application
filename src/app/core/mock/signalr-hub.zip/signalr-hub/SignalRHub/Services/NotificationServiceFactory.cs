﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;


namespace SignalRHub.Services
{
    public interface INotificationServiceFactory
    {
        NotificationService CreateNotificationService();
    }

    public class NotificationServiceFactory : INotificationServiceFactory
    {
        private readonly IConfiguration _configuration;
        private readonly IDbContextFactory _dbContextFactory;
        private readonly ILogger<NotificationServiceFactory> _logger;
        private readonly ILoggerFactory _loggerFactory;


        public NotificationServiceFactory(
            ILogger<NotificationServiceFactory> logger, 
            ILoggerFactory loggerFactory, 
            IConfiguration configuration, 
            IDbContextFactory dbContextFactory)
        {
            _configuration = configuration;
            _dbContextFactory = dbContextFactory;
            _logger = logger;
            _loggerFactory = loggerFactory;
        }

        public NotificationService CreateNotificationService()
        {
            return new NotificationService(_loggerFactory, _dbContextFactory);
        }
    }
}
