import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { AppStoreFacade } from '@app/store/app-store/app-store.facade';

export interface CanComponentDeactivate {
  canDeactivate: () => Observable<boolean> | Promise<boolean> | boolean;
}

@Injectable()
export class LibraryDeactivateGuard implements CanDeactivate<CanComponentDeactivate> {

  constructor(private appStoreFacade: AppStoreFacade) {
  }

  canDeactivate(
    component: CanComponentDeactivate,
    _currentRoute: ActivatedRouteSnapshot,
    _currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {


    // do NOT clear the selected collection when navigating to '/upload' because the Upload process
    // should display 3 or 4 uplod steps based on the existence of the sellected collection
    if (nextState.url.indexOf('/upload') === -1) {
      this.appStoreFacade.setActiveMenuCollectionId(null);
    }

    return component.canDeactivate ? component.canDeactivate() : true;
  }
}
