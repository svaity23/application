﻿using System;
using System.Text.Json.Serialization;

namespace WebApi.Dtos.Collection
{
    public class MoveCollectionDTO
    {
        /// <summary>
        /// Specifies the id of the collection that needs moving
        /// </summary>
        [JsonPropertyName("collectionId")]
        public Guid CollectionId { get; set; }

        /// <summary>
        /// When this is null or empty, it is pointing to the root of collections
        /// </summary>
        [JsonPropertyName("parentId")]
        public Guid? ParentId { get; set; }
    }
}
