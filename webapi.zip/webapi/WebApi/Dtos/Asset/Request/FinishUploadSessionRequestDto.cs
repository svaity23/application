﻿using System;

namespace WebApi.Dtos.Asset.Request
{
    public class FinishUploadSessionRequestDto
    {
        public string[] AssetIds { get; set; }
        public Guid UploadSessionId { get; set; }
    }
}
