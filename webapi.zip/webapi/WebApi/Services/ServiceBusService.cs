﻿using Marcom.Azure.ServiceBus;
using Marcom.Azure.ServiceBus.Config;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Threading.Tasks;

namespace WebApi.Services
{
    public class ServiceBusService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<ServiceBusService> _logger;
        private readonly IBusServiceFactory _busServiceFactory;
        private readonly ConcurrentDictionary<string, IBusSendService> _busCache; 


        /// <summary>
        /// Class responsible for all outgoing messages sent over ServiceBus. 
        /// The implementation contains a cache of the IBusSendService instances
        /// created upon request and reuses them when needed.
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        /// <param name="busServiceFactory"></param>
        public ServiceBusService(ILogger<ServiceBusService> logger, IConfiguration configuration, IBusServiceFactory busServiceFactory)
        {
            _configuration = configuration;
            _logger = logger;
            _busServiceFactory = busServiceFactory;
            _busCache = new ConcurrentDictionary<string, IBusSendService>(1, 10);
        }

        public async Task InitializeAsync()
        {
            // Have to warm up one service bus in particular because the user is waiting
            await SignalAccountRequested(new { MessageType = "TEST_STARTED", TestId = Guid.NewGuid().ToString() });
        }

        public async Task SignalNotificationInitiated(object message)
        {
            await Signal("NotificationInitiatedServiceBus", message);
        }

        public async Task SignalDistributedMarketing(object message)
        {
            await Signal("DistributedMarketingServiceBus", message);
        }

        public async Task SignalIndexAsset(object message)
        {
            await Signal("IndexAssetServiceBus", message);
        }

        public async Task SignalImageProcessed(object message)
        {
            await Signal("ImageProcessedServiceBus", message);
        }

        public async Task SignalImageUploaded(object message)
        {
            await Signal("ImageUploadedServiceBus", message);
        }

        public async Task SignalHubSpot(object message)
        {
            await Signal("HubspotAssetServiceBus", message);
        }

        public async Task SignalShareAsset(object message)  
        {
            await Signal("ShareAssetServiceBus", message);
        }

        public async Task SignalAITags(object message)
        {
            await Signal("AiTagsServiceBus", message);
        }

        public async Task SignalPDFUploaded(object message)
        {
            await Signal("PdfUploadedServiceBus", message);
        }

        public async Task SignalUserSync(object message)
        {
            await Signal("UserSyncServiceBus", message);
        }

        public async Task SignalSendEmail(object message)
        {
            await Signal("SendEmailServiceBus", message);
        }

        public async Task SignalAccountRequested(object message)
        {
            await Signal("AccountRequestedServiceBus", message);
        }

        /// <summary>
        /// Base implementation for a bus sending message, which caches the instances 
        /// of the services and re-use them when needed.
        /// </summary>
        /// <param name="configBusKey">The name of the bus section definition from appsettings</param>
        /// <param name="message">The message that should be sent</param>
        /// <returns></returns>
        private async Task Signal(string configBusKey, object message)
        {
            IBusSendService busService;
            _logger.LogDebug($"BEGIN Notifying {configBusKey}");

            if (!_busCache.TryGetValue(configBusKey, out busService)) 
            {
                busService = _busServiceFactory.CreateBusSendService(
                    _configuration[$"{configBusKey}:Endpoint"],
                    _configuration[$"{configBusKey}:TopicName"],
                    new ServiceBusSendSettings
                    {
                        ComputerName = _configuration["COMPUTERNAME"],
                        Environment = _configuration["DotnetEnvironment"],
                        TargetMachines = _configuration.Get<TargetMachineConfig>().TargetMachines
                    });
                _busCache.TryAdd(configBusKey, busService);
            }
            await busService.SendAsync(message);
            _logger.LogDebug($"END Notifying {configBusKey}");
        }

    }
}
