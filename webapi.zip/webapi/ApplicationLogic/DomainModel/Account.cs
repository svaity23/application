﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ApplicationLogic.DomainModel
{
    [Table("account")]
    [Index(nameof(Type), nameof(Active), nameof(Name), Name = "ix_account_type_active_companyname")]
    [Index(nameof(Name), Name = "uniq_account_name", IsUnique = true)]
    public partial class Account
    {
        public Account()
        {
            Asset = new HashSet<Asset>();
            Group = new HashSet<Group>();
            Metadata = new HashSet<Metadata>();
            Role = new HashSet<Role>();
            SettingAccount = new HashSet<Setting>();
            SettingAccountIdCriteriaNavigation = new HashSet<Setting>();
            User = new HashSet<User>();
            UserLegal = new HashSet<UserLegal>();
        }

        [Key]
        [Column("id")]
        public Guid Id { get; set; }
        [Column("externalId")]
        [StringLength(64)]
        public string ExternalId { get; set; }
        [Column("active")]
        public bool Active { get; set; }
        [Column("created")]
        public DateTime Created { get; set; }
        [Column("modified")]
        public DateTime? Modified { get; set; }
        [Column("type")]
        public Guid Type { get; set; }
        [Required]
        [Column("name")]
        [StringLength(64)]
        public string Name { get; set; }
        [Column("userId")]
        public Guid? UserId { get; set; }
        [Column("storageAccountName")]
        [StringLength(24)]
        public string StorageAccountName { get; set; }
        [Column("createdBy")]
        public Guid? CreatedBy { get; set; }
        [Column("lastModifiedBy")]
        public Guid? LastModifiedBy { get; set; }
        [Column("error")]
        public string Error { get; set; }
        [Column("salesforceId")]
        [StringLength(64)]
        public string SalesforceId { get; set; }
        [Column("trialExpiration")]
        public DateTime? TrialExpiration { get; set; }
        [Column("storageMaximumGb")]
        public int? StorageMaximumGb { get; set; }
        [Column("netsuiteId")]
        [StringLength(64)]
        public string NetsuiteId { get; set; }
        [Column("opportunityId")]
        [StringLength(64)]
        public string OpportunityId { get; set; }
        [Column("logo")]
        [StringLength(1024)]
        public string Logo { get; set; }
        [Column("theme")]
        [StringLength(64)]
        public string Theme { get; set; }

        [ForeignKey(nameof(Type))]
        [InverseProperty(nameof(AccountType.Account))]
        public virtual AccountType TypeNavigation { get; set; }
        [InverseProperty("Account")]
        public virtual ICollection<Asset> Asset { get; set; }
        [InverseProperty("Account")]
        public virtual ICollection<Group> Group { get; set; }
        [InverseProperty("Account")]
        public virtual ICollection<Metadata> Metadata { get; set; }
        [InverseProperty("Account")]
        public virtual ICollection<Role> Role { get; set; }
        [InverseProperty(nameof(Setting.Account))]
        public virtual ICollection<Setting> SettingAccount { get; set; }
        [InverseProperty(nameof(Setting.AccountIdCriteriaNavigation))]
        public virtual ICollection<Setting> SettingAccountIdCriteriaNavigation { get; set; }
        [InverseProperty("Account")]
        public virtual ICollection<User> User { get; set; }
        [InverseProperty("Account")]
        public virtual ICollection<UserLegal> UserLegal { get; set; }
    }
}
