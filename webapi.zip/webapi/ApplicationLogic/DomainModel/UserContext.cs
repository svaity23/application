﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ApplicationLogic.DomainModel
{
    [Keyless]
    public partial class UserContext
    {
        [Column("id")]
        public Guid Id { get; set; }
        [Required]
        [Column("firstName")]
        [StringLength(64)]
        public string FirstName { get; set; }
        [Column("lastName")]
        [StringLength(64)]
        public string LastName { get; set; }
        [Required]
        [Column("email")]
        [StringLength(128)]
        public string Email { get; set; }
        [Column("emailVerified")]
        public bool? EmailVerified { get; set; }
        [Column("userSalesforceId")]
        [StringLength(64)]
        public string UserSalesforceId { get; set; }
        [Column("accountId")]
        public Guid? AccountId { get; set; }
        [Column("accountName")]
        [StringLength(64)]
        public string AccountName { get; set; }
        [Column("accountActive")]
        public bool? AccountActive { get; set; }
        [Column("accountTrialExpiration")]
        public DateTime? AccountTrialExpiration { get; set; }
        [Column("accountTrialVerified")]
        public bool? AccountTrialVerified { get; set; }
        [Column("accountLogo")]
        [StringLength(1024)]
        public string AccountLogo { get; set; }
        [Column("accountFavicon")]
        [StringLength(1024)]
        public string AccountFavicon { get; set; }
        [Column("accountTheme")]
        [StringLength(64)]
        public string AccountTheme { get; set; }
        [Column("accountTypeName")]
        [StringLength(64)]
        public string AccountTypeName { get; set; }
        [Column("storageAccountName")]
        [StringLength(24)]
        public string StorageAccountName { get; set; }
        [Column("accountStorageMaximumGb")]
        public int? AccountStorageMaximumGb { get; set; }
        [Column("accountStorageUsed")]
        public long? AccountStorageUsed { get; set; }
        [Column("accountSalesforceId")]
        [StringLength(64)]
        public string AccountSalesforceId { get; set; }
        [Column("accountUserEmail")]
        [StringLength(128)]
        public string AccountUserEmail { get; set; }
        [Column("groupId")]
        public Guid? GroupId { get; set; }
        [Column("roleKey")]
        [StringLength(16)]
        public string RoleKey { get; set; }
        [Required]
        [Column("roleName")]
        [StringLength(64)]
        public string RoleName { get; set; }
        [Column("permissions")]
        public string Permissions { get; set; }
        [Column("legalDocuments")]
        public string LegalDocuments { get; set; }
        [Column("totalFavorites")]
        public int? TotalFavorites { get; set; }
        [Column("notifications")]
        public string Notifications { get; set; }
    }
}
