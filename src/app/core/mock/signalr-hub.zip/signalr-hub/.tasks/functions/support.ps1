function Get-Env {
    
    Param
    (
        [Parameter()]
        [string]$EnvVarValue,
        [Parameter(Mandatory=$false)]
        [scriptblock]$exec
    )
    PROCESS {
        if ($null -ne $EnvVarValue -and $EnvVarValue -ne "") {
            "$EnvVarValue"
        }
        else {
            $exec.Invoke() | % { "$_"}
        }
    }
} #End function