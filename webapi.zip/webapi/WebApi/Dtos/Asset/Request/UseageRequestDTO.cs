﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WebApi.Dtos.Asset.Request
{
    public class UseageRequestDTO
    {
        [JsonPropertyName("assetIds")]
        public List<Guid> AssetIds { get; set; }

        [JsonPropertyName("action")]
        public string Action { get; set; }
        
        [JsonPropertyName("actionDetails")]
        public string ActionDetails { get; set; }
    }
}
