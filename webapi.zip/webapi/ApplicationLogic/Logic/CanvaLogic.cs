﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLogic.Logic
{
    public class CanvaLogic
    {
        private readonly CanvaFinder _finder;
        private readonly NullLogger<GroupLogic> _logger;

        public CanvaLogic(damContext context)
        {
            _finder = new CanvaFinder(context);
            _logger = NullLogger<GroupLogic>.Instance;
        }

        public async Task<string> DeleteCanvaUserAsync(string jsonInput)
        {
            return await _finder.DeleteCanvaUserAsync(jsonInput);
        }

        public async Task<string> SaveCanvaUserAsync(Guid accountId, string jsonInput)
        {
            return await _finder.SaveCanvaUserAsync(accountId, jsonInput);
        }

        public async Task<string> GetAssetsAsync(string jsonInput)
        {
            return await _finder.GetAssetsAsync(jsonInput);
        }
    }
}
