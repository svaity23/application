import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import { AccountMetadataProfilesStoreFacade } from '@app/store/account-store/account-metadata-profile.facade';
import { AppStoreFacade } from '@app/store/app-store/app-store.facade';
import { Context } from '@app/core/models/context.model';
import { MetadataField } from '@app/core/models/entities/metadata-field.model';
import { MetadataFieldAndValueForPreview } from '@app/core/models/metadata-field-and-value-for-preview';
import { MetadataFieldValue } from '@app/core/models/entities/metadata-field-value.model';
import { MetadataProfileView } from '@app/core/models/metadata-profile-view.model';
import { Role } from '@app/core/models/entities/role.model';
import { ToastIcon, ToastSeverity, ToastTimeout } from '@app/core/enums';

@Component({
  selector: 'app-metadata-profile-form',
  templateUrl: './metadata-profile-form.component.html',
  styleUrls: ['./metadata-profile-form.component.scss']
})
export class MetadataProfileFormComponent implements OnInit {
  accountTypeName$: Observable<string>;
  context$: Observable<Context>;
  profile$: Observable<MetadataProfileView>;
  profileFieldAndValuesToPreview$: Observable<MetadataFieldAndValueForPreview[]>;
  profileFieldLabels$: Observable<string[]>;
  profileFieldsToModify$: Observable<MetadataField[]>;
  profileFieldValuesToModify$: Observable<MetadataFieldValue[]>;
  roles$: Observable<Role[]>;
  showIntegrations$: Observable<boolean>;
  showSave$: Observable<boolean>;
  showUserGroups$: Observable<boolean>;

  constructor(private appStoreFacade: AppStoreFacade, private accountMetadataProfilesStoreFacade: AccountMetadataProfilesStoreFacade) { }

  fieldAddedEvent(newField: MetadataField): void {
    this.accountMetadataProfilesStoreFacade.addMetadataProfileField(newField);
  }

  fieldDeletedEvent(deletedField: MetadataField): void {
    this.accountMetadataProfilesStoreFacade.openMetadataProfileConfirmationModal({
      title: 'Remove Field',
      message: 'Are you sure? After saving the updatd profile, previously entered metadata for this field will be deleted. This cannot be undone.',
      confirmButtonText: 'Remove',
      denyButtonText: 'Cancel',
      confirm: () => { this.deleteField(deletedField); },
      deny: () => { },
      confirmButtonIcon: 'trash'
    });
  }

  fieldExpandedOrCollapsedEvent(fieldToExpandOrCollapse: MetadataField): void {
    this.accountMetadataProfilesStoreFacade.expandOrCollapseMetadataProfileField(fieldToExpandOrCollapse);
  }

  fieldRequiredSettingUpdatedEvent(updatedField: MetadataField): void {
    this.accountMetadataProfilesStoreFacade.updateRequiredSettingOnMetadataProfileField(updatedField);
  }

  fieldsSortedEvent(fields: MetadataField[]): void {
    this.accountMetadataProfilesStoreFacade.updateSortMetadataProfileFields(fields);
  }

  fieldUpdatedEvent(updatedField: MetadataField): void {
    this.accountMetadataProfilesStoreFacade.updateMetadataProfileField(updatedField);
  }

  fieldValueDeletedEvent(deletedFieldValue: MetadataFieldValue): void {
    this.accountMetadataProfilesStoreFacade.openMetadataProfileConfirmationModal({
      title: 'Remove Field',
      message: 'Are you sure? After saving the updatd profile, previously entered metadata for this field will be deleted. This cannot be undone.',
      confirmButtonText: 'Remove',
      denyButtonText: 'Cancel',
      confirm: () => { this.deleteFieldValue(deletedFieldValue); },
      deny: () => { },
      confirmButtonIcon: 'trash'
    });
  }

  fieldValuesAddedEvent(fieldValues: MetadataFieldValue[]): void {
    this.accountMetadataProfilesStoreFacade.addMetadataProfileFieldValues(fieldValues);
  }

  fieldValuesSortedEvent(fieldValues: MetadataFieldValue[]): void {
    this.accountMetadataProfilesStoreFacade.updateSortMetadataProfileFieldValues(fieldValues);
  }

  fieldValueUpdatedEvent(updatedFieldValue: MetadataFieldValue): void {
    this.accountMetadataProfilesStoreFacade.updateMetadataProfileFieldValue(updatedFieldValue);
  }

  navigateTo(pageName): void {
    this.appStoreFacade.navigate(`account/${pageName}`);
  }

  navigateToProfiles(): void {
    this.appStoreFacade.navigate('/account/metadata-profiles');
  }

  ngOnInit(): void {
    this.accountTypeName$ = this.appStoreFacade.accountTypeName$;
    this.context$ = this.appStoreFacade.context.context$;
    this.profile$ = this.accountMetadataProfilesStoreFacade.selectedMetadataProfile$;
    this.profileFieldsToModify$ = this.accountMetadataProfilesStoreFacade.selectedMetadataProfileFieldsToModify$;
    this.profileFieldLabels$ = this.accountMetadataProfilesStoreFacade.selectedMetadataProfileFieldLabels$;
    this.profileFieldValuesToModify$ = this.accountMetadataProfilesStoreFacade.selectedMetadataProfileFieldValuesToModify$;
    this.profileFieldAndValuesToPreview$ = this.accountMetadataProfilesStoreFacade.selectMetadataProfileFieldAndValuesToPreview$;
    this.showIntegrations$ = this.appStoreFacade.showIntegrations$;
    this.showSave$ = this.accountMetadataProfilesStoreFacade.isMetadataProfileFieldsReadyForSave$;
    this.showUserGroups$ = this.appStoreFacade.context.isUserGroupsFeatureEnabled$;
    this.accountMetadataProfilesStoreFacade.loadProfileFields();
  }

  openPreviewModal(event: { profileFieldAndValues: MetadataFieldAndValueForPreview[], profileName: string }): void {
    this.accountMetadataProfilesStoreFacade.openMetadataPreviewModal({
      profileFieldAndValues: event.profileFieldAndValues,
      profileName: event.profileName,
      title: 'Preview',
      message: 'This preview shows how a DAM user will see your metadata profile while adding or editing an asset.'
    });
  }

  saveProfile(): void {
    this.accountMetadataProfilesStoreFacade.saveMetadataProfileFields();
  }

  showProfilePreview(): void {
    this.appStoreFacade.showToast({ message: 'Profile Preview Coming soon', icon: ToastIcon.InfoCircle, severity: ToastSeverity.Info, timeout: ToastTimeout.Default });
  }

  private deleteField(deletedField: MetadataField): void {
    this.accountMetadataProfilesStoreFacade.deleteMetadataProfileField(deletedField);
  }

  private deleteFieldValue(deletedFieldValue: MetadataFieldValue): void {
    this.accountMetadataProfilesStoreFacade.deleteMetadataProfileFieldValue(deletedFieldValue);
  }

}
