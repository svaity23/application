﻿using System.Threading.Tasks;

namespace SignalRHub.Hub
{
    /// <summary>
    /// This interface allows for a strongly typed hub.
    /// So we can do things like Context.Clients.All.BroadcastMessage(...)
    /// </summary>
    public interface IUploadHub
    {
        Task BroadcastMessage(object payloadJson);
    }
}
