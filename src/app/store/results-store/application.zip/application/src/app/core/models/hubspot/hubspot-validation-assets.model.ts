import { Asset } from '../entities/asset.model';

export interface HubspotValidationAssets {
	failedAssets: string[],
	validAssets: Asset[]
}
