import { ChangeDetectionStrategy, Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Observable } from 'rxjs';

import { AppStoreFacade } from '@app/store/app-store/app-store.facade';
import { Context } from '@app/core/models/context.model';
import { IntegrationSetting } from '@app/core/models/integration-setting.model';
import { Setting } from '@app/core/models/setting.model';

@Component({
  selector: 'app-integrations',
  templateUrl: './integrations.component.html',
  styleUrls: ['./integrations.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class IntegrationsComponent implements OnInit {

  accountSettings$: Observable<Setting[]>;
  accountTypeName$: Observable<string>;
  context$: Observable<Context>;
  isHubspotFeatureEnabled$: Observable<boolean>;
  isMarcomPortalAssetFeatureEnabled$: Observable<boolean>;
  isMarcomPortalLibraryFeatureEnabled$: Observable<boolean>;
  isMicrosoftSsoFeatureEnabled$: Observable<boolean>;
  isSlackFeatureEnabled$: Observable<boolean>;
  isWordpressFeatureEnabled$: Observable<boolean>;
  searchText$: Observable<string>;
  showIntegrations$: Observable<boolean>;
  showUserGroups$: Observable<boolean>;

  constructor(private appStoreFacade: AppStoreFacade) { }

  navigateTo(pageName: string): void {
    this.appStoreFacade.navigate(`account/${pageName}`);
  }

  ngOnInit(): void {
    this.appStoreFacade.setPageTitle('Integrations | MarcomGather');
    this.accountSettings$ = this.appStoreFacade.accountSettings$;
    this.accountTypeName$ = this.appStoreFacade.accountTypeName$;
    this.context$ = this.appStoreFacade.context.context$;
    this.isHubspotFeatureEnabled$ = this.appStoreFacade.context.isHubspotFeatureEnabled$;
    this.isMarcomPortalAssetFeatureEnabled$ = this.appStoreFacade.context.isMarcomPortalAssetFeatureEnabled$;
    this.isMarcomPortalLibraryFeatureEnabled$ = this.appStoreFacade.context.isMarcomPortalLibraryFeatureEnabled$;
    this.isMicrosoftSsoFeatureEnabled$ = this.appStoreFacade.context.isMicrosoftSsoFeatureEnabled$;
    this.isSlackFeatureEnabled$ = this.appStoreFacade.context.isSlackFeatureEnabled$;
    this.isWordpressFeatureEnabled$ = this.appStoreFacade.context.isWordpressFeatureEnabled$;
    this.showIntegrations$ = this.appStoreFacade.showIntegrations$;
    this.showUserGroups$ = this.appStoreFacade.context.isUserGroupsFeatureEnabled$;
  }

  toggleIntegrationStatus(integration: IntegrationSetting): void {
    this.appStoreFacade.toggleIntegrationStatus(integration);
  }

}
