﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AllowAnonymous]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class LightboxesPublicController : ControllerBase
    {
        private readonly ILogger<LightboxesPublicController> _logger;
        private readonly LightboxService _lightboxService;

        public LightboxesPublicController(ILogger<LightboxesPublicController> logger, LightboxService lightboxService)
        {
            _logger = logger;
            _lightboxService = lightboxService;            
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetLightbox(Guid id, int sortField, int skip, int pageSize)
        {
            var result = await _lightboxService.GetLightboxPublicAsync(id, sortField, skip, pageSize);
            if (result != null)
            {
                return Ok(result);
            }
            return NotFound();
        }
    }
}
