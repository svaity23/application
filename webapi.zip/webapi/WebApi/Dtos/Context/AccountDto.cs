﻿using System;
using System.Text.Json.Serialization;

namespace WebApi.Dtos.Context
{
    public class AccountDto
    {
        [JsonPropertyName("id")]
        public Guid Id { get; set; }      
        [JsonPropertyName("accountTypeName")]
        public string AccountTypeName { get; set; }
        [JsonPropertyName("name")]
        public string Name { get; set; }       
    }
}
