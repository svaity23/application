﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ApplicationLogic.Logic
{
    public class AccountLogic
    {
        private readonly AccountDetailFinder _accountDetailFinder;
        private readonly AccountFinder _accountFinder;

        public AccountLogic(damContext context)
        {
            _accountFinder = new AccountFinder(context);
            _accountDetailFinder = new AccountDetailFinder(context);
            Logger = NullLogger<AccountLogic>.Instance;
            // TODO - create logic for _finder
            //_finder.Logger =
        }

        public ILogger<AccountLogic> Logger { get; set; }

        public async Task<Account> FindByIdAsync(Guid id)
        {
            return await _accountFinder.FindByIdAsync(id);
        }

        public async Task<string> GetAccountDetailByAccountId(Guid accountId, Guid userId)
        {
            return await _accountDetailFinder.GetByAccountId(accountId, userId);
        }

        public async Task<AccountType> GetAccountTypeAsync(string typeName)
        {
            return await _accountDetailFinder.GetAccountTypeAsync(typeName);
        }

        public async Task<string> GetAllResultsAsync(bool includeInactive = true)
        {
            Logger.LogInformation($"[Logic] Getting all accounts");
            return await _accountDetailFinder.GetAllAsync(includeInactive);            
        }

        public async Task<string> GetFederateAdAccountByEmailAsync(string email)
        {
            return await _accountFinder.GetFederatedAdAccountByEmailAsync(email);
        }

        public async Task<AccountDetail> GetByNameAsync(string name)
        {
            return await _accountDetailFinder.GetByNameAsync(name);
        }

        public async Task<string> UpsertAccountAsync(Guid userId, string jsonString)
        {
            return await _accountFinder.UpsertAccountAsync(userId, jsonString);
        }

        public async Task<int> DeleteAccount(Guid accountId)
        {
            return await _accountFinder.DeleteAccount(accountId);
        }

        public async Task<string> UpdateAccountBrandDetailsAsync(Guid userId, Guid accountId, string jsonString)
        {
            return await _accountFinder.UpdateAccountBrandDetailsAsync(userId, accountId, jsonString);
        }

        public async Task<string> CreateFreeTrialSampleDataAsync(Guid accountId, Guid userId, string jsonInput)
        {
            return await _accountFinder.CreateFreeTrialSampleDataAsync(accountId, userId, jsonInput);
        }

        public async Task<string> GetAccountsByUserIdAsync(Guid userId)
        {
            return await _accountFinder.GetAccountsByUserIdAsync(userId);
        }

        public async Task<string> GetAccountFeaturesAsync(Guid accountId, Guid userId)
        {
            return await _accountFinder.GetAccountFeaturesAsync(accountId, userId);
        }

        public async Task<string> GetFederatedAdAccountByEmailAsync(string email)
        {
            return await _accountFinder.GetFederatedAdAccountByEmailAsync(email);
        }

        public async Task<string> SaveFederatedDomainAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            return await _accountFinder.SaveFederatedDomainAsync(accountId, userId, sessionId, jsonInput);
        }

        public async Task<string> DeleteFederatedDomainsAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            return await _accountFinder.DeleteFederatedDomainsAsync(accountId, userId, sessionId, jsonInput);
        }

        public async Task<string> UpdateAccountFeaturesAsync(Guid accountId, Guid userId, string jsonInput)
        {
            return await _accountFinder.UpdateAccountFeaturesAsync(accountId, userId, jsonInput);
        }
    }
}
