import { Collection } from '../entities/collection.model';
import { Group } from '../entities/group.model';

export interface PermissionsModalOptions {
  assign: (collection: Collection) => void;
  confirmButtonText: string;
  deny: () => void;
  denyButtonText: string;
  groupInfo: {groups: Group[], selectedCollection: Collection};
  title: string;
}
