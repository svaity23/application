﻿using System;

namespace WebApi.Dtos.Asset.Revision
{
    public class AssetRevisionDto
    {
        public DateTime? Created { get; set; }
        public AssetRevisionHistoryDto[] History { get; set; }
        public AssetRevisionsUserDto User { get; set; }
    }
}
