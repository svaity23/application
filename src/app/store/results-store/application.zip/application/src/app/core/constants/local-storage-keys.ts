export const SELECTED_ACCOUNT_ID = 'aId';
