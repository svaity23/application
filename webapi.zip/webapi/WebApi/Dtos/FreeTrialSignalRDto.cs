﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos
{
    public class FreeTrialSignalRDto
    {
        public string SignalRSource { get; set; }
        public string SignalRConnectionId { get; set; }
    }
}
