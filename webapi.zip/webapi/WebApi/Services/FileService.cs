﻿using ApplicationLogic.DomainModel;
using System;
using System.Collections.Generic;

namespace WebApi.Services
{
    public static class FileService
    {
        public static bool IsValidFileExtension(string fileExt)
        {
            var trimmedFileExt = fileExt.Trim(new char[] { '.' }).ToUpperInvariant();
            var enumNames = Enum.GetNames(typeof(FileExtensionType));
            return Array.IndexOf(enumNames, trimmedFileExt) >= 0;
        }

        /// <summary>
        /// Returns whether or not the fileExtension is a video file group type.
        /// </summary>
        /// <param name="fileExtension">File extension string with no '.'</param>
        /// <returns></returns>
        public static bool IsVideoFile(string fileExtension)
        {
            FileExtensionType fileExtentionType = Enum.Parse<FileExtensionType>(fileExtension.ToUpper());
            return GetVideoFileExtensions().Contains(fileExtentionType);
        }

        public static List<FileExtensionType> GetVideoFileExtensions()
        {
            return new List<FileExtensionType>
            {
                FileExtensionType.AVI,
                FileExtensionType.WMV,
                FileExtensionType.MOV,
                FileExtensionType.MP4,
                FileExtensionType.HEVC,
                FileExtensionType.R3D,
                FileExtensionType.VID,
                FileExtensionType.MPEG,
                FileExtensionType.LRV,
                FileExtensionType.SWF,
                FileExtensionType.FLV
            };
        }
    }

    public enum FileGroupType
    {
        Image = 0,
        Video = 1,
        Audio = 2,
        Design = 3,
        Presentation = 4,
        Document = 5,
        FusionPro = 6,
        Font = 7,
        Archive = 8
    }

    public enum FileExtensionType
    {
        // Image file extensions
        JPEG,
        JPG,
        GIF,
        PNG,
        TIFF,
        TIF,
        BMP,
        SVG,
        RAW,
        HEIC,
        NEF,
        ORF,
        CR2,
        DNG,
        ICO,
        CUR,

        // Video file extensions
        AVI,
        WMV,
        MOV,
        MP4,
        HEVC,
        R3D,
        VID,
        MPEG,
        LRV,
        SWF,
        FLV,

        // Audio file extensions
        MP3,
        WAV,
        M4A,
        FLAC,
        AIF,
        AAC,
        WMA,

        // Design file extensions
        EPS,
        HTML,
        PUB,
        SKETCH,
        PSD,
        AI,
        INDD,
        XD,
        ASE,
        // Invision ???

        // FusionPro file extensions
        // Template files ???

        // Presentation file extensions
        PPT,
        PPTX,
        PPTM,
        POT,
        POTX,
        POTM,
        PPS,
        PPSX,
        PPSM,
        PEZ,
        KEY,

        // Document file extensions
        XLS,
        XLSX,
        TXT,
        DOC,
        DOCX,
        CSV,
        PDF,

        // Font file extensions
        FNT,
        FON,
        TTF,
        OTF,
        WOF,
        TTC,

        // Archive file extensions
        ZIP
    }
}
