
export interface Metadata {
    active?: boolean;
    assetId: string;
    fromFile?: boolean;
    id: string;
    metadataFieldId: string;
    metadataFieldValueId: string;
    value: string;
}

