// sorted by the order we want to display in drop down
export enum AccountTypeKey {
    Trial = 'Trial',
    Evaluation = 'Free Evaluation',
    Essential = 'Essential',
    Team = 'Team',
    Business = 'Business',
    MCCInternal = 'MCCInternal'
}

