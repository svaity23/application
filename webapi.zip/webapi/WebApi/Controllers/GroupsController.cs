﻿using ApplicationLogic.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Dtos;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class GroupsController : ControllerBase
    {
        private readonly ILogger<GroupsController> _logger;
        private readonly GroupService _groupService;
        private readonly UserAccountService _userAccountService;

        public GroupsController(ILogger<GroupsController> logger, GroupService groupService, UserAccountService userAccountService)
        {
            _logger = logger;
            _groupService = groupService;
            _userAccountService = userAccountService;
        }

        /// <summary>
        /// Get all groups
        /// </summary>
        /// <remarks>
        /// Gets all groups for current account
        /// </remarks>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<GroupDto>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAllGroupsAsync()
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            GetEntitiesResponse<GroupDto> results = await _groupService.GetAllGroupsAsync(accountId, userId);
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entities ?? new List<GroupDto>()),
                    3 => Forbid(),// the user doesn't have admin rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }

        /// <summary>
        /// Bulk delete groups
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="groupIds"></param>
        /// <returns></returns>
        [HttpPost("bulk/deletes")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<Guid>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> BulkDeleteGroupsAsync([FromBody] BulkDeleteRequestDTO groupIds)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            _logger.LogWarning($"User {userId} initiate the bulk delete of groups {groupIds}");
            var results = await _groupService.BulkDeleteGroupsAsync(accountId, userId, groupIds);
            if (results != null)
            {
                int err = results.Errors[0].Code;
                return err switch
                {
                    0 => Ok(results.Entity),
                    3 => Forbid(),// the user doesn't have admin rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }

            return NotFound();
        }

        /// <summary>
        /// Delete group
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="groupId"></param>
        /// <returns></returns>
        [HttpDelete("{groupId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<Guid>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> DeleteGroupAsync(Guid groupId)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            _logger.LogWarning($"User {userId} initiate the delete of the group {groupId}");
            var results = await _groupService.DeleteGroupAsync(accountId, userId, groupId);
            if (results != null)
            {
                int err = results.Errors[0].Code;
                return err switch
                {
                    0 => Ok(results.Entity),
                    3 => Forbid(),// the user doesn't have admin rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }

            return NotFound();
        }

        /// <summary>
        /// Update group
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="groupId"></param>
        /// <param name="update"></param>
        /// <returns></returns>
        [HttpPut("{groupId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(GroupDto))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public async Task<IActionResult> UpdateGroupAsync(Guid groupId, [FromBody] GroupDto update)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            if (update == null
                || update.AccountId == null
                || update.Name == null
                || groupId == Guid.Empty
                ) return BadRequest();

            _logger.LogWarning($"User {userId} pushes updates on groups {groupId}");
            var results = await _groupService.SaveGroupAsync(accountId, userId, update);
            if (results != null)
            {
                int err = results.Errors[0].Code;
                return err switch
                {
                    0 => Ok(results.Entity),
                    2 => Conflict(),// a group with the specified name already exists in db
                    3 => Forbid(),// the user doesn't have administrative rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }

            return NotFound();
        }

        /// <summary>
        /// Create new group
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="group"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created, Type = typeof(GroupDto))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public async Task<IActionResult> CreateGroupAsync([FromBody] GroupDto group)
        {

            if (group == null
                || group.Name == null
                || group.Id != Guid.Empty
                ) return BadRequest();

            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            group.AccountId = accountId;

            _logger.LogWarning($"User {userId} creates a new group {group.Name}");
            var results = await _groupService.SaveGroupAsync(accountId, userId, group);
            if (results != null)
            {
                int err = results.Errors[0].Code;
                return err switch
                {
                    0 => StatusCode(StatusCodes.Status201Created, results.Entity),
                    2 => Conflict(),// a group with the specified name already exists in db
                    3 => Forbid(),// the user doesn't have admin rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }

    }
}