import { HttpEvent } from '@angular/common/http';
import { Injectable, Injector } from '@angular/core';
import { Observable } from 'rxjs';

import { Asset } from '../models/entities/asset.model';
import { AssetValidateReplaceResponse } from '../models/entities/asset-validate-replace-response.model';
import { BaseDataService } from './base-data.service';
import { SignalRSource } from '../enums/signal-r-source.enum';

export interface UploadRevisionDataServiceInterface {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  uploadRevisionForAsset(asset: AssetValidateReplaceResponse, file: File, source: SignalRSource): Observable<HttpEvent<any>>;
  validateAndReplaceAsset(asset: Asset, oldAssetId: string): Observable<AssetValidateReplaceResponse>
}

@Injectable({
  providedIn: 'root'
})
export class UploadRevisionDataService extends BaseDataService implements UploadRevisionDataServiceInterface {

  constructor(injector: Injector) {
    super(injector);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  uploadRevisionForAsset(asset: AssetValidateReplaceResponse, file: File, source: SignalRSource): Observable<HttpEvent<any>> {

    const data = new FormData();
    data.append('assetId', asset.id);
    data.append('uploadSessionId', asset.uploadSessionId);
    data.append('source', source);
    data.append('fileGroup', asset.fileGroup.toString());
    data.append('revision', 'true');

    // signalRConnectionId will be added via the signalr interceptor.
    // data.append('signalRConnectionId', signalRConnectionId);

    data.append('file', file, file.name);

    const url = `${this.uploadApiUrl}/upload`;
    return this.createApiPost({ url, data, options: { reportProgress: true, observe: 'events', responseType: 'json' } });
  }

  validateAndReplaceAsset(asset: Asset, oldAssetId: string): Observable<AssetValidateReplaceResponse> {
    const data = {
      id: asset.id,
      name: asset.name,
      favorite: asset.favorite,
      fileName: asset.fileName,
      fileSize: asset.fileSize,
    };
    const url = `${this.webApiUrl}/upload/assetRevision/${oldAssetId}`;
    return this.createApiPost({ url, data });
  }
}
