﻿using System.Collections.Generic;

namespace SignalRHub.Messages
{
    public class AssetAttachmentReplyDTO
	{
		public List<SaveErrorDTO> Updates;
		public List<MetadataEntryDTO> MetadataInfo;
    }
}
