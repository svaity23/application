import { AssetFile } from './asset-file.model';

export interface GoogleDriveFile extends AssetFile {
	googleFileId: string;
}
