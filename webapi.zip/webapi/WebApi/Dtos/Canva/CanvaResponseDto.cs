﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos.Canva
{
    public class CanvaResponseDto
    {
        public string Type { get; set; }
        public string ErrorCode { get; set; }
        public List<object> Resources { get; set; }
        public string Continuation { get; set; }
    }
}
