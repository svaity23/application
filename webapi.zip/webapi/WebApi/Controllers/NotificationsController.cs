﻿using ApplicationLogic.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Dtos.Notification;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class NotificationsController : ControllerBase
    {
        private readonly ILogger<NotificationsController> _logger;
        private readonly NotificationService _notificationService;
        private readonly UserAccountService _userAccountService;

        public NotificationsController(ILogger<NotificationsController> logger, NotificationService notificationService, UserAccountService userAccountService)
        {
            _logger = logger;
            _notificationService = notificationService;
            _userAccountService = userAccountService;
        }

        /// <summary>
        /// Returns the list of notifications for a user.
        /// </summary>
        /// <remarks>
        /// Returns the list of notifications for a user.
        /// </remarks>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<NotificationDto>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAllNotificationsAsync()
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            GetEntitiesResponse<NotificationDto> results = await _notificationService.GetAllNotificationsAsync(accountId, userId);

            if (results != null)
            {

                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entities ?? new List<NotificationDto>()),
                    3 => Forbid(),// the user doesn't have admin rights
                    _ => BadRequest(),// user not found
                };
            }
            return NotFound();
        }

        /// <summary>
        /// Marks one or multiple notifications
        /// </summary>
        /// <remarks>
        /// Marks one or multiple notifications as read/unread
        /// </remarks>
        /// <returns></returns>
        [HttpPut("mark")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<Guid>))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> MarkNotificationsAsReadAsync([FromBody] MarkNotificationDTO data)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            _logger.LogWarning($"User {userId} marks the notifications");
            var results = await _notificationService.MarkNotificationAsync(accountId, userId, data);
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entities ?? new List<Guid>()),
                    3 => Forbid(),// the user doesn't have admin rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }

            return NotFound();
        }

        /// <summary>
        /// Delete Notifications based on the list of notification id's supplied
        /// </summary>
        /// <remarks>
        /// Returns the list of notification ids removed successfully.
        /// </remarks>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<Guid>))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> DeleteByIdAsync(Guid id)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            _logger.LogWarning($"User {userId} initiate the delete of the notification {id}");
            var results = await _notificationService.DeleteAsync(accountId, userId, id);
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entities ?? new List<Guid>()),
                    3 => Forbid(),// the user doesn't have admin rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }

            return NotFound();
        }
    }
}