﻿using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Jwt;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace WebApi.Services
{
    public class SisenseService
    {
        const string API_LOGIN_PATH = "/v1/authentication/login";
        const string API_USERS_PATH = "/v1/users";
        const string API_GROUPS_PATH = "/v1/groups";
        const string API_DATA_SECURITY_PATH = "/elasticubes/datasecurity";

        private readonly ILogger<UserService> _logger;
        private readonly IConfiguration _configuration;
        private readonly SecretClient _secretClient;
        private readonly string _baseAdress;
        private string _apiAccessToken = String.Empty;


        public SisenseService(IConfiguration configuration, SecretClient secretClient, ILogger<UserService> logger)
        {
            _configuration = configuration;
            _logger = logger;
            _secretClient = secretClient;
            _baseAdress = _configuration["Sisense:Uri"] + "/api";
        }

        private async Task<string> GetApiAccessTokenAsync()
        {
                if (String.IsNullOrEmpty(_apiAccessToken))
                {
                    string json = null;
                    string postUrl = _baseAdress + API_LOGIN_PATH;

                    using (var client = new HttpClient())
                    {
                        var content = new FormUrlEncodedContent(new[]
                        {
                         new KeyValuePair<string, string>("username", await GetSecretFromKeyVaultsAsync(_configuration["KeyVault:Secrets:SisenseApiKeyUserName"])),
                         new KeyValuePair<string, string>("password", await GetSecretFromKeyVaultsAsync(_configuration["KeyVault:Secrets:SisenseApiKeyUserPassword"]))
                        });
                        var httpResponseMessage = client.PostAsync(postUrl, content).Result;
                        json = httpResponseMessage.Content.ReadAsStringAsync().Result;
                    }

                    //Extract the Access Token
                    dynamic results = JsonConvert.DeserializeObject<dynamic>(json);
                    if (results != null)
                        _apiAccessToken = results.access_token;
                }
                return _apiAccessToken;
        }

        public async Task<Uri> GetLaunchUrlAsync(string accountId)
        {

            // create user and group and apply data security if necessary
            await ManageUserAsync(accountId);

            string appPage = $"{ _configuration["Sisense:Uri"]}/app/main#/dashboards/{_configuration["Sisense:DefaultDashboardId"]}?embed=true&t=true&l=true";
            string launchUrl = $"{ _configuration["Sisense:Uri"]}/jwt?jwt={await GetJwtTokenAsync(accountId)}&return_to={appPage}";

            return new Uri(launchUrl);
        }

        private async Task ManageUserAsync(string accountId)
        {
            string userId = await GetUserIdAsync(accountId);

            // if user doesn't exist create a grup, a data security rule
            // and then create the user and add it to the group
            if(userId == null)
            {
                string groupName = "Account_" + accountId;
                string groupId = await GetGroupIdAsync(groupName);
                if (groupId == null)
                {
                    groupId = await CreateGroupAsync(groupName);
                }

                await CreateGroupRestrictionsAsync(accountId, groupId);

                await CreateUserAsync(accountId, groupId);
            }
        }

  
        private async Task<string> GetUserIdAsync(string userName)
        {
            string pathUrl = $"{API_USERS_PATH}?userName={userName}";
            dynamic results = await HttpRequestAsync(pathUrl, HttpMethod.Get);
            if (results != null && results is JArray && results.Count > 0)
            {
                return results[0]._id;
            }
            return null;
        }

        private async Task<string> GetGroupIdAsync(string groupName)
        {
            string pathUrl = $"{API_GROUPS_PATH}?name={groupName}";
            dynamic results = await HttpRequestAsync(pathUrl, HttpMethod.Get);
            if (results != null && results is JArray && results.Count > 0)
            {
                return results[0]._id;
            }
            return null;
        }
        private async Task<string> CreateGroupAsync(string groupName)
        {
            string jsonRequest = @"
            {{
                ""name"": ""{0}""
            }}";
            string request = String.Format(CultureInfo.InvariantCulture, jsonRequest, groupName);
            var content = new StringContent(request, Encoding.UTF8, "application/json");
            dynamic result = await HttpRequestAsync(API_GROUPS_PATH, HttpMethod.Post, content);
            return result._id;
        }

        private async Task CreateGroupRestrictionsAsync(string accountId, string groupId)
        {
            IList<DataSecurityFilter> dataSecurity = new List<DataSecurityFilter>();
            _configuration.GetSection("Sisense:DataSecurity").Bind(dataSecurity);
            string elasticube = _configuration["Sisense:Elasticube"];

            foreach (var ds in dataSecurity)
            {
                string jsonRequest = @"
                [{{
                    ""server"": ""LocalHost"",
                    ""elasticube"": ""{0}"",
                    ""table"": ""{1}"",
                    ""column"": ""{2}"",
                    ""datatype"": ""text"",
                    ""shares"": [{{
                        ""party"": ""{3}"",
                        ""type"": ""group""
                    }}],
                    ""members"": [
                        ""{4}""
                    ],
                    ""allMembers"": null
                }}]";

                string request = String.Format(CultureInfo.InvariantCulture, jsonRequest, elasticube, ds.Table, ds.Column, groupId, accountId.ToUpperInvariant());
                var content = new StringContent(request, Encoding.UTF8, "application/json");
                await HttpRequestAsync(API_DATA_SECURITY_PATH, HttpMethod.Post, content);
            }
        }

        private async Task<string> CreateUserAsync(string accountId, string groupId)
        {
            string jsonRequest = @"
            {{
                ""email"": ""{0}"",
                ""userName"": ""{1}"",
                ""groups"": [""{2}""]
            }}";
            string request = String.Format(CultureInfo.InvariantCulture, jsonRequest, accountId + "@gatherbi.com", accountId, groupId);
            var content = new StringContent(request, Encoding.UTF8, "application/json");
            dynamic result = await HttpRequestAsync(API_USERS_PATH, HttpMethod.Post, content);
            return result._id;
        }

        private async Task<string> GetJwtTokenAsync(string accountId)
        {
            TimeSpan timeSinceEpoch = (DateTime.UtcNow - new DateTime(1970, 1, 1));
            int timestamp = (int)timeSinceEpoch.TotalSeconds;

            var payload = new System.Collections.Generic.Dictionary<string, object>() {
                 { "iat", timestamp},
                 { "sub", accountId + "@gatherbi.com"},
                 { "jti", Guid.NewGuid() }
            };

            string token = JsonWebToken.Encode(payload, await GetSecretFromKeyVaultsAsync(_configuration["KeyVault:Secrets:SisenseSharedSecretKey"]), JwtHashAlgorithm.HS256);

            return token;
        }

        private async Task<string> GetSecretFromKeyVaultsAsync(string key)
        {

            var secret = await _secretClient.GetSecretAsync(key);
            string value = secret.Value.Value;

            if (string.IsNullOrWhiteSpace(value))
            {
                throw new InvalidOperationException($"Cannot fetch key={key} from Key Vaults");
            }

            return value;
        }

        private async Task<dynamic> HttpRequestAsync(string path, HttpMethod method, HttpContent content = null)
        {
            string apiUrl = $"{_baseAdress}{path}";
            using var client = new HttpClient();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", await GetApiAccessTokenAsync());

            HttpRequestMessage request = new HttpRequestMessage(method, apiUrl);
            if (content != null)
            {
                request.Content = content;
            }
            HttpResponseMessage response = await client.SendAsync(request);
            string strContent = await response.Content.ReadAsStringAsync();
            dynamic result = JsonConvert.DeserializeObject<dynamic>(strContent);
            if (!response.IsSuccessStatusCode)
            {
                throw new HttpRequestException($"Failed request {method.ToString()}: {apiUrl}. Result :{strContent} ");
            }
            _logger.LogDebug($"{method.ToString()} {apiUrl}. Response: ${strContent}");
            return result;
        }

        internal class DataSecurityFilter
        {
            public string Table { get; set; }
            public string Column { get; set; }
        }

    }

}
