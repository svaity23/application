import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { BaseDataService } from './base-data.service';

import { AssetDownloadRequest } from '../models/asset-download-request.model';

export interface WordPressDataServiceInterface {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  downloadAssets(assetDownloadRequests: Array<AssetDownloadRequest>): Observable<any>;
}

@Injectable({ providedIn: 'root' })
export class WordPressDataService extends BaseDataService implements WordPressDataServiceInterface {

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  downloadAssets(assetDownloadRequests: Array<AssetDownloadRequest>): Observable<any> {
    const url = `${this.downloadApiUrl}/download/wordpress-assets`;
    return this.createApiPost({ url, data: assetDownloadRequests });
  }

}
