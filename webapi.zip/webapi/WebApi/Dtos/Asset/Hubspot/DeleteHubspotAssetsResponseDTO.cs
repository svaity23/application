﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos.Asset.Hubspot
{
    public class DeleteHubspotAssetsResponseDTO
    {
        public Guid[] Ids { get; set; }
    }
}
