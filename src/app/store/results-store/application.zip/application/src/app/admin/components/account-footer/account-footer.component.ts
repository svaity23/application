import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output, ViewEncapsulation } from '@angular/core';

import { AccountDetail } from '@app/core/models/entities/account-detail.model';

@Component({
  selector: 'app-account-footer',
  templateUrl: './account-footer.component.html',
  styleUrls: ['./account-footer.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountFooterComponent  {

  @Input() account: AccountDetail;
  @Output() deleteAccountEvent = new EventEmitter();
  @Output() generateAssetThumbnailsEvent = new EventEmitter();
  @Output() indexAssetSearchEvent = new EventEmitter();
  @Input() isSavingChanges: boolean;
  @Output() processAssetsEvent = new EventEmitter();
  @Output() syncUsersEvent = new EventEmitter();

  constructor() { }

  deleteAccount(): void {
    this.deleteAccountEvent.emit(this.account.id);
  }
  
  generateAssetThumbnails(): void {
    this.generateAssetThumbnailsEvent.emit(this.account.id);
  }

  indexAssetSearch(): void {
    this.indexAssetSearchEvent.emit(this.account.id);
  }

  processAssets(): void {
    this.processAssetsEvent.emit(this.account.id);
  }

  syncUsers(): void {
    this.syncUsersEvent.emit(this.account.id);
  }

}
