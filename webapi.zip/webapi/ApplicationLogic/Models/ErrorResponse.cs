﻿using System.Text.Json.Serialization;

namespace ApplicationLogic.Models
{
    public class ErrorResponse
    {
        [JsonPropertyName("message")]
        public string Message { get; set; }
        
        [JsonPropertyName("code")]
        public int Code { get; set; }
    }
}
