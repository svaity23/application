﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationLogic.Models
{
    public class SalesforceMessageModel
    {
        public Guid AccountId { get; set; }
        public SalesforceLeadDetailsModel LeadDetails { get; set; }
        public Guid UserId { get; set; }
    }
}
