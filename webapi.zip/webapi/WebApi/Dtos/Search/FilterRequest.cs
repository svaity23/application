﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Enums;

namespace WebApi.Dtos.Search
{
    public class FilterRequest
    {
        public FilterGroupTypeEnum FilterGroupType { get; set; }
        public Guid? MetadataFieldId { get; set; }
        public string[] Values { get; set; }
    }
}
