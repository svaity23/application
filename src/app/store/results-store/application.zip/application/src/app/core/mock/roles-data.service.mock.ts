import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { RolesDataServiceInterface } from '../data-services/roles-data.service';

import { Role } from '../models/entities/role.model';

@Injectable({ providedIn: 'root' })
export class RolesDataServiceMock implements RolesDataServiceInterface {
    private internalRolesList: Role[] = [];

    constructor() {
        const roles = [
            { id: '71D293B4-5EEF-4796-B53A-900CF64BD0C2', key: 'admin', internal: false,  externalId: null, accountId: null, active: true, name: 'Admin User', description: 'All user previleges' },
            { id: 'EBFEAD56-0081-4E0C-9FA7-2937048AF182', key: 'contributor', internal: false, externalId: null, accountId: null, active: true,  name: 'Contributor User', description: 'Upload, edit, comment, download, share and delete assets' },
            { id: '74606970-05E4-4D5B-BEA6-ED571782F2E5', key: 'mcc-admin', internal: true, externalId: null, accountId: null, active: true,  name: 'Mcc Admin', description: 'Preview and download assets' },
            { id: '08BCF757-9419-4CC6-9FEE-F3BB34FC348D', key: 'sys-admin', internal: true, externalId: null, accountId: null, active: true,  name: 'System Admin', description: 'Preview and download assets' },
            { id: '46BB7C52-9E7D-4F15-84E0-FD57FCA2167C', key: 'trial', internal: false, externalId: null, accountId: null, active: true,  name: 'Trial User', description: 'Preview and download assets' },
            { id: '49E6268E-E2B4-4494-836B-D59DCC8CBA55', key: 'viewer', internal: false, externalId: null, accountId: null, active: true,  name: 'Viewer User', description: 'Preview and download assets' },
        ];

        this.internalRolesList = roles;
    }

    getAll(): Observable<Role[]> {
        return new Observable(observer => {
            // clone this internal list because store-freeze will make it immutable later in the dispatch pipeline
            const clone = JSON.parse(JSON.stringify(this.internalRolesList));

            // Yield a single value and complete
            observer.next(clone);
            observer.complete();
        });
    }
}
