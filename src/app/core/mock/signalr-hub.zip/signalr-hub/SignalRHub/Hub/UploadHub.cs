﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace SignalRHub.Hub
{    
    [Authorize]
    public class UploadHub : Hub<IUploadHub>
    {
        private readonly ILogger<UploadHub> _logger;

        public UploadHub(ILogger<UploadHub> logger)
        {
            _logger = logger;
        }

        public string GetConnectionId()
        {
            return Context.ConnectionId;        
        }

        public override Task OnConnectedAsync()
        {
            _logger.LogDebug($"Client Connected: {Context.ConnectionId}");
            return base.OnConnectedAsync();
        }

        public override Task OnDisconnectedAsync(Exception exception)
        {
            _logger.LogDebug($"Client Disconnected: {Context.ConnectionId}");
            return base.OnDisconnectedAsync(exception);
        }
    }
}
