﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class CollectionFinder
    {
        private readonly ILogger<CollectionFinder> _logger;
        private readonly damContext _context;


        public CollectionFinder(damContext context)
        {
            _context = context;
            _logger = NullLogger<CollectionFinder>.Instance;
        }


        public async Task<string> GetAllAsync(Guid accountId, Guid userId)
        {
            _logger.LogInformation($"[Finder] Getting all collections for" +
                $"\n\taccount = {accountId}" +
                $"\n\tuser = {userId}");
            string ret = await ExecuteAsync("getCollections", 
                accountId, userId, "{ \"collectionId\" : \"" + Guid.Empty + "\"}");
            return ret;
        }


        public async Task<string> GetIdsForUserAsync(Guid accountId, Guid userId)
        {
            _logger.LogInformation($"[Finder] Get collection ids visible for" +
                $"\n\taccount = {accountId}" +
                $"\n\tuser = {userId}");
            string result = await ExecuteAsync("getCollectionIds",
                accountId, userId);
            return result;
        }



        public async Task<string> SaveAsync(Guid accountId, Guid userId, string jsonCollection)
        {
            _logger.LogInformation($"[Finder] Save collection for" +
                $"\n\taccount = {accountId}" +
                $"\n\tuser = {userId}" +
                $"\n\tusing {jsonCollection}");
            return await ExecuteAsync("saveCollection", 
                accountId, userId, jsonCollection);
        }


        public async Task<string> MoveCollectionAsync(Guid accountId, Guid userId, Guid collectionId, Guid parentId)
        {
            _logger.LogInformation($"[Finder] Move collection " +
                $"\n\taccount = {accountId}" +
                $"\n\tuser = {userId}" +
                $"\n\tcollectionId {collectionId} goes under {parentId}");

            List<SqlParameter> sqlParmsList = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithGuid(nameof(collectionId), collectionId)
                .WithGuid(nameof(parentId), parentId)
                .Build();

            string ret = await _context
                .ExecuteNonQueryJsonOutputAsync("moveCollection", sqlParmsList);
            return ret;
        }

        public async Task<string> DeleteAsync(Guid accountId, Guid userId, string jsonCollectionIdArray)
        {
            _logger.LogInformation($"[Finder] Deletes one or multiple collections for" +
                $"\n\taccount = {accountId}" +
                $"\n\tuser = {userId}" +
                $"\n\tid:\n{jsonCollectionIdArray}");
            return await ExecuteAsync("deleteCollections",
                accountId, userId, jsonCollectionIdArray);
        }


        public async Task<string> GetByIdAsync(Guid accountId, Guid userId, Guid idCollection)
        {
            _logger.LogInformation($"[Finder] Getting all collections for" +
                $"\n\taccount = {accountId}" +
                $"\n\tuser = {userId}" +
                $"\n\tid:\n{idCollection}");
            return await ExecuteAsync("getCollections", 
                accountId, userId, "{ \"collectionId\" : \"" + idCollection + "\"}");
        }


        /// <summary>
        /// Executes asynchronously the specified stored procedure with the attached parameters
        /// </summary>
        /// <param name="procedure">name of the TSQL procedure to execute</param>
        /// <param name="accountId">the id of the account</param>
        /// <param name="userId">the id of the user performing this action</param>
        /// <param name="json"><i>Optional.</i> Any additional parameters, 
        /// encoded as a valid JSON object serialized to string</param>
        /// <returns>The Task with the JSON string received as response from TSQL procedure.</returns>
        private async Task<string> ExecuteAsync(
            string procedure, 
            Guid accountId, 
            Guid userId, 
            string json = null
        )
        {
            SpParams paramList = new SpParams();
            paramList.WithAccountId(accountId);
            paramList.WithUserId(userId);

            if (json != null) paramList.WithJson(json);

            List<SqlParameter> sqlParmsList = paramList.Build();
            string ret = await _context
                .ExecuteNonQueryJsonOutputAsync(procedure, sqlParmsList);

             return ret;
        }
    }
}
