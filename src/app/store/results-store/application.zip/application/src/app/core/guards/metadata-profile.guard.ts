import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { filter, first, map, switchMap, take, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AccountMetadataProfilesStoreFacade } from '@app/store/account-store/account-metadata-profile.facade';
import { MetadataProfileView } from '../models/metadata-profile-view.model';

@Injectable({
  providedIn: 'root'
})
export class MetadataProfileGuard implements CanActivate {

  constructor(private accountMetadataProfileStorefacade: AccountMetadataProfilesStoreFacade, private router: Router) { }

  canActivate(
     // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
     _route: ActivatedRouteSnapshot,
     // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
     _state: RouterStateSnapshot): Observable<boolean | UrlTree> {
     return this.prefetchMetadataProfiles().pipe(
       switchMap(() => this.isProfileInState())
     );
  }

  private isProfileInState(): Observable<boolean | UrlTree> {
    return this.accountMetadataProfileStorefacade.selectedMetadataProfile$.pipe(
      take(1),
      map(profile => {
        if (profile) {
          return true;
        } else {
          return this.router.parseUrl('account/metadata-profiles');
        }
      })
    );
  }

  private prefetchMetadataProfiles(): Observable<MetadataProfileView[]> {
    return this.accountMetadataProfileStorefacade.isLoaded$.pipe(
      tap(isLoaded => {
        if (isLoaded !== true) {
          this.accountMetadataProfileStorefacade.loadAll();
        }
      }),
      filter(isLoaded => isLoaded === true),
      switchMap(() => this.accountMetadataProfileStorefacade.metadataProfiles$),
      first()
    );
  }
}
