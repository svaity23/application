import { ChangeDetectionStrategy, EventEmitter, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { Component, Input, OnChanges, OnInit, Output } from '@angular/core';
import { ControlContainer, NgForm } from '@angular/forms';
import { Integration } from '@app/core/models/integrations/integration.model';

@Component({
  selector: 'app-marcom-library-integration-details',
  templateUrl: './marcom-library-integration-details.component.html',
  styleUrls: ['./marcom-library-integration-details.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class MarcomLibraryIntegrationDetailsComponent implements OnChanges, OnInit {

  @Output() componentLoad = new EventEmitter();
  @Input() integration: Integration;
  integrationToModify: Integration;
  @Input() resetScreen: boolean;
  @Output() tokenChange: EventEmitter<Integration> = new EventEmitter<Integration>();

  constructor() { }

  loadUiData(): void {
    if(this.integration) {
      this.integrationToModify = {...this.integration};
    }
    else {
      this.integrationToModify = {
        key: 'marcom-library',
        token: ''
      }
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.integration && changes.integration.currentValue) {
      this.integrationToModify = { ...changes.integration.currentValue };
      if(this.integrationToModify && this.integrationToModify?.key) {
        this.tokenChange.emit(this.integrationToModify);
      }
    }
    else if(changes.resetScreen && changes.resetScreen.currentValue) {
      this.loadUiData();
    }
  }
  
  ngOnInit(): void {
    this.loadUiData();
    this.componentLoad.emit();
  }

  tokenValueChange($event: string): void {
    this.integrationToModify = {...this.integrationToModify, token: $event};
    this.tokenChange.emit(this.integrationToModify);
  }
}
