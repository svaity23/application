﻿using System.Text.Json.Serialization;

namespace WebApi.Dtos.Asset.Hubspot
{
    public class HubspotErrorDTO
    {
        [JsonPropertyName("code")]
        public int Code { get; set; }

        [JsonPropertyName("description")]
        public string Description { get; set; }
    }
}
