import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { cn } from 'src/utils/cn';

import { Group } from '@app/core/models/entities/group.model';

@Component({
  selector: 'app-group-bulk-action-header',
  templateUrl: './group-bulk-action-header.component.html',
  styleUrls: ['./group-bulk-action-header.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class GroupBulkActionHeaderComponent implements OnInit {
  @Input() className = '';
  @Output() deleteClickedEvent = new EventEmitter();
  @Input() selectedGroups: Group[];

  constructor() { }

  ngOnInit(): void {
    this.className = cn('group-bulk-action-header', this.className);
  }
}
