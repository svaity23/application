import { ErrorResponse } from '../api-responses/error-response';
import { FileGroupType, FileType } from '@app/core/enums';

export interface AssetValidateReplaceResponse {

    // todo -- trim the return values to only whats needed
    // we are no longer trying to match this up to exactly
    // the asset model

    accountId?: string;
    active?: boolean;
    assetType: string;
    collectionId: string;
    created: Date;
    createdByUserId: string;
    createdByUserName: string;
    description: string;
    error: ErrorResponse[];
    expired?: boolean;
    expireOn?: Date;
    externalId?: string;
    favorite?: boolean;
    fileExtension: FileType;
    fileGroup: FileGroupType;
    fileName: string;
    fileSize: number;
    id: string;
    lastModifiedByUserId: string;
    modified?: Date;
    modifiedByUserName: string;
    name: string;
    uploadSessionId?: string;
    uploadStatus: number;
}
