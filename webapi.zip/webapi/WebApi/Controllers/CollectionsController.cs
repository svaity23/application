﻿using ApplicationLogic.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net.Mime;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Dtos;
using WebApi.Dtos.Collection;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class CollectionsController : ControllerBase
    {
        private readonly ILogger<CollectionsController> _logger;
        private readonly CollectionService _collectionService;
        private readonly UserAccountService _userAccountService;


        public CollectionsController(
            ILogger<CollectionsController> logger,
            CollectionService collectionService,
            UserAccountService userAccountService)
        {
            _logger = logger;
            _collectionService = collectionService;
            _userAccountService = userAccountService;
        }

        /// <summary>
        /// Get all collections for current user
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ApiExplorerSettings(IgnoreApi = false)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<CollectionDto>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAllCollections()
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            GetEntitiesResponse<CollectionDto> results =
                await _collectionService.GetAllAsync(accountId, userId);
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entities ?? new List<CollectionDto>()),
                    3 => Forbid(),// the user doesn't have rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }

        /// <summary>
        /// Get collection by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<CollectionDto>))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetCollectionById(Guid id)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            // TODO --refactor this to return entity singular and not entities
            GetEntitiesResponse<CollectionDto> results =
                await _collectionService.GetCollectionByIdAsync(accountId, userId, id);
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entities ?? new List<CollectionDto>()),
                    3 => Forbid(),// the user doesn't have rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }

        /// <summary>
        /// Create new collection
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="collection"></param>
        /// <returns></returns>
        [HttpPost]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created, Type = typeof(CollectionDto))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public async Task<IActionResult> CreateAsync([FromBody] CollectionDto collection)
        {

            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            if (collection == null) return BadRequest();

            if (collection.Id != Guid.Empty)
                ModelState.AddModelError("Id", "Non empty id for the new collection");
            if (string.IsNullOrEmpty(collection.Name))
                ModelState.AddModelError("Name", "Collection name is empty");

            if (ModelState.ErrorCount > 0)
                return BadRequest(ModelState);


            collection.AccountId = accountId;

            _logger.LogWarning($"User {userId} creates a new collection {collection.Name}");
            var results = await _collectionService.SaveAsync(accountId, userId, collection);
            if (results != null)
            {
                int err = results.Errors[0].Code;
                return err switch
                {
                    0 => StatusCode(StatusCodes.Status201Created, results.Entity),
                    2 => Conflict(),// a group with the specified name already exists in db
                    3 => Forbid(),// the user doesn't have rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }


        [HttpPost("move")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status406NotAcceptable)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> MoveCollectionAsync([FromBody] MoveCollectionDTO moveData)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            if (moveData == null) return BadRequest();

            if (moveData.CollectionId == Guid.Empty)
                ModelState.AddModelError("Id", "Empty id for the collection");

            if (ModelState.ErrorCount > 0)
                return BadRequest(ModelState);
            if (moveData.ParentId == null) moveData.ParentId = Guid.Empty;

            _logger.LogWarning($"User {userId} moves the collection {moveData.CollectionId} to {moveData.ParentId}");
            var results = await _collectionService.MoveCollectionAsync(accountId, userId, moveData.CollectionId, (Guid)moveData.ParentId);
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => StatusCode(StatusCodes.Status201Created, results.Entities),
                    2 => Conflict(),      // a collection with the specified name already exists in the destination
                    3 => Forbid(),        // the user doesn't have rights
                    4 => StatusCode(406), // not acceptable to move a collection with children under a different collection 
                    _ => BadRequest(),    // invalid json input for stored procedure
                };
            }
            return NotFound();
        }

        /// <summary>
        /// Update collection
        /// </summary>
        /// <param name="id"></param>
        /// <param name="collection"></param>
        /// <returns></returns>
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CollectionDto))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public async Task<IActionResult> UpdateCollectionAsync(Guid id, [FromBody] CollectionDto collection)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            if (id != collection?.Id ||
                accountId != collection.AccountId // make sure they have access to collection
                ) return BadRequest();

            if (collection.Id == Guid.Empty || collection.Id == Guid.Empty)
                ModelState.AddModelError("Id", "Empty id for the collection");
            if (string.IsNullOrEmpty(collection.Name))
                ModelState.AddModelError("Name", "Collection name is empty");
            if (collection.AccountId == null || collection.AccountId == Guid.Empty)
                ModelState.AddModelError("AccountId", "Empty id for the collection");

            if (ModelState.ErrorCount > 0)
                return BadRequest(ModelState);

            _logger.LogWarning($"User {userId} updates the collection {collection.Name}");
            var results = await _collectionService.SaveAsync(accountId, userId, collection);
            if (results != null)
            {
                int err = results.Errors[0].Code;
                return err switch
                {
                    0 => StatusCode(StatusCodes.Status200OK, results.Entity),
                    2 => Conflict(),// a group with the specified name already exists in db
                    3 => Forbid(),// the user doesn't have rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }

        /// <summary>
        /// Delete collection by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<Guid>))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> DeleteByIdAsync(Guid id)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService); ;
            var userId = this.User.GetUserId();

            _logger.LogWarning($"User {userId} initiate the delete of the collection {id}");
            var results = await _collectionService.DeleteAsync(accountId, userId, id);
            if (results != null)
            {
                int err = results.Errors[0].Code;
                return err switch
                {
                    0 => Ok(results.Entity),
                    3 => Forbid(),// the user doesn't have rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }

            return NotFound();
        }
    }
}
