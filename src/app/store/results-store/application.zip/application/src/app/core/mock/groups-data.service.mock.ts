import { Injectable } from '@angular/core';

import * as faker from 'faker/locale/en_US';
import { Observable, of } from 'rxjs';

import { Group } from '../models/entities/group.model';
import { GroupsDataServiceInterface } from '../data-services/groups-data.service';

@Injectable({ providedIn: 'root' })
export class GroupsDataServiceMock implements GroupsDataServiceInterface {
    private internalGroupsList: Group[] = [];

    constructor() {
        const oneGroup = (): Group => {
            const group: Group = {
                accountId: faker.random.number().toString(),
                externalId: faker.random.number().toString(),
                id: faker.random.number().toString(),
                name: 'First Group',
                description: 'First Group description',
                selected: false,
                active: true
            };
            return group;
        };
        const randomGroups = (
            count = faker.random.number({ min: 4, max: 4 })
        ): Group[] => {
            // eslint-disable-next-line prefer-spread
            return Array.apply(null, Array(count)).map(() => oneGroup());
        };

        this.internalGroupsList = randomGroups();
    }

    add(group: Group): Observable<Group> {
        return new Observable(observer => {
            const usersCount = this.internalGroupsList.length + 1;
            this.internalGroupsList.splice(usersCount, 0, { ...group });

            // Yield a single value and complete
            observer.next(group);
            observer.complete();
        });
    }

    bulkDelete(groups: Group[]): Observable<string[]> {
        return of(groups.map(u => u.id));
    }
    delete(id: string): Observable<Group> {
        return new Observable(observer => {
            const itemToDelete = this.internalGroupsList.find(x => x.id === id);
            const indexToDelete = this.internalGroupsList.indexOf(itemToDelete);

            this.internalGroupsList.splice(indexToDelete, 1);

            itemToDelete.active = false;
            const clone = JSON.parse(JSON.stringify(itemToDelete));
            observer.next(clone);
            observer.complete();
        });
    }

    getAll(): Observable<Group[]> {
        return new Observable(observer => {
            // clone this internal list because store-freeze will make it immutable later in the dispatch pipeline
            const clone = JSON.parse(JSON.stringify(this.internalGroupsList));

            // Yield a single value and complete
            observer.next(clone);
            observer.complete();
        });
    }

    updateGroup(group: Group): Observable<Group> {
        return new Observable(observer => {
            const itemToModify = this.internalGroupsList.find(x => x.id === group.id);
            const indexToModify = this.internalGroupsList.indexOf(itemToModify);

            this.internalGroupsList.splice(indexToModify, 1, { ...group });

            const clone = JSON.parse(JSON.stringify(this.internalGroupsList));
            // Yield a single value and complete

            observer.next(clone);
            observer.complete();
        });
    }
}
