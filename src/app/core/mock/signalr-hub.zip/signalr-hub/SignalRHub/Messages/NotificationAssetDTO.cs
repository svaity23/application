﻿using System;

namespace SignalRHub.Messages
{
    public class NotificationAssetDTO
    {
        public Guid Id { get; set; }
        public AttachmentDTO Attachment { get; set; }
        public string Name { get; set; }
        public int? FileGroup { get; set; }
    }
}
