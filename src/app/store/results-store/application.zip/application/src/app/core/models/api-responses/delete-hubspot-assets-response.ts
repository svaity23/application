export interface DeleteHubspotAssetsResponse {
    ids: string[];
 }