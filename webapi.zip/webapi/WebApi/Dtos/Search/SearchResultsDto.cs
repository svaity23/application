﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos.Search
{
    /// <summary>
    /// used for search response
    /// </summary>
    public class SearchResultsDto
    {
        public int AssetCount { get; set; }
        public IEnumerable<AssetDto> Assets { get; set; }
        public SearchFilters Filters { get; set; }
    }
}
