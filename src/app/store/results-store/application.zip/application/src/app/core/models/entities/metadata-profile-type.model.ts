
export interface MetadataProfileType {
    id: number;
    name: string; // FileGroupType (image, video, document)
}
