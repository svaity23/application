﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using WebApi.Dtos;
using WebApi.Dtos.Setting;
using WebApi.Services;
using WebApiTests.Shared;

namespace WebApiTests.Services
{
    [TestClass]
    public class DBSettingService
    {
        private static readonly Guid TEST_ACCOUNT = Guid.Parse("5189526F-642F-449F-B018-5F5027A7191B"); // marcel@saguaro.ro
        private static readonly string TEST_PREFIX = "test-setting-";
        private static damContext dbContext;
        private static SettingService sut;
        private static List<UserDetailDto> _testUsers;
        private static UserDetailDto adminUser;
        private static UserDetailDto contributorUser;
        private static UserDetailDto viewerUser;
        private static UserLogic _userLogic;
        private static readonly Random _rnd = new Random();
        private static readonly JsonSerializerOptions options = new JsonSerializerOptions()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            ReferenceHandler = ReferenceHandler.Preserve
        };


        [ClassInitialize]
        public static void BeforeClass(TestContext context)
        {
            Debug.WriteLine("Before all tests");
            dbContext = AzureSQLTools.InitializeDamContext();

            var loggerFactory = (ILoggerFactory)new LoggerFactory();
            //ServiceBusService is depedency injected into the SettingService, but it's not needed here.
            //If it is ever needed in the future, and instance of the ServiceBus can be pased in.
            sut = new SettingService(loggerFactory.CreateLogger<SettingService>(), dbContext, null);

            _testUsers = AzureSQLTools.GetAccountUsers(dbContext, TEST_ACCOUNT);
            adminUser = AzureSQLTools.GetTestUser(dbContext, "admin", TEST_ACCOUNT);
            contributorUser = AzureSQLTools.GetTestUser(dbContext, "contributor", TEST_ACCOUNT);
            viewerUser = AzureSQLTools.GetTestUser(dbContext, "viewer", TEST_ACCOUNT);

            _userLogic = new UserLogic(dbContext);
        }

        [ClassCleanup]
        public static void AfterClass()
        {
            Debug.WriteLine("Clean up after all tests");
            dbContext.Database.ExecuteSqlRaw("delete from [dbo].[setting] where [accountId] = {0} and [key] like '"+ TEST_PREFIX + "%'", TEST_ACCOUNT);

            dbContext.Dispose();
        }

        [TestInitialize]
        public void BeforeTest()
        {
            Debug.WriteLine("...Prepare test");
        }

        [TestCleanup]
        public void AfterTest()
        {
            Debug.WriteLine("...Clear test\n");
        }

        [TestMethod("Retrieve all front end settings")]
        public void GetFrontEndSettings_Admin() 
        {
            Assert.IsNotNull(adminUser); // Make sure we have a such user first ;-)
            GetEntityResponse<SettingsDto> result = sut.GetFrontEndSettings(TEST_ACCOUNT, adminUser.Id).Result;

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Error);
            Assert.AreEqual<int>(0, result.Error.Code);

            Assert.IsNotNull(result.Entity);

        }

        [TestMethod("Insert a new boolean setting")]
        public void SetBooleanSetting()
        {
            AreaSettingDto insert = new AreaSettingDto()
            {
                Key = $"{TEST_PREFIX}-BOOL_ADMIN",
                BoolValue = true,
                ValueType = 0
            };
            UpsertResponse<AreaSettingDto> result = sut.UpdateAccountSettings(TEST_ACCOUNT, adminUser.Id, insert).Result;
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Errors);
            Assert.AreEqual<int>(0, result.Errors[0].Code);

            Assert.IsNotNull(result.Entity);
            Assert.AreEqual(insert.Key, result.Entity.Key);
            Assert.AreEqual(0, result.Entity.ValueType);
            Assert.IsTrue(result.Entity.BoolValue);
        }

        [TestMethod("Insert a new int setting")]
        public void SetIntSetting()
        {
            AreaSettingDto insert = new AreaSettingDto()
            {
                Key = $"{TEST_PREFIX}-INT_ADMIN",
                IntValue = 101010,
                ValueType = 1
            };
            UpsertResponse<AreaSettingDto> result = sut.UpdateAccountSettings(TEST_ACCOUNT, adminUser.Id, insert).Result;
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Errors);
            Assert.AreEqual<int>(0, result.Errors[0].Code);

            Assert.IsNotNull(result.Entity);
            Assert.AreEqual(insert.Key, result.Entity.Key);
            Assert.AreEqual(insert.ValueType, result.Entity.ValueType);
            Assert.AreEqual(insert.IntValue, result.Entity.IntValue);
        }

        [TestMethod("Insert a new date setting")]
        public void SetDateSetting()
        {
            AreaSettingDto insert = new AreaSettingDto()
            {
                Key = $"{TEST_PREFIX}-INT_ADMIN",
                DateValue = DateTime.Now,
                ValueType = 2
            };
            UpsertResponse<AreaSettingDto> result = sut.UpdateAccountSettings(TEST_ACCOUNT, adminUser.Id, insert).Result;
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Errors);
            Assert.AreEqual<int>(0, result.Errors[0].Code);

            Assert.IsNotNull(result.Entity);
            Assert.AreEqual(insert.Key, result.Entity.Key);
            Assert.AreEqual(insert.ValueType, result.Entity.ValueType);
            Assert.AreEqual(insert.DateValue.ToString("u"), result.Entity.DateValue.ToString("u"));
        }

        [TestMethod("Insert a string date setting")]
        public void SetStringSetting()
        {
            AreaSettingDto insert = new AreaSettingDto()
            {
                Key = $"{TEST_PREFIX}-INT_ADMIN",
                StringValue = "some-random-text-value",
                ValueType = 3
            };
            UpsertResponse<AreaSettingDto> result = sut.UpdateAccountSettings(TEST_ACCOUNT, adminUser.Id, insert).Result;
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Errors);
            Assert.AreEqual<int>(0, result.Errors[0].Code);

            Assert.IsNotNull(result.Entity);
            Assert.AreEqual(insert.Key, result.Entity.Key);
            Assert.AreEqual(insert.ValueType, result.Entity.ValueType);
            Assert.AreEqual(insert.StringValue, result.Entity.StringValue);
        }
    }
}
