﻿using ApplicationLogic.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApi.Dtos;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AllowAnonymous]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class LightboxPublicAssetsController : ControllerBase
    {
        private readonly ILogger<LightboxPublicAssetsController> _logger;
        private readonly LightboxAssetService _lightboxAssetService;
        private readonly IConfiguration _configuration;
        private readonly LightboxService _lightboxService;
        private readonly ISearchAssetsServiceFactory _searchAssetsServiceFactory;

        public LightboxPublicAssetsController(
            ILogger<LightboxPublicAssetsController> logger,
            LightboxAssetService lightboxAssetService,
            IConfiguration configuration,
            LightboxService lightboxService,
            ISearchAssetsServiceFactory searchAssetsServiceFactory)
        {
            _logger = logger;
            _lightboxAssetService = lightboxAssetService;
            _lightboxService = lightboxService;
            _logger = logger;
            _configuration = configuration;
            _searchAssetsServiceFactory = searchAssetsServiceFactory;
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetLightboxAssets(Guid id, int sortField, int skip, int pageSize)
        {
            GetEntitiesResponse<AssetDto> results =
                await _lightboxAssetService.GetLightboxPublicAssetsAsync(id, sortField, skip, pageSize);
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entities ?? new List<AssetDto>()),
                    3 => Forbid(),// the user doesn't have rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }

        
        [HttpGet("assetPreviewDetails")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetAssetForPreviewAsync(Guid id, Guid accountId, Guid lightboxId)
        {
            var assetPreview = await _lightboxAssetService.GetAssetForPreviewAsync(accountId, id, lightboxId);
            if (assetPreview == null)
                return NotFound();

            return Ok(assetPreview);
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> QueryAssets(QueryRequestDto query)
        {
            // Get base lightbox.
            var lightboxPublic = await _lightboxService.GetBaseLightboxPublicAsync((Guid)query.LightboxId);

            if (lightboxPublic == null)
            {
                return null;
            }
            var accountId = lightboxPublic.AccountId;


            _logger.LogDebug($"[LightboxesPublicController] Querying assets for account = {accountId}, sortField = {query.SortField}, skip = {query.Skip}, " +
                             $"pageSize = {query.PageSize}, searchTerm = {query.SearchTerm}, lightboxId = {query.LightboxId} ");
            _logger.LogDebug("BEGIN: lightbox public queryAssets");

            var searchAssetsService = await _searchAssetsServiceFactory.CreateSearchLightboxAssetServiceAsync((Guid)accountId);
            var actionResult = await searchAssetsService.GetPublicLightboxAssetsSearchResultsFromElasticsearchAsync(query.SearchTerm, query.SortField, query.Skip, query.PageSize, query.LightboxId);

            // var result = await _lightboxAssetService.GetLightboxPublicSearchResultsAsync((Guid)query.LightboxId, actionResult);

            _logger.LogDebug("END: queryAssets");

            return Ok(actionResult);
        }
    }
}
