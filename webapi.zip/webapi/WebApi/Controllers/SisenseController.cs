using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class SisenseController : ControllerBase
    {
        private readonly ILogger<SisenseController> _logger;
        private readonly SisenseService _sisenseService;
        private readonly UserAccountService _userAccountService;

        public SisenseController(ILogger<SisenseController> logger, SisenseService sisenseService, UserAccountService userAccountService)
        {
            _logger = logger;
            _sisenseService = sisenseService;
            _userAccountService = userAccountService;
        }

        [HttpGet("launchUrl")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetSisenseLaunchUrlAsync()
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);

            var url = await _sisenseService.GetLaunchUrlAsync(accountId.ToString());
            return Ok(url);
        }
    }
}
