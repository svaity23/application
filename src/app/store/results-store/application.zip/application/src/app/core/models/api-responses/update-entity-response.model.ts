import { ErrorResponse } from './error-response';

export interface UpdateEntityResponse {
    errors: ErrorResponse[]
    id: string;
}
