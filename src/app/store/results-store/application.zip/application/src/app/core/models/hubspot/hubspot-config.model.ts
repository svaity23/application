export interface HubspotConfig {
	authorizeUrl: string,
	clientId: string,
	scopes: string
}
