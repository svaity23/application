﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class AccountDetailFinder
    {
        public ILogger<AccountDetailFinder> Logger { get; set; }
        
        private damContext _context;

        public AccountDetailFinder(damContext context) {
            _context = context;
            Logger = NullLogger<AccountDetailFinder>.Instance;
        }

        public async Task<AccountType> GetAccountTypeAsync(string typeName)
        {
#pragma warning disable CA1304 // Specify CultureInfo
            return await _context.AccountType.FirstOrDefaultAsync(t => t.Name.ToLower() == typeName.ToLower());
#pragma warning restore CA1304 // Specify CultureInfo
        }

        public async Task<string> GetAllAsync(bool includeInactive = true)
        {            
            List<SqlParameter> parameters = new SpParams()
                .WithIncludeInactive(includeInactive)
                .Build();

            return await _context.ExecuteNonQueryJsonOutputAsync("getAccounts", parameters).ConfigureAwait(false);
        }

        public async Task<string> GetByAccountId(Guid accountId, Guid userId)
        {
            //return await _context.AccountDetail.FirstOrDefaultAsync(a => a.Id == accountId);

            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)                
                .Build();

            return await _context.ExecuteNonQueryJsonOutputAsync("getAccountDetails", parameters).ConfigureAwait(false);
        }

        public async Task<AccountDetail> GetByNameAsync(string name)
        {
            return await _context.AccountDetail
#pragma warning disable CA1304 // Specify CultureInfo
                .FirstOrDefaultAsync(a => a.Name.Trim().ToLower() == name.Trim().ToLower());
#pragma warning restore CA1304 // Specify CultureInfo
        }
    }
}
