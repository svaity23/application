import { Component, Injector, OnDestroy, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import { APP_CONFIG, AppConfig } from '@app/app-config';
import { AppStoreFacade } from '@app/store/app-store/app-store.facade';
import { Context } from '@app/core/models/context.model';
import { HubspotCredentials } from '@app/core/models/hubspot/hubspot-credentials.model';
import { HubspotSyncStatus } from '@app/core/models/hubspot/hubspot-sync-status.model';
import { HubspotSyncStatusStoreFacade } from '@app/store/account-store/hubspot-sync-status-store.facade';
import { Setting } from '@app/core/models/setting.model';

@Component({
  selector: 'app-hubspot-configuration-page',
  templateUrl: './hubspot-configuration-page.component.html',
  styleUrls: ['./hubspot-configuration-page.component.scss']
})
export class HubspotConfigurationPageComponent implements OnInit, OnDestroy {
  accountSettings$: Observable<Setting[]>;
  accountTypeName$: Observable<string>;
  context$: Observable<Context>;
  hubspotSyncStatus$: Observable<HubspotSyncStatus>;
  hubspotWindowReference: object;
  messageHandlerArrowFunction;
  showIntegrations$: Observable<boolean>;
  showUserGroups$: Observable<boolean>;

  private appSettings: AppConfig;

  constructor(
    private injector: Injector,
    private appStoreFacade: AppStoreFacade,
    private hubspotSyncStatusStoreFacade: HubspotSyncStatusStoreFacade
    ) {
      this.appSettings = this.injector.get(APP_CONFIG);
  }

   // eslint-disable-next-line @typescript-eslint/no-explicit-any
   messageHandler(e: any): void {
    if (e.data) {
      if (typeof e.data === 'object') {
        if (e.data.oauthResponse){
          const oauthResponse = e.data.oauthResponse;
          const hubspotCredentials: HubspotCredentials = {
            token: oauthResponse.access_token,
            refreshToken: oauthResponse.refresh_token,
            expiration: oauthResponse.expires_in
          }

          this.saveHubspotCredentials(hubspotCredentials);
        }
      }
    }
  }

  navigateTo(pageName): void {
    this.appStoreFacade.navigate(`account/${pageName}`);
  }

  navigateToIntegrations(): void {
    this.appStoreFacade.navigate('account/integrations');
  }

  ngOnDestroy(): void {
    window.removeEventListener('message', this.messageHandlerArrowFunction);
  }

  ngOnInit(): void {
    this.accountSettings$ = this.appStoreFacade.accountSettings$;
    this.context$ = this.appStoreFacade.context.context$;
    this.accountTypeName$ = this.appStoreFacade.accountTypeName$;
    this.showIntegrations$ = this.appStoreFacade.showIntegrations$;
    this.showUserGroups$ = this.appStoreFacade.context.isUserGroupsFeatureEnabled$;
    this.hubspotSyncStatus$ = this.hubspotSyncStatusStoreFacade.hubspotSyncStatus$;
  }

  openPopupWindow(authUrl: string): void {
    let width = 1080;
    let height = 800;
    const chromeWidthAdjustment = 260;
    const chromeHeightAdjustment = 220;

    const dualScreenLeft = window.screenLeft !==  undefined ? window.screenLeft : window.screenX;
    const screenWidth = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width;

    const left = dualScreenLeft + (screenWidth - width ) / 2;
    const top = (screen.height / 2) - (height / 2);

    const isChrome = navigator.userAgent.indexOf('Chrome') !== -1;
    if (dualScreenLeft && isChrome) {
      width = width + chromeWidthAdjustment;
      height = height + chromeHeightAdjustment;
    }

    let options = 'resizable, scrollbars';
    options += ',width=' + width;
    options += ',height=' + height;
    options += ',top=' + top;
    options += ',left=' + left;

    this.hubspotWindowReference = window.open( authUrl, 'HubSpot Window', options );
    this.messageHandlerArrowFunction = (ev) => { this.messageHandler(ev); };
    window.addEventListener('message', this.messageHandlerArrowFunction, false);
  }

  saveHubspotCredentials(hubspotCredentials: HubspotCredentials): void {
    this.appStoreFacade.saveHubspotCredentials(hubspotCredentials);
  }

  signinToHubspot(): void {
    const REDIRECT_URI = window.location.origin + '/hubspot/oauth';

    const authUrl =
      this.appSettings.hubspotConfig.authorizeUrl +
      `?client_id=${encodeURIComponent(this.appSettings.hubspotConfig.clientId)}` +
      `&scope=${encodeURIComponent(this.appSettings.hubspotConfig.scopes)}` +
      `&redirect_uri=${encodeURIComponent(REDIRECT_URI)}`;

    this.openPopupWindow(authUrl);
  }

  signOutOfHubspot(): void {
    this.appStoreFacade.resetHubspotCredentials();
  }

  syncAllAssets(): void {
    this.appStoreFacade.syncAllHubspotAssets();
  }


}
