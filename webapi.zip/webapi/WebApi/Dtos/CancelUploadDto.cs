﻿using System;

namespace WebApi.Dtos
{
    public class CancelUploadDto
    {
        public Guid UploadSessionId { get; set; }
    }
}
