﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos.Asset.Request
{
    public class DownloadAssetsDTO
    {
        public Guid[] Ids { get; set; }
        public int MinutesValid { get; set; }
    }
}
