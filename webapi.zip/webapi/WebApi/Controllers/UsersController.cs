﻿using ApplicationLogic.Models;
using Aspose.Cells;
using Microsoft.ApplicationInsights;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Dtos;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class UsersController : ControllerBase
    {
        private readonly ILogger<UsersController> _logger;
        private readonly TelemetryClient _telemetryClient;
        private readonly UserAccountService _userAccountService;
        private readonly UserService _userService;


        public UsersController(ILogger<UsersController> logger, TelemetryClient telemetryClient, UserAccountService userAccountService, UserService userService)
        {
            _logger = logger;
            _telemetryClient = telemetryClient;
            _userAccountService = userAccountService;
            _userService = userService;

            RegisterAsposeLicenses();
        }

        private void RegisterAsposeLicenses()
        {
            var license = new License();
            license.SetLicense("Aspose.Total.NET.lic");
            _logger.LogDebug("Aspose.Cells license set successfully.");
        }

        /// <summary>
        /// Validates the user file's data format
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        [HttpPost("bulk/validateUsersFile")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UserCsvResponseDto))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BulkValidateUsersFileAsync(IFormFile file)
        {
            if (file == null || file.Length == 0) return BadRequest("None or empty users file!");
            var filename = file.FileName;
            var fileExt = filename[(1 + filename.LastIndexOf('.'))..].ToLower();
            Stream csvStream;
            if (fileExt.Equals("csv"))
            {
                csvStream = file.OpenReadStream();
            }
            else
            {
                try
                {
                    var loadFormat = fileExt switch
                    {
                        "xlsx" => LoadFormat.Xlsx,
                        _ => LoadFormat.Auto
                    };
                    LoadOptions options = new LoadOptions(loadFormat);
                    Workbook workbook = new Workbook(file.OpenReadStream(), options);
                    csvStream = new MemoryStream(4096);
                    workbook.Save(csvStream, SaveFormat.Csv);
                    csvStream.Flush();
                    csvStream.Position = 0;
                }
                catch (CellsException e)
                {
                    _logger.LogWarning(e, $"While loading the spreadsheet file from: {filename}");
                    return BadRequest($"Invalid spreadsheet file: {filename}");
                }
            }
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var responseDto = await _userService.BulkValidateCsvAsync(csvStream, accountId);
            return Ok(responseDto);

        }

        /// <summary>
        /// Bulk user creation
        /// </summary>
        /// <param name="users"></param>
        /// <returns></returns>
        [HttpPost("bulk/create")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<UserDetailDto>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> BulkCreateAsync(List<UserDetailDto> users)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();

            var results = await _userService.CreateBulkAsync(accountId, userId, sessionId, users);
            if (results != null)
            {
                int err = results.Errors[0].Code;
                return err switch
                {
                    0 => Ok(results.Entity ?? new List<UserDetailDto>()),
                    3 => Forbid(),// the user doesn't have admin rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }

        [HttpGet("bulk/download")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task BulkUsers([FromQuery] bool includeInactive = false)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var results = await _userService.GetByAccountIdAsync(accountId, includeInactive);
           
            Workbook wb = new Workbook(FileFormatType.Csv);
            var sheet = wb.Worksheets[0];
            int r = 0;

            sheet.Cells[r, 0].PutValue("Email and name fields are required. Role will default to Viewer if left empty.");
            r++;

            sheet.Cells[r, 0].PutValue("Email Address");
            sheet.Cells[r, 1].PutValue("First Name");
            sheet.Cells[r, 2].PutValue("Last Name");
            sheet.Cells[r, 3].PutValue("Role");
            sheet.Cells[r, 4].PutValue("Active");
            r++;

            for (int i = 0; i < results.Count; i++)
            {
                var user = results[i];
                sheet.Cells[r, 0].PutValue(user.Email);
                sheet.Cells[r, 1].PutValue(user.FirstName);
                sheet.Cells[r, 2].PutValue(user.LastName);
                sheet.Cells[r, 3].PutValue(user.AccountOwner ? $"{user.RoleName} - Account Owner" : user.RoleName);
                sheet.Cells[r, 4].PutValue(user.Active);
                r++;
            }

            Response.ContentType = "application/csv";
            Response.Headers.Add("Content-Disposition", "attachment; filename=users.csv");
            wb.Save(Response.BodyWriter.AsStream(), SaveFormat.Csv);
        }

        /// <summary>
        /// Bulk user group assignment
        /// </summary>
        /// <param name="bulkGroupAssign"></param>
        /// <returns></returns>
        [HttpPut("bulk/assignGroup")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<UserDetailDto>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> BulkAssignGroup([FromBody] BulkAssignGroupDto bulkGroupAssign)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            UpsertResponse<List<UserDetailDto>> results = await _userService.AssignGroupToUsers(accountId, userId, bulkGroupAssign);
            if (results != null)
            {
                int err = results.Errors[0].Code;
                return err switch
                {
                    0 => Ok(results.Entity ?? new List<UserDetailDto>()),
                    3 => Forbid(),// the user doesn't have admin rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }

        /// <summary>
        /// Bulk user deletion
        /// </summary>
        /// <param name="bulkDeleteRequest"></param>
        /// <returns></returns>
        [HttpPost("bulk/deletes")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> BulkDeleteUsers([FromBody] BulkDeleteRequestDTO bulkDeleteRequest)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();

            var results = await _userService.DeleteUsersAsync(accountId, userId, sessionId, bulkDeleteRequest);
            return Ok(results);
        }

        /// <summary>
        /// Validates if user email already exists
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("validateEmail")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> ValidateEmailAsync([FromBody] UserDetailDto dto)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);            
            var results = await _userService.ValidateEmailAsync(dto.Email, accountId, dto.FirstName, dto.LastName, dto.Federated, dto.Id);
            return Ok(results);
        }

        /// <summary>
        /// Email verification request
        /// </summary>
        /// <returns></returns>
        [HttpPost("emailVerificationRequest")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> SendEmailVerification()
        {
            Guid userId = this.User.GetUserId();
            Guid accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            await _userService.SendEmailVerificationMessageAsync(userId, accountId);
            return Ok();
        }

        /// <summary>
        /// Resends welcome email
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("resendWelcomeEmailRequest")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ResendWelcomeEmail([FromBody] UserDetailDto dto)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            if (dto.Id == Guid.Empty)
            {
                return BadRequest();
            }
            await _userService.ResendWelcomEmailMessageAsync(dto.Id, accountId);
            return Ok();
        }

        /// <summary>
        /// Marks email as verified by user
        /// </summary>
        /// <returns></returns>
        [HttpPost("emailVerification")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> Verify()
        {
            Guid userId = this.User.GetUserId();
            Guid accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            Guid sessionid = this.Request.GetB2CSessionId();
            await _userService.SaveUserEmailVerification(accountId, userId, sessionid).ConfigureAwait(false);
            return Ok();
        }

        /// <summary>
        /// New user creation
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created, Type = typeof(UserDetailDto))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        public async Task<IActionResult> CreateAsync([FromBody] UserDetailDto dto)
        {
            try
            {
                var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
                if (dto.Id != Guid.Empty)
                {
                    return BadRequest();
                }
                dto.AccountId = accountId;
                var existing = await _userService.GetByAccountIdAndEmailAsync(accountId, dto.Email);

                if (existing != null)
                {
                    ModelState.AddModelError("email", "User email already in use");
                    return BadRequest(ModelState);
                }               
                
                Guid byUserId = this.User.GetUserId();
                var sessionId = this.Request.GetB2CSessionId();

                var result = await _userService.CreateUserAsync(byUserId, sessionId, dto).ConfigureAwait(false);

                if (result.Entity == null)
                {
                    StringBuilder errorList = new StringBuilder();
                    if (result.Errors != null)
                    {
                        foreach (ErrorResponse error in result.Errors)
                        {
                            errorList.Append("Message: " + error.Message);
                            errorList.Append("; Code: " + error.Code);
                            errorList.Append("; ");
                        }
                        var dbError = errorList.ToString();
                        _logger.LogInformation($"CreateUser Error: {dbError}");
                        _telemetryClient.TrackTrace("CreateUser Error: " + dbError);
                    }
                    return UnprocessableEntity(result.Errors);
                }

                return CreatedAtAction(nameof(GetById), new { id = result.Entity.Id }, result.Entity);
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex) // // Do not catch general exception types TODO catch specific types
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _telemetryClient.TrackException(ex);
                _logger.LogInformation($"CreateUser error {ex.Message}");
                _telemetryClient.TrackTrace($"CreateUser error {ex.Message}");
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        /// <summary>
        /// Federated user creation
        /// </summary>
        /// <returns></returns>
        [HttpPost("createFederated")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created, Type = typeof(UpsertResponse<UserDetailDto>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        public async Task<IActionResult> CreateFederatedAsync()
        {

            _logger.LogInformation("CreateFederated: Begin");
            var email = this.User.GetClaim("emails");
            _logger.LogInformation($"CreateFederated: Processing claims for user {email}.");

            if (Guid.TryParse(this.User.GetClaim("extension_userId").Trim(), out Guid userId))
            {
                if (userId != Guid.Empty) //User already exists nothing to do here
                {
                    _logger.LogInformation($"CreateFederated: User {email} is already provisioned.");
                    return StatusCode(StatusCodes.Status400BadRequest);
                }
            }            

            try
            {
                var idpId = this.User.GetIdpId().ToString();
                var upn = this.User.GetClaim("federated_upn");
                if (string.IsNullOrWhiteSpace(idpId))
                {
                    _logger.LogInformation($"CreateFederated: User {email} does not have an idpId.");
                    return StatusCode(StatusCodes.Status400BadRequest);
                }

                var firstName = this.User.GetClaim("given_name");
                var lastName = this.User.GetClaim("family_name");
                if (string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(lastName))
                {
                    var fullName = this.User.GetClaim("name").Split(' ').ToList();
                    if (fullName.Count > 1)
                    {
                        firstName = fullName[0];
                        fullName.RemoveAt(0);
                        lastName = string.Join(' ', fullName);
                    }
                    if (string.IsNullOrWhiteSpace(firstName))
                    {
                        firstName = "unknown";
                    }
                    if (string.IsNullOrWhiteSpace(lastName))
                    {
                        lastName = "unknown";
                    }
                }

                UserDetailDto dto = new UserDetailDto
                {
                    FirstName = firstName,
                    LastName = lastName,
                    Email = email,
                    Active = true
                };                                

                _logger.LogInformation($"CreateFederated: Creating DB record for User {email}. {dto.ToJsonString()}");
                var sessionId = this.Request.GetB2CSessionId();
                var result = await _userService.CreateUserAsync(Guid.Empty, sessionId, dto, true, idpId, upn).ConfigureAwait(false);

                if (result.Entity == null)
                {
                    StringBuilder errorList = new StringBuilder();
                    if (result.Errors != null)
                    {
                        foreach (ErrorResponse error in result.Errors)
                        {
                            errorList.Append("Message: " + error.Message);
                            errorList.Append("; Code: " + error.Code);
                            errorList.Append("; ");
                        }
                        var dbError = errorList.ToString();
                        _logger.LogInformation($"CreateFederated: DB error for User {email}. {dbError}");
                        _telemetryClient.TrackTrace($"CreateFederated: DB error for User {email}. {dbError}");
                        _telemetryClient.TrackException(new Exception(dbError));
                    }
                    return UnprocessableEntity(result.Errors);
                }

                _logger.LogInformation($"CreateFederated: User {email} successfully added to the account.");
                return CreatedAtAction(nameof(GetById), new { id = result.Entity.Id }, result);
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex) // // Do not catch general exception types TODO catch specific types
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _telemetryClient.TrackException(ex);
                _logger.LogInformation($"CreateFederated: Exception for User {email}. {ex.Message}");
                _telemetryClient.TrackTrace($"CreateFederated: Exception for User {email}. {ex.Message}");
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        /// <summary>
        /// Returns account users
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<UserDetailDto>))]
        public async Task<IActionResult> GetAccountUsers()
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var results = await _userService.GetByAccountIdAsync(accountId, true);            
            return Ok(results);
        }

        /// <summary>
        /// Returns an account user by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UserDetailDto))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetById(Guid id)
        {

            var result = await _userService.GetUserByIdAsync(id);
            if (result != null)
            {   
                return Ok(UserService.ToDto(result));
            }            
            return NotFound();
        }

        /// <summary>
        /// Updates user information
        /// </summary>
        /// <param name="forUserId"></param>
        /// <param name="update"></param>
        /// <returns></returns>
        [HttpPut("{forUserId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UserDetailDto))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UpdateUserAsync(Guid forUserId, [FromBody] UserDetailDto update)
        {
            if (update == null
                || update.AccountId == null
                || update.Email == null
                ) return BadRequest();

            Guid byUserId = this.User.GetUserId();
            Guid accountId = (Guid)update.AccountId;
            Guid sessionId = this.Request.GetB2CSessionId();
            if (accountId == Guid.Empty)
            {
                return BadRequest();
            }
            var user = await _userService.UpdateUserAsync(byUserId, forUserId, accountId, sessionId, update).ConfigureAwait(false);
            if (user != null)
            {
                return Ok(UserService.ToDto(user));
            }
            return NotFound();
        }

        /// <summary>
        /// Syncs user information with idp
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost("sync/{id}")]
        [AllowAnonymous]
        [ApiExplorerSettings(IgnoreApi = true)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> SendUserToSync(Guid id)
        {
            //var authUser = this.User;
            var userToSync = await _userService.GetUserByIdAsync(id);
            if (userToSync == null)
            {
                return NotFound();
            }

            /* // For now, no fancy logic, just always all sync                 

            // 2 Scenarios this method can be used
            if (!authUser.Identity.IsAuthenticated) {
                // 1) No authenticated user. Request via postman because no user to login to the DAM app.
                // To sync a system admin user created in the database manually to AAD B2C
                if (userToSync.Role.Key != InternalUserRoleKeys.SystemAdmin)
                {
                    return BadRequest();
                }
            }
            else {
                // 1) Authorized user. 
                // Typically for an account admin, to sync users for their account
                var authUserAccountId = authUser.GetAccountId();
                if(userToSync.AccountId.ToString() != authUserAccountId)
                {
                    return NotFound();
                }
            }
            */

            await _userService.SyncUser(userToSync.Id, userToSync.AccountId, userToSync.Active);
            return Ok();
        }
    }
}
