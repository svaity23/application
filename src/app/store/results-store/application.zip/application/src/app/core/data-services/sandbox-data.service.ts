import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { BaseDataService } from './base-data.service';

@Injectable({
    providedIn: 'root'
})
export class SandboxDataService extends BaseDataService {

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    testStatus(statusCode: number): Observable<any> {
        const url = `${this.webApiUrl}/status?statuscode=${statusCode}`;
        return this.createApiGet({ url });
    }
}
