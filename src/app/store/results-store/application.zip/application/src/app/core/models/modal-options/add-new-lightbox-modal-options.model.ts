import { Lightbox } from '../entities/lightbox.model';

export interface AddNewLightboxModalOptions {
    confirm: (lightboxName: string) => void;
    confirmButtonText: string;
    deny: () => void;
    denyButtonText: string;
    lightboxes: Lightbox[];
    title: string;
}
