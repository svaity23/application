# SignalR Hub

SignalrR hub uses Azure Service Hub to establish an connection between the browser and back-end container(s) so users will be informed instantly when images processing and similar tasks are complete.

## Messages

### File Uploaded

The message is sent as soon as the WebAPI succeeds uploading the file into the account **assets** container.  The message has the following structure:

```json
{
	"MessageType": "FILE_UPLOADED",
    "AssetId": "95d19ff1-2372-4965-8734-c08fbf948001",
    "SignalRConnectionId": "CzAAJy13OctS5vdNvYPbXw40ccf6561"
}
```



### Thumbnail Ready

The message is sent when the Image Converter has processed the uploaded asset and the resulted images (thumbnails, low-resolution, etc.) files are created and stored within the account storage space.  The message has the informative role, telling what was done and in which containers it has been saved.  The sample below shows a message for a "partially resolved" asset:

```json
{
    "messageType": "THUMBNAIL_READY",
    "assetId": "95d19ff1-2372-4965-8734-c08fbf948001",
    "statusCode": 206,
    "assetBlob": "95d19ff1-2372-4965-8734-c08fbf948001.pdf",
    "containerName": "assets",
    "account": "5189526f642f449fb0185f50",
    "results": [
        {
            "name": "web",
            "statusCode": 200,
            "containerName": "web",
            "blobName": "95d19ff1-2372-4965-8734-c08fbf948001.png"
        },
        {
            "name": "thumb",
            "statusCode": 200,
            "containerName": "thumbnail",
            "blobName": "95d19ff1-2372-4965-8734-c08fbf948001.png"
        },
        {
            "name": "meta",
            "statusCode": 501,
            "containerName": null,
            "blobName": null
        },
        {
            "name": "low-res",
            "statusCode": 200,
            "containerName": "low-resolution",
            "blobName": "95d19ff1-2372-4965-8734-c08fbf948001.jpg"
        }
    ],
}
```



## Running

Simply press F5 to run the application. See the sections below to understand how best to debug the application.

## Debugging

Those of you already developing against the Azure Service Bus provided by Marcom may have noticed lost messages. It happens because of the Competing Consumer Pattern and the fact that fellow developers or Kubernetes (AKS) containers running the same code might grab your messages.

We've made changes so that you can get any service bus message you need for your projects running locally (dotnet run or F5) without concern that another developer or a container on SBX AKS will grab that message before you can.

As a developer, here's the supported use-cases sending an Azure Service Bus message:
1.	If I want the messages for my copies of SignalRHub, CancelUpload and UserSync running locally (F5), I will get them every single time even though other developers and SBX containers were subscribed to the same Topic 
2.	SBX containers won't get the messages that I intend to consume locally and try to duplicate work (e.g. write to tables a second time). 
3.	Messages I create but intend for SBX containers (e.g. because I don't want to run SignalRHub locally) arrive every time on the SBX machines for processing, and my copies of 
SignalRHub, etc. won't see those messages next time I run them. 

Out of the box it will just work, assuming you're not running CancelUpload and UserSync locally, but instead letting the shared SBX containers do the workk (#3 above). If you'd like to run them locally (#1 above), it's easy, and I'll explain below how to do that.

In the WebAPI's settings, there's a configuration section indicating where you'd like your Service Bus messages to be processed (e.g. locally or let SBX do it).

```json
"TargetMachines": {
"thumbnailWorker": null,
"signalRHubWorker": "local",
"cancelUploadWorker": null,
"userSyncWorker": null
},
```

You can use null (as we did above) to have SBX process the messages. "sbx" or "aks" do the same. If you want to run it locally, change it to "local" or your computer name in quotes. Then load the project (SignalRHub, Cancel-Upoad, User-Sync) and hit F5. 

Valid values:

|vlaue|effect|
|-----|------|
|null, "sbx", or "aks"|the sbx environment will process the messages using containers listening there|
|"local", "<<your computer name>>"|you will process messages using projects you're running locally (F5 or dotnet run)|

What if you don't want to accidentally check that appsettings.json file in and make enemies?!? We've got you covered. Just add a file in the right place (c:/damConfig/shared/appsettings.json).

*c:/damConfig/shared/appsettings.json:*
```json
{
  "TargetMachines": {
    "thumbnailWorker": "sbx",
    "signalRHubWorker": "local",
    "cancelUploadWorker": "sbx",
    "userSyncWorker": "sbx"
  }
}
```