import { ChangeDetectionStrategy, Component, Injector, OnInit, ViewEncapsulation } from '@angular/core';
import Oidc from 'oidc-client';

import { APP_CONFIG, AppConfig } from '@app/app-config';
import { AppStoreFacade } from '@app/store/app-store/app-store.facade';

@Component({
  selector: 'app-account-federation',
  templateUrl: './account-federation.component.html',
  styleUrls: ['./account-federation.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountFederationComponent implements OnInit {
  redirectLoading = false;
  private appSettings: AppConfig;
  constructor(private appStoreFacade: AppStoreFacade, private injector: Injector) {
    this.appSettings = this.injector.get(APP_CONFIG);
  }


  ngOnInit(): void {
    const config = {
        ...this.appSettings.federatedConsentConfig,
        userStore: new Oidc.WebStorageStateStore({ store: window.sessionStorage })
    }
    const manager = new Oidc.UserManager(config);
    manager.getUser()
    .then(consentUser => {
      this.appStoreFacade.saveFederatedDomain(consentUser.profile?.federated_email);
      // remove oidc record
      manager.removeUser();    
    });
  }

  redirectToIntegrations(): void {
    this.redirectLoading = true;
    this.appStoreFacade.navigate('/account/integrations');
  }
}
