import { Injectable } from '@angular/core';

import { catchError, map } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

import { AccountDetail } from '../models/entities/account-detail.model';
import { BaseDataService } from './base-data.service';
import { Context } from '../models/context.model';
import { SignalRSource } from '../enums/signal-r-source.enum';
import { UpsertEntityResponse } from '../models/api-responses/upsert-entity-response.model';
// import { SignalRSource } from '../enums/signal-r-source.enum';

export interface ContextDataServiceInterface {
    getApplicationContext(pluginName: string): Observable<Context>;
    getSisenseLaunchUrl(): Observable<string>;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    resetToDefaultFavicon(): Observable<any>;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    resetToDefaultLogo(): Observable<any>;
    updateAccountTheme(accountId: string, theme: string): Observable<string>;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    uploadFavicon(file: File): Observable<any>;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    uploadLogo(file: File): Observable<any>;
    userSelfReg(): Observable<UpsertEntityResponse<AccountDetail>>;
    verifyScopeAccess(scope: string): Observable<boolean>;
}

@Injectable({ providedIn: 'root' })
export class ContextDataService extends BaseDataService implements ContextDataServiceInterface {

    getApplicationContext(pluginName: string): Observable<Context> {
        let url = `${this.webApiUrl}/context`;
        if (pluginName) {
            url = url + `?pluginName=${pluginName}`;
        }
        return this.createApiGet({ url });
    }
    getSisenseLaunchUrl(): Observable<string> {
        const url = `${this.webApiUrl}/sisense/launchUrl`;
        return this.createApiGet({ url });
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    resetToDefaultFavicon(): Observable<any> {
        const url = `${this.webApiUrl}/upload/favicon`;
        return this.createApiDelete({ url });
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    resetToDefaultLogo(): Observable<any> {
        const url = `${this.webApiUrl}/upload/logo`;
        return this.createApiDelete({ url });
    }

    updateAccountTheme(accountId: string, theme: string): Observable<string> {
        const url = `${this.webApiUrl}/accounts/${accountId}/themes/${theme}`;
        return this.createApiPut({ url });
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    uploadFavicon(file: File): Observable<any> {
        const data = new FormData();
        data.append('file', file, file.name);
        const url = `${this.webApiUrl}/upload/favicon`;
        return this.createApiPost({ url, data });
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    uploadLogo(file: File): Observable<any> {
        const data = new FormData();
        data.append('file', file, file.name);
        const url = `${this.webApiUrl}/upload/logo`;
        return this.createApiPost({ url, data });
    }

    userSelfReg(): Observable<UpsertEntityResponse<AccountDetail>> {
        const url = `${this.webApiUrl}/accounts/selfReg`;
        const data = {
            SignalRSource: SignalRSource.PROVISION
        }

        return this.createApiPost({ url, data });
        // return this.createApiPost({ url});
    }

    verifyScopeAccess(scope: string): Observable<boolean> {
        const url = `${this.webApiUrl}/context/scope/${scope}`;
        return this.createApiGet({ url })
            .pipe(
                map(() => true),
                catchError(() => of(false))
            );
    }
}
