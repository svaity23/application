import { AssetAttachment } from '../asset-attachment.model';
import { AssetViewState } from '@app/core/models/view-states/asset-view-state.model';
import { ErrorResponse } from '../api-responses/error-response';
import { FileGroupType, FileType } from '@app/core/enums';

export interface Asset {
    accountId?: string;
    active?: boolean;
    attachment?: AssetAttachment;
    collectionId: string;
    created: Date;
    createdByUserId: string;
    createdByUserName: string;
    description: string;
    error: ErrorResponse[];
    expired?: boolean;
    expireOn?: Date;
    externalId?: string;
    favorite?: boolean;
    fileExtension: FileType;
    fileGroup: FileGroupType;
    fileName: string;
    fileSize: number;
    id: string;
    lastModifiedByUserId: string;
    lightboxIds?: string[];
    modified?: Date;
    modifiedByUserName: string;
    name: string;
    uploadSessionId?: string;
    viewState: AssetViewState;
}
