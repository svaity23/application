﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Dtos;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class MetadataProfilesController : ControllerBase
    {
        private readonly ILogger<MetadataProfilesController> _logger;
        private readonly IConfiguration _configuration;
        private readonly MetadataProfileService _metadataProfileService;        
        private readonly UserAccountService _userAccountService;

        public MetadataProfilesController(ILogger<MetadataProfilesController> logger, IConfiguration configuration, MetadataProfileService metadataProfileService, UserAccountService userAccountService)
        {
            _logger = logger;
            _configuration = configuration;
            _metadataProfileService = metadataProfileService;
            _userAccountService = userAccountService;
        }

        /// <summary>
        /// Get all metadata profiles
        /// </summary>
        /// <remarks>
        /// Get all default metadata profiles
        /// </remarks>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(MetadataProfileViewResponseDto))]
        public async Task<IActionResult> GetAll()
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var results = await _metadataProfileService.GetMetadataProfilesAsync(accountId);
            return Ok(results);
        }

        /// <summary>
        /// Get metadata profile fields by profile id
        /// </summary>
        /// <remarks>
        /// Get metadata profile fields by profile id
        /// </remarks>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}/fields")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(MetadataFieldResponseDto))]
        public async Task<IActionResult> GetProfileFields(Guid id)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var results = await _metadataProfileService.GetMetadataProfileFieldsByProfileIdAsync(accountId, id);
            return Ok(results);
        }

        /// <summary>
        /// Update metadata profile field
        /// </summary>
        /// <remarks>
        /// Update metadata profile field by id
        /// </remarks>
        /// <param name="id"></param>
        /// <param name="MetadataFieldRequest"></param>
        /// <returns></returns>
        [HttpPut("{id}/fields")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(MetadataFieldResponseDto))]
        public async Task<IActionResult> SaveProfileFields(Guid id, [FromBody] MetadataFieldRequestDto MetadataFieldRequest)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var results = await _metadataProfileService.SaveMetadataProfileFieldsByProfileIdAsync(accountId, MetadataFieldRequest);
            return Ok(results);

        }
    }
}
