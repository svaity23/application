﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos.Asset.Request
{
    public class PermalinkRequest
    {
        public Guid AssetId { get; set; }
        public string ExternalId { get; set; }
        public string Resolution { get; set; }
        public string Sas { get; set; }
        public DateTime SasExpiration { get; set; }

        public string Destination { get; set; }
    }
}
