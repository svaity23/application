﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class GroupFinder
    {

        private readonly damContext _context;

        public GroupFinder(damContext context)
        {
            _context = context;
        }

        public async Task<string> GetAllGroupAsync(Guid accountId, Guid userId)
        {
            return await ExecuteAsync("getGroups", accountId, userId);
        }

        public async Task<string> DeleteGroupAsync(Guid accountId, Guid userId, string jsonGroups)
        {
            return await ExecuteAsync("deleteGroup", accountId, userId, jsonGroups);
        }

        public async Task<string> SaveGroupAsync(Guid accountId, Guid userId, string jsonGroupUpdate)
        {
            return await ExecuteAsync("saveGroup", accountId, userId, jsonGroupUpdate);
        }

        private async Task<string> ExecuteAsync(string procedure, Guid accountId, Guid userId, string json = null)
        {
            SpParams paramList = new SpParams();
            paramList.WithAccountId(accountId);
            paramList.WithUserId(userId);
            if (json!=null) paramList.WithJson(json);

            List<SqlParameter> sqlParmsList = paramList.Build();
            return await _context.ExecuteNonQueryJsonOutputAsync(procedure, sqlParmsList).ConfigureAwait(false);
        }

    }
}
