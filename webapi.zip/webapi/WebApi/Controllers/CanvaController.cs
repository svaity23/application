﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using WebApi.Common.Constants;
using WebApi.Dtos;
using WebApi.Dtos.Canva;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AllowAnonymous]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class CanvaController : ControllerBase
    {
        private readonly ILogger<IntegrationController> _logger;
        private readonly IConfiguration _configuration;
        private readonly KeyVaultService _keyVaultService;
        private readonly CanvaService _canvaService;
        private readonly string CANVA_CLIENT_SECRET;
        private readonly string CANVA_SIGNATURE_VERIFICATION_BODY = "{\"user\":\"TEST_USER\",\"brand\":\"TEST_BRAND\"}";

        public CanvaController(ILogger<IntegrationController> logger, CanvaService canvaAuthService, IConfiguration configuration, KeyVaultService keyVaultService)
        {
            _logger = logger;
            _canvaService = canvaAuthService;
            _configuration = configuration;
            _keyVaultService = keyVaultService;
            CANVA_CLIENT_SECRET = GetCanvaClientSecret();
        }

        [HttpGet("auth")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        public IActionResult SignatureVerification(
            string time,
            string user,
            string brand,
            string extensions,
            string state,
            string signatures)
        {
            _logger.LogInformation("Signature verification test");
            if (IsValidGetRequest(time, user, brand, extensions, state, signatures))
            {
                string currentURL = HttpContext.Request.Host.Value;
                string newHostValue = currentURL.Replace("webapi-", "");
                string fullRedirectURL = $"https://{newHostValue}/integration/canva?user={user}&&state={state}";
                
                return Redirect(fullRedirectURL);
            }

            _logger.LogInformation("Canva/SignatureVerification: Unable to validate GetRequest");
            return Unauthorized();
        }

        [HttpPost("configuration/delete")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        public async Task<IActionResult> RemoveUserCredentialsAsync()
        {
            _logger.LogInformation("Removing user credentials.");

            _logger.LogInformation("Verifying POST request signature.");
            string bodyAsString = await GetRawBodyAsync();
            bodyAsString = Regex.Replace(bodyAsString, @"\s+", "");
            if (!IsValidPostRequest(CANVA_CLIENT_SECRET, HttpContext.Request, bodyAsString))
            {
                return Unauthorized();
            } 
            else if (bodyAsString.Equals(CANVA_SIGNATURE_VERIFICATION_BODY))
            {
                return Ok();
            }
            _logger.LogInformation("POST request signature successfully verified.");

            var canvaRequestDto = JsonConvert.DeserializeObject<CanvaRequestDto>(bodyAsString);
            await _canvaService.DeleteCanvaUserAsync(canvaRequestDto);
            var resp = new CanvaResponseDto()
            {
                Type = "SUCCESS"
            };
            return Ok(resp);

        }

        [HttpPost("content/resources/find")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        public async Task<ActionResult> ContentResourcesAsync()
        {
            _logger.LogInformation("Content resources request");

            _logger.LogInformation("Verifying POST request signature.");
            string bodyAsString = await GetRawBodyAsync();
            bodyAsString = Regex.Replace(bodyAsString, @"\s+", "");
            if (!IsValidPostRequest(CANVA_CLIENT_SECRET, HttpContext.Request, bodyAsString))
            {
                return Unauthorized();
            }
            else if (bodyAsString.Equals(CANVA_SIGNATURE_VERIFICATION_BODY))
            {
                return Ok();
            }
            _logger.LogInformation("POST request signature successfully verified.");

            var canvaRequest = JsonConvert.DeserializeObject<CanvaRequestDto>(bodyAsString);
            var assets = await _canvaService.GetAssetsAsync(canvaRequest);
            _logger.LogInformation("Assets json for Canva:\n\r" + assets.ToJsonString());

            return Ok(assets);
        }

        private string GetCanvaClientSecret()
        {
            var keyvaultSecret = _keyVaultService.GetSecret(KeyVaultSecretKey.CanvaClientSecret);
            if(string.IsNullOrEmpty(keyvaultSecret))
            {
                _logger.LogError("Canva Client Secret Not found");
            }
            return keyvaultSecret;
        }

        private bool IsValidGetRequest(
            string time,
            string user,
            string brand,
            string extensions,
            string state,
            string signatures)
        {
            if (String.IsNullOrEmpty(time) || String.IsNullOrEmpty(user) || String.IsNullOrEmpty(brand) || String.IsNullOrEmpty(extensions) || String.IsNullOrEmpty(state) || String.IsNullOrEmpty(signatures))
            {
                return false;
            }
            else
            {
                long sentAtSeconds = long.Parse(time);
                long receivedAtSeconds = DateTimeOffset.Now.ToUnixTimeMilliseconds() / 1000;
                if (!IsValidTimestamp(sentAtSeconds, receivedAtSeconds))
                {
                    return false;
                }

                // Construct the message
                string version = "v1";
                string message = $"{version}:{time}:{user}:{brand}:{extensions}:{state}";

                // Calculate the signature
                string signature = CalculateSignature(CANVA_CLIENT_SECRET, message);
                _logger.LogInformation("GET Received signature: " + signatures);
                _logger.LogInformation("GET Calculated signature: " + signature);

                // Reject requests with invalid signatures
                if (!signatures.Contains(signature, StringComparison.InvariantCultureIgnoreCase))
                {
                    return false;
                }

                return true;
            }
        }

        private bool IsValidPostRequest(string secret, HttpRequest request, string bodyAsString)
        {
            // Verify the timestamp
            IHeaderDictionary headers = request.Headers;
            long sentAtSeconds = long.Parse(headers["X-Canva-Timestamp"]);
            long receivedAtSeconds = DateTimeOffset.Now.ToUnixTimeMilliseconds() / 1000;

            if (!IsValidTimestamp(sentAtSeconds, receivedAtSeconds))
            {
                return false;
            }

            // Construct the message
            string version = "v1";
            string timestamp = headers["X-Canva-Timestamp"];
            string path = GetPathForSignatureVerification(request.Path);
            string message = $"{version}:{timestamp}:{path}:{bodyAsString}";
            string receivedSignature = headers["X-Canva-Signatures"].ToString().ToUpper();

            // Calculate the signature
            string signature = CalculateSignature(secret, message);
//            _logger.LogInformation("POST Received signature: " + receivedSignature);
//            _logger.LogInformation("POST Calculated signature: " + signature);

            // Reject requests with invalid signatures
            if (!receivedSignature.Contains(signature, StringComparison.InvariantCultureIgnoreCase))
            {
                return false;
            }

            return true;
        }

        private bool IsValidTimestamp(long sentAtSeconds, long receivedAtSeconds)
        {
            const long leniencyInSeconds = 300;
            long elapsedTime = sentAtSeconds - receivedAtSeconds;

            return Math.Abs(sentAtSeconds - receivedAtSeconds) < leniencyInSeconds;
        }

        private string GetPathForSignatureVerification(string input)
        {
            string[] paths = new string[] { "/configuration", "/configuration/delete", "/content/resources/find" };

            foreach (string path in paths)
            {
                if (input.EndsWith(path))
                {
                    return path;
                }
            }

            return "";
        }

        private async Task<string> GetRawBodyAsync()
        {
            var reader = new StreamReader(HttpContext.Request.Body);
            return await reader.ReadToEndAsync();
        }

        private string CalculateSignature(string secret, string message)
        {
            // Step 2 - verify POST request signature - decode the client secret(base64-encoded string)
            byte[] key = Convert.FromBase64String(secret);

            // Step 4 - verify POST request signature - calculate the SHA-256 hash using the key and the message
            HMACSHA256 hmac = new HMACSHA256(key);
            byte[] sha256Hash = hmac.ComputeHash(Encoding.ASCII.GetBytes(message));

            // Step 4 - verify POST request signature - convert SHA-256 hash into a hex-encoded string.
            string hexEncodedSha = Convert.ToHexString(sha256Hash);

            return hexEncodedSha.ToUpper();
        }
    }
}
