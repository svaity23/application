import { Injectable } from '@angular/core';

import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { BaseDataService } from './base-data.service';
import { Notification } from '../models/notification.model';

export interface NotificationsDataServiceInterface {
  delete(id: string): Observable<string[]>;
  getAllNotifications(): Observable<Notification[]>;
  markNotifications(ids: string[], read: boolean): Observable<string[]>;
}

@Injectable({
  providedIn: 'root'
})
export class NotificationsDataService extends BaseDataService implements NotificationsDataServiceInterface {

  delete(id: string): Observable<string[]> {
    const url = `${this.webApiUrl}/notifications/${id}`;
    return this.createApiDelete({ url, options: { observe: 'response' } }).pipe(
            // eslint-disable-next-line @typescript-eslint/dot-notation
            map((data) => data['body'])
    );
  }

  getAllNotifications(): Observable<Notification[]> {
    const url = `${this.webApiUrl}/notifications`;
    return this.createApiGet({ url });
  }

  markNotifications(ids: string[], read:boolean): Observable<string[]> {
    const dto = {
      Ids: ids,
      MarkAsRead: read
    };
    const url = `${this.webApiUrl}/notifications/mark`;
    return this.createApiPut({ url, data: dto });
  }
}
