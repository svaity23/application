﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class SettingFinder
    {
        private damContext _context;

        public SettingFinder(damContext context)
        {
            _context = context;
        }

        public async Task<string> GetFrontEndSettings(Guid accountId, Guid userId)
        {
            SpParams paramList = new SpParams();
            paramList.WithAccountId(accountId);
            paramList.WithUserId(userId);
            return await ExecuteAsync("getFrontEndSettings", paramList);
        }

        public async Task<string> UpdateFrontEndSettings(Guid accountId, Guid userId, string jsonInput)
        {
            SpParams paramList = new SpParams();
            paramList.WithAccountId(accountId);
            paramList.WithUserId(userId);
            return await ExecuteAsync("saveFrontEndSettings", paramList, jsonInput);
        }


        private async Task<string> ExecuteAsync(string procedure, SpParams paramList, string json = null)
        {
           
            if (json != null) paramList.WithJson(json);

            List<SqlParameter> sqlParmsList = paramList.Build();
            return await _context.ExecuteNonQueryJsonOutputAsync(procedure, sqlParmsList).ConfigureAwait(false);
        }
    }
}
