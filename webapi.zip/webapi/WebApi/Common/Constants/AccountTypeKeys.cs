﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Common.Constants
{
    public static class AccountTypeKeys
    {
        public const string Basic = "Basic";
        public const string MCCInternal = "MCC Internal";
        public const string Trial = "Trial";
    }    
}
