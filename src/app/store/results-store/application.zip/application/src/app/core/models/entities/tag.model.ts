
export interface Tag {
    aiGeneratedValues: string[];    
    assetId: string;
    modified?: Date;
    modifiedByUserFullName?: string;
    ocrGeneratedValues?: string;
    values: string[]; // TODO: change to string
}
