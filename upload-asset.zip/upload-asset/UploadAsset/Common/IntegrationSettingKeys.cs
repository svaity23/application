﻿namespace UploadAsset.Common
{
    public class IntegrationSettingKeys
    {
        public const string Hubspot = "integration-hubspot-enabled";
        public const string Marcom = "integration-marcomcentral-enabled";
    }
}
