﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace WebApi.Services
{
    public interface IGoogleServiceFactory
    {
        GoogleDriveService CreateGoogleDriveService(string accessToken);
    }

    public class GoogleServiceFactory : IGoogleServiceFactory
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<GoogleServiceFactory> _logger;
        private readonly ILoggerFactory _loggerFactory;
        private readonly bool _isDevelopment; 

        public GoogleServiceFactory(IConfiguration configuration, ILogger<GoogleServiceFactory> logger, ILoggerFactory loggerFactory, IWebHostEnvironment webHostEnvironment)
        {
            _configuration = configuration;
            _logger = logger;
            _loggerFactory = loggerFactory;
            _isDevelopment = webHostEnvironment.IsDevelopment();
        }

        public GoogleDriveService CreateGoogleDriveService(string accessToken)
        {
            var logger = _loggerFactory.CreateLogger<GoogleDriveService>();
            //var health = new Common.Health();

            return new GoogleDriveService(_configuration, logger, accessToken);
        }
    }
}
