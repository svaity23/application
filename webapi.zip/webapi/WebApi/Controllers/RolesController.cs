﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Dtos;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class RolesController : ControllerBase
    {
        private readonly ILogger<RolesController> _logger;
        private readonly RoleService _roleService;
        private readonly UserAccountService _userAccountService;

        public RolesController(ILogger<RolesController> logger, RoleService roleService, UserAccountService userAccountService)
        {
            _logger = logger;
            _roleService = roleService;
            _userAccountService = userAccountService;
        }

        /// <summary>
        /// Get all roles
        /// </summary>
        /// <remarks>
        /// Get all roles for current account
        /// </remarks>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<RoleDto>))]
        public async Task<IActionResult> GetAccountRoles()
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);

            var results = _roleService.GetAccountRolesAsync(accountId);
            var dtos = new List<RoleDto>();
            await foreach (var result in results)
            {
                dtos.Add(RoleService.ToDto(result));
            }
            return Ok(dtos);
        }

        /// <summary>
        /// Get role by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(RoleDto))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetById(Guid id)
        {
            var result = await _roleService.GetRoleByIdAsync(id);
            if (result != null)
            {
                return Ok(RoleService.ToDto(result));
            }
            return NotFound();
        }        
    }
}