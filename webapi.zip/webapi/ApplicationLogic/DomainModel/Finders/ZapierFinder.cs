﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class ZapierFinder
    {
        private readonly damContext _context;

        public ZapierFinder(damContext context)
        {
            _context = context;
        }

        public async Task<string> GetZapierAssetsInfo(Guid accountId, Guid userId, string jsonParams)
        {

            List<SqlParameter> paramList = new SpParams()
                 .WithAccountId(accountId)
                 .WithUserId(userId)
                 .WithJson(jsonParams)
                 .Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("getAssetsInfoForZapier", paramList);
        }

    }
}
