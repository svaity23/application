﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace UploadAsset.Dtos
{
    public class AccountBrandParamsDto
    {
        [JsonPropertyName("logo")]
        public string Logo { get; set; }
        [JsonPropertyName("theme")]
        public string Theme { get; set; }
    }
}
