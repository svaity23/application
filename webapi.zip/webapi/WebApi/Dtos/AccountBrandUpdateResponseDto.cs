﻿using System.Text.Json.Serialization;

namespace WebApi.Dtos
{
    public class AccountBrandUpdateResponseDto
    {
        [JsonPropertyName("favicon")]
        public string Favicon { get; set; }

        [JsonPropertyName("logo")]
        public string Logo { get; set; }

        [JsonPropertyName("theme")]
        public string Theme { get; set; }
    }
}
