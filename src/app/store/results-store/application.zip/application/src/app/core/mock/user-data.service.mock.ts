import { Injectable } from '@angular/core';

import * as faker from 'faker/locale/en_US';
import { Observable, of } from 'rxjs';

import { AccountLite } from '../models/account-lite.model';
import { UpsertEntityResponse } from '../models/api-responses/upsert-entity-response.model';
import { User } from '../models/entities/user.model';
import { UsersDataServiceInterface } from '../data-services/users-data.service';
import { ValidateEmailResponse } from '../models/api-responses/validate-email-response.model';
import { ValidateUsersResponse } from '../models/api-responses/validate-users-response.model';

@Injectable({ providedIn: 'root' })
export class UsersDataServiceMock implements UsersDataServiceInterface {
    private internalUsersList: User[] = [];

    constructor() {
        const oneUser = (): User => {
            const user: User = {
                id: faker.random.number().toString(),
                externalId: faker.random.number().toString(),
                accountId: null,
                accountName: '',
                accountCount: 0,
                active: true,
                firstName: faker.name.firstName(),
                lastName: faker.name.lastName(),
                lastLoginDate: new Date(),
                email: faker.internet.email(),
                roleId: faker.random.number({ min: 1, max: 3 }).toString(),
                roleKey: '',
                roleName: '',
                selected: false,
                groupId: faker.random.number({ min: 1, max: 3 }).toString()
            };
            return user;
        };
        const randomUsers = (
            count = faker.random.number({ min: 4, max: 4 })
        ): User[] => {
            // eslint-disable-next-line prefer-spread
            return Array.apply(null, Array(count)).map(() => oneUser());
        };

        this.internalUsersList = randomUsers();
        this.internalUsersList.sort((s1, s2) => s1.firstName.toLocaleLowerCase() > s2.firstName.toLocaleLowerCase() ? 1 : -1);
    }

    add(user: User): Observable<User> {
        return new Observable(observer => {
            const usersCount = this.internalUsersList.length + 1;
            this.internalUsersList.splice(usersCount, 0, { ...user });

            // Yield a single value and complete
            observer.next(user);
            observer.complete();
        });
    }

    addFederated(): Observable<UpsertEntityResponse<User>> {
        throw new Error('Method not implemented');
    }

    assignGroup(users: User[], groupId: string): Observable<User[]> {
        throw new Error('Method not implemented to assign group ' + groupId + 'to ' + users.length + ' users ');
    }

    bulkInactivate(users: User[]): Observable<string[]> {
        return of(users.map(u => u.id));
    }

    delete(id: string): Observable<User> {
        return new Observable(observer => {
            const itemToDelete = this.internalUsersList.find(x => x.id === id);
            const indexToDelete = this.internalUsersList.indexOf(itemToDelete);

            this.internalUsersList.splice(indexToDelete, 1);

            itemToDelete.active = false;
            const clone = JSON.parse(JSON.stringify(itemToDelete));
            observer.next(clone);
            observer.complete();
        });
    }

    downloadAllUsers(includeInactiveUsers: boolean): Observable<Blob> {
        throw new Error('Method not implemented.' + includeInactiveUsers);
    }

    filterUsers(searchText: string): Observable<User[]> {
        return new Observable(observer => {
            const items =
                this.internalUsersList.filter(u => {
                    return u.lastName.toString().toLocaleLowerCase().includes(searchText.toLocaleLowerCase())
                        || u.firstName.toString().toLocaleLowerCase().includes(searchText.toLocaleLowerCase())
                        || u.email.toString().toLocaleLowerCase().includes(searchText.toLocaleLowerCase());
                });


            // Yield a single value and complete
            const clone = JSON.parse(JSON.stringify(items));
            observer.next(clone);
            observer.complete();
        });
    }

    getAll(): Observable<User[]> {
        return new Observable(observer => {
            // clone this internal list because store-freeze will make it immutable later in the dispatch pipeline
            const clone = JSON.parse(JSON.stringify(this.internalUsersList));

            // Yield a single value and complete
            observer.next(clone);
            observer.complete();
        });
    }

    getUserAccounts(): Observable<AccountLite[]> {
        throw new Error('Method not implemented.');
    }

    sendEmailVerificationRequest(): Observable<boolean> {
        return of(true);
    }

    updateUser(user: User): Observable<User> {
        return new Observable(observer => {
            const itemToModify = this.internalUsersList.find(x => x.id === user.id);
            const indexToModify = this.internalUsersList.indexOf(itemToModify);

            this.internalUsersList.splice(indexToModify, 1, { ...user });

            const clone = JSON.parse(JSON.stringify(this.internalUsersList));
            // Yield a single value and complete

            observer.next(clone);
            observer.complete();
        });
    }

    validateUploadUsersFile(usersFile: File): Observable<ValidateUsersResponse> {
        // eslint-disable-next-line no-empty
        if (usersFile.name) { }
        const response: ValidateUsersResponse = {
          errors: [],
          users: [],
          warnings: []
        }
        return of(response);
    }

    validateUserEmail(user: User): Observable<ValidateEmailResponse> {
        const itemWithSameEmail = this.internalUsersList.find(u => u.email === user.email);
        const response: ValidateEmailResponse = {
            error: '0',
            valid: itemWithSameEmail ? 0 : 1
        }
        return of(response);
    }

    verifyUserEmail(): Observable<boolean> {
        return of(true);
    }
}
