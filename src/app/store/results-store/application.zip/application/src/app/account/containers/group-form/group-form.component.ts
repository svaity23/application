import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import { AppGroupStoreFacade } from '@app/store/app-store/app-group-store.facade';
import { AppStoreFacade } from '@app/store/app-store/app-store.facade';
import { Context } from '@app/core/models/context.model';
import { Group } from '@app/core/models/entities/group.model';
@Component({
  selector: 'app-group-form',
  templateUrl: './group-form.component.html',
  styleUrls: ['./group-form.component.scss']
})
export class GroupFormComponent implements OnInit {
  accountTypeName$: Observable<string>;
  context$: Observable<Context>;
  group$: Observable<Group>;
  invalidGroup$: Observable<boolean>;
  isGroupModified = false;
  logoUrl$: Observable<string>;
  searchText$: Observable<string>;
  showIntegrations$: Observable<boolean>;
  showUserGroups$: Observable<boolean>;

  private newGroup = false;

  constructor(
    private appStoreFacade: AppStoreFacade,
    private appGroupStoreFacade: AppGroupStoreFacade) { }

  navigateTo(pageName): void {
    this.appStoreFacade.navigate(`account/${pageName}`);
    this.appStoreFacade.partialResetAppStore();
  }

  navigateToGroupList(): void {
    this.appStoreFacade.navigate('/account/groups');
    this.appStoreFacade.partialResetAppStore();
    this.appGroupStoreFacade.setSelectedGroupId(null);
  }

  ngOnInit(): void {
    this.accountTypeName$ = this.appStoreFacade.accountTypeName$;
    this.context$ = this.appStoreFacade.context.context$;
    this.group$ = this.appGroupStoreFacade.selectedGroup$;
    this.invalidGroup$ = this.appGroupStoreFacade.invalidGroup$;
    this.logoUrl$ = this.appStoreFacade.logoUrl$;
    this.searchText$ = this.appGroupStoreFacade.searchText$;
    this.showIntegrations$ = this.appStoreFacade.showIntegrations$;
    this.showUserGroups$ = this.appStoreFacade.context.isUserGroupsFeatureEnabled$;
  }

  onGroupFieldChange(group: Group):void {
    if (group.id == null) {
      this.newGroup = true;
    }
    this.appGroupStoreFacade.updateGroupToModify({ ...group });
    this.isGroupModified = true;
  }

  onGroupValidateChange(group: Group): void {
    if (group.id == null) {
      this.newGroup = true;
    }
    this.appGroupStoreFacade.validateGroup({ ...group });
    this.isGroupModified = true;
  }

  onSaveChanges(): void {
    if (this.newGroup) {
      this.appGroupStoreFacade.addGroup();
    } else {
      this.appGroupStoreFacade.updateGroup();
    }
    this.navigateToGroupList();
    this.appGroupStoreFacade.setSelectedGroupId(null);
  }

  openConfirmationModal(): void {
    this.appGroupStoreFacade.openGroupConfirmationModal({
      title: 'Delete Groups',
      message: 'Any users assigned to this group will be removed from the group and their permissions will be updated.\n\nThis action cannot be undone.',
      confirmButtonText: 'Delete',
      denyButtonText: 'Cancel',
      confirm: this.delete,
      deny: () => { },
      confirmButtonIcon: 'trash'
    });
  }

  private delete = () => {
    this.appGroupStoreFacade.deleteGroup();
  }
}
