﻿using System.Collections.Generic;

namespace SignalRHub.Messages
{
    public class ThumbReadyDTO: AbstractAssetMessageDTO
    {
        private const string MESSAGE_TYPE = "THUMBNAIL_READY";
        private readonly List<MetadataEntryDTO> _metadataEntries = new List<MetadataEntryDTO>();
        private readonly List<TaskResultDTO> _tasks = new List<TaskResultDTO>();
        private readonly List<FileMetadataTagDTO> _fileMetadataTags = new List<FileMetadataTagDTO>();

        public ThumbReadyDTO(string assetId) : base(MESSAGE_TYPE, assetId) { }

        public int StatusCode { get; set; }
        public string Source { get; set; }
        public string ContainerName { get; set; }
        public string AssetBlob { get; set; }
        public string AccountName { get; set; }
        public MetadataInfoDTO MetadataInfo { get; set; }
        public string AssetDescription { get; set; }

        public List<MetadataEntryDTO> Metadata
        {
            get { return _metadataEntries;  }
        }

        public List<TaskResultDTO> Results 
        { 
            get { return _tasks; } 
        }

        public List<FileMetadataTagDTO> FileMetadataTags
        {
            get { return _fileMetadataTags; }
        }

        public void AddMetaResults(MetadataEntryDTO entry)
        {
            _metadataEntries.Add(entry);
        }

        public void AddTaskResult(TaskResultDTO results)
        {
            _tasks.Add(results);
        }
    }

    public class TaskResultDTO 
    {
        public string Name { get; set; }
        public int StatusCode { get; set; }
        public string ContainerName { get; set; }
        public string BlobName { get; set; }
    }

    public class FileMetadataTagDTO
    {
        public string Name { get; set; }
    }
    public class MetadataInfoDTO
    {
        public string Created { get; set; }
        public string Author { get; set; }        
    }

    public class MetadataEntryDTO
    {
        public string Id { get; set; }
        public string AssetId { get; set; }
        public string MetadataFieldId { get; set; }
        public string Value { get; set; }
    }


}
