﻿
using System;
using System.Text.Json.Serialization;

namespace WebApi.Dtos
{
    public class UserDetailDto
    {
        public Guid Id { get; set; }
        public string ExternalId { get; set; }
        public bool EmailVerified { get; set; }
        public bool Federated { get; set; }
        public Guid? AccountId { get; set; }
        public bool Active { get; set; }
        public Guid? RoleId { get; set; }
        public string RoleName { get; set; }
        public string RoleKey { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public Guid? GroupId { get; set; }
        public DateTime? LastLoginDate { get; set; }
        public int accountCount { get; set; }
        public bool AccountOwner { get; set; }
    }
}
