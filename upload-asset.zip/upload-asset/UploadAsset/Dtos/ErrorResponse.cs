﻿using System.Text.Json.Serialization;

namespace UploadAsset.Dtos
{
    public class ErrorResponse
    {
        [JsonPropertyName("message")]
        public string Message { get; set; }

        [JsonPropertyName("code")]
        public int Code { get; set; }
    }
}
