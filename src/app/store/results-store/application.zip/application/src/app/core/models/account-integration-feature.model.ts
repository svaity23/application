export interface AccountIntegrationFeature {
    description: string;
    enabled: boolean;
    key: string;
    logo: string;
    name: string;
}