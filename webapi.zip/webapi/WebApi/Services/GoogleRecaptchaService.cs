﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Net.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Net;
using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using WebApi.Dtos;
using WebApi.Common.Constants;

namespace WebApi.Services
{
    public class GoogleRecaptchaService
    {
        private readonly ILogger<GoogleRecaptchaService> _logger;
        private readonly IConfiguration _configuration;
        private KeyVaultService _keyVaultService;

        public GoogleRecaptchaService(IConfiguration configuration, KeyVaultService keyVaultService, ILogger<GoogleRecaptchaService> logger)
        {
            _configuration = configuration;
            _logger = logger;
            _keyVaultService = keyVaultService;
        }

        public async Task<bool> ValidateRecaptchaToken(string email, string token)
        {    

            if (string.IsNullOrEmpty(token))
            {
                throw new Exception("Recaptha token not found.");
            }

            var captchaSecret = _keyVaultService.GetSecret(KeyVaultSecretKey.GoogleRecaptchaV2);

            HttpResponseMessage res;
            string validationResult;
            using (HttpClient client = new HttpClient())
            {
                var url = $"https://www.google.com/recaptcha/api/siteverify";
                var dict = new Dictionary<string, string>();
                dict.Add("secret", captchaSecret);
                dict.Add("response", token);

                res = client.PostAsync(url, new FormUrlEncodedContent(dict)).Result;
                validationResult = await res.Content.ReadAsStringAsync();
            }

            var logResult = validationResult?.Replace("\n", "");
            _logger.LogInformation($"ValidateRecapthaResponse - email {email} Content={logResult}");

            if (res.StatusCode != HttpStatusCode.OK)
            {
                return false;
            }

            JObject obj = JObject.Parse(validationResult);
            return (bool)obj["success"];
        }
    }
}
