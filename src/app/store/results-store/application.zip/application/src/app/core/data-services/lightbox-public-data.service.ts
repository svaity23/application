import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { BaseDataService } from './base-data.service';
import { LightboxAsset } from '../models/entities/lightbox-asset.model';
import { LightboxPublic } from '../models/lightbox-public.model';
import { PublicLightboxSearchResults } from '../models/public-lightbox-search-results.model';

export interface LightboxPublicDataServiceInterface {
	getAssetForPreviewById(id: string, accountId: string, lightboxId, string): Observable<LightboxAsset>;
	getLightbox(id: string, sortField: number, skip: number, pageSize: number): Observable<LightboxPublic>;
	loadMoreAssets(id: string, sortField: number, skip: number, pageSize: number): Observable<LightboxAsset[]>;
	// tslint:disable-next-line: max-line-length
	queryAssets(sortField: number, skip: number, pageSize: number, searchTerm: string, lightboxId: string): Observable<PublicLightboxSearchResults>;
}

@Injectable({ providedIn: 'root' })
export class LightboxPublicDataService extends BaseDataService implements LightboxPublicDataServiceInterface {
	
	getAssetForPreviewById(id: string, accountId: string, lightboxId: string): Observable<LightboxAsset> {    
		const params = new HttpParams()
			.set('id', id)
			.set('accountId', accountId.toString())
			.set('lightboxId', lightboxId.toString());

			const url = `${this.webApiUrl}/lightboxPublicAssets/assetPreviewDetails/`;
		return this.createAnonApiGet({ url, params });
  }

	getLightbox(id: string, sortField: number, skip: number, pageSize: number): Observable<LightboxPublic> {
		const params = new HttpParams()
			.set('id', id)
			.set('sortField', sortField.toString())
			.set('skip', skip.toString())
			.set('pageSize', pageSize.toString());

		const url = `${this.webApiUrl}/lightboxespublic`;
		return this.createAnonApiGet({ url, params });
	}

	loadMoreAssets(id: string, sortField: number, skip: number, pageSize: number): Observable<LightboxAsset[]> {
		const params = new HttpParams()
			.set('id', id)
			.set('sortField', sortField.toString())
			.set('skip', skip.toString())
			.set('pageSize', pageSize.toString());

		const url = `${this.webApiUrl}/lightboxpublicassets`;
		return this.createAnonApiGet({ url, params });
	}

	// tslint:disable-next-line: max-line-length
	queryAssets(sortField: number, skip: number, pageSize: number, searchTerm: string, lightboxId: string): Observable<PublicLightboxSearchResults> {
		const queryRequest = {
			sortField,
			skip,
			pageSize,
			searchTerm,
			lightboxId
		};
		const url = `${this.webApiUrl}/lightboxpublicassets`;
		return this.createAnonApiPost({ url, data: queryRequest });
	}
}
