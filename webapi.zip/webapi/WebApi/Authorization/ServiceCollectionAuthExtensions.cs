﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Authorization
{
    public static class ServiceCollectionAuthExtensions
    {
        public static IServiceCollection AddAuthenticationAndAuthorizationPolicies(this IServiceCollection services, IConfiguration configuration)
        {
            // disables mapping on jwt claims to microsofts defaults
            System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.DefaultMapInboundClaims = false;

            var gatherAdB2COptions = new AzureAdB2COptions();
            configuration.GetSection("GatherAdB2C").Bind(gatherAdB2COptions);

            services.AddAuthentication(options =>
            {
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, jwtOptions =>
            {
                jwtOptions.Authority = gatherAdB2COptions.Authority;
                jwtOptions.Events = new JwtBearerEvents
                {
                    OnAuthenticationFailed = AuthenticationFailed
                };

                jwtOptions.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateAudience = false, // exclude this check to support future dynamic clients. otherwise, we'd have to read db for each client(audience).
                    ValidateIssuer = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true
                };
            });

            // Register our custom policy provider and  authorization handlers
            services.AddSingleton<IAuthorizationPolicyProvider, AuthPermissionsPolicyProvider>();
            services.AddSingleton<IAuthorizationHandler, RolesAuthorizationHandler>();
            services.AddSingleton<IAuthorizationHandler, ScopesAuthorizationHandler>();

            return services;
        }


        private static Task AuthenticationFailed(AuthenticationFailedContext arg)
        {
            if (arg.Exception.GetType() == typeof(SecurityTokenExpiredException))
            {
                // additional header, should already be additional info the WWW-Authenticate header field
                arg.Response.Headers.Add("Token-Expired", "true");
            }

            // Should be removed from production code:
            //var s = $"AuthenticationFailed: {arg.Exception.Message}";
            //arg.Response.ContentLength = s.Length;
            //arg.Response.Body.WriteAsync(Encoding.UTF8.GetBytes(s), 0, s.Length);

            return Task.CompletedTask;
        }
    }
}
