import { InjectionToken } from '@angular/core';

import { CanvaConfig } from './core/models/canva/canva-config.model';
import { ChurnZeroConfig } from '@app/core/models/churn-zero-config.model';

import { DropboxConfig } from './core/models/dropbox-config.model';
import { FederatedConsentConfig } from './core/models/federated-consent-config';
import { FreeTrialConfig } from './core/models/free-trial-config.model';
import { GoogleDriveConfig } from './core/models/google-drive-config.model';
import { HubspotConfig } from './core/models/hubspot/hubspot-config.model';
import { MsalConfig } from './core/models/msal-config.model';
import { OidcClientConfig } from './core/models/oidc-client-config.model';
import { OneDriveConfig } from './core/models/onedrive.config.model';
import { SalesForceChatConfig } from './core/models/sales-force-chat-config.model';
import { SlackConfig } from './core/models/slack-config';

// eslint-disable-next-line prefer-const
export let APP_CONFIG = new InjectionToken<AppConfig>('app.config');

export interface AppConfig {
    apiDomains: string[];
    appInsights: {
        instrumentationKey: string
    }
    backgroundColor: string;
    basehref: string;
    buyNowUrl: string;
    churnZeroConfig: ChurnZeroConfig;
		downloadApiUrl: string;
    dropboxConfig: DropboxConfig;
    environment: string;
    federatedConsentConfig: FederatedConsentConfig;
    freeTrialConfig: FreeTrialConfig;
    googleDriveConfig: GoogleDriveConfig;
    hubspotConfig: HubspotConfig;
    canvaConfig: CanvaConfig;
    name: string;
    oidcConfig: OidcClientConfig;
    oneDriveConfig: OneDriveConfig;
    salesForceChatConfig: SalesForceChatConfig;
    signalRUrl: string;
    slackConfig: SlackConfig;
    uploadApiUrl: string;
    version: string;
    webApiUrl: string;
    wordpressMsalConfig: MsalConfig;
}
