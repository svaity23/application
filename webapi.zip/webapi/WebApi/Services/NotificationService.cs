﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using WebApi.Dtos;
using WebApi.Dtos.Notification;

namespace WebApi.Services
{
    public class NotificationService
    {
        private readonly ILogger<NotificationService> _logger;
        private readonly NotificationLogic _notificationLogic;
        private readonly JsonSerializerOptions _options = new JsonSerializerOptions()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };


        public NotificationService(ILogger<NotificationService> logger, damContext context)
        {
            _logger = logger;
            _notificationLogic = new NotificationLogic(context);
            _logger.LogInformation("NotificationService initialized");
        }

        public async Task<GetEntitiesResponse<NotificationDto>> GetAllNotificationsAsync(Guid accountId, Guid userId)
        {
            string resultJson = await _notificationLogic.GetAllNotificationsAsync(accountId, userId);
            GetEntitiesResponse<NotificationDto> result = JsonSerializer.Deserialize<GetEntitiesResponse<NotificationDto>>(resultJson, _options);
            return result;
        }

        public async Task<GetEntitiesResponse<Guid>> DeleteAsync
            (Guid accountId, Guid userId, Guid notificationId)
        {
            var resultJson = await _notificationLogic.DeleteAsync(accountId, userId, notificationId);
            GetEntitiesResponse<Guid> result =
                JsonSerializer.Deserialize<GetEntitiesResponse<Guid>>(
                    resultJson, _options
                );
            return result;
        }

        public async Task<GetEntitiesResponse<Guid>> MarkNotificationAsync(Guid accountId, Guid userId, MarkNotificationDTO inputData)
        {
            string jsonInput = JsonSerializer.Serialize(inputData);

            var resultJson = await _notificationLogic.MarkNotificationAsync(accountId, userId, jsonInput);
            GetEntitiesResponse<Guid> result =
                JsonSerializer.Deserialize<GetEntitiesResponse<Guid>>(
                    resultJson, _options
                );
            return result;
        }
    }

}
