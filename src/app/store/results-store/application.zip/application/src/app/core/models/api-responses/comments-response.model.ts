import { CollaborationUser } from '../collaboration-user.model';
import { CommentThread } from '../comment-thread.model';

export interface CommentsResponse {
    threads: CommentThread[];
    users: CollaborationUser[];
}
