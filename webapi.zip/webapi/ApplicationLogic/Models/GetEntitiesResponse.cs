﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace ApplicationLogic.Models
{
    /// <summary>
    /// Generic DTO used for GET requests.  
    /// The DTO allows holding the error response (code and message), 
    /// telling how the request got solved and also the entities returned as a list.
    /// </summary>
    /// <typeparam name="T">The type of returned entities</typeparam>
    public class GetEntitiesResponse<T>
    {
        [JsonPropertyName("entities")]
        public List<T> Entities { get; set; }
        
        [JsonPropertyName("error")]
        public ErrorResponse Error { get; set; }
    }
}
