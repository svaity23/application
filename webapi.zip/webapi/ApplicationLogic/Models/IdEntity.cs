﻿using System;
using System.Text.Json.Serialization;

namespace ApplicationLogic.Models
{
    public class IdEntity
    {
        [JsonPropertyName("id")]
        public Guid Id { get; set; }
    }
}
