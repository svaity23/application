﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace UploadAsset.Services
{
    public interface IOneDriveServiceFactory
    {
        OneDriveService CreateOneDriveService();
    }

    public class OneDriveServiceFactory : IOneDriveServiceFactory
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<OneDriveServiceFactory> _logger;
        private readonly ILoggerFactory _loggerFactory;
        private readonly bool _isDevelopment; 

        public OneDriveServiceFactory(IConfiguration configuration, ILogger<OneDriveServiceFactory> logger, ILoggerFactory loggerFactory, IWebHostEnvironment webHostEnvironment)
        {
            _configuration = configuration;
            _logger = logger;
            _loggerFactory = loggerFactory;
            _isDevelopment = webHostEnvironment.IsDevelopment();
        }

        public OneDriveService CreateOneDriveService()
        {
            var logger = _loggerFactory.CreateLogger<OneDriveService>();

            return new OneDriveService(_configuration, logger);
        }
    }
}
