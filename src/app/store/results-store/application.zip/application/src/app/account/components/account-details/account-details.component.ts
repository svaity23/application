import { ChangeDetectionStrategy, Component, Injector, Input, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { ControlContainer, NgForm } from '@angular/forms';
import { DatePipe } from '@angular/common';

import { AccountTypeKey } from '@app/core/enums/account-type-key.enum';
import { APP_CONFIG, AppConfig } from '@app/app-config';
import { Context } from '@app/core/models/context.model';
import { CustomTheme } from '@app/core/models/custom-theme.model';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class AccountDetailsComponent implements OnInit {
  @ViewChild('accountForm') accountForm: NgForm;
  accountType: string;
  @Input() context: Context;
  datePipe = new DatePipe('en-US');
  progress: number;
  @Input() selectedTheme: CustomTheme;
  showUpgrade = false;
  storageUsedText = '';
  trialExpirationDateString: string;
  private appSettings: AppConfig;

  constructor(private injector: Injector) {
    this.appSettings = this.injector.get(APP_CONFIG);
  }

  navToBuyNow(): void {
    window.open(this.appSettings.buyNowUrl, '_blank');
  }

  ngOnInit(): void {
    this.loadUi();
  }

  private loadUi(): void {
    const accountStorageUsedInGB = this.context.accountStorageUsed / 1073741824;
    this.storageUsedText = accountStorageUsedInGB.toFixed(2) + ' GB of ' + this.context.accountStorageMaximumGb + ' GB Used';
    this.progress = (accountStorageUsedInGB / this.context.accountStorageMaximumGb) * 100;
    this.showUpgrade = (this.context.accountTypeName === AccountTypeKey.Essential || this.context.accountTypeName === AccountTypeKey.Trial) ? true : false;

    switch (this.context.accountTypeName) {
      case AccountTypeKey.Business:
        this.accountType = 'Business';
        this.trialExpirationDateString = null;
        break;
      case AccountTypeKey.Essential:
        this.accountType = 'Essential';
        this.trialExpirationDateString = null;
        break;
      case AccountTypeKey.Evaluation:
        this.accountType = 'Free Evaluation';
        this.trialExpirationDateString = null;
        break;
      case AccountTypeKey.MCCInternal:
        this.accountType = 'MCC Internal';
        this.trialExpirationDateString = null;
        break;
      case AccountTypeKey.Team:
        this.accountType = 'Team';
        this.trialExpirationDateString = null;
        break;
      case AccountTypeKey.Trial:
        this.accountType = 'Trial';
        this.trialExpirationDateString = this.datePipe.transform(this.context.accountTrialExpiration, 'MM/d/yyyy');
        break;
      default:
    }
  }
}

