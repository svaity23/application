export interface ParagraphRun {
    color?: string;
    font?: string;
    pointSize?: number;
    text?: string;
}