export enum SignalRSource {
  UPLOAD = 'UPLOAD',
	LIBRARY = 'LIBRARY',
	ASSET = 'ASSET',
	PROVISION = 'PROVISION'
}
