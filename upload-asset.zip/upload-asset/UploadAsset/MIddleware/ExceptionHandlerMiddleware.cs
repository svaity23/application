﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;
using UploadAsset.Common;

namespace UploadAsset.Middleware
{
    public class ExceptionHandlerMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger _logger;

        public ExceptionHandlerMiddleware(RequestDelegate next, ILoggerFactory loggerFactory)
        {
            _next = next;
            _logger = loggerFactory.CreateLogger<ExceptionHandlerMiddleware>();
        }

        public async Task Invoke(HttpContext context, Health health)
        {
            try
            {
                await _next(context);
            }
            catch (Exception error)
            {
                _logger.LogError(error, "Exception: ");

                var response = context.Response;
                response.ContentType = "application/json";

                switch (error)
                {
                    case Azure.Identity.CredentialUnavailableException:
                        // cant authenticate to azure, mark container unhealthy so we can recycle in case managed identity needs a jump start
                        _logger.LogError(error, "CredentialUnavailableException.  Health.Live = false.");
                        health.Live = false;
                        response.StatusCode = (int)HttpStatusCode.InternalServerError;
                        break;
                    case Azure.Identity.AuthenticationFailedException:
                        // cant authenticate to azure, mark container unhealthy so we can recycle in case managed identity needs a jump start
                        _logger.LogError(error,"AuthenticationFailedException.  Health.Live = false.");
                        health.Live = false;

                        response.StatusCode = (int)HttpStatusCode.InternalServerError;
                        break;              
                    default:
                        // unhandled error
                        response.StatusCode = (int)HttpStatusCode.InternalServerError;
                        break;
                }

                var result = JsonSerializer.Serialize(new { message = error?.Message });
                await response.WriteAsync(result);
            }
        }
    }

    
}
