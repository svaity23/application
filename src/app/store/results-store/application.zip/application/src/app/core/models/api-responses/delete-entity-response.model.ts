export interface DeleteEntityResponse {
    error: string[]
    id: string;
}
