import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { cn } from 'src/utils/cn';

import { Context } from '@app/core/models/context.model';
import { Group } from '@app/core/models/entities/group.model';

@Component({
  selector: 'app-group-list',
  templateUrl: './group-list.component.html',
  styleUrls: ['./group-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class GroupListComponent implements OnInit, OnChanges {

  allSelected = false;
  @Input() className = '';
  @Input() context: Context;
  @Output() deleteGroupEvent = new EventEmitter<Group>();
  @Output() editGroupEvent = new EventEmitter<Group>();
  @Input() groups: Group[] = [];
  @Output() groupSelected = new EventEmitter<Group>();
  groupsToDisplay: Group[]; // we need this because we do a sort, and do not want to modify state itself
  @Output() setAllSelected = new EventEmitter<boolean>();
  show = false;
  sortField = 'name';
  sortOrder = 'desc';

  constructor() { }

  deleteGroup(group: Group): void {
    this.deleteGroupEvent.emit(group);
  }

  editGroup(group: Group): void {
    this.editGroupEvent.emit(group);
  }

  getDescription(group: Group): string {
    return (group.description) ? group.description : '';
  }

  getNameInitials(group: Group): string {
    let nameInitials ='';
    const nameParts = group?.name?.split(' ', 2);
    nameParts.forEach(str => nameInitials += str.charAt(0).toUpperCase());
    return nameInitials;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.groups) {
      this.groupsToDisplay = [...changes.groups.currentValue];
      const groupsSelected = this.groupsToDisplay.filter((item) => item.selected === true);
      this.allSelected = (this.groupsToDisplay?.length > 0 && groupsSelected?.length === this.groupsToDisplay.length) ? true : false;
      if (!changes.groups.isFirstChange()) {
        this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
        this.sort(this.sortField);
      }
    }
  }

  ngOnInit(): void {
    this.className = cn('group-list', this.className);
    this.sort('name');
  }

  selectGroup(group: Group): void {
    this.groupSelected.emit(group);
  }

  sort(columnName: string): void {
    // toggle sort order if already selected
    if (this.sortField === columnName) {
      this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortField = columnName;
      this.sortOrder = 'asc';
    }

    // setup the evalution
    const v1 = this.sortOrder === 'asc' ? 1 : -1;
    const v2 = this.sortOrder === 'asc' ? -1 : 1;


    switch (this.sortField) {
      case 'name':
        this.groupsToDisplay.sort((s1, s2) => s1.name.toLocaleLowerCase() > s2.name.toLocaleLowerCase() ? v1 : v2);
        break;
      case 'description':
        this.groupsToDisplay.sort((s1, s2) =>
          this.getDescription(s1).toLocaleLowerCase() > this.getDescription(s2).toLocaleLowerCase() ? v1 : v2);
          break;
      default:
    }
  }

  toggleAllSelected(): void {
    this.setAllSelected.emit(!this.allSelected);
  }

  toggleDropDown(): void {
    this.show = !this.show;
  }
}
