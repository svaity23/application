﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLogic.Logic
{
    public class ZapierLogic
    {
        private ZapierFinder _finder;

        public ZapierLogic(damContext context)
        {
            _finder = new ZapierFinder(context);
        }

        public async Task<string> GetZapierAssetsInfo(Guid accountId, Guid userId, string jsonParams)
        {
            return await _finder.GetZapierAssetsInfo(accountId, userId, jsonParams);
        }
    }
}
