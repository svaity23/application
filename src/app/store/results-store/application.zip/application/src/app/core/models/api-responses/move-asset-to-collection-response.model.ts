import { HubspotEntityResponse } from './hubspot-entity-response.model';
import { IdEntityResponse } from './id-entity-response.model';

export interface MoveAssetToCollectionResponse {
    assetIds: IdEntityResponse[],
    error?: string[];
    idsOnHubspot?: HubspotEntityResponse[]
    toCollectionId: string;
}
