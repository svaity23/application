﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace UploadAsset.Services
{
    public class DropboxService
    {
        private readonly ILogger<DropboxService> _logger;
        private readonly IConfiguration _configuration;
        // private DropboxClient _dropboxClient;

        public DropboxService(IConfiguration configuration, ILogger<DropboxService> logger)
        {

            _configuration = configuration;
            _logger = logger;
            // _dropboxClient = CreateClient(accessToken);
        }

        //private DropboxClient CreateClient(string accessToken)
        //{
        //    return new DropboxClient(accessToken, new DropboxClientConfig("MarcomGather"));
        //}

        public async Task<Stream> GetFileStreamAsync(string fileUrl)
        {
            return await new HttpClient().GetStreamAsync(fileUrl); ;
        }

        // Don't delete. Not used but could be used if direct link from client causes problems.
        //private async Task<string> GetDropboxFileTempUrlAsync(string fileId)
        //{
        //    IAsyncResult result = _dropboxClient.Files.BeginGetTemporaryLink(fileId, (args) => { });
        //    result.AsyncWaitHandle.WaitOne();
        //    GetTemporaryLinkResult linkResult = _dropboxClient.Files.EndGetTemporaryLink(result);

        //    return await Task.FromResult(linkResult.Link);
        //}
    }  
}