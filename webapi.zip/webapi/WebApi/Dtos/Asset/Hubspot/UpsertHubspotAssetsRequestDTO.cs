﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos.Asset.Hubspot
{
    public class UpsertHubspotAssetsRequestDTO
    {
        public Guid[] Ids { get; set; }
        public string SignalRConnectionId { get; set; }
    }
}
