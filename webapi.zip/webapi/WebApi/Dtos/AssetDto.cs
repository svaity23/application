﻿using System;

namespace WebApi.Dtos
{
    public class AssetDto
    {
        public Guid Id { get; set; }
        public string ExternalId { get; set; }
        public Guid AccountId { get; set; }
        public bool Active { get; set; }
        public AttachmentDto Attachment { get; set; }
        public DateTime Created { get; set; }
        public DateTime? Modified { get; set; }
        public DateTime? ExpireOn { get; set; }
        public string FileName { get; set; }
        public string Uri { get; set; }
        public Guid? CollectionId { get; set; }      
        public Guid? UploadSessionId { get; set; }
        public int UploadStatus { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public long? FileSize { get; set; }
        public int? FileGroup { get; set; }
        public string FileExtension { get; set; }
        public Guid? CreatedByUserId { get; set; }
        public Guid? LastModifiedByUserId { get; set; }
        public string CreatedByUserName { get; set; }
        public string ModifiedByUserName { get; set; }
        public string[] LightboxIds { get; set; }
        public bool? Favorite { get; set; }
        public bool Expired { get; set; }
        //public string Error { get; set; } // TODO - add this back in once we do a cleanup to the data so it matches the correct objects in the database and client model.

    }
}
