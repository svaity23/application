/** Custom account level metadata profiles. Used as the view model for metadata-profiles.component.ts */
export interface MetadataProfileView {
    assetCount: number;
    fieldCount: number;
    id?: string;
    metadataProfileTypeId: number;
    name: string;
}
