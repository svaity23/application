﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Dtos.Context;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class ContextController : ControllerBase
    {
        private readonly ILogger<ContextController> _logger;
        private readonly AccountService _accountService;
        private readonly UserAccountService _userAccountService;
        private readonly UserService _userService;


        public ContextController(ILogger<ContextController> logger, AccountService accountService, UserAccountService userAccountService, UserService userService)
        {
            _logger = logger;
            _accountService = accountService;
            _userAccountService = userAccountService;
            _userService = userService;
        }

        /// <summary>
        /// Get user context
        /// </summary>
        /// <remarks>
        /// Returns user and account context information
        /// </remarks>
        /// <param name="pluginName">For use with 3rd party integration</param>
        /// <returns></returns>
        [HttpGet()]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Get([FromQuery] string pluginName = "")
        {
            var isAccountIdFromHeaderValid = Guid.TryParse(HttpContext.Request.GetHeaderValue("accountId"), out Guid accountId);
            if (isAccountIdFromHeaderValid)
            {
                accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            }
            else
            {
                // sys-admin no account id
                accountId = Guid.Empty;
            }
            var userId = this.User.GetUserId();
            var sessionId = this.Request.GetB2CSessionId();
 
            // in case, the request comes from an integration plug-in (WordPress, HotSpot, etc.), 
            // the permissions to the application should be limited to viewer role
            bool asViewer = !string.IsNullOrWhiteSpace(pluginName);

            // TODO - Deserialize to DTO
            dynamic result = await _userService.GetUserContext(accountId, userId, sessionId, asViewer);
            if (result != null)
            {
                // This is needed to help serialize the sasKeys property on the context object.
                var settings = new JsonSerializerSettings();
                settings.ContractResolver = new CamelCasePropertyNamesContractResolver();

                return Ok(JsonConvert.SerializeObject(result, settings));
            }
            return NotFound();
        }

        /// <summary>
        /// Get scope access
        /// </summary>
        /// <remarks>
        /// Validate if the current user has access to the requested scope
        /// </remarks>
        /// <param name="scope"></param>
        /// <returns></returns>
        [HttpGet("scope/{scope}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> GetScopeAccess(string scope)
        {
            var userId = this.User.GetUserId();

            var hasAccess = false;
            switch(scope.ToLowerInvariant().Trim())
            {
                case "sys":
                    hasAccess = await _userService.ValidateSysAdminAccess(userId);
                    break;
                default:
                    break;
            }
         
            if (!hasAccess)
            {
                return StatusCode(StatusCodes.Status403Forbidden);
            }
           
            return Ok();
        }
        
        /// <summary>
        /// Get accounts for current user
        /// </summary>
        /// <remarks>
        /// Get accounts for current user
        /// </remarks>
        /// <returns></returns>
        [HttpGet("accounts")]
        [ApiExplorerSettings(IgnoreApi = false)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<AccountDto>))]
        public async Task<IActionResult> GetAccountsByUserId()
        {
            var userId = this.User.GetUserId();
            var results = await _accountService.GetAccountsByUserIdAsync(userId);
            // no errors or the error code is set to 0 ==> there's something into the entity list 
            var accounts = ((results?.Error?.Code == 0)) ? results.Entities : new List<AccountDto>();            
            return Ok(accounts);
        }
    }
}