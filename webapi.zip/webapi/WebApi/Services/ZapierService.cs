﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using WebApi.Dtos.Zapier;

namespace WebApi.Services
{
    public class ZapierService
    {
        private readonly JsonSerializerOptions _options = new JsonSerializerOptions()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };
        private ZapierLogic _zapierLogic;

        public ZapierService(damContext context)
        {
            _zapierLogic = new ZapierLogic(context);
        }

        /// <summary>
        /// Returns assets info for zapier, it returns all assets or the ones from a specified collection
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="userId"></param>
        /// <param name="collectionId"></param>
        /// <returns></returns>
        public async Task<GetEntitiesResponse<ZapAssetInfo>> GetAssetsInfo(Guid accountId, Guid userId, Guid? collectionId = null)
        {
            var input = new
            {
                CollectionId = collectionId
            };
            string inputJson = JsonSerializer.Serialize(input, _options);
            string resultJson = await _zapierLogic.GetZapierAssetsInfo(accountId, userId, inputJson);
            GetEntitiesResponse<ZapAssetInfo> result = JsonSerializer.Deserialize<GetEntitiesResponse<ZapAssetInfo>>(resultJson, _options);
            return result;
        }

    }
}
