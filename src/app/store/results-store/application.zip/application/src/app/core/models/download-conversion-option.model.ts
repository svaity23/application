export interface DownloadConversionOption {
	checked: boolean;
	conversionType?: number;
	footerNote: string;
	id: string;
	label: string;
	name: string;
}
