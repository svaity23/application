import { NgModule } from '@angular/core';

import { NoHostInterceptor } from './ng-no-host';
import { ContribRenderExtensionModule } from '../../core/render-extension';
import { ContribRenderInterceptModule, RENDER_INTERCEPTORS } from '../../core/render-intercept';

@NgModule({
  declarations: [],
  exports: [
    ContribRenderInterceptModule,
    ContribRenderExtensionModule,
  ],
  providers: [
    { provide: RENDER_INTERCEPTORS, multi: true, useClass: NoHostInterceptor },
  ],
})
export class AppNgNoHostModule {}
