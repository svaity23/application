﻿using Azure.Identity;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using System.Threading.Tasks;
namespace UploadAsset.Services
{
    public class BlobService
    {
        private readonly ILogger<BlobService> _logger;
        private BlobServiceClient _blobServiceClient;

        public BlobService(ILogger<BlobService> logger, BlobServiceClient blobServiceClient)
        {
            _logger = logger;
            _blobServiceClient = blobServiceClient;

            _logger.LogDebug("==========> broken debug line."); // not working. Will retest after reboot and if failed check ILoggerFactory in IBlobServiceSingleton.
        }

        public async Task<BlobClient> UploadAsync(string containerName, string blobName, Stream stream, IProgress<long> progressHandler = null)
        {
            _logger.LogDebug("BEGIN: UploadAsync");

            BlobContainerClient blobContainerClient = _blobServiceClient.GetBlobContainerClient(containerName);
            var blobClient = blobContainerClient.GetBlobClient(blobName);

            // Upload the blob.
            try
            {
                await UploadSafeAsync(blobClient, stream, progressHandler);
            }
            catch (Azure.RequestFailedException ex)
            {
                if (ex.ErrorCode != "ContainerNotFound")
                    throw;

                // make the container
                _logger.LogDebug("BEGIN: CreateIfNotExistsAsync");
                await blobContainerClient.CreateIfNotExistsAsync(PublicAccessType.None);  // if not exists in case another instance of this code beat us here (already created it)
                _logger.LogDebug("END: CreateIfNotExistsAsync");

                // get a fresh container and blob client (to avoid file corruption I've seen without doing this)
                blobContainerClient = _blobServiceClient.GetBlobContainerClient(containerName);
                blobClient = blobContainerClient.GetBlobClient(blobName);

                // upload the blob
                await UploadSafeAsync(blobClient, stream, progressHandler);
            }

            _logger.LogDebug("END: UploadAsync");
            return blobClient;
        }

        private static async Task UploadSafeAsync(BlobClient blobClient, Stream stream, IProgress<long> progressHandler)
        {
            if (progressHandler == null)
            {
                await blobClient.UploadAsync(stream, true);
            }
            else
            {
                var blobOptions = new BlobUploadOptions();
                blobOptions.ProgressHandler = progressHandler;
                await blobClient.UploadAsync(stream, blobOptions);
            }
        }

        /// <summary>
        /// Used to get the formatted container name using the accountId and default container name
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="defaultContainerName"></param>
        /// <returns>Formated container name {account-id-guid}-{containerName}</returns>
        public static string GetBlobContainerName(Guid accountId, string defaultContainerName)
        {
            return $"{accountId}-{defaultContainerName}";
        }
    }
}
