﻿using System;
using System.Text.Json.Serialization;

namespace ApplicationLogic.Models
{
    public class UpdateEntityResponse
    {
        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [JsonPropertyName("errors")]
        public ErrorResponse[] Errors { get; set; }
    }
}
