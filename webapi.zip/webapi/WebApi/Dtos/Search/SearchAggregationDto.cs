﻿using System.Collections.Generic;
using WebApi.Enums;

namespace WebApi.Dtos.Search
{
    public class SearchAggregationDto
    {
        public IEnumerable<AggregationBucketDto> Buckets { get; set; }
        public FilterGroupTypeEnum FilterGroupType { get; set; }
        public string Name { get; set; }
    }
}