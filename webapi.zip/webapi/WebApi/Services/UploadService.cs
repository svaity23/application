﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using Azure.Storage.Blobs.Models;
using Marcom.Azure.ServiceBus;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Threading.Tasks;
using WebApi.Dtos;
using WebApi.Dtos.Asset.Request;
using WebApi.Enums;
using WebApi.Extensions;

namespace WebApi.Services
{
    public class UploadService
    {
        private readonly ILogger<UploadService> _logger;
        private readonly ServiceBusService _serviceBusService;
        private readonly IConfiguration _configuration;
        private readonly AccountLogic _accountLogic;
        private readonly AssetLogic _assetLogic;
        private readonly BlobService _blobService;
        private readonly damContext _context;

        // todo consolidate into const file

        public UploadService(IConfiguration configuration, ILogger<UploadService> logger, ServiceBusService serviceBusService, BlobService blobService, damContext context)
        {
            _logger = logger;
            _serviceBusService = serviceBusService;
            _blobService = blobService;
            _configuration = configuration;
            _context = context;

            _accountLogic = new AccountLogic(_context);
            _assetLogic = new AssetLogic(_context);
        }

        public async Task CancelUploadAsync(Guid accountId, Guid uploadSessionId)
        {
            // Send cancel upload request message onto bus to have cancellation container pick it up.
            await _serviceBusService.SignalImageUploaded(new
            {
                MessageType = ServiceBusMessageType.CANCEL_UPLOAD_SESSION,
                AccountId = accountId,
                UploadSessionId = uploadSessionId.ToString(),
                StorageContainerName = _blobService.GetBlobContainerName(accountId, _configuration["BlobStorage:UploadContainerName"])
            });
        }

        /// <summary>
        /// The complexity of this method is due to the fact we need to stream LARGE file uploads. Client is passing in file and sessionId as formData.
        /// Each value appended to the form must be extracted via a stream reader.
        /// 
        /// Most of this logic was copied from website below.
        /// 
        /// TODO: More security and validation needs to be done on this method. Specifically concerning reading and storing the filename.
        /// 
        /// https://docs.microsoft.com/en-us/aspnet/core/mvc/models/file-uploads?view=aspnetcore-3.1
        /// 
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="accountId"></param>
        /// <returns></returns>
        public async Task ProcessFileUploadAsync(MultipartReader reader, Guid accountId)
        {
            var section = await reader.ReadNextSectionAsync();

            Guid assetId = Guid.Empty;
            Guid uploadSessionId = Guid.Empty;
            string signalRConnectionId = null;
            string untrustedFileName = null;
            string blobName = null;
            string source = null;
            string fileGroup = null;
            string messageType = ServiceBusMessageType.FILE_UPLOADED;
            string storageAccountName = _configuration["BlobStorage:StorageAccountName"];
            string defaultUploadContainerName = _configuration["BlobStorage:UploadContainerName"];
            string uploadDestinationContainerName = _blobService.GetBlobContainerName(accountId, defaultUploadContainerName);

            while (section != null)
            {
                var hasContentDispositionHeader = ContentDispositionHeaderValue.TryParse(section.ContentDisposition, out var contentDisposition);

                if (hasContentDispositionHeader)
                {
                    // Current content is a file. Process the file stream.
                    if (HasFileContentDisposition(contentDisposition))
                    {
                        untrustedFileName = contentDisposition.FileName.Value;

                        string uploadMsg = $@"
                            ******************************************************
                            * uploading file {untrustedFileName} at {DateTime.Now}
                            ******************************************************";
                        _logger.LogDebug(uploadMsg);

                        // Create the blob in storage.
                        blobName = GetBlobName(assetId, untrustedFileName);

                        // Upload the blob.
                        await _blobService.UploadAsync(uploadDestinationContainerName, blobName, section.Body);
                    }
                    else if (HasFormDataContentDisposition(contentDisposition))
                    {
                        var key = HeaderUtilities.RemoveQuotes(contentDisposition.Name).Value;

                        using (var streamReader = new StreamReader(section.Body, detectEncodingFromByteOrderMarks: true, bufferSize: 1024, leaveOpen: true))
                        {
                            var value = await streamReader.ReadToEndAsync();
                            if (!string.IsNullOrEmpty(value))
                            {
                                switch (key)
                                {
                                    case "uploadSessionId":
                                        uploadSessionId = Guid.Parse(value);
                                        break;
                                    case "assetId":
                                        assetId = Guid.Parse(value);
                                        break;
                                    case "signalRConnectionId":
                                        signalRConnectionId = value;
                                        break;
                                    case "fileGroup":
                                        if (value == "1") messageType = ServiceBusMessageType.VIDEO_UPLOADED;
                                        fileGroup = value;
                                        break;
                                    case "source":
                                        source = value;
                                        break;

                                }
                            }
                        }
                    }
                }

                // Drain any remaining section body that hasn't been consumed and read the headers for the next section.
                section = await reader.ReadNextSectionAsync();
            }

            // This will be picked up by cancel-upload and image-converter
            await _serviceBusService.SignalImageUploaded(new
            {
                MessageType = messageType,
                AssetId = assetId.ToString(),
                UploadSessionId = uploadSessionId.ToString(),
                AccountId = accountId,
                StorageAccountName = storageAccountName,
                BlobName = blobName,
                FileGroup = fileGroup,
                ID = Guid.NewGuid(),
                Opaque = new
                {
                    SignalRConnectionId = signalRConnectionId,
                    AssetId = assetId.ToString(),
                    Source = source,
                    AccountId = accountId
                },
                TenantInfo = new
                {
                    Account = new
                    {
                        Type = "AzureBlobStorage",
                        Details = new
                        {
                            AccountName = storageAccountName,
                            ContainerName = defaultUploadContainerName,
                            ContainerNamePrefix = accountId.ToString()
                        }
                    }
                },
                Source = new
                {
                    FileName = assetId.ToString() + Path.GetExtension(untrustedFileName).ToLowerInvariant()
                },
                Processing = new
                {
                    Tasks = GetImageConverterProcessingTasks()
                }
            });

            // This will be picked up by the signal-r-hub
            await _serviceBusService.SignalImageProcessed(new
            {
                MessageType = ServiceBusMessageType.FILE_UPLOADED,
                AssetId = assetId.ToString(),
                Opaque = new
                {
                    SignalRConnectionId = signalRConnectionId,
                    Source = source
                }
            });
        }


        public async Task UploadDropboxFile(HttpResponse response, DropboxService dropboxService, DropboxUploadRequest request, Guid accountId)
        {
            // Setting content length to 100. As in 100 bytes.
            response.ContentLength = 100;

            using (Stream contentStream = await dropboxService.GetFileStreamAsync(request.DropboxLink))
            {
                // Create a progress handler to track the progress from google to azure storage.
                var progressHandler = new BlobUploadProgressHandler(request.FileSizeBytes);
                progressHandler.ProgressHandler += async (object sender, BlobUploadProgressEventArgs e) => {
                    // This will get called everytime the upload progress gets updated.
                    // The EventArgs will let us know how many percentage points to progress.
                    // Each percentage point represents 1 byte of data that needs to be sent down to client.
                    for (var i = 0; i < e.PercentagePointsToProgress; i++)
                    {
                        byte[] progress = new byte[1] { 1 };
                        try
                        {
                            await response.Body.WriteAsync(progress);
                        }
                        catch (InvalidOperationException opEx)
                        {
                            _logger.LogWarning("Dropbox file upload progress stream exceeded 100 percent. No harm done.", opEx.Message);
                        }

                        await response.Body.FlushAsync();
                    }
                };
                await ProcessDropboxFileUploadAsync(contentStream, accountId, request, progressHandler);
            }
        }

        public async Task UploadZapierDropboxFile(DropboxService dropboxService, DropboxUploadRequest request, Guid accountId)
        {
            using (Stream contentStream = await dropboxService.GetFileStreamAsync(request.DropboxLink))
            {
                await ProcessDropboxFileUploadAsync(contentStream, accountId, request, null);
            }
        }

        public async Task UploadGoogleFile(HttpResponse response, GoogleDriveService googleDriveService, GoogleUploadRequest request, Guid accountId)
        {
            // Setting content length to 100. As in 100 bytes.
            response.ContentLength = 100;

            using (Stream contentStream = await googleDriveService.GetFileAsStreamAsync(request.GoogleFileId))
            {
                // Create a progress handler to track the progress from google to azure storage.
                var progressHandler = new BlobUploadProgressHandler(request.FileSizeBytes);
                progressHandler.ProgressHandler += async (object sender, BlobUploadProgressEventArgs e) => {
                    // This will get called everytime the upload progress gets updated.
                    // The EventArgs will let us know how many percentage points to progress.
                    // Each percentage point represents 1 byte of data that needs to be sent down to client.
                    for (var i = 0; i < e.PercentagePointsToProgress; i++)
                    {
                        byte[] progress = new byte[1] { 1 };
                        try
                        {
                            await response.Body.WriteAsync(progress);
                        }
                        catch (InvalidOperationException opEx)
                        {
                            _logger.LogWarning("Google file upload progress stream exceeded 100 percent. No harm done.", opEx.Message);
                        }

                        await response.Body.FlushAsync();
                    }
                };
                await ProcessGoogleFileUploadAsync(contentStream, accountId, request, progressHandler);
            }
        }

        public async Task UploadOneDriveFile(HttpResponse response, OneDriveService oneDriveService, OneDriveUploadRequest request, Guid accountId)
        {
            // Setting content length to 100. As in 100 bytes.
            response.ContentLength = 100;

            using (Stream contentStream = await oneDriveService.GetFileStreamAsync(request.OneDriveLink))
            {
                // Create a progress handler to track the progress from google to azure storage.
                var progressHandler = new BlobUploadProgressHandler(request.FileSizeBytes);
                progressHandler.ProgressHandler += async (object sender, BlobUploadProgressEventArgs e) => {
                    // This will get called everytime the upload progress gets updated.
                    // The EventArgs will let us know how many percentage points to progress.
                    // Each percentage point represents 1 byte of data that needs to be sent down to client.
                    for (var i = 0; i < e.PercentagePointsToProgress; i++)
                    {
                        byte[] progress = new byte[1] { 1 };
                        try
                        {
                            await response.Body.WriteAsync(progress);
                        }
                        catch (InvalidOperationException opEx)
                        {
                            _logger.LogWarning("OneDrive file upload progress stream exceeded 100 percent. No harm done.", opEx.Message);
                        }

                        await response.Body.FlushAsync();
                    }
                };
                await ProcessOneDriveFileUploadAsync(contentStream, accountId, request, progressHandler);
            }
        }

        // TODO: Consolidate all 3 file provider upload methods
        public async Task ProcessOneDriveFileUploadAsync(Stream stream, Guid accountId, OneDriveUploadRequest request, IProgress<long> progressHandler)
        {
            Guid assetId = request.AssetId;
            Guid uploadSessionId = request.UploadSessionId;
            string signalRConnectionId = request.SignalRConnectionId;
            string untrustedFileName = request.FileName;
            string source = request.Source;
            string fileGroup = request.FileGroup;
            string messageType = ServiceBusMessageType.FILE_UPLOADED;
            string storageAccountName = _configuration["BlobStorage:StorageAccountName"];
            string defaultUploadContainerName = _configuration["BlobStorage:UploadContainerName"];
            string uploadDestinationContainerName = _blobService.GetBlobContainerName(accountId, defaultUploadContainerName);

            // Create the blob in storage.
            var blobName = GetBlobName(assetId, untrustedFileName);

            // Upload the blob.
            await _blobService.UploadAsync(uploadDestinationContainerName, blobName, stream, progressHandler);

            // This will be picked up by cancel-upload and image-converter
            await _serviceBusService.SignalImageUploaded(new
            {
                MessageType = messageType,
                AssetId = assetId.ToString(),
                UploadSessionId = uploadSessionId.ToString(),
                AccountId = accountId,
                StorageAccountName = storageAccountName,
                BlobName = blobName,
                FileGroup = fileGroup,
                ID = Guid.NewGuid(),
                Opaque = new
                {
                    SignalRConnectionId = signalRConnectionId,
                    AssetId = assetId.ToString(),
                    Source = source,
                    AccountId = accountId
                },
                TenantInfo = new
                {
                    Account = new
                    {
                        Type = "AzureBlobStorage",
                        Details = new
                        {
                            AccountName = storageAccountName,
                            ContainerName = defaultUploadContainerName,
                            ContainerNamePrefix = accountId.ToString()
                        }
                    }
                },
                Source = new
                {
                    FileName = assetId.ToString() + Path.GetExtension(untrustedFileName).ToLowerInvariant()
                },
                Processing = new
                {
                    Tasks = GetImageConverterProcessingTasks()
                }
            });

            // This will be picked up by the signal-r-hub
            await _serviceBusService.SignalImageProcessed(new
            {
                MessageType = ServiceBusMessageType.FILE_UPLOADED,
                AssetId = assetId.ToString(),
                Opaque = new
                {
                    SignalRConnectionId = signalRConnectionId,
                    Source = source
                }
            });
        }

        public async Task ProcessDropboxFileUploadAsync(Stream stream, Guid accountId, DropboxUploadRequest request, IProgress<long> progressHandler)
        {
            Guid assetId = request.AssetId;
            Guid uploadSessionId = request.UploadSessionId;
            string signalRConnectionId = request.SignalRConnectionId;
            string untrustedFileName = request.FileName;
            string source = request.Source;
            string fileGroup = request.FileGroup;
            string messageType = ServiceBusMessageType.FILE_UPLOADED;
            string storageAccountName = _configuration["BlobStorage:StorageAccountName"];
            string defaultUploadContainerName = _configuration["BlobStorage:UploadContainerName"];
            string uploadDestinationContainerName = _blobService.GetBlobContainerName(accountId, defaultUploadContainerName);

            // Create the blob in storage.
            var blobName = GetBlobName(assetId, untrustedFileName);

            await _blobService.UploadAsync(uploadDestinationContainerName, blobName, stream, progressHandler);

            // This will be picked up by cancel-upload and image-converter
            await _serviceBusService.SignalImageUploaded(new
            {
                MessageType = messageType,
                AssetId = assetId.ToString(),
                UploadSessionId = uploadSessionId.ToString(),
                AccountId = accountId,
                StorageAccountName = storageAccountName,
                BlobName = blobName,
                FileGroup = fileGroup,
                ID = Guid.NewGuid(),
                Opaque = new
                {
                    SignalRConnectionId = signalRConnectionId,
                    AssetId = assetId.ToString(),
                    Source = source,
                    AccountId = accountId
                },
                TenantInfo = new
                {
                    Account = new
                    {
                        Type = "AzureBlobStorage",
                        Details = new
                        {
                            AccountName = storageAccountName,
                            ContainerName = defaultUploadContainerName,
                            ContainerNamePrefix = accountId.ToString()
                        }
                    }
                },
                Source = new
                {
                    FileName = assetId.ToString() + Path.GetExtension(untrustedFileName).ToLowerInvariant()
                },
                Processing = new
                {
                    Tasks = GetImageConverterProcessingTasks()
                }
            });

            if (progressHandler != null)
            {
                // This will be picked up by the signal-r-hub
                await _serviceBusService.SignalImageProcessed(new
                {
                    MessageType = ServiceBusMessageType.FILE_UPLOADED,
                    AssetId = assetId.ToString(),
                    Opaque = new
                    {
                        SignalRConnectionId = signalRConnectionId,
                        Source = source
                    }
                });
            }
        }

        public async Task ProcessGoogleFileUploadAsync(Stream stream, Guid accountId, GoogleUploadRequest request, IProgress<long> progressHandler)
        {
            Guid assetId = request.AssetId;
            Guid uploadSessionId = request.UploadSessionId;
            string signalRConnectionId = request.SignalRConnectionId;
            string untrustedFileName = request.FileName;
            string source = request.Source;
            string fileGroup = request.FileGroup;
            string messageType = ServiceBusMessageType.FILE_UPLOADED;
            string storageAccountName = _configuration["BlobStorage:StorageAccountName"];
            string defaultUploadContainerName = _configuration["BlobStorage:UploadContainerName"];
            string uploadDestinationContainerName = _blobService.GetBlobContainerName(accountId, defaultUploadContainerName);

            // Create the blob in storage.
            var blobName = GetBlobName(assetId, untrustedFileName);

            // Upload the blob.
            await _blobService.UploadAsync(uploadDestinationContainerName, blobName, stream, progressHandler);

            // This will be picked up by cancel-upload and image-converter
            await _serviceBusService.SignalImageUploaded(new
            {
                MessageType = messageType,
                AssetId = assetId.ToString(),
                UploadSessionId = uploadSessionId.ToString(),
                AccountId = accountId,
                StorageAccountName = storageAccountName,
                BlobName = blobName,
                FileGroup = fileGroup,
                ID = Guid.NewGuid(),
                Opaque = new
                {
                    SignalRConnectionId = signalRConnectionId,
                    AssetId = assetId.ToString(),
                    Source = source,
                    AccountId = accountId
                },
                TenantInfo = new
                {
                    Account = new
                    {
                        Type = "AzureBlobStorage",
                        Details = new
                        {
                            AccountName = storageAccountName,
                            ContainerName = defaultUploadContainerName,
                            ContainerNamePrefix = accountId.ToString()
                        }
                    }
                },
                Source = new
                {
                    FileName = assetId.ToString() + Path.GetExtension(untrustedFileName).ToLowerInvariant()
                },
                Processing = new
                {
                    Tasks = GetImageConverterProcessingTasks()
                }
            });

            // This will be picked up by the signal-r-hub
            await _serviceBusService.SignalImageProcessed(new
            {
                MessageType = ServiceBusMessageType.FILE_UPLOADED,
                AssetId = assetId.ToString(),
                Opaque = new
                {
                    SignalRConnectionId = signalRConnectionId,
                    Source = source
                }
            });
        }

        public async Task<AccountBrandUpdateResponseDto> ResetToDefaultLogo(Guid accountId, Guid userId)
        {
            string logo = "";
            var accountBrandParams = new AccountBrandParamsDto
            {
                Logo = logo
            };

            var jsonString = accountBrandParams.ToJsonString();
            var jsonResult = await _accountLogic.UpdateAccountBrandDetailsAsync(userId, accountId, jsonString);
            return JsonConvert.DeserializeObject<AccountBrandUpdateResponseDto>(jsonResult);
        }

        public async Task<AccountBrandUpdateResponseDto> ProcessLogoFileUploadAsync(MultipartReader reader, Guid accountId, Guid userId)
        {
            var section = await reader.ReadNextSectionAsync();

            string untrustedFileName = null;
            string blobName = null;
            var logoId = Guid.NewGuid();
            var account = await _accountLogic.FindByIdAsync(accountId);

            string storageAccountName = _configuration["BlobStorage:StorageAccountName"];
            string defaultBrandUploadContainerName = _configuration["BlobStorage:BrandContainerName"];
            string uploadDestinationContainerName = _blobService.GetBlobContainerName(accountId, defaultBrandUploadContainerName);

            while (section != null)
            {
                var hasContentDispositionHeader = ContentDispositionHeaderValue.TryParse(section.ContentDisposition, out var contentDisposition);

                if (hasContentDispositionHeader)
                {
                    // Current content is a file. Process the file stream.
                    if (HasFileContentDisposition(contentDisposition))
                    {
                        untrustedFileName = contentDisposition.FileName.Value;

                        string uploadMsg = $@"
                            ******************************************************
                            * uploading file {untrustedFileName} at {DateTime.Now}                      
                            ******************************************************";
                        _logger.LogDebug(uploadMsg);

                        // Create the blob in storage.
                        blobName = GetBlobName(logoId, untrustedFileName);

                        // Upload the blob. // deleting older ones will be implemented later
                        if (blobName.EndsWith(".svg"))
                        {
                            await _blobService.UploadAsync(uploadDestinationContainerName, blobName, section.Body, blobHttpHeaders: new BlobHttpHeaders { ContentType = "image/svg+xml" });
                        }
                        else
                        {
                            await _blobService.UploadAsync(uploadDestinationContainerName, blobName, section.Body);
                        }

                        //  blobClient.DeleteAsync()

                        // delete the other logos from the container

                        // update the logo name in the account table ex : 312fbb64-e8d0-41d3-97d4-28b770c067a3.png
                        string logo = blobName;
                        var accountBrandParams = new AccountBrandParamsDto
                        {
                            Logo = logo
                        };

                        var jsonString = accountBrandParams.ToJsonString();
                        var jsonResult = await _accountLogic.UpdateAccountBrandDetailsAsync(userId, accountId, jsonString);
                        if (jsonResult != null)
                        {
                            return JsonConvert.DeserializeObject<AccountBrandUpdateResponseDto>(jsonResult);
                        }
                        return null;
                    }
                }
            }
            return null;
        }

        public async Task<AccountBrandUpdateResponseDto> ResetToDefaultFavicon(Guid accountId, Guid userId)
        {
            var account = await _accountLogic.FindByIdAsync(accountId);
            string favicon = "";
            var accountBrandParams = new AccountBrandParamsDto
            {
                Favicon = favicon
            };

            var jsonString = accountBrandParams.ToJsonString();
            var jsonResult = await _accountLogic.UpdateAccountBrandDetailsAsync(userId, accountId, jsonString);
            return JsonConvert.DeserializeObject<AccountBrandUpdateResponseDto>(jsonResult);
        }

        public async Task<AccountBrandUpdateResponseDto> ProcessFaviconFileUploadAsync(MultipartReader reader, Guid accountId, Guid userId)
        {
            var section = await reader.ReadNextSectionAsync();

            string untrustedFileName = null;
            string blobName = null;
            var faviconId = Guid.NewGuid();
            var account = await _accountLogic.FindByIdAsync(accountId);

            string storageAccountName = _configuration["BlobStorage:StorageAccountName"];
            string defaultBrandUploadContainerName = _configuration["BlobStorage:BrandContainerName"];
            string uploadDestinationContainerName = _blobService.GetBlobContainerName(accountId, defaultBrandUploadContainerName);

            while (section != null)
            {
                var hasContentDispositionHeader = ContentDispositionHeaderValue.TryParse(section.ContentDisposition, out var contentDisposition);

                if (hasContentDispositionHeader)
                {
                    // Current content is a file. Process the file stream.
                    if (HasFileContentDisposition(contentDisposition))
                    {
                        untrustedFileName = contentDisposition.FileName.Value;

                        string uploadMsg = $@"
                            ******************************************************
                            * uploading file {untrustedFileName} at {DateTime.Now}                      
                            ******************************************************";
                        _logger.LogDebug(uploadMsg);

                        // Create the blob in storage.
                        blobName = GetBlobName(faviconId, untrustedFileName);

                        // Upload the blob. // deleting older ones will be implemented later

                        await _blobService.UploadAsync(uploadDestinationContainerName, blobName, section.Body, blobHttpHeaders: new BlobHttpHeaders { ContentType = "image/x-icon" });

                        //  blobClient.DeleteAsync()

                        // delete the other favicons from the container

                        // update the favicon name in the account table ex : 312fbb64-e8d0-41d3-97d4-28b770c067a3.png
                        string favicon = blobName;
                        var accountBrandParams = new AccountBrandParamsDto
                        {
                            Favicon = favicon
                        };

                        var jsonString = accountBrandParams.ToJsonString();
                        var jsonResult = await _accountLogic.UpdateAccountBrandDetailsAsync(userId, accountId, jsonString);
                        if (jsonResult != null)
                        {
                            return JsonConvert.DeserializeObject<AccountBrandUpdateResponseDto>(jsonResult);
                        }
                        return null;
                    }
                }
            }
            return null;
        }

        public async Task<AssetValidateCreateResponseDto[]> ValidateAndCreateAssets(Guid accountId, Guid userId, AssetUploadRequestDto[] assets)
        {
            var jsonString = assets.ToJsonString();
            string maxFileUploadSizeInBytes = _configuration["MaxFileUploadSizeInBytes"];
            var jsonResult = await _assetLogic.ValidateAndCreateAssets(accountId, userId, jsonString, long.Parse(maxFileUploadSizeInBytes));
            return JsonConvert.DeserializeObject<AssetValidateCreateResponseDto[]>(jsonResult);
        }

        public async Task<AssetValidateReplaceResponseDto> ValidateAndReplaceAsset(Guid accountId, Guid userId, Guid sessionId, AssetRevisionRequestDto asset, Guid oldAssetId)
        {
            string maxFileUploadSizeInBytes = _configuration["MaxFileUploadSizeInBytes"];
            var assetListParams = new ReplaceAssetDto
            {
                OldAssetId = oldAssetId,
                MaxFileUploadSizeInBytes = long.Parse(maxFileUploadSizeInBytes),
                Asset = asset
            };

            var jsonString = assetListParams.ToJsonString();
            string jsonOutput = await _assetLogic.ValidateAndReplaceAsset(accountId, userId, sessionId, jsonString);
            var newAsset = JsonConvert.DeserializeObject<AssetValidateReplaceResponseDto>(jsonOutput);

            // Wait, what happens if the validate and replace fails?
            // Why do we automatically send asset delete for index?

            await _serviceBusService.SignalIndexAsset(
                new
                {
                    MessageType = ServiceBusMessageType.ASSETS_DELETED,
                    AccountId = accountId,
                    AssetIds = new Guid[] { oldAssetId }
                });

            return newAsset;
        }

        private string GetBlobName(Guid assetId, string fileName)
        {
            var fileExt = Path.GetExtension(fileName);
            var blobName = assetId.ToString() + fileExt;
            return blobName.ToLowerInvariant();
        }

        /// <summary>
        /// Helper used to tell if current content in form is a file
        /// </summary>
        /// <param name="contentDisposition"></param>
        /// <returns></returns>
        private static bool HasFileContentDisposition(ContentDispositionHeaderValue contentDisposition)
        {
            // Content-Disposition: form-data; name="myfile1"; filename="Misc 002.jpg"
            return contentDisposition != null
                && contentDisposition.DispositionType.Equals("form-data")
                && (!string.IsNullOrEmpty(contentDisposition.FileName.Value)
                    || !string.IsNullOrEmpty(contentDisposition.FileNameStar.Value));
        }

        /// <summary>
        /// Helper used to tell if current content in form is form data
        /// </summary>
        /// <param name="contentDisposition"></param>
        /// <returns></returns>
        private static bool HasFormDataContentDisposition(ContentDispositionHeaderValue contentDisposition)
        {
            // Content-Disposition: form-data; name="key";
            return contentDisposition != null
                && contentDisposition.DispositionType.Equals("form-data")
                && string.IsNullOrEmpty(contentDisposition.FileName.Value)
                && string.IsNullOrEmpty(contentDisposition.FileNameStar.Value);
        }

        private static object[] GetImageConverterProcessingTasks()
        {
            return new[] {
                new {
                    Name = "web",
                    Destinations = new [] {
                        new {
                            Details = new {
                                ContainerName = "web"
                            }
                        }
                    }
                },
                new {
                    Name = "thumb",
                    Destinations = new [] {
                        new {
                            Details = new {
                                ContainerName = "thumbnail"
                            }
                        }
                    }
                },
                new {
                    Name = "meta",
                    Destinations = new [] {
                        new {
                            Details = new {
                                ContainerName = "metadata"
                            }
                        }
                    }
                },
                new {
                    Name = "low-res",
                    Destinations = new [] {
                        new {
                            Details = new {
                                ContainerName = "low-resolution"
                            }
                        }
                    }
                },
            };
        }
    }
}
