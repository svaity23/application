export interface OneDriveConfig {
	clientId: string,
}
