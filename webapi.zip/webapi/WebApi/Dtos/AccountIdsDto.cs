﻿using System.Text.Json.Serialization;

namespace WebApi.Dtos
{
    public class AccountIdsDto
    {
        [JsonPropertyName("ids")]
        public string Ids { get; set; }
    }
}
