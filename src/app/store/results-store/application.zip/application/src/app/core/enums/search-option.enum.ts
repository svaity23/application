export enum SearchOption {
    CurrentCollection = 0,
    AllAssets = 1,
    CurrentLightbox = 2
}
