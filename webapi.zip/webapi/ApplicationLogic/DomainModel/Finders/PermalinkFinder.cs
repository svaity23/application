﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class PermalinkFinder
    {
        public ILogger<PermalinkFinder> Logger { get; set; }

        private damContext _context;

        public PermalinkFinder(damContext context) {
            _context = context;
            Logger = NullLogger<PermalinkFinder>.Instance;
        }

        public async Task<string> SavePermalinkAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {          
            List<SqlParameter> parameters = new SpParams()
                .WithUserId(userId)
                .WithAccountId(accountId)
                .WithSessionId(sessionId)
                .WithJson(jsonInput)
                .Build();

            Logger.LogInformation(string.Format(CultureInfo.InvariantCulture, "[Finder] SavePermalink Params = \n{0}", parameters.ToString()));

            return await _context.ExecuteNonQueryJsonOutputAsync("savePermalink", parameters).ConfigureAwait(false);
        }

    }
}
