import { MetadataField } from './metadata-field.model';
import { MetadataFieldValue } from './metadata-field-value.model';
import { MetadataProfile } from './metadata-profile.model';
import { MetadataProfileType } from './metadata-profile-type.model';

export interface MetadataProfileInfo {
    metadataFields: MetadataField[];
    metadataFieldValues: MetadataFieldValue[];
    metadataProfiles: MetadataProfile[];
    metadataProfileTypes: MetadataProfileType[];
}

