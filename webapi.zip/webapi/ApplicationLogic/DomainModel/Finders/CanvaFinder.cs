﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class CanvaFinder
    {
        private damContext _context;

        public CanvaFinder(damContext context)
        {
            _context = context;
        }

        public async Task<string> DeleteCanvaUserAsync(string jsonInput)
        {
            SpParams paramList = new SpParams();
            paramList.WithJson(jsonInput);
            List<SqlParameter> sqlParmsList = paramList.Build();

            return await _context.ExecuteNonQueryJsonOutputAsync("deleteCanvaUser", sqlParmsList).ConfigureAwait(false);
        }


        public async Task<string> SaveCanvaUserAsync(Guid accountId, string jsonInput)
        {
            return await ExecuteAsync("saveCanvaLoggedInUser", accountId, jsonInput);
        }

        public async Task<string> GetAssetsAsync(string jsonInput)
        {
            SpParams paramList = new SpParams();
            paramList.WithJson(jsonInput);
            List<SqlParameter> sqlParmsList = paramList.Build();
            
            return await _context.ExecuteNonQueryJsonOutputAsync("getCanvaAssets", sqlParmsList).ConfigureAwait(false);
        }

        private async Task<string> ExecuteAsync(string procedure, Guid accountId, string json = null)
        {
            SpParams paramList = new SpParams();
            paramList.WithAccountId(accountId);
            if (json != null) paramList.WithJson(json);

            List<SqlParameter> sqlParmsList = paramList.Build();
            return await _context.ExecuteNonQueryJsonOutputAsync(procedure, sqlParmsList).ConfigureAwait(false);
        }

    }
}
