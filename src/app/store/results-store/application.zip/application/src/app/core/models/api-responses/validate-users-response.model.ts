import { User } from '../entities/user.model';

export interface ValidateUsersResponse {
  errors: string[],
  users: User[],
  warnings: string[]
}
