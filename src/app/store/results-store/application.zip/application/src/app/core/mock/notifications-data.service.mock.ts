import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { Notification } from '../models/notification.model';
import { NotificationsDataServiceInterface } from '../data-services/notifications-data.service';

@Injectable({ providedIn: 'root' })
export class NotificationsDataServiceMock implements NotificationsDataServiceInterface {
    private internalNotificationsList: Notification[] = [];

    constructor() {
        this.internalNotificationsList = [];
    }

    delete(id: string): Observable<string[]> {
        return new Observable(observer => {
            const index = this.internalNotificationsList.findIndex(notification => notification.id === id);
            this.internalNotificationsList.splice(index, 1);
            // clone this internal list because store-freeze will make it immutable later in the dispatch pipeline
            const clone = JSON.parse(JSON.stringify(this.internalNotificationsList));

            // Yield a single value and complete
            observer.next(clone);
            observer.complete();
        });
    }

    getAllNotifications(): Observable<Notification[]> {
        return new Observable(observer => {
            // clone this internal list because store-freeze will make it immutable later in the dispatch pipeline
            const clone = JSON.parse(JSON.stringify(this.internalNotificationsList));

            // Yield a single value and complete
            observer.next(clone);
            observer.complete();
        });
     }

    markNotifications(ids: string[], read: boolean): Observable<string[]> {
        return new Observable(observer => {
            this.internalNotificationsList.forEach(notification => {
              if (ids.indexOf(notification.id) !== -1) {
                notification.read = read;
              }
            })
            // clone this internal list because store-freeze will make it immutable later in the dispatch pipeline
            const clone = JSON.parse(JSON.stringify(this.internalNotificationsList));

            // Yield a single value and complete
            observer.next(clone);
            observer.complete();
        });
    }
}
