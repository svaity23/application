﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using System.Text.Json;
using System.Net;
using System.Net.Http;
using System;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AllowAnonymous]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class SignUpController : Controller
    {
        private readonly ILogger<SignUpController> _logger;
        private readonly AccountService _accountService;
        private readonly UserService _userService;
        private readonly GoogleRecaptchaService _recaptchaService;

        public SignUpController(ILogger<SignUpController> logger, AccountService accountService, GoogleRecaptchaService recaptchaService, UserService userService)
        {
            _logger = logger;
            _accountService = accountService;
            _recaptchaService = recaptchaService;
            _userService = userService;
        }

        [HttpPost("federation")]
        public async Task<IActionResult> FederationAllowed([FromBody] JsonElement request)
        {
            string upn = "";
            string email = "";
            JsonElement upnJson;
            JsonElement emailJson;

            if (request.TryGetProperty("Upn", out upnJson))
            {
                upn = upnJson.GetString();
            }

            if (request.TryGetProperty("Email", out emailJson))
            {
                email = emailJson.GetString();
            }

            try
            {
                _logger.LogInformation($"ValidateFederationAllowed - params: upn={upn} email={email}");

                if (string.IsNullOrWhiteSpace(email))
                {
                    _logger.LogInformation($"ValidateFederationAllowed: GATHERFA404E Email is missing for federated user with upn {upn}.");
                    return StatusCode((int)HttpStatusCode.Conflict, new { version = "1.0.0", status = (int)HttpStatusCode.Conflict, userMessage = "GATHERFA404E Email is missing for federated user.", FederationVerified = false });
                }

                var federatedEmail = string.IsNullOrWhiteSpace(upn) ? email : upn;

                var account = await _accountService.GetFederateAdAccountByEmailAsync(federatedEmail);

                if (account != null && account.Id != Guid.Empty)
                {
                    _logger.LogInformation($"ValidateFederationAllowed: Federation account verified for {federatedEmail}");
                    return StatusCode((int)HttpStatusCode.OK, new { version = "1.0.0", status = (int)HttpStatusCode.OK, userMessage = "Federation account verified.", FederationVerified = true });

                }
                else
                {
                    _logger.LogInformation($"ValidateFederationAllowed: GATHERFA404 Federation account missing for {federatedEmail}");
                    return StatusCode((int)HttpStatusCode.Conflict, new { version = "1.0.0", status = (int)HttpStatusCode.Conflict, userMessage = "GATHERFA404 Federation account missing.", FederationVerified = false });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"ValidateFederationAllowed - GATHERFA400 Error validating {upn}.");
                return StatusCode((int)HttpStatusCode.Conflict, new { version = "1.0.0", status = (int)HttpStatusCode.Conflict, userMessage = $"GATHERFA400 {ex.Message}", FederationVerified = false });
            }
        }

        [HttpPost("company-verification")]
        public async Task<IActionResult> CompanyAllowed([FromBody] JsonElement request)
        {
            string company = "";
            JsonElement companyJson;
            string email = "";
            JsonElement emailJson;

            if (request.TryGetProperty("Company", out companyJson))
            {
                company = companyJson.GetString();
            }

            if (request.TryGetProperty("Email", out emailJson))
            {
                email = emailJson.GetString();
            }

            try
            {
                _logger.LogInformation($"CompanyAllowed - params: company={company} email={email}");

                string message;

                if (string.IsNullOrWhiteSpace(company))
                {
                    message = "GATHERVC404 Company name is missing in the request.";
                    _logger.LogInformation("CompanyAllowed: " + message + " User {email}.");
                    return StatusCode((int)HttpStatusCode.Conflict, new { version = "1.0.0", status = (int)HttpStatusCode.Conflict, userMessage = message, CompanyVerified = false });
                }

                var account = await _accountService.GetAccountByNameAsync(company);

                if (account != null && account.Id != Guid.Empty)
                {
                    message = "An account already exists with your company name. Please chat with us for assistance.";
                    _logger.LogInformation($"CompanyAllowed: Duplicate company name found {company} user {email}");
                    return StatusCode((int)HttpStatusCode.Conflict, new { version = "1.0.0", status = (int)HttpStatusCode.Conflict, userMessage = message, CompanyVerified = false });                    
                }
                else
                {
                    _logger.LogInformation($"CompanyAllowed: Company name verified for {company} user {email}");
                    return StatusCode((int)HttpStatusCode.OK, new { version = "1.0.0", status = (int)HttpStatusCode.OK, userMessage = "Company name verified.", CompanyVerified = true });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"CompanyAllowed - Exception occurred for {company} user {email}. {ex.Message}.");
                return StatusCode((int)HttpStatusCode.Conflict, new { version = "1.0.0", status = (int)HttpStatusCode.Conflict, userMessage = "Error has occurred. Please try again.", CompanyVerified = false });
            }
        }

        [HttpPost("google-recaptcha")]
        public async Task<IActionResult> GoogleRecapthaValidation([FromBody] JsonElement request)
        {
            string token = "";
            JsonElement tokenJson;
            string email = "";
            JsonElement emailJson;

            if (request.TryGetProperty("ResponseToken", out tokenJson))
            {
                token = tokenJson.GetString();
            }

            if (request.TryGetProperty("Email", out emailJson))
            {
                email = emailJson.GetString();
            }

            string message;

            try
            {
                _logger.LogInformation($"GoogleRecapthaValidation - params: email={email} recaptcha={token}");

                
                if (string.IsNullOrWhiteSpace(token))
                {
                    message = "Captcha API failed.";
                    _logger.LogInformation($"GoogleRecapthaValidation: {message} for user {email}.");
                    return StatusCode((int)HttpStatusCode.BadRequest, new { version = "1.0.0", status = (int)HttpStatusCode.BadRequest, userMessage = message });
                }

                var success = await _recaptchaService.ValidateRecaptchaToken(email, token);

                if (!success)
                {
                    message = "Recaptcha failed, please retry";
                    _logger.LogInformation($"GoogleRecapthaValidation: {message} for user {email}.");
                    return StatusCode((int)HttpStatusCode.Conflict, new { version = "1.0.0", status = (int)HttpStatusCode.Conflict, userMessage = message });
                }
                else
                {
                    _logger.LogInformation($"GoogleRecapthaValidation: Recaptcha validation passed for user {email}");
                    return StatusCode((int)HttpStatusCode.OK, new { version = "1.0.0", status = (int)HttpStatusCode.OK, userMessage = "Recaptcha validation passed." });
                }
            }
            catch (Exception ex)
            {
                message = "Captcha API failed.";
                _logger.LogInformation($"GoogleRecapthaValidation: {message} for user {email} {ex.Message}.");
                return StatusCode((int)HttpStatusCode.BadRequest, new { version = "1.0.0", status = (int)HttpStatusCode.BadRequest, userMessage = message });
            }
        }

        [HttpPost("email-verification")]
        public async Task<IActionResult> SaveUserEmailVerification([FromBody] JsonElement request)
        {
            string idpId = "";
            JsonElement idpIdJson;

            string email = "";
            JsonElement emailJson;

            if (request.TryGetProperty("IdpId", out idpIdJson))
            {
                idpId = idpIdJson.GetString();
            }

            if (request.TryGetProperty("Email", out emailJson))
            {
                email = emailJson.GetString();
            }

            try
            {
                _logger.LogInformation($"SaveUserEmailVerification - params: idpId={idpId} email={email}");

                string message;

                if (string.IsNullOrWhiteSpace(idpId))
                {
                    message = "GATHERVE404 Idp Id is missing in the request.";
                    _logger.LogInformation("SaveUserEmailVerification: " + message + $" user {email}.");
                    return StatusCode((int)HttpStatusCode.Conflict, new { version = "1.0.0", status = (int)HttpStatusCode.Conflict, userMessage = message, EmailVerified = false });
                }

                if(string.IsNullOrWhiteSpace(email))
                {
                    message = "GATHERVE404 Email is missing in the request.";
                    _logger.LogInformation("SaveUserEmailVerification: " + message + $" idpId {idpId}.");
                    return StatusCode((int)HttpStatusCode.Conflict, new { version = "1.0.0", status = (int)HttpStatusCode.Conflict, userMessage = message, EmailVerified = false });
                }

                var result = await _userService.SaveUserEmailVerification(idpId, email).ConfigureAwait(false);

                if (result > 0)
                {
                    _logger.LogInformation($"SaveUserEmailVerification: Email verified for idpId {idpId} user {email}");
                    return StatusCode((int)HttpStatusCode.OK, new { version = "1.0.0", status = (int)HttpStatusCode.OK, userMessage = "User email verified.", EmailVerified = true });                    
                }
                else
                {
                    message = "Cannot verify user email. Error GATHERVE401.";
                    _logger.LogInformation("SaveUserEmailVerification: " + message + $" idpId {idpId} user {email}.");
                    return StatusCode((int)HttpStatusCode.Conflict, new { version = "1.0.0", status = (int)HttpStatusCode.Conflict, userMessage = message, EmailVerified = false });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"SaveUserEmailVerification - Exception occurred for idpId {idpId} user {email}. {ex.Message}.");
                return StatusCode((int)HttpStatusCode.Conflict, new { version = "1.0.0", status = (int)HttpStatusCode.Conflict, userMessage = "Error has occurred. Please try again. Error GATHERVE400.", EmailVerified = false });
            }
        }
    }
}
