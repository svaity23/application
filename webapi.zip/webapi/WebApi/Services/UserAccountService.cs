﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Dtos;

namespace WebApi.Services
{
    public class UserAccountService
    {
        private readonly ILogger<UserAccountService> _logger;
        private UserLogic _userLogic;
      
        public UserAccountService(ILogger<UserAccountService> logger, damContext context)
        {
            _logger = logger;
            _userLogic = new UserLogic(context);
        }

       public async Task<Guid[]> GetAccountIdsByUserIdAsync(Guid userId)
        {
            var jsonOutput = await _userLogic.GetAccountIdsByUserIdAsync(userId);
            var accountIdsDto = JsonConvert.DeserializeObject<AccountIdsDto>(jsonOutput);
            if(accountIdsDto != null && !string.IsNullOrEmpty(accountIdsDto.Ids))
            {
                var accountIdsList = accountIdsDto.Ids.Split(',').ToList();
                return accountIdsList.Select(i => Guid.Parse(i)).ToArray();
            }

            return null;
        }
    }
}
