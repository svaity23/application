﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Threading.Tasks;

namespace ApplicationLogic.Logic
{
    public class IntegrationLogic
    {
        public ILogger<IntegrationLogic> Logger { get; set; }
        
        private readonly IntegrationFinder _finder;

        public IntegrationLogic(damContext context) {
            _finder = new IntegrationFinder(context);
            Logger = NullLogger<IntegrationLogic>.Instance;
        }
        
        public async Task<string> GetIntegrationSettingsByAccountIdAsync(Guid userId)
        {
            return await _finder.GetIntegrationSettingsByAccountIdAsync(userId);
        }
    }
}
