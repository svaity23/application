import { Collection } from '../entities/collection.model';

export interface RenameModalOptions {
  collectionInfo: {collections: Collection[], selectedCollection: Collection};
  confirm: (collection: Collection) => void;
  confirmButtonText: string;
  deny: () => void;
  denyButtonText: string;
  title: string;
}
