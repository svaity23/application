import { NotificationAsset } from './notification-asset.model';
import { NotificationAuthor } from './notification-author.model';

export interface NotificationComment {
    asset: NotificationAsset;
    author: NotificationAuthor;
    comment: string;
    id: string;
    threadId?: number;
}
