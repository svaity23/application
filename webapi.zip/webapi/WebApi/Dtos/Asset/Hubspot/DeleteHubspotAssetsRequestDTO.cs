﻿using System;

namespace WebApi.Dtos.Asset.Hubspot
{
    public class DeleteHubspotAssetsRequestDTO
    {
        public Guid[] Ids { get; set; }
        public string SignalRConnectionId { get; set; }
    }
}
