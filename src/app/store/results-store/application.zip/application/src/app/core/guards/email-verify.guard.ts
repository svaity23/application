import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { OidcFacade } from 'ng-oidc-client';

import { filter, first, map, switchMap, take, tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

import { AccountTypeKey } from '@app/core/enums/account-type-key.enum';
import { AppStoreFacade } from '@app/store/app-store/app-store.facade';

@Injectable({
  providedIn: 'root'
})
export class EmailVerifyGuard implements CanActivate {

  accountTypeKeyEnum = AccountTypeKey;

  constructor(private appStoreFacade: AppStoreFacade, private oidcFacade: OidcFacade, private router: Router) { }

  canActivate(
    // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
    _route: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
    _state: RouterStateSnapshot,
    ): Observable<boolean | UrlTree>  {

      return this.oidcFacade.waitForAuthenticationLoaded().pipe(
        switchMap(() => {
          return this.isUserEmailVerified();
        })
      );
  }

  private isContextEmailVerified(): Observable<boolean> {
    return this.appStoreFacade.context.context$.pipe(
      tap(context => {
        if (!context) {
          this.appStoreFacade.loadContext();
        }
      }),
      filter(context => context != null),
      first(),
      map(context => context.emailVerified === true)
    );
  }

  private isUserEmailVerified(): Observable<boolean | UrlTree> {
    return this.oidcFacade.identity$.pipe(
      take(1),
      switchMap((user) => {
        // check that user email is verified in claims
        if (user && !user.expired) {
          // check that user email in db is verified, adb2c updates the flag directly
          return this.isContextEmailVerified().pipe(
            map((isVerified: boolean) =>  isVerified ? true : this.router.parseUrl('/email-verification-error'))
          );
        } else {
          // go to library and it will initiate sign in
          return of(this.router.parseUrl('/library'));
        }
      })
    );
  }
}
