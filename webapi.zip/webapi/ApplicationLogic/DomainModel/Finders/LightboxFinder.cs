﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class LightboxFinder
    {
        private readonly ILogger<LightboxFinder> _logger;
        private readonly damContext _context;
        private const string LightboxIdParam = "@lightboxId";

        public LightboxFinder(damContext context)
        {
            _context = context;
            _logger = NullLogger<LightboxFinder>.Instance;
        }

        public async Task<string> DeleteAsync(Guid accountId, Guid userId, string json)
        {
            // deleteLightboxById
            _logger.LogInformation($"[Finder] Deletes one or multiple lightboxes for" +
                $"\n\taccount = {accountId}" +
                $"\n\tuser = {userId}" +
                $"\n\tid:\n{json}");

            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithJson(json)
                .Build();

            _logger.LogInformation(string.Format(CultureInfo.InvariantCulture, "[Finder] DeleteAsync Params = \n{0}", parameters.ToString()));

            return await _context.ExecuteNonQueryJsonOutputAsync("deleteLightboxes", parameters).ConfigureAwait(false);            
        }

        public async Task<string> DeleteByIdAsync(Guid accountId, Guid userId, Guid id)
        {
            // deleteLightboxById
            _logger.LogInformation($"[Finder] Deleting lightbox for " +
                $"\n\taccount = {accountId}" +
                $"\n\tuser = {userId}" +
                $"\n\tid:\n{id}");

            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithGuid("lightboxId", id)
                .Build();

            _logger.LogInformation(string.Format(CultureInfo.InvariantCulture, "[Finder] DeleteByIdAsync Params = \n{0}", parameters.ToString()));

            return await _context.ExecuteNonQueryJsonOutputAsync("deleteLightboxById", parameters).ConfigureAwait(false);
        }

        public async Task<string> GetAllAsync(Guid accountId, Guid userId)
        {
            _logger.LogInformation($"[Finder] Getting all lightboxes for" +
                $"\n\taccount = {accountId}" +
                $"\n\tuser = {userId}");
            string jsonInput = "{ \"lightboxId\" : \"" + Guid.Empty + "\"}";

            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithJson(jsonInput)
                .Build();

            _logger.LogInformation(string.Format(CultureInfo.InvariantCulture, "[Finder] GetAllAsync Params = \n{0}", parameters.ToString()));

            return await _context.ExecuteNonQueryJsonOutputAsync("getLightboxes", parameters).ConfigureAwait(false);
        }

        public async Task<string> GetPreviewAssetsAsync(Guid accountId, Guid userId)
        {
            _logger.LogInformation($"[Finder] Getting preview assets for all lightboxes on" +
                $"\n\taccount = {accountId}" +
                $"\n\tuser = {userId}");
            string jsonInput = "{ \"lightboxId\" : \"" + Guid.Empty + "\"}";

            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .Build();

            _logger.LogInformation(string.Format(CultureInfo.InvariantCulture, "[Finder] GetPreviewAssetsAsync Params = \n{0}", parameters.ToString()));

            return await _context.ExecuteNonQueryJsonOutputAsync("getLightboxPreviewAssets", parameters).ConfigureAwait(false);
        }


        public async Task<string> UpsertLightboxAsync(Guid accountId, Guid userId, string jsonInput)
        {
            if (jsonInput == null) return null;

            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithJson(jsonInput)
                .Build();

            _logger.LogInformation(string.Format(CultureInfo.InvariantCulture, "[Finder] UpsertLightboxAsync Params = \n{0}", parameters.ToString()));

            return await _context.ExecuteNonQueryJsonOutputAsync("upsertLightbox", parameters).ConfigureAwait(false);
        }

        public async Task<string> GetByIdAsync(Guid accountId, Guid userId, Guid id)
        {
            _logger.LogInformation($"[Finder] Getting all lightboxes for" +
                $"\n\taccount = {accountId}" +
                $"\n\tuser = {userId}" +
                $"\n\tid:\n{id}");

            string jsonInput = "{ \"lightboxId\" : \"" + id + "\"}";

            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithJson(jsonInput)
                .Build();

            _logger.LogInformation(string.Format(CultureInfo.InvariantCulture, "[Finder] GetByIdAsync Params = \n{0}", parameters.ToString()));

            return await _context.ExecuteNonQueryJsonOutputAsync("getLightboxes", parameters).ConfigureAwait(false);            
        }

        public async Task<string> GetByIdAsync(Guid id)
        {
            List<SqlParameter> paramList = new List<SqlParameter>();

            SqlParameter lightboxIdParam = new SqlParameter(LightboxIdParam, SqlDbType.UniqueIdentifier);
            lightboxIdParam.Value = id;

            paramList.Add(lightboxIdParam);

            return await _context.ExecuteNonQueryJsonOutputAsync("getLightboxById", paramList);
        }
    }
}

