import { ChangeDetectionStrategy, Component, EventEmitter, HostBinding, Input, Output, ViewEncapsulation } from '@angular/core';

import { AccountTypeKey } from '@app/core/enums/account-type-key.enum';

@Component({
  selector: 'app-account-sidebar',
  templateUrl: './account-sidebar.component.html',
  styleUrls: ['./account-sidebar.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountSidebarComponent  {
  accountTypeKeyEnum = AccountTypeKey;
  @Input() accountTypeName: string;
  @Input() activeSideMenu = '';
  @Output() navigateToEvent = new EventEmitter<string>();
  @HostBinding('attr.ngNoHost') noHost = '';
  @Input() showIntegrations = false;
  @Input() showUserGroups = false;

  constructor() { }

  menuClick(pageName: string): void {
    this.navigateToEvent.emit(pageName);
  }
}
