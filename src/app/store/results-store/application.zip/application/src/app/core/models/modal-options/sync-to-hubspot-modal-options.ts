import { Asset } from '../entities/asset.model';
import { CustomTheme } from '../custom-theme.model';

export interface SyncToHubspotModalOptions {
  fileNames: string[];
  message: string;
  selectedTheme?: CustomTheme;
  title: string;
  validAssets: Asset[];
}