﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLogic.Logic
{
    public class UserLogic
    {
        public ILogger<UserLogic> Logger { get; set; }
        
        private readonly UserFinder _finder;

        public UserLogic(damContext context) {
            _finder = new UserFinder(context);
            Logger = NullLogger<UserLogic>.Instance;
            // TODO - create logic for _finder
            //_finder.Logger = 
        }
                
        public async Task<string> DeleteUsersAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            return await _finder.DeleteUsersAsync(accountId, userId, sessionId, jsonInput);
        }
        public async Task<string> CreateUserAsync(Guid userId, Guid sessionId, string jsonInput)
        {
            return await _finder.CreateAsync(userId, sessionId, jsonInput);
        }

        public async Task<string> GetByAccountIdAsync(Guid accountId, bool includeInactive = false)
        {
            Logger.LogInformation($"[Logic] Getting users for account = {accountId}");
            return await _finder.GetByAccountIdAsync(accountId, includeInactive);
        }

        public async Task<string> GetByIdAndAccountIdAsync(Guid userId, Guid accountId)
        {
            return await _finder.GetByIdAndAccountIdAsync(userId, accountId);
        }

        public async Task<string> GetByAccountIdAndEmailAsync(Guid accountId, string email)
        {
            return await _finder.GetByAccountIdAndEmailAsync(accountId, email);
        }
        public async Task<User> GetUserByEmailAsync(string email)
        {
            return await _finder.GetByEmailAsync(email);
        }

        public async Task<User> GetUserByIdAsync(Guid id)
        {
            return await _finder.GetByIdAsync(id);
        }

        public async Task<string> AssignGroupToUsers(Guid accountId, Guid userId, string jsonInput)
        {
            return await _finder.AssignGroupToUsers(accountId, userId, jsonInput);
        }

        public async Task<User> GetUserByIdpIdAsync(string idpId)
        {
            return await _finder.GetByIdpIdAsync(idpId);
        }

        public async Task<string> GetUserContext(Guid accountId, Guid userId, bool asViewer)
        {
            return await _finder.GetUserContext(accountId, userId, asViewer);
        }

        public async Task<int> SaveUserEmailVerification(Guid accountId, Guid userId, Guid sessionId)
        {
            return await _finder.SaveUserEmailVerification(accountId, userId, sessionId);
        }

        public async Task<int> SaveUserEmailVerification(string idpId, string email)
        {
            return await _finder.SaveUserEmailVerification(idpId, email);
        }

        public async Task<string> ValidateEmailAsync(string email, Guid accountId, string firstName, string lastName, bool federated, Guid? userId)
        {
            return await _finder.ValidateEmailAsync(email, accountId, firstName, lastName, federated, userId);
        }

        public async Task<string> UpdateUserAsync(Guid userId, Guid accountId, Guid sessionId, string jsonInput)
        {
            return await _finder.UpdateAsync(userId, accountId, sessionId, jsonInput);
        }

        public async Task<string> CreateUserLogoutAsync(Guid userId, Guid? accountId, Guid sessionId)
        {
            return await _finder.CreateUserLogoutAsync(userId, accountId, sessionId);
        }

        public async Task<string> CreateUserLoginAsync(Guid userId, Guid? accountId, Guid sessionId)
        {
            return await _finder.CreateUserLoginAsync(userId, accountId, sessionId);
        }

        public async Task<string> GetAccountIdsByUserIdAsync(Guid userId)
        {
            return await _finder.GetAccountIdsByUserIdAsync(userId);
        }

        public async Task<string> ValidateBulkAsync(string jsonUsers, Guid accountId)
        {
            return await _finder.ValidateBulkAsync(jsonUsers, accountId);
        }

        public async Task<string> CreateBulkAsync(Guid accountId, Guid byUserId, Guid sessionId, string jsonInput)
        {
            return await _finder.CreateBulkAsync(accountId, byUserId, sessionId, jsonInput);
        }
    }
}
