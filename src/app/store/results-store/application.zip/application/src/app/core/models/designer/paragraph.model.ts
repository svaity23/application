import { ParagraphRun } from './paragraph-run.model';

export interface Paragraph {
    alignment: string;
    leading: number;
    lineSpacing: number;
    runs: ParagraphRun[];
}