import { ChangeDetectionStrategy, Component, EventEmitter, HostBinding, Input, OnChanges, OnInit, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';

import { Context } from '@app/core/models/context.model';
import { User } from '@app/core/models/entities/user.model';

@Component({
  selector: 'app-user-details-header',
  templateUrl: './user-details-header.component.html',
  styleUrls: ['./user-details-header.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush

})
export class UserDetailsHeaderComponent implements OnInit, OnChanges {

  allUsersButtonText: string;
  @Input() className = '';
  @Input() context: Context;
  @Input() invalidUserEmailMessage: string;
  @Input() isDisabled = true;
  @Input() isUserFormTouched: boolean;
  @Output() navigateAllUsersEvent = new EventEmitter();
  @HostBinding('attr.ngNoHost') noHost = '';
  @Output() openInvalidUserEmailMessage = new EventEmitter<string>();
  @Output() openResendEmailMessage = new EventEmitter();
  @Input() searchText: string;
  @Input() user: User;
  @Output() userChangeEvent = new EventEmitter<User>();
  userName: string;

  constructor() { }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.user) {
      this.userName = (changes.user.currentValue != null) ? (changes.user.currentValue.firstName + ' ' + changes.user.currentValue.lastName) : '';
    }
  }

  ngOnInit(): void {
    this.allUsersButtonText = this.searchText ? `Back to Search Results for "${this.searchText}"` : 'All Users';
  }

  resendClicked(): void {
    this.openResendEmailMessage.emit(this.user);
  }

  saveChanges(): void {
    if (this.invalidUserEmailMessage) {
      this.openInvalidUserEmailMessage.emit(this.invalidUserEmailMessage);
    }
    else {
      this.userChangeEvent.emit(this.user);
    }
  }
}
