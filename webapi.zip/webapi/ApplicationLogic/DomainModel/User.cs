﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ApplicationLogic.DomainModel
{
    [Table("user")]
    [Index(nameof(RoleId), nameof(Active), Name = "ix_user_roleId")]
    [Index(nameof(Email), Name = "uniq_user_email", IsUnique = true)]
    public partial class User
    {
        public User()
        {
            AssetCreatedByNavigation = new HashSet<Asset>();
            AssetLastModifiedByNavigation = new HashSet<Asset>();
            Setting = new HashSet<Setting>();
            UserLegal = new HashSet<UserLegal>();
        }

        [Key]
        [Column("id")]
        public Guid Id { get; set; }
        [Column("externalId")]
        [StringLength(64)]
        public string ExternalId { get; set; }
        [Column("idpId")]
        [StringLength(64)]
        public string IdpId { get; set; }
        [Column("accountId")]
        public Guid? AccountId { get; set; }
        [Column("active")]
        public bool Active { get; set; }
        [Column("created")]
        public DateTime Created { get; set; }
        [Column("modified")]
        public DateTime? Modified { get; set; }
        [Column("roleId")]
        public Guid? RoleId { get; set; }
        [Required]
        [Column("firstName")]
        [StringLength(64)]
        public string FirstName { get; set; }
        [Column("lastName")]
        [StringLength(64)]
        public string LastName { get; set; }
        [Required]
        [Column("email")]
        [StringLength(128)]
        public string Email { get; set; }
        [Column("salesforceId")]
        [StringLength(64)]
        public string SalesforceId { get; set; }
        [Column("groupId")]
        public Guid? GroupId { get; set; }

        [ForeignKey(nameof(AccountId))]
        [InverseProperty("User")]
        public virtual Account Account { get; set; }
        [ForeignKey(nameof(RoleId))]
        [InverseProperty("User")]
        public virtual Role Role { get; set; }
        [InverseProperty(nameof(Asset.CreatedByNavigation))]
        public virtual ICollection<Asset> AssetCreatedByNavigation { get; set; }
        [InverseProperty(nameof(Asset.LastModifiedByNavigation))]
        public virtual ICollection<Asset> AssetLastModifiedByNavigation { get; set; }
        [InverseProperty("UserIdCriteriaNavigation")]
        public virtual ICollection<Setting> Setting { get; set; }
        [InverseProperty("User")]
        public virtual ICollection<UserLegal> UserLegal { get; set; }
    }
}
