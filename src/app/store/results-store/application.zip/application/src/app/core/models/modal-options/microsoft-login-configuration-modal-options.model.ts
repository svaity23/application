import { Context } from '@app/core/models/context.model';

import { CustomTheme } from '../custom-theme.model';

export interface MicrosoftLoginConfigurationModalOptions {
  context?: Context;
  federatedDomain?: string;
  selectedTheme?: CustomTheme;
  title: string;
  redirectToMicrosoftLogin: (claims: Map<string, string>) => void;
  removeFederatedDomain: (id: string) => void;
}
