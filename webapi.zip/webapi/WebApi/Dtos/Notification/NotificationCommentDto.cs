﻿using System;

namespace WebApi.Dtos.Notification
{
    public class NotificationCommentDto
    {
        public Guid Id { get; set; }
        public NotificationAuthorDto Author { get; set; }
        public int ThreadId { get; set; }
        public string Comment { get; set; }
        public NotificationAssetDto Asset { get; set; }
    }
}
