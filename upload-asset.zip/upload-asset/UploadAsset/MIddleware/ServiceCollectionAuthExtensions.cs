﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UploadAsset.Middleware
{
    public static class ServiceCollectionAuthExtensions
    {
        public static IServiceCollection AddAuthenticationAndAuthorizationPolicies(this IServiceCollection services, IConfiguration configuration)
        {
            // this is important to allow derived JwtBearerHandler to work
            services.TryAddEnumerable(ServiceDescriptor.Singleton<IPostConfigureOptions<JwtBearerOptions>, JwtBearerPostConfigureOptions>());

            // disables mapping on jwt claims to microsofts defaults
            System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.DefaultMapInboundClaims = false;

            // todo - refactor config to be a collection to beging with and iterate over a collection?
            var gatherAdB2COptions = new AzureAdB2COptions();
            var santaCruzAdB2COptions = new AzureAdB2COptions();
            configuration.GetSection("GatherAdB2C").Bind(gatherAdB2COptions);
            configuration.GetSection("SantaCruzAdB2C").Bind(santaCruzAdB2COptions);

            // work around until we modify the appsettings.  Create temp collection
            var adb2cClients = new List<AzureAdB2COptions>() { santaCruzAdB2COptions, gatherAdB2COptions };

            adb2cClients.ForEach(client =>
            {
                if (string.IsNullOrEmpty(client.ClientId))
                {
                    return;
                }   

                services
                .AddAuthentication()
                .AddScheme<JwtBearerOptions, JWTAuthenticationHandler>(client.ClientName, jwtOptions =>
                {
                    jwtOptions.Audience = client.ClientId;
                    jwtOptions.Authority = client.Authority;
                    jwtOptions.Events = new JwtBearerEvents
                    {
                        OnAuthenticationFailed = AuthenticationFailed
                    };

                    jwtOptions.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        ValidIssuer = client.Issuer, // NOTE: doesn't seem that it's checked, but new versions of middleware might so this line of code remains
                        ValidAudience = client.ClientId,
                        //IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:Key"])) // NOTE: is retrieved from well-known (discovery) endpoint
                    };
                });
            });

            // set default schemes once
            services.AddAuthentication(options =>
            {
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            });


            // Next create policies

            // collection the schema names, we'll default to add them all for each policy
            var authSchemeNames = adb2cClients.Select(c => c.ClientName).ToArray();

            services.AddAuthorization(options =>
            {
                options.DefaultPolicy = new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .AddAuthenticationSchemes(authSchemeNames)
                    .Build();

                options.AddPolicy("FullApi", policy =>
                {
                    policy.AddAuthenticationSchemes(authSchemeNames);
                    policy.RequireClaim("scp", "api");
                });

                options.AddPolicy("LimitedApi", policy =>
                {
                    policy.AddAuthenticationSchemes(authSchemeNames);
                    policy.RequireClaim("scp", "public.api");
                });

                options.AddPolicy("FullOrLimitedApi", policy =>
                {
                    policy.AddAuthenticationSchemes(authSchemeNames);
                    policy.RequireClaim("scp", "api", "public.api");
                });
            });        

            return services;
        }


        private static Task AuthenticationFailed(AuthenticationFailedContext arg)
        {
            if (arg.Exception.GetType() == typeof(SecurityTokenExpiredException))
            {
                // additional header, should already be additional info the WWW-Authenticate header field
                arg.Response.Headers.Add("Token-Expired", "true");
            }

            // Should be removed from production code:
            //var s = $"AuthenticationFailed: {arg.Exception.Message}";
            //arg.Response.ContentLength = s.Length;
            //arg.Response.Body.WriteAsync(Encoding.UTF8.GetBytes(s), 0, s.Length);

            return Task.CompletedTask;
        }
    }
}
