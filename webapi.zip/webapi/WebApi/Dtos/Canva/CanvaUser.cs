﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos.Canva
{
    public class CanvaUser
    {
        public Guid Id { get; set; }
        public string CanvaUserId { get; set; }
        public Guid AccountId { get; set; }
        public Guid UserId { get; set; }
    }
}
