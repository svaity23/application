export enum ViewMode {
    Default = 'default',
    Design = 'design'
}
