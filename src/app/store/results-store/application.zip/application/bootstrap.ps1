$modules = Get-Module -list

if ( $modules.name -notcontains 'invokebuild' ) {
    'Installing invokebuild'
    Install-Module -Name InvokeBuild -RequiredVersion 5.5.9 -Scope CurrentUser -Force
} 

if ( $modules.name -notcontains 'pester') {
    "Installing pester"
    Install-Module WindowsCompatibility -Force
    Install-Module -Name Pester -RequiredVersion 4.10.1 -Scope CurrentUser -Force
} 

