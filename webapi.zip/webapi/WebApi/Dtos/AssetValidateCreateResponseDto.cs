﻿using ApplicationLogic.Models;
using System;

namespace WebApi.Dtos
{
    public class AssetValidateCreateResponseDto
    {
        public Guid Id { get; set; }
        public Guid AccountId { get; set; }
        public bool Active { get; set; }
        public DateTime Created { get; set; }
        public DateTime? Modified { get; set; }
        public string FileName { get; set; }
        public Guid? UploadSessionId { get; set; }
        public long? FileSize { get; set; }
        public int? FileGroup { get; set; }
        public string FileExtension { get; set; }
        public Guid? CreatedByUserId { get; set; }
        public Guid? LastModifiedByUserId { get; set; }
        public ErrorResponse[] Error { get; set; }
    }
}
