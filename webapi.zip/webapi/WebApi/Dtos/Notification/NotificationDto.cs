﻿using System;

namespace WebApi.Dtos.Notification
{
    public class NotificationDto
    {
        public Guid Id { get; set; }
        public DateTime Created { get; set; }
        public bool Read { get; set; }
        public string Type { get; set; }
        public NotificationCommentDto Comment { get; set; }
    }
}
