export enum SettingValueType {
    BoolValue = 0,
    IntValue = 1,
    DateValue = 2,
    StringValue = 3
}