import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { filter, first, map, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AppStoreFacade } from '@app/store/app-store/app-store.facade';

@Injectable({
  providedIn: 'root'
})
export class AccountUserGuard implements CanActivate {

  constructor(private appStoreFacade: AppStoreFacade, private router: Router) { }

  canActivate(
    // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
    _route: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
    _state: RouterStateSnapshot,
    ): Observable<boolean | UrlTree>  {

      // alert('AccountUserGuard canActivate:' + new Date());
      return this.isAccountUser();
  }

  private isAccountUser(): Observable<boolean | UrlTree> {
    return this.appStoreFacade.context.context$.pipe(
      tap(context => {
        if (!context) {
          this.appStoreFacade.loadContext();
        }
      }),
      filter(context => context != null),
      first(),
      map(context => {
        if (context.accountId) {
          return true;
        } else {
          return this.router.parseUrl('/admin/accounts');
        }
      })
    );
  }
}
