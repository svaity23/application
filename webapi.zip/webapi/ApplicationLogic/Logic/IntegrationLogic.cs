﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLogic.Logic
{
    public class IntegrationLogic
    {
        private readonly IntegrationFinder _finder;
        //private readonly NullLogger<IntegrationLogic> _logger;

        public IntegrationLogic(damContext context)
        {
            _finder = new IntegrationFinder(context);
            //_logger = NullLogger<IntegrationLogic>.Instance;
        }

        public async Task<string> GetMarcomIntegrations(Guid accountId)
        {
            return await _finder.GetMarcomIntegrations(accountId);
        }

        public async Task<string> UpsertIntegrationAsync(Guid accountId, string jsonInput)
        {
            return await _finder.UpsertIntegrationAsync(accountId, jsonInput);
        }
    }
}

