﻿using System;

namespace SignalRHub.Messages
{
    public class NotificationInitiatedMessage : AbstractMessage
    {
        public Guid AssetCommentId { get; set; }
        public Guid[] UserIds { get; set; }
    }
}
