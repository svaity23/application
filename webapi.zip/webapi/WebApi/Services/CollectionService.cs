﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using WebApi.Dtos;

namespace WebApi.Services
{
    public class CollectionService
    {
        private CollectionLogic _collectionLogic;
        private readonly JsonSerializerOptions _options = new JsonSerializerOptions()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };


        public CollectionService(damContext context)
        {
            _collectionLogic = new CollectionLogic(context);
        }


        /// <summary>
        /// Returns all collections visible to the specified user, 
        /// together their details. This is used in the initialization process
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<GetEntitiesResponse<CollectionDto>> GetAllAsync(Guid accountId, Guid userId)
        {
            string resultJson = 
                await _collectionLogic.GetAllAsync(accountId, userId);
            GetEntitiesResponse<CollectionDto> result = 
                JsonSerializer.Deserialize<GetEntitiesResponse<CollectionDto>>(
                    resultJson, _options
                );
            return result;
        }


        /// <summary>
        /// Returns a single collection instance to the corresponding id
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="userId"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<GetEntitiesResponse<CollectionDto>> GetCollectionByIdAsync
            (Guid accountId, Guid userId, Guid id)
        {
            string resultJson =
                await _collectionLogic.GetByIdAsync(accountId, userId, id);
            GetEntitiesResponse<CollectionDto> result =
                JsonSerializer.Deserialize<GetEntitiesResponse<CollectionDto>>(
                    resultJson, _options
                );
            return result;
        }


        /// <summary>
        /// Returns the list of collection ids which are visible for the specified 
        /// account and user id.  If the user id has a group associated, then the 
        /// list of the collection ids should include:
        /// - those collections which are in the same group with the user
        /// - those collections which are not having any group assigned.
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="userId"></param>
        /// <returns>The list of collection ids to which the user is entitled, or 
        /// null entity when the user is not having a group restriction</returns>
        public async Task<GetEntitiesResponse<Guid>> GetEntitledIdsForUserAsync
            (Guid accountId, Guid userId)
        {
            string resultJson =
                await _collectionLogic.GetEntitledIdsForUserAsync(accountId, userId);
            GetEntitiesResponse<Guid> result =
                JsonSerializer.Deserialize<GetEntitiesResponse<Guid>>(
                    resultJson, _options
                );
            return result;
        }


        /// <summary>
        /// Used for saving a new or existing collection.  
        /// If the collection is new, it should have the id set to Guid.Empty
        /// If the collection exists and is under a change operation, it should get the id
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="userId"></param>
        /// <param name="collection"></param>
        /// <returns></returns>
        public async Task<UpsertResponse<CollectionDto>> SaveAsync
            (Guid accountId, Guid userId, CollectionDto collection)
        {
            var jsonCollection = JsonSerializer.Serialize(collection, _options);
            var resultJson = await _collectionLogic.SaveAsync(accountId, userId, jsonCollection);
            UpsertResponse<CollectionDto> result = 
                JsonSerializer.Deserialize<UpsertResponse<CollectionDto>>(
                    resultJson, _options
                );
            return result;
        }


        /// <summary>
        /// Deletes a collection definitions, specified by its id.
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="userId"></param>
        /// <param name="collectionId"></param>
        /// <returns></returns>
        public async Task<UpsertResponse<List<Guid>>> DeleteAsync
            (Guid accountId, Guid userId, Guid collectionId)
        {
            BulkDeleteRequestDTO collections = new BulkDeleteRequestDTO
            {
                Ids = new Guid[] { collectionId }
            };
            var jsonIdArray = JsonSerializer.Serialize(collections, _options);
            var resultJson = await _collectionLogic.DeleteAsync(accountId, userId, jsonIdArray);
            UpsertResponse<List<Guid>> result = 
                JsonSerializer.Deserialize<UpsertResponse<List<Guid>>>(
                    resultJson, _options
                );
            return result;
        }

        /// <summary>
        /// Moves a collection to a different parent or to the root of the collections
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="userId"></param>
        /// <param name="collectionId"></param>
        /// <param name="parentId">the GUID of the parent collection or Guid.Empty if the move operation goes under root</param>
        /// <returns></returns>
        public async Task<GetEntitiesResponse<CollectionDto>> MoveCollectionAsync(Guid accountId, Guid userId, Guid collectionId, Guid parentId)
        {
            string resultJson =
                await _collectionLogic.MoveCollectionAsync(accountId, userId, collectionId, parentId);
            GetEntitiesResponse<CollectionDto> result =
                JsonSerializer.Deserialize<GetEntitiesResponse<CollectionDto>>(
                    resultJson, _options
                );
            return result;
        }
    }
}
