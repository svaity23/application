﻿using System.Text.Json.Serialization;

namespace WebApi.Dtos
{
    public class PostUploadSummaryFileGroupDto
    {
        [JsonPropertyName("count")]
        public int Count { get; set; }

        [JsonPropertyName("fileGroupType")]
        public int FileGroupType { get; set; } // FileGroupType enum is in FileService right now.  Need to move it out to global.
    }
}
