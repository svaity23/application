﻿namespace SignalRHub
{
    public class ReceiveServiceBusesConfig
    {
        public const string ReceiveServiceBusesSection = "ReceiveServiceBuses";
        public BusReceiveServiceConfig ImageProcessedServiceBus { get; set; }

        public BusReceiveServiceConfig TagsProcessedServiceBus { get; set; }        

        public BusReceiveServiceConfig AccountProcessedServiceBus { get; set; }

        public BusReceiveServiceConfig CustomizeAssetProcessedServiceBus { get; set; }

        public BusReceiveServiceConfig NotificationInitiatedServiceBus { get; set; }
    }
}
