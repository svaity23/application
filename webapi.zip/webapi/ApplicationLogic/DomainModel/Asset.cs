﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ApplicationLogic.DomainModel
{
    [Table("asset")]
    [Index(nameof(Active), nameof(CollectionId), Name = "ix_asset_active")]
    public partial class Asset
    {
        public Asset()
        {
            Metadata = new HashSet<Metadata>();
        }

        [Key]
        [Column("id")]
        public Guid Id { get; set; }
        [Column("externalId")]
        [StringLength(64)]
        public string ExternalId { get; set; }
        [Column("accountId")]
        public Guid AccountId { get; set; }
        [Column("active")]
        public bool Active { get; set; }
        [Column("created")]
        public DateTime Created { get; set; }
        [Column("modified")]
        public DateTime? Modified { get; set; }
        [Required]
        [Column("fileName")]
        [StringLength(1024)]
        public string FileName { get; set; }
        [Column("uri")]
        [StringLength(1024)]
        public string Uri { get; set; }
        [Column("collectionId")]
        public Guid? CollectionId { get; set; }
        [Column("uploadSessionId")]
        public Guid? UploadSessionId { get; set; }
        [Column("name")]
        [StringLength(1024)]
        public string Name { get; set; }
        [Column("description")]
        [StringLength(1024)]
        public string Description { get; set; }
        [Column("fileSize")]
        public long? FileSize { get; set; }
        [Column("createdBy")]
        public Guid? CreatedBy { get; set; }
        [Column("lastModifiedBy")]
        public Guid? LastModifiedBy { get; set; }
        [Column("error")]
        public string Error { get; set; }
        [Column("fileGroup")]
        public int? FileGroup { get; set; }
        [Column("fileExtension")]
        [StringLength(6)]
        public string FileExtension { get; set; }
        [Column("originId")]
        public Guid? OriginId { get; set; }
        [Column("attachment")]
        public string Attachment { get; set; }
        [Column("blobCopySuccess")]
        public bool? BlobCopySuccess { get; set; }
        [Column("blobCopyErrors")]
        public string BlobCopyErrors { get; set; }

        [ForeignKey(nameof(AccountId))]
        [InverseProperty("Asset")]
        public virtual Account Account { get; set; }
        [ForeignKey(nameof(CreatedBy))]
        [InverseProperty(nameof(User.AssetCreatedByNavigation))]
        public virtual User CreatedByNavigation { get; set; }
        [ForeignKey(nameof(LastModifiedBy))]
        [InverseProperty(nameof(User.AssetLastModifiedByNavigation))]
        public virtual User LastModifiedByNavigation { get; set; }
        [InverseProperty("Asset")]
        public virtual ICollection<Metadata> Metadata { get; set; }
    }
}
