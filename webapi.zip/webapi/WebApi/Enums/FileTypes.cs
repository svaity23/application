﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Enums
{
    public static class FileTypes
    {
        private static string[] IMAGE =
        {
            "JPEG",
            "JPG",
            "GIF",
            "PNG",
            "TIFF",
            "TIF",
            "BMP",
            "SVG",
            "RAW",
            "HEIC",
            "NEF",
            "ORF",
            "CR2",
            "DNG",
            "ICO",
            "CUR"
        };

        private static string[] VIDEO =
        {
            "AVI",
            "WMV",
            "MOV",
            "MP4",
            "HEVC",
            "R3D",
            "VID",
            "MPEG",
            "LRV",
            "SWF",
            "FLV"
        };

        private static string[] AUDIO =
        {
            "MP3",
            "WAV",
            "M4A",
            "FLAC",
            "AIF",
            "AAC",
            "WMA"
        };

        private static string[] DESIGN =
        {
            "EPS",
            "HTML",
            "PUB",
            "SKETCH",
            "PSD",
            "AI",
            "INDD",
            "XD",
            "ASE"
        };

        private static string[] PRESENTATION =
        {
            "PPT",
            "PPTX",
            "PPTM",
            "POT",
            "POTX",
            "POTM",
            "PPS",
            "PPSX",
            "PPSM",
            "PEZ",
            "KEY"
        };

        private static string[] DOCUMENT =
        {
            "XLS",
            "XLSX",
            "TXT",
            "DOC",
            "DOCX",
            "CSV",
            "PDF"
        };

        private static string[] FONT =
        {
            "FNT",
            "FON",
            "TTF",
            "OTF",
            "WOFF",
            "TTC"
        };

        private static string[] ARCHIVE =
        {
            "ZIP"
        };

        public static int GetFileGroup(string fileExtension)
        {
            fileExtension = fileExtension.Trim().ToUpperInvariant();
            if (fileExtension.StartsWith(".")) fileExtension = fileExtension.Substring(1);

            if (IMAGE.Contains(fileExtension)) return 0;
            else if (VIDEO.Contains(fileExtension)) return 1;
            else if (AUDIO.Contains(fileExtension)) return 2;
            else if (DESIGN.Contains(fileExtension)) return 3;
            else if (PRESENTATION.Contains(fileExtension)) return 4;
            else if (DOCUMENT.Contains(fileExtension)) return 5;
            else if (FONT.Contains(fileExtension)) return 7;
            else if (ARCHIVE.Contains(fileExtension)) return 8;

            return -1; //unsupported file type
        }

        public static string GetFileGroupName(int fileGroup)
        {
            return fileGroup switch
            {
                0 => "Image",
                1 => "Video",
                2 => "Audio",
                3 => "Design",
                4 => "Presentation",
                5 => "Document",
                7 => "Font",
                8 => "Archive",

                _ => $"Unknown ({fileGroup})"
            };
        }
    }
}
