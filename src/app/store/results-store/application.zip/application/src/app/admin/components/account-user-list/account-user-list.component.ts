import { ChangeDetectionStrategy, Component,  Input, OnChanges, SimpleChanges, ViewEncapsulation } from '@angular/core';

import { AccountDetail } from '@app/core/models/entities/account-detail.model';
import { User } from '@app/core/models/entities/user.model';

@Component({
  selector: 'app-account-user-list',
  templateUrl: './account-user-list.component.html',
  styleUrls: ['./account-user-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountUserListComponent implements OnChanges {
  @Input() account: AccountDetail;
  @Input() accountUsers: User[];
  accountUsersToDisplay: User[]; // we need this because we do a sort, and do not want to modify state itself
  searchUserEmailText = '';
  searchUserNameText = '';
  searchUserRoleText = '';
  sortField = 'name';
  sortOrder = 'desc';
  constructor() { }

  filterAccountUsersToDisplay(): void {
    this.resetAccountUsersToDisplay();
    this.accountUsersToDisplay = this.accountUsersToDisplay.filter((item) => {
      if ((item.firstName.toString().toLocaleLowerCase().includes(this.searchUserNameText.toLocaleLowerCase()) ||
          item.lastName.toString().toLocaleLowerCase().includes(this.searchUserNameText.toLocaleLowerCase()))
          && item.roleName.toString().toLocaleLowerCase().includes(this.searchUserRoleText.toLocaleLowerCase())
          && item.email.toString().toLocaleLowerCase().includes(this.searchUserEmailText.toLocaleLowerCase()))
        return item;
    });
  }

  getRoleName(user: User): string {
    let roleName;
    let accountOwnerSubTitle = '';
    // eslint-disable-next-line prefer-const
    roleName = user.roleName;
    if (user.id === this.account.userId) {
      accountOwnerSubTitle = ' - Account Owner';
    }
    return roleName + accountOwnerSubTitle;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.accountUsers) {
      this.accountUsersToDisplay = [...this.accountUsers];
    }
  }

  resetAccountUsersToDisplay(): void {
    this.accountUsersToDisplay = [...this.accountUsers];
  }

  sort(columnName: string): void {
    // toggle sort order if already selected
    if (this.sortField === columnName) {
      this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortField = columnName;
      this.sortOrder = 'asc';
    }

    // setup the evalution
    const v1 = this.sortOrder === 'asc' ? 1 : -1;
    const v2 = this.sortOrder === 'asc' ? -1 : 1;

    switch (this.sortField) {
      case 'name':
        this.accountUsersToDisplay.sort((s1, s2) => s1.firstName.toLocaleLowerCase() > s2.firstName.toLocaleLowerCase() ? v1 : v2);
        break;
      case 'email':
        this.accountUsersToDisplay.sort((s1, s2) => s1.email.toLocaleLowerCase() > s2.email.toLocaleLowerCase() ? v1 : v2);
        break;
      case 'role':
        this.accountUsersToDisplay.sort((s1, s2) => s1.roleKey > s2.roleKey ? v1 : v2);
        break;
      default:
    }
  }
}
