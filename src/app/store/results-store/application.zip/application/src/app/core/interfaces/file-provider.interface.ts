import { Observable } from 'rxjs';

import { AssetFile } from '../models/asset-file.model';
import { AuthProvider } from './auth-provider.interface';
import { SocialAuthUser } from '../models/social-auth-user';

export interface FileProvider {
	authProvider: AuthProvider;
	getFilesSelectedSubject(): Observable<AssetFile[]>;
	load(): Observable<SocialAuthUser>;
}
