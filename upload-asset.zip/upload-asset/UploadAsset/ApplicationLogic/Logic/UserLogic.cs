﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Threading.Tasks;

namespace ApplicationLogic.Logic
{
    public class UserLogic
    {
        public ILogger<UserLogic> Logger { get; set; }
        
        private readonly UserFinder _finder;

        public UserLogic(damContext context) {
            _finder = new UserFinder(context);
            Logger = NullLogger<UserLogic>.Instance;
            // TODO - create logic for _finder
            //_finder.Logger = 
        }
        

        public async Task<string> GetAccountIdsByUserIdAsync(Guid userId)
        {
            return await _finder.GetAccountIdsByUserIdAsync(userId);
        }
    }
}
