﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using WebApi.Dtos.Asset.Request;
using WebApi.Extensions;

namespace WebApi.Services
{
    public class PermalinkService
    {
        private readonly ILogger<PermalinkService> _logger;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private PermalinkLogic _permalinkLogic;

#pragma warning disable CA1801 // Review unused parameters
        public PermalinkService(IConfiguration configuration, ILogger<PermalinkService> logger, damContext context, IHttpContextAccessor httpContextAccessor)
#pragma warning restore CA1801 // Review unused parameters
        {
            _logger = logger;
            _httpContextAccessor = httpContextAccessor;
            _permalinkLogic = new PermalinkLogic(context);            

        }

        public async Task<Permalink> SavePermalinkAsync(Guid accountId, Guid userId, Guid sessionId, PermalinkRequest request)
        {
            _logger.LogDebug($"[PermalinkService] SavePermalink = {accountId}");

            var jsonOutput = await _permalinkLogic.SavePermalinkAsync(accountId, userId, sessionId, request.ToJsonString() );
            return Newtonsoft.Json.JsonConvert.DeserializeObject<Permalink>(jsonOutput);
        }

        public string GetPermalinkUri(Permalink response)
        {
            var myHost = _httpContextAccessor.HttpContext.Request.Host;
            UriBuilder fullUri = new UriBuilder()
            {
                Scheme = "https", // _httpContextAccessor.HttpContext.Request.Scheme,   // cant explain why on SBX/DEV/QA its coming out as 'http', hard code for now
                Host = myHost.Host,  
                Path = $"permalink/{response.Path}",
            };

            if (myHost.Port != null)
            {
                // if running locally, this wont know which port permalink is running, so you'll just have to modify the link in the browser
                // avoiding adding a config entry just for testing
                fullUri.Port = (int)myHost.Port; 
            }

            return fullUri.ToString();
        }

    }
}
