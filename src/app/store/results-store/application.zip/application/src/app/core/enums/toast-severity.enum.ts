export enum ToastSeverity {
  Success,
  Info,
  Warning,
  Error,
  DeleteSuccess,
  Progress
}
