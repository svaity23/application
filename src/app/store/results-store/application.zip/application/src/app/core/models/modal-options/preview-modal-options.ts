import { MetadataFieldAndValueForPreview } from '../metadata-field-and-value-for-preview';
export class PreviewModalOptions {
  message: string;
  profileFieldAndValues: MetadataFieldAndValueForPreview[];
  profileName: string;
  title: string;
}
