import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { createGuid, nullGuid } from 'src/utils/guid';

import { FieldType } from '@app/core/enums/field-type.enum';
import { MetadataField } from '@app/core/models/entities/metadata-field.model';
import { MetadataFieldValue } from '@app/core/models/entities/metadata-field-value.model';

@Component({
  selector: 'app-metadata-profile-fields',
  templateUrl: './metadata-profile-fields.component.html',
  styleUrls: ['./metadata-profile-fields.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MetadataProfileFieldsComponent implements OnInit, OnChanges {
  @Input() accountId: string;
  allowFieldSorting = true;
  @Output() fieldAddedEvent = new EventEmitter<MetadataField>();
  @Output() fieldDeleteAttemptedEvent = new EventEmitter<MetadataField>();
  @Output() fieldExpandedOrCollapsedEvent = new EventEmitter<MetadataField>();
  @Output() fieldRequiredSettingUpdatedEvent = new EventEmitter<MetadataField>();
  @Output() fieldsSortedEvent = new EventEmitter<MetadataField[]>();
  fieldToMove: MetadataField;
  fieldToMoveAfter: MetadataField;
  fieldType = FieldType;
  fieldTypeKeys: string[];
  @Output() fieldUpdatedEvent = new EventEmitter<MetadataField>();
  @Output() fieldValueDeleteAttemptedEvent = new EventEmitter<MetadataFieldValue>();
  @Output() fieldValuesAddedEvent = new EventEmitter<MetadataFieldValue[]>();
  @Output() fieldValuesSortedEvent = new EventEmitter<MetadataFieldValue[]>();
  @Output() fieldValueUpdatedEvent = new EventEmitter<MetadataFieldValue>();
  @Input() profileFieldLabels: string[];
  profileFieldsToDisplay: MetadataField[] = []; // we need this because we do a sort, and do not want to modify state itself
  @Input() profileFieldsToModify: MetadataField[];
  @Input() profileFieldValuesToModify: MetadataFieldValue[];

  constructor() {
  }

  allowDrop($event): void {
    $event.preventDefault();
  }

  dragFieldEnd(): void {
    this.clearDragAndDropFields();
  }

  dragFieldOver(field: MetadataField): void {
    this.fieldToMoveAfter = field;
  }

  dragFieldStart($event, field: MetadataField): void {
    if (field.expandField) { return; }
    this.clearDragAndDropFields();
    this.fieldToMove = field;

    console.log($event);

    // creating a copy of the div to show whats being dragged
    // const ghostElem = $event.currentTarget.cloneNode(true);
    // ghostElem.classList.add('drag-ghost-field');
    // document.body.appendChild(ghostElem);
    // $event.dataTransfer.setDragImage(ghostElem, 0, 0);
    // $event.dataTransfer.setData('text', $event.target.id);
  }

  dragNewFieldEnd($event): void {
    $event.target.classList.remove('onDrag');
  }

  dragNewFieldOver($event): void {
    $event.preventDefault();
    $event.target.classList.add('activeDropZone');
  }

  dragNewFieldStart($event): void {
    $event.target.classList.add('onDrag');
    // creating a copy of the div to show whats being dragged over
    const ghostElem = $event.currentTarget.cloneNode(true);
    ghostElem.classList.add('drag-ghost');
    document.body.appendChild(ghostElem);
    $event.dataTransfer.setDragImage(ghostElem, 0, 0);
    $event.dataTransfer.setData('text', $event.target.id);
  }

  dropField($event): void {
    $event.preventDefault();
    if (this.fieldToMove.id === this.fieldToMoveAfter.id) {
      this.clearDragAndDropFields();
      return; // nothing to do
    } else {
      this.reOrderFields();
    }
  }

  dropNewField($event): void {
    $event.preventDefault();
    $event.target.classList.remove('activeDropZone');
    const data = +$event.dataTransfer.getData('text'); // 0
    let newMetadataField: MetadataField;
    if (data === this.fieldType.Text || data === this.fieldType.Textarea) { // Text fields and text area
      newMetadataField = {
        id: createGuid(),
        accountId: this.accountId,
        active: true,
        default: false,
        expandField: true,
        previous: null,
        label: '',
        metadataFieldTypeId: Number(data),
        metadataProfileId: this.profileFieldsToDisplay[0].metadataProfileId
      };
    }
    if (data === this.fieldType.Dropdown || data === this.fieldType.Checkbox || data === this.fieldType.Radio) { // for dropdowns, checkboxes and radio buttons
      const newMetadataFieldId = createGuid();
      newMetadataField = {
        id: newMetadataFieldId,
        accountId: this.accountId,
        active: true,
        default: false,
        expandField: true,
        previous: null,
        label: '',
        metadataFieldTypeId: Number(data),
        metadataProfileId: this.profileFieldsToDisplay[0].metadataProfileId
      };
      // add field values
      const fieldValues = this.createDefaultFieldValues(newMetadataFieldId)
      this.fieldValuesAddedEvent.emit(fieldValues);
    }
    if (this.profileFieldsToDisplay.length >= 1) {
      newMetadataField.previous = this.profileFieldsToDisplay[this.profileFieldsToDisplay.length - 1].id;
    } else {
      newMetadataField.previous = this.profileFieldsToDisplay[this.profileFieldsToDisplay.length - 1].id;
    }

    // remove ghost elements from the DOM
    const elements = document.getElementsByClassName('drag-ghost');
    while(elements.length > 0){
        elements[0].parentNode.removeChild(elements[0]);
    }

    this.fieldAddedEvent.emit(newMetadataField);

  }

  fieldDeleteAttempted($event: MetadataField): void {
    this.fieldDeleteAttemptedEvent.emit($event);
  }

  fieldUpdated($event: MetadataField): void {
    this.fieldUpdatedEvent.emit($event);
  }

  fieldValueDeleteAttempted($event: MetadataFieldValue): void {
    this.fieldValueDeleteAttemptedEvent.emit($event);
  }

  fieldValuesAdded($event: MetadataFieldValue[]): void {
    this.fieldValuesAddedEvent.emit($event);
  }

  fieldValuesSorted($event: MetadataFieldValue[]): void {
    this.fieldValuesSortedEvent.emit($event);
  }

  fieldValueUpdated($event: MetadataFieldValue): void {
    this.fieldValueUpdatedEvent.emit($event);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.profileFieldsToModify) {
      // const copyOfProfileFields = [...changes.profileFieldsToModify.currentValue];
      // this.sortProfileFieldsInOrderOfPrevious(copyOfProfileFields);
      this.profileFieldsToDisplay = [...changes.profileFieldsToModify.currentValue];
      this.setAllowFieldSorting();
    }
  }

  ngOnInit(): void {
    this.fieldTypeKeys = this.getFieldTypeEnumValues(this.fieldType);
  }

  // sortProfileFieldsInOrderOfPrevious(profileFields: MetadataField[]): void {
  //   this.profileFieldsToDisplay = [];
  //   let previousToFind = nullGuid;
  //   const n = profileFields.length;
  //   for (let i = 0; i < n; i++) {
  //     const fieldIndex = profileFields.findIndex(item => item.previous.toLocaleLowerCase() === previousToFind);
  //     previousToFind = profileFields[fieldIndex].id.toLocaleLowerCase();
  //     const newFieldToModify = {...profileFields[fieldIndex]};
  //     this.profileFieldsToDisplay.push(newFieldToModify);
  //   }
  // }

  toggleExpandField(field: MetadataField): void {
    this.fieldExpandedOrCollapsedEvent.emit(field);
    this.setAllowFieldSorting();
  }

  toggleRequiredChange(field: MetadataField): void {
    this.fieldRequiredSettingUpdatedEvent.emit(field);
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  trackByFn(index: any): void {
    return index;
  }
  private clearDragAndDropFields(): void {
    this.fieldToMove = this.fieldToMoveAfter = null;
  }

  private createDefaultFieldValues(id: string): MetadataFieldValue[] {
    const listOps: MetadataFieldValue[] = [];
    let previousId = nullGuid;
    let listOp: MetadataFieldValue;
    const defaultCount = 3;
    for (let i = 0; i < defaultCount; i++) {
      if(i !== 0) {
        previousId = listOps[i-1].id;
      }
      listOp = {
        accountId: this.accountId,
        active: true,
        id: createGuid(),
        metadataFieldId: id,
        previous: previousId,
        value: ''
      }
      listOps.push(listOp);
    }
    return listOps;
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private getFieldTypeEnumValues(filedType: any): string[] {
    const objectEnum = Object.keys(filedType);
    const values = objectEnum.slice(0, objectEnum.length / 2);
    return values;
  }

  private reOrderFields(): void {
    // removes from old location in fields array
    const itemToMoveIndex = this.profileFieldsToDisplay.findIndex(item => item.id === this.fieldToMove.id);
    const itemToMove = this.profileFieldsToDisplay.splice(itemToMoveIndex, 1)[0];

    // adds to new location in fields array
    const itemToMoveAfterIndex = this.profileFieldsToDisplay.findIndex(item => item.id === this.fieldToMoveAfter.id);
    this.profileFieldsToDisplay.splice(itemToMoveAfterIndex + 1, 0, itemToMove);
    // console.log('[' + itemToMoveIndex + ',' + itemToMoveAfterIndex + ']');
    const tempFieldsToModify: MetadataField[] = [];
    this.profileFieldsToDisplay.forEach(element => {
      const newElement = { ...element };
      tempFieldsToModify.push(newElement);
    });

    // loop from the end and update the 'previous' field to update the sort order
    for (let i = tempFieldsToModify.length - 1; i > 0; i--) {
      tempFieldsToModify[i].previous = tempFieldsToModify[i-1].id
    }
    tempFieldsToModify[0].previous = nullGuid; // first one is always a null guid
    this.clearDragAndDropFields();
    this.fieldsSortedEvent.emit(tempFieldsToModify);
  }

  /** Enables field level sorting if all fields are collapsed */
  private setAllowFieldSorting(): void {
    let foundExpandedFields = false;
    this.profileFieldsToDisplay.forEach(field => {
      if (field.expandField) {
        foundExpandedFields = true;
      }
    })
    this.allowFieldSorting = !foundExpandedFields;
  }

}
