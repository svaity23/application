﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WebApi.Dtos.Asset
{
    public class LightboxAssetListParamsDto
    {
        [JsonPropertyName("sortField")]
        public int SortField { get; set; }
        [JsonPropertyName("lightboxId")]
        public Guid? LightboxId { get; set; }
        [JsonPropertyName("skip")]
        public int Skip { get; set; }
        [JsonPropertyName("pageSize")]
        public int PageSize { get; set; }
        [JsonPropertyName("includeInactive")]
        public bool IncludeInactive { get; set; }
        [JsonPropertyName("isOnMyFavorites")]
        public bool IsOnMyFavorites { get; set; }
    }
}
