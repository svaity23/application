import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';

import { filter, first, map, switchMap, take, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { AccountDetail } from '../models/entities/account-detail.model';
import { AdminAccountStoreFacade } from '@app/store/admin-store/admin-account-store.facade';

@Injectable({
  providedIn: 'root'
})
export class AccountGuard implements CanActivate {

  constructor(private accountStorefacade: AdminAccountStoreFacade, private router: Router) { }

  canActivate(
    // eslint-disable-next-line @typescript-eslint/naming-convention,no-underscore-dangle,id-blacklist,id-match
    _route: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/naming-convention, no-underscore-dangle, id-blacklist, id-match
    _state: RouterStateSnapshot): Observable<boolean | UrlTree> {


    // todo -- repurpose this to load single account?, removed guard from edit route, and forcing component to loadAccountSelected

    return this.prefetchAccounts().pipe(
      switchMap(() => this.isAccountInState())
    );
  }

  private isAccountInState(): Observable<boolean | UrlTree> {
    return this.accountStorefacade.selectedAccount$.pipe(
      take(1),
      map(account => {
        if (account) {
          return true;
        } else {
          return this.router.parseUrl('/admin/accounts');
        }
      })
    );
  }

  private prefetchAccounts(): Observable<AccountDetail[]> {
    return this.accountStorefacade.isLoaded$.pipe(
      tap(isLoaded => {
        if (isLoaded !== true) {
          this.accountStorefacade.loadAccounts();
        }
      }),
      filter(isLoaded => isLoaded === true),
      switchMap(() => this.accountStorefacade.accounts$),
      first()
    );
  }
}
