﻿namespace UploadAsset.Dtos
{
    public class GoogleUploadRequest: BaseFileUploadRequest
    {
        public string AccessToken { get; set; }   
        public string FileName { get; set; }
        public long FileSizeBytes { get; set; }
        public string GoogleFileId { get; set; }        
    }
}
