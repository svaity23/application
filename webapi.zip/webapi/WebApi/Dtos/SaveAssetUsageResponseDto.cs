﻿using System.Text.Json.Serialization;

namespace WebApi.Dtos
{
    public class SaveAssetUsageResponseDto
    {
        [JsonPropertyName("rowsInserted")]
        public int RowsInserted { get; set; }
    }
}
