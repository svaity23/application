export interface AssetForDownload {
  assetId: string;
  conversionResult: string;
	downloadProgress: number;
	fileName: string;
}
