export interface MetadataFieldValue {
    accountId: string;
    active?: boolean;
    id: string;
    metadataFieldId: string;
    previous: string;
    value: string;
}

