﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationLogic.Models
{
    public class SalesforceLeadDetailsModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Company { get; set; }
    }
}
