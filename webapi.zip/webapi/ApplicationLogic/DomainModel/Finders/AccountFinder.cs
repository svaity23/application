﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Utils;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApplicationLogic.DomainModel.Finders
{
    public class AccountFinder
    {
        public ILogger<AccountFinder> Logger { get; set; }

        private damContext _context;

        public AccountFinder(damContext context) {
            _context = context;
            Logger = NullLogger<AccountFinder>.Instance;
        }

        public async Task<Account> FindByIdAsync(Guid id)
        {
            return await _context.FindAsync<Account>(id);
        }

        public IQueryable<Account> GetQuerable()
        {
            return _context.Account.AsQueryable();
        }

        public async Task<string> UpsertAccountAsync(Guid userId, string jsonInput)
        {
            SpParams paramList = new SpParams();
            paramList.WithUserId(userId);
            paramList.WithJson(jsonInput);

            List<SqlParameter> sqlParmsList = paramList.Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("upsertAccount", sqlParmsList).ConfigureAwait(false);
        }

        public async Task<string> UpdateAccountBrandDetailsAsync(Guid userId, Guid accountId, string jsonInput)
        {
            SpParams paramList = new SpParams();
            paramList.WithUserId(userId);
            paramList.WithAccountId(accountId);
            paramList.WithJson(jsonInput);

            List<SqlParameter> sqlParmsList = paramList.Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("updateAccountBrandDetails", sqlParmsList).ConfigureAwait(false);
        }

        public async Task<string> CreateFreeTrialSampleDataAsync(Guid accountId, Guid userId, string jsonInput)
        {
            SpParams paramList = new SpParams();
            paramList.WithUserId(userId);
            paramList.WithAccountId(accountId);
            paramList.WithJson(jsonInput);

            List<SqlParameter> sqlParmsList = paramList.Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("createFreeTrialSeedData", sqlParmsList).ConfigureAwait(false);
        }

        public async Task<string> GetAccountsByUserIdAsync(Guid userId)
        {
            SpParams paramList = new SpParams();
            paramList.WithUserId(userId);            

            List<SqlParameter> sqlParmsList = paramList.Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("getAccountsByUserId", sqlParmsList).ConfigureAwait(false);
        }

        public async Task<int> DeleteAccount(Guid accountId)
        {
            SpParams paramList = new SpParams();
            paramList.WithAccountId(accountId);

            List<SqlParameter> sqlParmsList = paramList.Build();
            return await _context.ExecuteNonQueryAsync("setAccountForDelete", sqlParmsList).ConfigureAwait(false);
        }

        public async Task<string> GetAccountFeaturesAsync(Guid accountId, Guid userId)
        {
            SpParams paramList = new SpParams();
            paramList.WithAccountId(accountId);
            paramList.WithUserId(userId);

            List<SqlParameter> sqlParmsList = paramList.Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("getAccountFeatures", sqlParmsList).ConfigureAwait(false);

        }

        public async Task<string> GetFederatedAdAccountByEmailAsync(string email)
        {
            SpParams paramList = new SpParams();
            paramList.WithString("email", email);

            List<SqlParameter> sqlParmsList = paramList.Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("getFederatedAdAccountByEmail", sqlParmsList).ConfigureAwait(false);
        }

        public async Task<string> SaveFederatedDomainAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithSessionId(sessionId)
                .WithJson(jsonInput)
                .Build();

            return await _context.ExecuteNonQueryJsonOutputAsync("saveAccountFederatedDomain", parameters).ConfigureAwait(false);
        }

        public async Task<string> DeleteFederatedDomainsAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            List<SqlParameter> parameters = new SpParams()
                .WithAccountId(accountId)
                .WithUserId(userId)
                .WithSessionId(sessionId)
                .WithJson(jsonInput)
                .Build();

            return await _context.ExecuteNonQueryJsonOutputAsync("deleteFederatedDomains", parameters).ConfigureAwait(false);
        }

        public async Task<string> UpdateAccountFeaturesAsync(Guid accountId, Guid userId, string jsonInput)
        {
            SpParams paramList = new SpParams();
            paramList.WithAccountId(accountId);
            paramList.WithUserId(userId);
            paramList.WithJson(jsonInput);

            List<SqlParameter> sqlParmsList = paramList.Build();
            return await _context.ExecuteNonQueryJsonOutputAsync("updateAccountFeatures", sqlParmsList).ConfigureAwait(false);
        }
    }
}
