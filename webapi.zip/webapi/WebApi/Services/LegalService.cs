﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using WebApi.Dtos;
using System;
using System.Threading.Tasks;

namespace WebApi.Services
{
    public class LegalService
    {
        private readonly damContext _context;

        public LegalService(damContext context)
        {
            _context = context;
        }

        public async Task<int> AcceptLegal(AcceptLegalDto legalDto)
        {
            UserLegal userLegal = new UserLegal()
            {
                AccountId = Guid.Parse(legalDto.AccountId),
                UserId = Guid.Parse(legalDto.UserId),
                LegalId = legalDto.LegalId
            };
            _context.UserLegal.Add(userLegal);
            return await _context.SaveChangesAsync();
        }
    }
}
