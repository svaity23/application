export interface AttachmentEntry {
  blobName: string;
  containerName: string;
  name: string;
  statusCode: number;
}
