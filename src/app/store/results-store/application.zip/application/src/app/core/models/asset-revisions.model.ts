import { AssetRevisionsHistory } from './asset-revisions-history.model';
import { AssetRevisionsUser } from './asset-revisions-user.model';

export interface AssetRevisions {
    created: Date;
    history: AssetRevisionsHistory[];
    user: AssetRevisionsUser
}
