﻿using ApplicationLogic.DomainModel.Context;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.IdentityModel.Tokens.Jwt;
using WebApi.Common.Constants;

namespace WebApi.Services
{
    public class AzureAdB2cService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<AzureAdB2cService> _logger;
        private KeyVaultService _keyVaultService;

        public AzureAdB2cService(IConfiguration configuration, KeyVaultService keyVaultService, ILogger<AzureAdB2cService> logger, damContext context)
        {
            _configuration = configuration;
            _keyVaultService = keyVaultService;
            _logger = logger;
        }

        public string BuildIdToken(IList<System.Security.Claims.Claim> claims)
        {
            string issuer = _configuration.GetSection("AzureAdB2C:IdToken:Issuer")?.Value;

            // Create the token
            string b2CClientId = _configuration.GetSection("AzureAdB2C:ClientId")?.Value;
            try
            {
                var signingCredentials = new X509SigningCredentials(_keyVaultService.GetCertificate(KeyVaultSecretKey.IdTokenAdb2cCert));
                if (signingCredentials == null)
                {
                    _logger.LogError("WebApi Integrations: Could not get the certificate Signing Credentials");
                    return null;
                }

                JwtSecurityToken token = new JwtSecurityToken(
                        issuer,
                        b2CClientId,
                        claims,
                        DateTime.Now,
#pragma warning disable CA1305 // Specify IFormatProvider
                        DateTime.Now.AddMinutes(5),
#pragma warning restore CA1305 // Specify IFormatProvider
                        signingCredentials
                        );
                JwtSecurityTokenHandler jwtHandler = new JwtSecurityTokenHandler();

                return jwtHandler.WriteToken(token);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "WebApi AzureAdB2cService: Exception occurred building token");
                //_telemetryClient.TrackException(ex);
                return null;
            }
        }                
    }
}
