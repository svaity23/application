import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { cn } from 'src/utils/cn';

import { Group } from '@app/core/models/entities/group.model';

@Component({
  selector: 'app-group-search',
  templateUrl: './group-search.component.html',
  styleUrls: ['./group-search.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class GroupSearchComponent implements OnInit, OnChanges {
  @Output() addNewGroup = new EventEmitter();
  @Input() className = '';
  isEnabled = false;
  @Output() searchInputChange: EventEmitter<string> = new EventEmitter<string>();
  @Input() searchText: string;
  @Input() selectedGroups: Group[];
  show = false;
  visible = false;

  constructor() { }

  addGroup(): void {
    this.addNewGroup.emit();
  }

  filterGroups(): void {
    this.searchInputChange.emit(this.searchText);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.searchText?.currentValue) {
      this.toggleSearchButton();
    }
  }

  ngOnInit(): void {
    this.className = cn('group-search', this.className);
  }

  onInputTextFocus(): void {
    this.show = true;
    this.isEnabled = false;
  }

  toggleSearchButton(): void {
    this.show = true;
    this.isEnabled = true;
  }

}

