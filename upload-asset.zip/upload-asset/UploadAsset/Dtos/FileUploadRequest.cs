﻿using Microsoft.AspNetCore.Http;

namespace UploadAsset.Dtos
{
    public class FileUploadRequest: BaseFileUploadRequest
    {        
        public IFormFile File { get; set; }
    }
}
