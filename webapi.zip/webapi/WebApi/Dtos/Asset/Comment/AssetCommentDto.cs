﻿using System;

namespace WebApi.Dtos.Asset.Comment
{
    public class AssetCommentDto
    {
        public Guid? Id { get; set; }
        public bool Active { get; set; }
        public CollaborationUserDto Author { get; set; }
        public DateTime? Created { get; set; } 
        public int ThreadId { get; set; } = -1;
        public string Comment { get; set; } = "";
        public Guid[] TaggedUserIds { get; set; }
        public bool IsAnnotation { get; set; }
        public int PositionLeft { get; set; }
        public int PositionTop { get; set; }
        public bool Resolved { get; set; }
        public Guid? RevisionId { get; set; }
    }
}
