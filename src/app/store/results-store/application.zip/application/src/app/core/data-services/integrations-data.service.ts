import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { BaseDataService } from './base-data.service';

import { Integration } from '../models/integrations/integration.model';
import { IntegrationSetting } from '../models/integration-setting.model';
import { Setting } from '../models/setting.model';

export interface IntegrationsServiceInterface {

    toggleIntegrationStatus(integration: IntegrationSetting, enabled: boolean): Observable<Setting>;
}

@Injectable({ providedIn: 'root' })
export class IntegrationsDataService extends BaseDataService implements IntegrationsServiceInterface {

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    buildAdb2cIdToken(claims: object): Observable<any> {
        const url = `${this.webApiUrl}/azureadb2c/idtoken`;
        return this.createApiPost({ url, data: claims });
    }

    getMarcomIntegrations(): Observable<Integration[]> {
        const url = `${this.webApiUrl}/integration/marcom`;
        return this.createApiGet({ url });
    }
    
    saveIntegration(integration: Integration): Observable<Integration> {
        const integrationDto = integration;

        const url = `${this.webApiUrl}/integration`;
        return this.createApiPost({ url, data: integrationDto });
    }

    //TODO: Update the follow Observable<Setting> and Setting references to Integration
    toggleIntegrationStatus(integration: IntegrationSetting, enabled: boolean): Observable<Setting> {
        const dto = {
            key: integration.key,
            valueType: 0,
            boolValue: enabled
        };
        const url = `${this.webApiUrl}/settings/account`;
        return this.createApiPut({ url, data: dto });
    }
}