export interface CanvaConfig {
	clientSecret: string
}
