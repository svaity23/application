﻿using ApplicationLogic.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApi.Authorization;
using WebApi.Dtos;
using WebApi.Dtos.Asset.Request;
using WebApi.Extensions;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AuthorizePermissions(Scopes = new[] {"api", "asset.read", "public.api", "dam.api", "dam.public.api" })]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class LightboxAssetsController : ControllerBase
    {
        private readonly ILogger<LightboxAssetsController> _logger;
        private readonly IConfiguration _configuration;
        private readonly LightboxAssetService _lightboxAssetService;
        private readonly UserAccountService _userAccountService;


        public LightboxAssetsController(
            ILogger<LightboxAssetsController> logger,
            IConfiguration configuration,
            LightboxAssetService lightboxAssetService,
            UserAccountService userAccountService)
        {
            _logger = logger;
            _configuration = configuration;
            _lightboxAssetService = lightboxAssetService;
            _userAccountService = userAccountService;
        }
        /// <summary>
        /// Get lightbox assets
        /// </summary>
        /// <param name="sortField"></param>
        /// <param name="lightboxId"></param>
        /// <param name="skip"></param>
        /// <param name="pageSize"></param>
        /// <param name="isOnMyFavorites"></param>
        /// <returns></returns>
        [HttpGet]
        [ApiExplorerSettings(IgnoreApi = false)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<AssetDto>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]        
        public async Task<IActionResult> GetLigthboxAssetsAsync(int sortField, Guid? lightboxId, int skip, int pageSize, bool? isOnMyFavorites)
        {
            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();

            GetEntitiesResponse<AssetDto> results = await _lightboxAssetService.GetAccountAssetsAsync(accountId, userId, sortField, lightboxId, skip, pageSize, false, isOnMyFavorites.HasValue ? (bool)isOnMyFavorites : false);
            if (results != null)
            {
                int err = results.Error.Code;
                return err switch
                {
                    0 => Ok(results.Entities ?? new List<AssetDto>()),
                    3 => Forbid(),// the user doesn't have admin rights
                    _ => BadRequest(),// invalid json input for stored procedure
                };
            }
            return NotFound();
        }        

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UpsertLightboxAssetsResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateLightboxAssetsAsync([FromBody] UpsertLightboxAssetsRequest update)
        {
            if (update == null || update.Ids == null || update.LightboxId.Equals(Guid.Empty))
            {
                return BadRequest();
            }

            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();                     
            var result = await _lightboxAssetService.UpsertLightboxAssetsAsync(accountId, userId, update);
            return Ok(result);
        }

        [HttpPost("bulk/delete")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<Guid>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> DeleteLightboxAssetsAsync([FromBody]DeleteLightboxAssetsRequestDTO request)
        {
            if (request == null || request.AssetIds == null || request.LightboxId.Equals(Guid.Empty))
            {
                return BadRequest();
            }

            var accountId = await this.User.GetAccountIdAsync(HttpContext.Request, _userAccountService);
            var userId = this.User.GetUserId();           
            var results = await _lightboxAssetService.DeleteLightboxAssetsAsync(accountId, userId, request);
            return Ok(results);        
        }
    }
}
