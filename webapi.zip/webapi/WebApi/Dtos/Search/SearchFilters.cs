﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos.Search
{
    public class SearchFilters
    {
        public IEnumerable<SearchAggregationDto> Aggregations { get; set; }
        public IEnumerable<FilterGroup> Groups { get; set; }
    }
}
