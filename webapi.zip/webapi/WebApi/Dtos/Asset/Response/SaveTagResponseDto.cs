﻿using System;
using System.Text.Json.Serialization;

namespace WebApi.Dtos.Asset.Response
{
    public class SaveTagResponseDto
    {
        [JsonPropertyName("assetId")]
        public Guid AssetId { get; set; }

        [JsonPropertyName("modified")]
        public DateTime? Modified { get; set; }

        [JsonPropertyName("modifiedByUserFullName")]
        public string ModifiedByUserFullName { get; set; }

        [JsonPropertyName("values")]
        public string[] Values { get; set; }

        [JsonPropertyName("aiGeneratedValues")]
        public string[] AiGeneratedValues { get; set; }

        [JsonPropertyName("ocrGeneratedValues")]
        public string OcrGeneratedValues { get; set; }
    }
}
