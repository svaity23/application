﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WebApi.Dtos
{
    public class LightboxAssetDto
    {
        [JsonPropertyName("id")]
        public Guid Id { get; set; }
        [JsonPropertyName("accountId")]
        public Guid AccountId { get; set; }
        [JsonPropertyName("active")]
        public bool Active { get; set; }
        [JsonPropertyName("attachment")]
        public AttachmentDto Attachment { get; set; }
        [JsonPropertyName("created")]
        public DateTime Created { get; set; }
        [JsonPropertyName("modified")]
        public DateTime? Modified { get; set; }
        [JsonPropertyName("fileName")]
        public string FileName { get; set; }
        [JsonPropertyName("lightboxId")]
        public Guid? LightboxId { get; set; }
        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("description")]
        public string Description { get; set; }
        [JsonPropertyName("fileSize")]
        public long? FileSize { get; set; }
        [JsonPropertyName("fileGroup")]
        public int? FileGroup { get; set; }
        [JsonPropertyName("fileExtension")]
        public string FileExtension { get; set; }
    }
}
