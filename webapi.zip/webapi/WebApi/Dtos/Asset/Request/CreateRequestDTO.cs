﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos.Asset.Request
{
    public class CreateRequestDTO
    {
        public AssetDto[] Assets { get; set; }
    }
}
