﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApi.Dtos;
using WebApi.Dtos.Asset;
using WebApi.Dtos.Asset.Request;
using WebApi.Dtos.Search;
using WebApi.Enums;
using WebApi.Extensions;

namespace WebApi.Services
{
    public class LightboxAssetService
    {
        private readonly LightboxAssetLogic _lightboxAssetLogic;
        private readonly ServiceBusService _serviceBusService;
        private readonly LightboxLogic _lightboxLogic;
        private readonly BlobService _blobService;
        private readonly IConfiguration _configuration;

        public LightboxAssetService(ServiceBusService serviceBusService, damContext context, IConfiguration configuration, BlobService blobService)
        {

            _lightboxAssetLogic = new LightboxAssetLogic(context);
            _lightboxLogic = new LightboxLogic(context);
            _serviceBusService = serviceBusService;
            _blobService = blobService;
            _configuration = configuration;
        }

        public async Task<GetEntitiesResponse<AssetDto>> GetAccountAssetsAsync(Guid accountId, Guid userId, int sortField, Guid? lightboxId, int skip, int pageSize, bool includeInactive = false, bool isOnMyFavorites = false)
        {
            var assetListParams = new LightboxAssetListParamsDto
            {
                SortField = sortField,
                LightboxId = lightboxId,
                Skip = skip,
                PageSize = pageSize,
                IncludeInactive = includeInactive,
                IsOnMyFavorites = isOnMyFavorites
            };
            var jsonString = assetListParams.ToJsonString();
            var jsonOutput = await _lightboxAssetLogic.GetByAccountIdAsync(accountId, userId, jsonString);

            GetEntitiesResponse<AssetDto> result = Newtonsoft.Json.JsonConvert.DeserializeObject<GetEntitiesResponse<AssetDto>>(jsonOutput);
            return result;
        }

        public async Task<GetEntitiesResponse<AssetDto>> GetLightboxPublicAssetsAsync(Guid id, int sortField, int skip, int pageSize)
        {
            // Get assets inside lightbox
            var listParams = new LightboxAssetListParamsDto
            {
                SortField = sortField,
                LightboxId = id,
                Skip = skip,
                PageSize = pageSize,
                IncludeInactive = false
            };
            var jsonString = listParams.ToJsonString();
            var jsonOutputAssets = await _lightboxAssetLogic.GetLightboxAssetsById(id, jsonString);
            GetEntitiesResponse<AssetDto> lightboxAssets = Newtonsoft.Json.JsonConvert.DeserializeObject<GetEntitiesResponse<AssetDto>>(jsonOutputAssets);

            return lightboxAssets;
        }

        public async Task<LightboxAssetDto> GetAssetForPreviewAsync(Guid accountId, Guid assetId, Guid lightboxId)
        {
            var jsonOutput = await _lightboxAssetLogic.GetAssetForPreviewAsync(accountId, assetId, lightboxId);
            return JsonConvert.DeserializeObject<LightboxAssetDto>(jsonOutput);
        }
        public async Task<UpsertLightboxAssetsResponse> UpsertLightboxAssetsAsync(Guid accountId, Guid userId, UpsertLightboxAssetsRequest updateAssetRequest)
        {
            var jsonString = updateAssetRequest.ToJsonString();
            var upsertResponse = await _lightboxAssetLogic.UpsertLightboxAssetsAsync(accountId, userId, jsonString);
            var result = Newtonsoft.Json.JsonConvert.DeserializeObject<UpsertLightboxAssetsResponse>(upsertResponse);
            await _serviceBusService.SignalIndexAsset(new
            {
                MessageType = ServiceBusMessageType.ASSETS_MODIFIED,
                AccountId = accountId.ToString(),
                AssetIds = updateAssetRequest.Ids
            });
            return result;
        }
        
        public async Task<List<Guid>> DeleteLightboxAssetsAsync(Guid accountId, Guid userId, DeleteLightboxAssetsRequestDTO request)
        {
            var jsonString = request.ToJsonString();
            var deleteResponse = await _lightboxAssetLogic.DeleteAssetsAsync(accountId, userId, jsonString);
            var result = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Guid>>(deleteResponse);
            await _serviceBusService.SignalIndexAsset(new
            {
                MessageType = ServiceBusMessageType.ASSETS_MODIFIED,
                AccountId = accountId.ToString(),
                AssetIds = result
            });
            return result;
        }
    }
}
