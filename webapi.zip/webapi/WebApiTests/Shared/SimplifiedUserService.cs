﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApi.Dtos;

namespace WebApiTests.Shared
{
    public class SimplifiedUserService
    {
        private UserLogic _userLogic;

        public SimplifiedUserService(damContext context)
        {
            _userLogic = new UserLogic(context);
        }

        public async Task<List<UserDetailDto>> GetByAccountIdAsync(Guid accountId, bool includeInactive = false)
        {
            var users = await _userLogic.GetByAccountIdAsync(accountId, includeInactive);
            var result = JsonConvert.DeserializeObject<List<UserDetailDto>>(users);
            return result;
        }
    }
}
