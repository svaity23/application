import { Metadata } from './entities/metadata.model';
import { MetadataField } from './entities/metadata-field.model';
import { MetadataFieldValue } from './entities/metadata-field-value.model';

export interface MetadataFieldAndValue {
    metadata: Metadata[];
    metadataField: MetadataField;
    metadataFieldValues: MetadataFieldValue[];
    metadataToModify: Metadata[];
}
