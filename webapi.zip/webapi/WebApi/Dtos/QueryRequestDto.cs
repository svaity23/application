﻿using System;
using WebApi.Dtos.Search;

namespace WebApi.Dtos
{
    public class QueryRequestDto
    {
        public FilterRequest[] FilterRequests { get; set; }
        public int SortField { get; set; }
        public Guid? CollectionId { get; set; }
        public int Skip { get; set; }
        public int PageSize { get; set; }
        public string SearchTerm { get; set; }
        public bool IncludeFilters { get; set; } = true;
        public bool SearchFavorites { get; set; } = false;
        public Guid? LightboxId { get; set; }
        public bool SearchExpiredAssets { get; set; } = false;
        public bool SearchCleanupAssets { get; set; } = false;
    }
}
