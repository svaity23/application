﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos
{
    public class MetadataFieldValueDto
    {
        public Guid? AccountId { get; set; }
        public Guid? Id { get; set; }
        public bool Active { get; set; }
        public Guid MetadataFieldId { get; set; }
        public string Value { get; set; }
        public Guid Previous { get; set; }
    }
}
