﻿using Microsoft.AspNetCore.Authorization;
using System;

namespace WebApi.Authorization
{
    public class AuthorizePermissionsAttribute: AuthorizeAttribute
    {
        public const string RolesGroup = "Roles";
        public const string ScopesGroup = "Scopes";

        private string[] _scopes;
        private string[] _roles;

        //_isDefault precaution as if the Policy is set explicitly
        // then we'll want to clear it out before setting our custom policy
        private bool _isDefault = true;

        public AuthorizePermissionsAttribute()
        {
            _roles = Array.Empty<string>();
            _scopes = Array.Empty<string>();
        }

        public string[] Scopes
        {
            get => _scopes;
            set
            {
                BuildPolicy(ref _scopes, value, ScopesGroup);
            }
        }

        new public string[] Roles
        {
            get => _roles;
            set
            {
                BuildPolicy(ref _roles, value, RolesGroup);
            }
        }

        private void BuildPolicy(ref string[] target, string[] value, string group)
        {
            target = value ?? Array.Empty<string>();

            if (_isDefault)
            {
                Policy = string.Empty;
                _isDefault = false;
            }

            Policy += $"{group}${string.Join("|", target)};";
        }
    }
}
