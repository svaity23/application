import { cn } from 'src/utils/cn';
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';


import { AccountIntegrationFeature } from '@app/core/models/account-integration-feature.model';
import { Feature } from '@app/core/models/feature.model';
import { FeatureKey } from '@app/core/enums/feature-key.enum';

@Component({
  selector: 'app-account-integrations',
  templateUrl: './account-integrations.component.html',
  styleUrls: ['./account-integrations.component.scss']
})
export class AccountIntegrationsComponent implements OnInit, OnChanges {
  @Input() accountFeatures: Feature[];
  @Input() className = '';
  @Output() featuresChange: EventEmitter<Feature[]> = new EventEmitter<Feature[]>();
  icons: number[] = [];
  integrationsListToDisplay: AccountIntegrationFeature[] = [];

  show = false;
  sortField = 'name';
  sortOrder = 'asc';

  private featuresToModify: Feature[];

  constructor() { }

  getLogo(integration: AccountIntegrationFeature): string {
    return 'assets/img/' + integration.logo + '.svg';
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.accountFeatures) {
      this.featuresToModify = [...changes.accountFeatures.currentValue];
      this.integrationsListToDisplay = this.prepareIntegrationListToDisplay();
    }
  }

  ngOnInit(): void {
    this.className = cn('integration-list', this.className);
  }

  prepareIntegrationListToDisplay(): AccountIntegrationFeature[] {

    const integrationsList: AccountIntegrationFeature[] = [];

    const hubspotAccountIntegrationFeature: AccountIntegrationFeature = {
      key: FeatureKey.Hubspot,
      enabled: this.isAccountFeatureEnabled(FeatureKey.Hubspot), // todo merge and get new features
      name: 'HubSpot',
      description: 'Enables option for users to share collections to HubSpot.',
      logo: 'logo-hubspot'
    }
    integrationsList.push(hubspotAccountIntegrationFeature);

    const marcomPortalAssetIntegrationFeature: AccountIntegrationFeature = {
      key: FeatureKey.MarcomPortalAsset,
      enabled: this.isAccountFeatureEnabled(FeatureKey.MarcomPortalAsset),
      name: 'MarcomCentral',
      description: 'Enables option to configure MarcomCentral Asset Integration.',
      logo: 'MCC_PrimaryLogo'
    }
    integrationsList.push(marcomPortalAssetIntegrationFeature);

    const marcomPortalLibraryIntegrationFeature: AccountIntegrationFeature = {
      key: FeatureKey.MarcomPortalLibrary,
      enabled: this.isAccountFeatureEnabled(FeatureKey.MarcomPortalLibrary),
      name: 'MarcomCentral',
      description: 'Enables option to configure MarcomCentral Library Integration.',
      logo: 'MCC_PrimaryLogo'
    }
    integrationsList.push(marcomPortalLibraryIntegrationFeature);

    const MicrosoftLoginAccountIntegrationFeature: AccountIntegrationFeature = {
      key: FeatureKey.MicrosoftSso,
      enabled: this.isAccountFeatureEnabled(FeatureKey.MicrosoftSso),
      name: 'Microsoft',
      description: 'Allows anyone within your organization to login using their Microsoft credentials. Approval by your Microsoft Account Admin is needed to complete this integration.',
      logo: 'logo-microsoft'
    }
    integrationsList.push(MicrosoftLoginAccountIntegrationFeature);

    const slackIntegration: AccountIntegrationFeature = {
      key: FeatureKey.Slack,
      enabled: this.isAccountFeatureEnabled(FeatureKey.Slack),
      name: 'Slack',
      description: 'Enables option for users to share assets to Slack. User will be prompted to authorize the access prior to sharing.',
      logo: 'logo-slack'
    }
    integrationsList.push(slackIntegration);

    const wordpressAccountIntegrationFeature: AccountIntegrationFeature = {
      key: FeatureKey.Wordpress,
      enabled: this.isAccountFeatureEnabled(FeatureKey.Wordpress),
      name: 'Wordpress',
      description: 'Allows access to use the MarcomGather plugin in WordPress.',
      logo: 'logo-wordpress'
    }
    integrationsList.push(wordpressAccountIntegrationFeature);

    return integrationsList;
  }

  sort(columnName: string): void {
    // toggle sort order if already selected
    if (this.sortField === columnName) {
      this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortField = columnName;
      this.sortOrder = 'asc';
    }
    // setup the evaluation
    const v1 = this.sortOrder === 'asc' ? 1 : -1;
    const v2 = this.sortOrder === 'asc' ? -1 : 1;
    switch (this.sortField) {
      case 'name':
        this.integrationsListToDisplay.sort((s1, s2) => s1.name.toLocaleLowerCase() > s2.name.toLocaleLowerCase() ? v1 : v2);
        break;
      case 'description':
        this.integrationsListToDisplay.sort((s1, s2) =>
          this.getDescription(s1).toLocaleLowerCase() > this.getDescription(s2).toLocaleLowerCase() ? v1 : v2);
        break;
      default:
    }
  }

  toggleIntegration(integration: AccountIntegrationFeature): void {
    const featureIndex = this.featuresToModify.findIndex(f => f.key === integration.key);
    if (featureIndex > -1) {
      this.featuresToModify.splice(featureIndex, 1);
      integration.enabled = false;
    } else {
      const feature: Feature = { key: integration.key };
      this.featuresToModify.push(feature)
      integration.enabled = true;
    }

    this.featuresChange.emit(this.featuresToModify);
  }

  private getDescription(integration: AccountIntegrationFeature): string {
    return (integration.description) ? integration.description : '';
  }

  private isAccountFeatureEnabled(featureKey: FeatureKey): boolean {
    return this?.featuresToModify?.find(n => n.key === featureKey) != null;
  }

}
