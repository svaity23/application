export interface HubspotCollectionActionResponse {
    assetCount: number;
 }