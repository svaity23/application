import { CustomTheme } from '../custom-theme.model';

export interface UploadUsersModalOptions {
  cancel: () => void;
  cancelButtonText: string;
  confirm: () => void;
  confirmButtonText: string;
  selectedTheme?: CustomTheme;
  title: string;
}
