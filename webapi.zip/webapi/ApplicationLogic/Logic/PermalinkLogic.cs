﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Threading.Tasks;


namespace ApplicationLogic.Logic
{
    public class PermalinkLogic
    {
        public ILogger<PermalinkLogic> Logger { get; set; }

        private readonly PermalinkFinder _finder;

        public PermalinkLogic(damContext context)
        {
            _finder = new PermalinkFinder(context);
            Logger = NullLogger<PermalinkLogic>.Instance;            
        }

        public async Task<string> SavePermalinkAsync(Guid accountId, Guid userId, Guid sessionId, string jsonInput)
        {
            return await _finder.SavePermalinkAsync(accountId, userId, sessionId, jsonInput);          
        }
     
    }
}
