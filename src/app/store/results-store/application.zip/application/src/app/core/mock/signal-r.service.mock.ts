import { Injectable } from '@angular/core';

import { Observable, of, Subject } from 'rxjs';

import { HubConnectionState } from '@microsoft/signalr';

import { BasePayload } from '../models/signal-r-payloads/base-payload.model';
import { ISignalRService } from '../services/signal-r.service';

@Injectable({ providedIn: 'root' })
export class SignalRServiceMock implements ISignalRService {

	private connectionSubject = new Subject<{connectionId: string, connectionState: HubConnectionState}>();
	private payloadReceivedSubject = new Subject<BasePayload>();

	constructor() { }

	broadcast(_args: BasePayload): void {
		throw new Error('Method not implemented.');
	}

	getConnection(): Observable<{connectionId: string, connectionState: HubConnectionState}> {
		return this.connectionSubject.asObservable();
	}

	payloadReceived(): Observable<BasePayload> {
		return this.payloadReceivedSubject.asObservable();
	}

	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	startConnection(): Observable<any> {
		return of('');
	}
}
