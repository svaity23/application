﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using WebApi.Dtos.Notification;
using WebApi.Dtos.Setting;

namespace WebApi.Dtos.Context
{
    public class UserContextDto
    {
        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [JsonPropertyName("firstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("lastName")]
        public string LastName { get; set; }

        [JsonPropertyName("email")]
        public string Email { get; set; }

        [JsonPropertyName("emailVerified")]
        public bool EmailVerified { get; set; }

        [JsonPropertyName("federated")]
        public bool? Federated { get; set; }

        [JsonPropertyName("userSalesforceId")]
        public string UserSalesforceId { get; set; }

        [JsonPropertyName("accountId")]
        public Guid? AccountId { get; set; }

        [JsonPropertyName("accountName")]
        public string AccountName { get; set; }

        [JsonPropertyName("accountActive")]
        public bool? AccountActive { get; set; }

        [JsonPropertyName("accountTrialExpiration")]
        public DateTime? AccountTrialExpiration { get; set; }

        [JsonPropertyName("accountTrialVerified")]
        public bool? AccountTrialVerified { get; set; }

        [JsonPropertyName("accountLogo")]
        public string AccountLogo { get; set; }

        [JsonPropertyName("accountFavicon")]
        public string AccountFavicon { get; set; }

        [JsonPropertyName("accountTheme")]
        public string AccountTheme { get; set; }

        [JsonPropertyName("accountTypeName")]
        public string AccountTypeName { get; set; }

        [JsonPropertyName("storageAccountName")]
        public string StorageAccountName { get; set; }

        [JsonPropertyName("accountStorageMaximumGb")]
        public int? AccountStorageMaximumGb { get; set; }

        [JsonPropertyName("accountStorageUsed")]
        public long? AccountStorageUsed { get; set; }

        [JsonPropertyName("accountSalesforceId")]
        public string AccountSalesforceId { get; set; }

        [JsonPropertyName("accountUserEmail")]
        public string AccountUserEmail { get; set; }

        [JsonPropertyName("groupId")]
        public Guid? GroupId { get; set; }

        [JsonPropertyName("legalDocuments")]
        public List<LegalDocumentDto> LegalDocuments { get; set; }

        [JsonPropertyName("notifications")]
        public List<NotificationDto> Notifications { get; set; }

        [JsonPropertyName("federatedDomains")]
        public List<FederatedDomainDto> FederatedDomains { get; set; }

        [JsonPropertyName("frontEndSettings")]
        public SettingsDto FrontEndSettings { get; set; }

        [JsonPropertyName("totalFavorites")]
        public int? TotalFavorites { get; set; }
        [JsonPropertyName("totalExpiredAssets")]
        public int? TotalExpiredAssets { get; set; }

        [JsonPropertyName("totalCleanUpAssets")]
        public int? TotalCleanUpAssets { get; set; }

        [JsonPropertyName("permissions")]
        public List<PermissionDto> Permissions { get; set; }

        [JsonPropertyName("features")]
        public List<FeatureDto> Features { get; set; }

        [JsonPropertyName("roleKey")]
        public string RoleKey { get; set; }

        [JsonPropertyName("roleName")]
        public string RoleName { get; set; }
    }
}
