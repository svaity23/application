﻿using Marcom.Azure.ServiceBus.Config;

namespace SignalRHub
{
    public class BusReceiveServiceConfig
    {
        //public static readonly string SectionName = "ImageProcessedServiceBus";
        public string EndPoint { get; set; }
        public string TopicName { get; set; }
        public string SubscriptionName { get; set; }
        public SubscriptionOptions SubscriptionOptions { get; set; }
    }
}
