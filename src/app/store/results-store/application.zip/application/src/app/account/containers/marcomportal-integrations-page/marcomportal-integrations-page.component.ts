import { AfterViewInit, ChangeDetectionStrategy, Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Observable } from 'rxjs';

import { AccountStoreFacade } from '@app/store/account-store/account-store.facade';
import { AppStoreFacade } from '@app/store/app-store/app-store.facade';

import { Integration } from '@app/core/models/integrations/integration.model';
import { MarcomIntegrationFacade } from '@app/store/account-store/marcom-integration-facade';

@Component({
  selector: 'app-marcomportal-integrations-page',
  templateUrl: './marcomportal-integrations-page.component.html',
  styleUrls: ['./marcomportal-integrations-page.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MarcomPortalIntegrationsPageComponent implements OnInit, AfterViewInit {

  accountTypeName$: Observable<string>;
  assetIntegration$: Observable<Integration>;    
  assetIntegrationTouchedStatus$: Observable<boolean>;
  isMarcomPortalAssetFeatureEnabled$: Observable<boolean>;
  isMarcomPortalLibraryFeatureEnabled$: Observable<boolean>;
  libraryIntegration$: Observable<Integration>;
  libraryIntegrationTouchedStatus$: Observable<boolean>;
  resetAssetScreen = false;
  resetLibraryScreen = false;
  selectedTab: string;
  showIntegrations$: Observable<boolean>;
  showUserGroups$: Observable<boolean>;  

  private assetIntegrationLoaded = false;
  private libraryIntegrationLoaded = false;
  
  constructor(
    private accountStoreFacade: AccountStoreFacade,
    private appStoreFacade: AppStoreFacade,
    private marcomIntegrationFacade: MarcomIntegrationFacade,
  ) { }
  
  cancelChanges() {
    // reset toModify objects
    switch (this.selectedTab) {
      case 'library-integration':
        this.marcomIntegrationFacade.resetMarcomLibraryIntegrationToModify();
        break;
      case 'asset-integration':
        this.marcomIntegrationFacade.resetMarcomAssetIntegrationToModify();
        break;
    }
  }

  changeTabs(value: string): void {
    if (value === this.selectedTab) {
      // same tab do nothing
      console.log('same tab');
      return;
    }

    this.marcomIntegrationFacade.verifyUnsavedMarcomIntegrationChangesAndChangeTabs(
      () => { this.selectedTab = value; },
      () => { this.cancelChanges(); this.reloadTabContents(value); },
      () => { }
    );
  }

  navigateTo(pageName: string): void {
    console.log(pageName);
    this.appStoreFacade.navigate(`account/${pageName}`);
  }


  // after all the child components are loaded, decide
  ngAfterViewInit(): void {
    if (this.libraryIntegrationLoaded) {
      this.selectedTab = 'library-integration';
    }
    else if (this.assetIntegrationLoaded) {
      this.selectedTab = 'asset-integration';
    }
  }

  ngOnInit(): void {
    this.appStoreFacade.setPageTitle('MarcomCentral Integrations');
    this.accountStoreFacade.marcomIntegrationFacade.getMarcomIntegrations();
    this.accountTypeName$ = this.appStoreFacade.accountTypeName$;
    this.isMarcomPortalAssetFeatureEnabled$ = this.appStoreFacade.context.isMarcomPortalAssetFeatureEnabled$;
    this.isMarcomPortalLibraryFeatureEnabled$ = this.appStoreFacade.context.isMarcomPortalLibraryFeatureEnabled$;
    this.libraryIntegration$ = this.accountStoreFacade.marcomIntegrationFacade.marcomLibraryIntegration$;
    this.libraryIntegrationTouchedStatus$ = this.marcomIntegrationFacade.marcomLibraryIntegrationTouchedStatus$;
    this.assetIntegration$ = this.accountStoreFacade.marcomIntegrationFacade.marcomAssetIntegration$;
    this.assetIntegrationTouchedStatus$ = this.marcomIntegrationFacade.marcomAssetIntegrationTouchedStatus$;
    this.showIntegrations$ = this.appStoreFacade.showIntegrations$;
    this.showUserGroups$ = this.appStoreFacade.context.isUserGroupsFeatureEnabled$;
  }

  onAssetComponentLoad() {
    this.assetIntegrationLoaded = true;
  }

  onCancelChanges(): void {
    this.marcomIntegrationFacade.resetMarcomLibraryIntegrationToModify();
    this.marcomIntegrationFacade.resetMarcomAssetIntegrationToModify();
    this.appStoreFacade.navigate('account/integrations');
  }

  onLibraryComponentLoad() {
    this.libraryIntegrationLoaded = true;
  }

  onSaveChanges(): void {
    switch (this.selectedTab) {
      case 'library-integration':
        this.marcomIntegrationFacade.saveMarcomLibraryIntegration();        
        break;
      case 'asset-integration':
        this.marcomIntegrationFacade.saveMarcomAssetIntegration();
        break;
    }
  }


  updateMarcomAssetIntegrationToModify(integration: Integration): void {
    this.marcomIntegrationFacade.updateMarcomAssetIntegrationToModify(integration);
    this.resetAssetScreen = false;
  }

  updateMarcomLibraryIntegrationToModify(integration: Integration): void {
    this.marcomIntegrationFacade.updateMarcomLibraryIntegrationToModify(integration);
    this.resetLibraryScreen = false;
  }  

  private reloadTabContents(value: string) {
    switch (this.selectedTab) {
      case 'library-integration':
        this.resetLibraryScreen = true;
        break;
      case 'asset-integration':
        this.resetAssetScreen = true;
        break;
    }
    this.selectedTab = value;
  }
}
