﻿using Azure.Security.KeyVault.Secrets;
using Marcom.Azure.ServiceBus;
using Marcom.Azure.ServiceBus.Config;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using WebApi.Services;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AllowAnonymous]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class StatusController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<StatusController> _logger;
        private readonly IBusServiceFactory _busServiceFactory;
        private readonly RoleService _roleService;
        private readonly BlobService _blobService;
        private readonly AssetService _assetService;
        private readonly AzureStorageService _azureStorageService;
        private readonly Common.Health _health;
        private readonly SecretClient _secretClient;


        public StatusController(IConfiguration configuration
                                , ILogger<StatusController> logger
                                , IBusServiceFactory busServiceFactory
                                , RoleService roleService
                                , BlobService blobService
                                , AssetService assetService
                                , AzureStorageService azureStorageService
                                , Common.Health health
                                , SecretClient secretClient)
        {
            _configuration = configuration;
            _logger = logger;
            _busServiceFactory = busServiceFactory;
            _roleService = roleService;
            _blobService = blobService;
            _assetService = assetService;
            _azureStorageService = azureStorageService;
            _health = health;
            _secretClient = secretClient;
        }

        [HttpGet]
        [Route("livez")]
        public IActionResult TestLivez()
        {
            _logger.LogInformation(">>>>>>>BEGIN: livenessProbe");

            if (_health.Live == false)
            {
                _logger.LogInformation(">>>>>>>End: (Failure) livenessProbe");
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

            _logger.LogInformation(">>>>>>>End: (Success) livenessProbe");

            return StatusCode(StatusCodes.Status200OK);
        }

        // temporary to test out force recycling pods
        [HttpGet]
        [Route("readyz")]
        public IActionResult TestReadyz()
        {
            _logger.LogInformation(">>>>>>>BEGIN: readinessProbe (ready)");

            if (_health.Ready == false)
            {
                _logger.LogInformation(">>>>>>>End: (Failure) readinessProbe");
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

            _logger.LogInformation(">>>>>>>End: (Success) readinessProbe");

            return StatusCode(StatusCodes.Status200OK);
        }

        [HttpGet]
        [Route("all")]
        public async Task<JsonResult> TestAll()
        {
            _logger.LogInformation("BEGIN: Test All");

            var ok = "OK";
            var fail = "FAIL";
            var verbose = "verbose";
            var errTrimLength = 160;
            var errTrimLengthKV = 70;

            var p = Request.QueryString.Value;

            var database = await TestDatabase();
            var serviceBus = await TestServiceBus();
            var blobStorage = await TestBlobStorage();
            var keyVault = await TestKeyVault();

            if (Request.QueryString.Value.ToLower().Contains(verbose))
            {
                var statusResult = new
                {
                    Database = database.error ? database.errorMessage.Substring(0, errTrimLength) : ok,
                    ServiceBus = serviceBus.error ? serviceBus.errorMessage.Substring(0, errTrimLength) : ok,
                    BlobStorage = blobStorage.error ? blobStorage.errorMessage.Substring(0, errTrimLength) : ok,
                    KeyVault = keyVault.error ? keyVault.errorMessage.Substring(0, errTrimLengthKV) : ok
                };

                _logger.LogInformation("END: All");
                return new JsonResult(statusResult, new JsonSerializerOptions() { WriteIndented = true });
            }
            else
            {
                string status = (database.error || serviceBus.error || blobStorage.error || keyVault.error) ? fail : ok;
                var statusResult = new { status = status };

                _logger.LogInformation("END: All");
                return new JsonResult(statusResult, new JsonSerializerOptions() { WriteIndented = true });
            }
        }

        [HttpGet]
        public IActionResult TestStatusCode(int? statusCode)
        {
            _logger.LogInformation($"return statusCode {statusCode}");

            string successMsg = $@"
                ******************************************************
                * /status hit at {DateTime.Now}                      
                ******************************************************";
            _logger.LogInformation(successMsg);

            if (!statusCode.HasValue)
                return Ok();

            return StatusCode(statusCode.Value);
        }

        [HttpGet]
        [Route("db")]
        public async Task<IActionResult> TestDatabaseEndpoint()
        {
            _logger.LogInformation("BEGIN: TestDatabase");

            var result = await TestDatabase();
            if (result.error)
            {
                _logger.LogError(result.errorMessage);
                return StatusCode(StatusCodes.Status500InternalServerError, result.errorMessage);
            }
            _logger.LogInformation("END: TestDatabase");
            return Content($"Successful Database test at { DateTime.UtcNow} ");
        }


        [HttpGet]
        [Route("sbac")]
        public async Task<IActionResult> TestServiceBusAssetConsolidationTopic()
        {
            _logger.LogInformation("BEGIN: TestServiceBusAssetConsolidationTopic");
            var accountId = Guid.Parse("8D42A5D8-5262-410E-A7C4-930FE6013416");
            var msg = new
            {
                AccountId = accountId
            };

            try
            {
                var busService = _busServiceFactory.CreateBusSendService(
                    _configuration["AssetConsolidationServiceBus:Endpoint"],
                    _configuration["AssetConsolidationServiceBus:TopicName"],
                new ServiceBusSendSettings
                {
                    ComputerName = _configuration["COMPUTERNAME"],
                    Environment = _configuration["DotnetEnvironment"],
                    TargetMachines = _configuration.Get<TargetMachineConfig>().TargetMachines
                });

                _logger.LogInformation("BEGIN: SendAsync");
                await busService.SendAsync(msg);
                _logger.LogInformation("END: (success) SendAsync");
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _logger.LogError(ex, "error testing service bus");
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }

            _logger.LogInformation("END: TestServiceBusAssetConsolidationTopic (success)");
            return Content($"Service Bus successful test at {DateTime.Now}");
        }

        [HttpGet]
        [Route("sb")]
        public async Task<IActionResult> TestServiceBusEndpoint()
        {
            _logger.LogInformation("BEGIN: TestServiceBus");

            var result = await TestServiceBus();
            if (result.error)
            {
                _logger.LogError(result.errorMessage);
                return StatusCode(StatusCodes.Status500InternalServerError, result.errorMessage);
            }

            _logger.LogInformation("END: TestServiceBus (success)");
            return Content($"Successful Service Bus test at { DateTime.UtcNow} ");
        }

        [HttpGet]
        [Route("sbc")]
        public async Task<IActionResult> TestServiceBusCancelUpload()
        {
            _logger.LogInformation("BEGIN: TestServiceBusCancelUpload");

            IActionResult actionResult;

            try
            {
                var busService = _busServiceFactory.CreateBusSendService(
                    _configuration["ImageUploadedServiceBus:Endpoint"],
                    _configuration["ImageUploadedServiceBus:TopicName"],
                    new ServiceBusSendSettings
                    {
                        ComputerName = _configuration["COMPUTERNAME"],
                        Environment = _configuration["DotnetEnvironment"],
                        TargetMachines = _configuration.Get<TargetMachineConfig>().TargetMachines
                    }
                );

                var msg = new //cancelUploadWorker
                {
                    MessageType = "TEST_STARTED",
                    TestId = Guid.NewGuid().ToString()
                };
                actionResult = await TestServiceBusSendAsync(busService, msg, msg.TestId, "cancelUploadWorker");
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _logger.LogError(ex, "error testing service bus");
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }

            _logger.LogInformation("END: TestServiceBusCancelUpload (success)");
            return actionResult;
        }


        [HttpGet]
        [Route("sbe")]
        public async Task<IActionResult> TestServiceBusSendEmail()
        {
            _logger.LogInformation("BEGIN: TestServiceBusSendEmail");

            IActionResult actionResult;

            try
            {
                var busService = _busServiceFactory.CreateBusSendService(
                    _configuration["SendEmailServiceBus:Endpoint"],
                    _configuration["SendEmailServiceBus:TopicName"],
                    new ServiceBusSendSettings
                    {
                        ComputerName = _configuration["COMPUTERNAME"],
                        Environment = _configuration["DotnetEnvironment"],
                        TargetMachines = _configuration.Get<TargetMachineConfig>().TargetMachines
                    }
                );

                var msg = new
                {
                    MessageType = "TEST_SEND_EMAIL",
                    TestId = Guid.NewGuid().ToString()
                };
                actionResult = await TestServiceBusSendAsync(busService, msg, msg.TestId, "sendEmailWorker");
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _logger.LogError(ex, "error testing service bus");
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }

            _logger.LogInformation("END: TestServiceBusSendEmail (success)");
            return actionResult;
        }

        [HttpGet]
        [Route("dm")]
        public async Task<IActionResult> TestServiceBusDistributedMarketing()
        {
            _logger.LogInformation("BEGIN: TestServiceBusUserSync");

            IActionResult actionResult;

            try
            {
                var busService = _busServiceFactory.CreateBusSendService(
                    _configuration["DistributedMarketingServiceBus:Endpoint"],
                    _configuration["DistributedMarketingServiceBus:TopicName"],
                    new ServiceBusSendSettings
                    {
                        ComputerName = _configuration["COMPUTERNAME"],
                        Environment = _configuration["DotnetEnvironment"],
                        TargetMachines = _configuration.Get<TargetMachineConfig>().TargetMachines
                    }
                );

                var msg = new
                {
                    Action = "MARCOM_PORTAL_TOKEN_CONFIGURATION",
                    TestId = Guid.NewGuid().ToString(),
                    Token = "4F2C275BA5557C5E542375A21633A8D3",
                    AccountId = new Guid("335C604E-545E-488E-BF99-6BFE94661415")
                };
                actionResult = await TestServiceBusSendAsync(busService, msg, msg.TestId, "distributedMarketingWorker");
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _logger.LogError(ex, "error testing service bus");
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }

            _logger.LogInformation("END: TestServiceBusUserSync (success)");
            return actionResult;
        }

        [HttpGet]
        [Route("sbu")]
        public async Task<IActionResult> TestServiceBusUserSync()
        {
            _logger.LogInformation("BEGIN: TestServiceBusUserSync");

            IActionResult actionResult;

            try
            {
                var busService = _busServiceFactory.CreateBusSendService(
                    _configuration["UserSyncServiceBus:Endpoint"],
                    _configuration["UserSyncServiceBus:TopicName"],
                    new ServiceBusSendSettings
                    {
                        ComputerName = _configuration["COMPUTERNAME"],
                        Environment = _configuration["DotnetEnvironment"],
                        TargetMachines = _configuration.Get<TargetMachineConfig>().TargetMachines
                    }
                );

                var msg = new
                {
                    Action = "TEST_STARTED",
                    TestId = Guid.NewGuid().ToString(),
                    Id = Guid.NewGuid().ToString()
                };
                actionResult = await TestServiceBusSendAsync(busService, msg, msg.Id, "userSyncWorker");
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _logger.LogError(ex, "error testing service bus");
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }

            _logger.LogInformation("END: TestServiceBusUserSync (success)");
            return actionResult;
        }

        [HttpGet]
        [Route("sbs")]
        public async Task<IActionResult> TestServiceBusSignalRHub()
        {
            _logger.LogInformation("BEGIN: TestServiceBusSignalRHub");

            IActionResult actionResult;

            try
            {
                // Hack? -- leveraging image-processed topic so signalRHub can catch and process
                var busService = _busServiceFactory.CreateBusSendService(
                    _configuration["ImageProcessedServiceBus:Endpoint"],
                    _configuration["ImageProcessedServiceBus:TopicName"],
                    new ServiceBusSendSettings
                    {
                        ComputerName = _configuration["COMPUTERNAME"],
                        Environment = _configuration["DotnetEnvironment"],
                        TargetMachines = _configuration.Get<TargetMachineConfig>().TargetMachines
                    }
                );

                var msg = new
                {
                    MessageType = "TEST_STARTED",
                    TestMessage = new
                    {
                        TestId = Guid.NewGuid().ToString()
                    }
                };
                actionResult = await TestServiceBusSendAsync(busService, msg, msg.TestMessage.TestId, "signalRHubWorker");
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _logger.LogError(ex, "error testing service bus");
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }

            _logger.LogInformation("END: TestServiceBusSignalRHub (success)");
            return actionResult;
        }

        [HttpGet]
        [Route("sbz")]
        public async Task<IActionResult> TestServiceBusShareZip()
        {
            _logger.LogInformation("BEGIN: TestServiceBusShareZip");

            IActionResult actionResult;

            try
            {
                var busService = _busServiceFactory.CreateBusSendService(
                    _configuration["ShareAssetServiceBus:Endpoint"],
                    _configuration["ShareAssetServiceBus:TopicName"],
                    new ServiceBusSendSettings
                    {
                        ComputerName = _configuration["COMPUTERNAME"],
                        Environment = _configuration["DotnetEnvironment"],
                        TargetMachines = _configuration.Get<TargetMachineConfig>().TargetMachines
                    }
                );

                ////TODO:  Test message, uncomment after testing is done. 
                //var msg = new
                //{
                //    MessageType = "TEST_STARTED",
                //    Id = Guid.NewGuid().ToString(),
                //    Action = "TEST_STARTED"
                //};
                var accountId = Guid.Parse("D35BF9DC-A8DC-4673-ADA4-2C5C91484CBA");
                var userId = Guid.Parse("2B095E61-83D6-4233-8962-60A903C316A5");
                var sessiionId = Guid.Parse("ECAABBCA-8FB2-20EF-AFB6-14B3B2FAD024");
                var assetIds = new Guid[]
                {
                Guid.Parse("D0BA884B-657E-4E88-8B0E-821A2F067D79"),
                Guid.Parse("84D63893-1D9C-480E-B557-7AC053E015B3"),
                Guid.Parse("A8DBE4A3-0592-4732-9F8D-F06FF1332664"),
                };

                var guid = Guid.NewGuid().ToString();
                var zipId = guid + @"\" + guid + ".zip";

                //var accountAssets = await _assetService.GetSasShareLinkAsync(accountId, userId, "shareLink", new List<Guid>(assetIds), true, null, zipId);
                var assets = await _assetService.GetAccountAssetInfoByIdsAsync(accountId, userId, sessiionId, "shareLink", new List<Guid>(assetIds), true, DateTime.Now.AddDays(30), zipId);

                var msg = new
                {
                    MessageType = "ASSET_SHARED",
                    Id = Guid.NewGuid().ToString(),
                    Action = "ASSET_SHARED",
                    ShareAssetModel = new
                    {
                        AccountId = accountId.ToString(),
                        ZipId = guid + @"\" + guid + ".zip",
                        AssetInfo = assets
                    }
                };

                actionResult = await TestServiceBusSendAsync(busService, msg, msg.Id, "shareAssetWorker");
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _logger.LogError(ex, "error testing service bus");
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }

            _logger.LogInformation("END: TestShareAssetServiceBus (success)");
            return actionResult;
        }

        private async Task<IActionResult> TestServiceBusSendAsync(IBusSendService busService, object msg, string testId, string workerKey)
        {
            string successMsg;

            try
            {
                _logger.LogInformation("BEGIN: SendAsync");
                var userProperties = await busService.SendAsync(msg);
                object workerProperty;
                userProperties.TryGetValue(workerKey, out workerProperty);
                var workerName = string.IsNullOrEmpty(workerProperty?.ToString()) ? "a node on the aks cluster" : workerProperty?.ToString();
                successMsg = $@"
                    ******************************************************
                    * Message Sent: {testId} *
                    * {workerKey}: {workerName}
                    ******************************************************
                    ";
                _logger.LogInformation(successMsg);
                _logger.LogInformation("END: (success) SendAsync");
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _logger.LogError(ex, "error in common test routines");
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }

            return Content(successMsg);
        }

        [HttpGet]
        [Route("sbsf")]
        public async Task<IActionResult> TestServiceBusAccountCreated()
        {
            _logger.LogInformation("BEGIN: TestServiceBusAccountCreated");

            IActionResult actionResult;

            try
            {
                var busService = _busServiceFactory.CreateBusSendService(
                    _configuration["AccountCreatedServiceBus:Endpoint"],
                    _configuration["AccountCreatedServiceBus:TopicName"],
                    new ServiceBusSendSettings
                    {
                        ComputerName = _configuration["COMPUTERNAME"],
                        Environment = _configuration["DotnetEnvironment"],
                        TargetMachines = _configuration.Get<TargetMachineConfig>().TargetMachines
                    }
                );

                var msg = new //salesforceWorker
                {
                    MessageType = "TEST_STARTED",
                    Action = "TEST_STARTED",
                    Id = Guid.NewGuid().ToString()
                };
                actionResult = await TestServiceBusSendAsync(busService, msg, msg.Id, "salesforceWorker");
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _logger.LogError(ex, "error testing service bus");
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }

            _logger.LogInformation("END: TestServiceBusAccountCreated (success)");
            return actionResult;
        }

        [HttpGet]
        [Route("sbca")]
        public async Task<IActionResult> TestServiceBusCustomizeAsset([FromQuery] string local = "")
        {
            _logger.LogInformation("BEGIN: TestServiceBusCustomizeAsset");

            var busService = _busServiceFactory.CreateBusSendService(
                _configuration["CustomizeAssetServiceBus:Endpoint"],
                _configuration["CustomizeAssetServiceBus:TopicName"],
                new ServiceBusSendSettings
                {
                    ComputerName = _configuration["COMPUTERNAME"],
                    Environment = _configuration["DotnetEnvironment"],
                    TargetMachines = _configuration.Get<TargetMachineConfig>().TargetMachines
                }
            );

            IActionResult actionResult;
            if (local == string.Empty)
            {
                var msg = new // Only MessageType is importanted, other fields will get dropped when deserializing
                {
                    MessageType = "TEST_STARTED",
                    TestMessage = new
                    {
                        Id = Guid.NewGuid().ToString(),
                        Source = "Webapi"
                    }
                };

                actionResult = await TestServiceBusSendAsync(busService, msg, msg.TestMessage.Id, "customizeAssetWorker");
            }
            else
            {
                // TODO - this will go away complete once we've have
                // a proper test harness outside of webapi to send a real request

                // Test CustomizeAssetRequest with a request that will download
                var msg = new
                {
                    BlobDetails = new
                    {
                        ContainerName = _configuration["BlobStorage:UploadContainerName"],
                        ContainerNamePrefix = "b0bdaf76-3238-48e0-af8d-8f847085eb8b", // sbx accountName: BEM+ (standard) (burita+freetrial.sbx03.owner)
                        Name = "c9b1d9a1-ef62-4063-82e4-ed0ffe05cb29.jpg",
                        StorageAccountName = _configuration["BlobStorage:StorageAccountName"]
                    },
                    MessageType = "CUSTOMIZE_ASSET",
                    Opaque = new
                    {
                        SignalRConnectionId = Guid.NewGuid().ToString(),
                        Source = "WebapiTest"
                    }
                };

                // Leveraging TestServiceBusSendAsync, so we need to include Id in the message.                
                actionResult = await TestServiceBusSendAsync(busService, msg, Guid.NewGuid().ToString(), "customizeAssetWorker");
            }

            _logger.LogInformation("END: TestServiceBusCustomizeAsset (success)");
            return actionResult;
        }

        [HttpGet]
        [Route("log")]
        public IActionResult TestLogging()
        {
            string successMsg = $@"
                ******************************************************
                * /status/LOG hit at {DateTime.Now}                      
                ******************************************************";
            _logger.LogInformation(successMsg);

            return Content(successMsg);
        }

        [HttpGet]
        [Route("kv")]
        public async Task<IActionResult> TestKeyVaultEndpoint()
        {
            _logger.LogDebug("************ Unconditional Info  log entry (TestKeyVault)");
            _logger.LogDebug("************ Unconditional Debug log entry (TestKeyVault)");

            _logger.LogInformation("BEGIN: TestKeyVault");

            try
            {
                var result = await TestKeyVault();
                if (result.error)
                {
                    _logger.LogError(result.errorMessage);
                    return StatusCode(StatusCodes.Status500InternalServerError, result.errorMessage);
                }
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _logger.LogError(ex, "error testing key vault for key");
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }

            _logger.LogInformation("END: TestKeyVault");

            return Content($"Successful Key Vault test at { DateTime.UtcNow} ");
        }

        [HttpGet]
        [Route("bs")]
        public async Task<IActionResult> ForceHealth()
        {
            _logger.LogDebug("************ Unconditional Info  log entry (TestBlobStorage)");
            _logger.LogDebug("************ Unconditional Debug log entry (TestBlobStorage)");

            _logger.LogInformation("BEGIN: Test blob storage");

            _logger.LogDebug($"Test storage account:{_configuration["TestStorageAccount"]}");
            _logger.LogDebug($"Test container: {_configuration["TestContainer"]}");
            _logger.LogDebug($"Test blob:{_configuration["TestBlob"]}");

            var result = await TestBlobStorage();
            if (result.error)
            {
                _logger.LogError(result.errorMessage);
                return StatusCode(StatusCodes.Status500InternalServerError, result.errorMessage);
            }

            _logger.LogInformation("END: TestBlogStorage");

            return Content($"Successful Blob Storage test at { DateTime.UtcNow} ");
        }

        private async Task<TestResult> TestDatabase()
        {
            try
            {
                _logger.LogInformation("BEGIN: GetRoleByKeyAsync");
                await _roleService.GetRoleByKeyAsync("viewer");
                _logger.LogInformation("END: GetRoleByKeyAsync");
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _logger.LogError(ex, "error testing Database");
                return new TestResult { error = true, errorMessage = ex.Message };
            }

            return new TestResult { error = false };
        }

        private async Task<TestResult> TestServiceBus()
        {
            try
            {
                var busService = _busServiceFactory.CreateBusSendService(
                    _configuration["UserSyncServiceBus:Endpoint"],
                    _configuration["UserSyncServiceBus:TopicName"],
                    new ServiceBusSendSettings
                    {
                        ComputerName = _configuration["COMPUTERNAME"],
                        Environment = _configuration["DotnetEnvironment"],
                        TargetMachines = _configuration.Get<TargetMachineConfig>().TargetMachines
                    }
                );
                var msg = new
                {
                    Action = "TEST_STARTED",
                    TestId = Guid.NewGuid().ToString(),
                    Id = Guid.NewGuid().ToString()
                };
                _logger.LogInformation("BEGIN: SendAsync");
                await busService.SendAsync(msg);
                _logger.LogInformation("END: (success) SendAsync");
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _logger.LogError(ex, "error testing Service Bus");
                return new TestResult { error = true, errorMessage = ex.Message };
            }

            return new TestResult { error = false };
        }
        private async Task<TestResult> TestBlobStorage()
        {
            try
            {
                // Get a test stream
                byte[] byteArray = Encoding.ASCII.GetBytes($"Hello from Managed Identity at {DateTime.Now}");
                var stream = new System.IO.MemoryStream(byteArray);

                // Upload the blob.
                _logger.LogInformation("BEGIN: UploadAsync");
                await _blobService.UploadAsync(_configuration["TestContainer"], _configuration["TestBlob"], stream);
                _logger.LogInformation("END: (success) UploadAsync");
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _logger.LogError(ex, "error testing Blob Storage");
                return new TestResult { error = true, errorMessage = ex.Message };

            }

            return new TestResult { error = false };
        }

        private async Task<TestResult> TestKeyVault()
        {
            var vaultKey = _configuration["KeyVault:KeyToTest"];

            try
            {
                _logger.LogDebug($"Key Vault test key:{vaultKey}");

                _logger.LogInformation($"BEGIN: Key Vault read value for: {vaultKey}");

                var secret = await _secretClient.GetSecretAsync(vaultKey);
                var neverDisplayMe = secret.Value.Value;
                if (string.IsNullOrWhiteSpace(neverDisplayMe) || string.IsNullOrWhiteSpace(neverDisplayMe))
                {
                    string msg = "error testing Key Vault: key vault returned no value";
                    _logger.LogError(msg);
                    return new TestResult { error = true, errorMessage = msg };
                }
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
#pragma warning restore CA1031 // Do not catch general exception types
            {
                _logger.LogError(ex.Message);
                return new TestResult { error = true, errorMessage = ex.Message };
            }

            return new TestResult { error = false };
        }

        private class TestResult
        {
            public bool error { get; set; }
            public string errorMessage { get; set; }
        }

    }
}
