import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { HostListener } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';

import { hammerjs } from 'node_modules/hammerjs';
import { OidcFacade } from 'ng-oidc-client';

import { Observable } from 'rxjs';

import { AppStoreFacade } from './store/app-store/app-store.facade';
import { Context } from './core/models/context.model';
import { CustomTheme } from './core/models/custom-theme.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnDestroy, OnInit {
  assetCountTotal$: Observable<number>;
  collectionsIsLoaded$:  Observable<boolean>;
  context$: Observable<Context>;
  contextLoading$: Observable<boolean>;
  faviconUrl$: Observable<string>;
  hammerjs = hammerjs;
  mobileQuery: MediaQueryList;
  pluginName$: Observable<string>;
  salesForceChatScriptReady$: Observable<boolean>;
  selectedTheme$: Observable<CustomTheme>;
  title = 'application';

  private _mobileQueryListener: () => void;

  constructor (
    private appStoreFacade: AppStoreFacade,
    private oidcFacade: OidcFacade,
    changeDetectorRef: ChangeDetectorRef,
    media: MediaMatcher
    ) {
      this.mobileQuery = media.matchMedia('(max-width: 834px)');
      appStoreFacade.setMobileState(!this.mobileQuery.matches);
      this._mobileQueryListener = () => {
        changeDetectorRef.detectChanges();
        appStoreFacade.setMobileState(!this.mobileQuery.matches);
      }
      this.mobileQuery.addEventListener('change', this._mobileQueryListener);
  }

  addSalesForceChatScript(context: Context): void {
    this.appStoreFacade.addSalesForceChatScript(context);
  }

  ngOnDestroy(): void {
    this.mobileQuery.removeEventListener('change', this._mobileQueryListener);
  }

  ngOnInit(): void {
    // Example loading config from app component.
    // this.oidcFacade.configureOidcClient(oidcConfigSettings);
    this.oidcFacade.getOidcUser();

    const urlParams = new URLSearchParams(window.location.search);
    const pluginName = urlParams.get('pluginName');
    this.appStoreFacade.updatePluginName(pluginName);

    this.assetCountTotal$ = this.appStoreFacade.assetCountTotal$;
    this.collectionsIsLoaded$ = this.appStoreFacade.collectionsIsLoaded$;
    this.context$ = this.appStoreFacade.context.context$;
    this.contextLoading$ = this.appStoreFacade.context.contextIsLoading$;
    this.faviconUrl$ = this.appStoreFacade.faviconUrl$;
    this.salesForceChatScriptReady$ = this.appStoreFacade.salesForceChatScriptReady$;
    this.selectedTheme$ = this.appStoreFacade.selectedTheme$;
  }

  notifyLogout(): void {
    this.appStoreFacade.notifyLogout();
  }

  @HostListener('window:beforeunload', ['$event'])
  unloadHandler(event: Event): void {
      event.preventDefault();
      this.notifyLogout();
  }

}
