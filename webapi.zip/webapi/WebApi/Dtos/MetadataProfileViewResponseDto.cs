﻿using System;
using System.Text.Json.Serialization;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Dtos
{
    public class MetadataProfileViewResponseDto
    {
        [JsonPropertyName("assetCount")]
        public int AssetCount { get; set; }

        [JsonPropertyName("fieldCount")]
        public int FieldCount { get; set; }

        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [JsonPropertyName("metadataProfileTypeId")]
        public int MetadataProfileTypeId { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }
    }
}
