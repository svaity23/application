﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using WebApi.Dtos;
using WebApi.Services;
using WebApiTests.Shared;

namespace WebApiTests.Services
{
    [TestClass]
    public class DBUserService
    {
        private static readonly Guid TEST_ACCOUNT = Guid.Parse("5189526F-642F-449F-B018-5F5027A7191B"); // marcel@saguaro.ro


        private static damContext dbContext;
        private static UserService _sut;
        private static List<UserDetailDto> _testUsers;
        private static UserDetailDto _admin;
        private static UserDetailDto _contributor;
        private static UserDetailDto _viewer;

        [ClassInitialize]
        public static void BeforeClass(TestContext context)
        {
            Debug.WriteLine("Before all tests");
            dbContext = AzureSQLTools.InitializeDamContext();

            var logger = LoggerFactory.Create(logConfig =>
                        {
                            logConfig.AddConsole();
                        }).CreateLogger<UserService>();
            _sut = new UserService(null, logger, dbContext, null, null);
            _testUsers = AzureSQLTools.GetAccountUsers(dbContext, TEST_ACCOUNT);
            _admin = AzureSQLTools.GetTestUser(dbContext, "admin", TEST_ACCOUNT);
            _contributor = AzureSQLTools.GetTestUser(dbContext, "contributor", TEST_ACCOUNT);
            _viewer = AzureSQLTools.GetTestUser(dbContext, "viewer", TEST_ACCOUNT);

        }

        [ClassCleanup]
        public static void AfterClass()
        {
            CleanUp();
            dbContext.Dispose();
        }

        private static void CleanUp()
        {
            Debug.WriteLine("Clean up after all tests");
            /*
            dbContext.Database.ExecuteSqlRaw("delete from [dbo].[user] " +
                "where [accountId] = {0} " +
                "and comment like '" + COMMENT_PREFIX + "%'", TEST_ACCOUNT);
            */
        }

        [TestMethod("Test csv validation")]
        public void TestVerifyCsvFile()
        {
            var assembly = Assembly.GetExecutingAssembly();
            var resourceName = "WebApiTests.Resources.default.csv";

            using Stream stream = assembly.GetManifestResourceStream(resourceName);
            var respDto = _sut.BulkValidateCsvAsync(stream, TEST_ACCOUNT).Result;

            Assert.AreEqual(2, respDto.Users.Count);
            Assert.AreEqual(0, respDto.Errors.Count);
        }

        [TestMethod("Test csv validation with errors")]
        public void TestVerifyCsvFileErrors()
        {
            var assembly = Assembly.GetExecutingAssembly();
            var resourceName = "WebApiTests.Resources.errors.csv";

            using Stream stream = assembly.GetManifestResourceStream(resourceName);
            var respDto = _sut.BulkValidateCsvAsync(stream, TEST_ACCOUNT).Result;

            Assert.AreEqual(1, respDto.Users.Count);
            Assert.AreEqual(2, respDto.Errors.Count);
        }

        /*[TestMethod("Get collaborative user for an admin")]
        public void GetCollaborationUsers_Admin()
        {
            var response = _sut.GetCollaborationUsers(TEST_ACCOUNT, _admin.Id).Result;
            Assert.IsNotNull(response);
            Assert.IsTrue(response.Entities.Count > 0);

            bool foundViewer = false;
            bool foundInactive = false;
            foreach (UserDetailDto u in response.Entities)
            {
                if (!foundViewer
                    && string.Compare("viewer", u.RoleKey, StringComparison.InvariantCulture) == 0)
                    foundViewer = true;
                if (!foundInactive
                    && !u.Active)
                    foundInactive = true;
            }
            Assert.IsFalse(foundInactive);
            Assert.IsFalse(foundViewer);

        }

        [TestMethod("Get collaborative user for a contributor")]
        public void GetCollaborationUsers_Contributor()
        {
            var response = _sut.GetCollaborationUsers(TEST_ACCOUNT, _contributor.Id).Result;
            Assert.IsNotNull(response);
            Assert.IsTrue(response.Entities.Count > 0);

            bool foundViewer = false;
            bool foundInactive = false;
            foreach(UserDetailDto u in response.Entities)
            {
                if (!foundViewer 
                    && string.Compare("viewer", u.RoleKey, StringComparison.InvariantCulture) == 0)
                    foundViewer = true;
                if (!foundInactive
                    && !u.Active)
                    foundInactive = true;
            }
            Assert.IsFalse(foundInactive);
            Assert.IsFalse(foundViewer);
        }
        */
    }
}
