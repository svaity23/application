import { Injectable } from '@angular/core';

import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { BaseDataService } from './base-data.service';
import { Group } from '../models/entities/group.model';

export interface GroupsDataServiceInterface {
    add(group: Group): Observable<Group>;
    bulkDelete(groups: Group[]): Observable<string[]>;
    delete(id: string): Observable<Group>;
    getAll(): Observable<Group[]>;
    updateGroup(group: Group): Observable<Group>;
}

@Injectable({ providedIn: 'root' })
export class GroupsDataService extends BaseDataService implements GroupsDataServiceInterface {

    add(group: Group): Observable<Group> {
        const dto = {
            ExternalId: group.externalId,
            Active: true,
            Name: group.name,
            Description: group.description
        };
        const url = `${this.webApiUrl}/groups`;
        return this.createApiPost({ url, data: dto });
    }

    bulkDelete(groups: Group[]): Observable<string[]> {
        const ids: string[] = groups.map(gr => gr.id);
        const deleteGroupsRequest = {
            ids
        };
        const url = `${this.webApiUrl}/groups/bulk/deletes`;
        return this.createApiPost({ url, data: deleteGroupsRequest });
    }

    delete(id: string): Observable<Group> {
        const url = `${this.webApiUrl}/groups/${id}`;
        return this.createApiDelete({ url, options: { observe: 'response' } }).pipe(
            // eslint-disable-next-line @typescript-eslint/dot-notation
            map((data) => data['body'] as Group)
        );
    }

    getAll(): Observable<Group[]> {
        const url = `${this.webApiUrl}/groups`;
        return this.createApiGet({ url });
    }

    updateGroup(group: Group): Observable<Group> {
        const id = group.id;
        const dto = {
            Id: group.id,
            AccountId: group.accountId,
            ExternalId: group.externalId,
            Active: group.active,
            Name: group.name,
            Description: group.description
        };
        const url = `${this.webApiUrl}/groups/${id}`;
        return this.createApiPut({ url, data: dto });
    }
}
