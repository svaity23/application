import { Asset } from './asset.model';
import { Collection } from './collection.model';

export interface DragData {
    type: 'asset' | 'collection';
    data: Asset | Collection
}
