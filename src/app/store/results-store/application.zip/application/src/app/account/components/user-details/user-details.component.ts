import { ChangeDetectionStrategy, Component, EventEmitter, HostBinding, Input, OnChanges, OnInit, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { ControlContainer, NgForm } from '@angular/forms';

import { cn } from 'src/utils/cn';

import { Context } from '@app/core/models/context.model';
import { Group } from '@app/core/models/entities/group.model';
import { Role } from '@app/core/models/entities/role.model';
import { RoleKey } from '@app/core/enums/role-key.enum';
import { User } from '@app/core/models/entities/user.model';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class UserDetailsComponent implements OnInit, OnChanges {

  allUsersButtonText = 'All Users';
  @Input() className = '';
  @Input() context: Context;
  disabled: boolean;
  @Input() invalidEmail = false;
  @Input() invalidEmailMessage;
  multiAccount = false;
  @HostBinding('attr.ngNoHost') noHost = '';
  @Input() roles: Role[] = [];
  selectedGroup: number;
  selectedRole: string;
  @Input() showUserGroups = false;
  @Input() user: User;
  @Output() userChange: EventEmitter<User> = new EventEmitter<User>();
  @Input() userForm: NgForm;
  userGroupNames: string[];
  @Input() userGroups: Group[];
  @Input() userRoleKey: string;
  userToModify: User;
  @Output() validateUser: EventEmitter<User> = new EventEmitter<User>();

  constructor() {
    this.userGroupNames = ['None Selected (All assets visible)'];
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  enter($event: any): void {
    $event.preventDefault();
  }

  getGroupId(groupName: string): string {
    let result = '';
    if (this.userGroups.length > 0) {
      for (const userGroup of this.userGroups) {
        if (groupName && groupName === userGroup.name) {
          result = userGroup.id;
          break;
        }
      }
    }

    return result;
  }

  isAdminUser(): boolean {
    return this.userRoleKey === RoleKey.admin;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.user) {
      this.userToModify = { ...changes.user.currentValue };
      this.selectedRole = this.userToModify.roleId;
      this.disabled = false;
      if (this.userToModify.federated === true) {
        this.disabled = true;
      }
      else if (this.userToModify.accountCount > 1) {
        this.multiAccount = true;
        this.disabled = (this.userToModify.email === this.context.email) ? false : true;
      }
    }
  }

  ngOnInit(): void {
    this.className = cn('user-details', this.className);

    this.selectedGroup = 0;
    const groupId = this.user ? this.user.groupId : '';

    if (this.userGroups.length > 0) {
      for (const group of this.userGroups) {
        this.userGroupNames.push(group.name);
        if (groupId?.toLowerCase() === group.id.toLowerCase()) {
          this.selectedGroup = this.userGroupNames.length - 1;
        }
      }
    }
  }

  selectedRoleValueChange($event, roleId: string): void {
    if ($event) {
      this.selectedRole = roleId;
      this.userToModify.roleId = roleId;
      this.userForm.form.markAsTouched();
    } else {
      this.selectedRole = null;
      this.userToModify.roleId = null;
      this.userForm.form.markAsUntouched();
    }
    this.userChange.emit(this.userToModify);
  }

  setRole(roleId: string): void {
    this.selectedRole = roleId;
    this.userToModify.roleId = roleId;
    this.userForm.form.markAsTouched();
  }

  userActiveChange(): void {
    this.userForm.form.markAsTouched();
    this.userToModify.active = !this.userToModify.active;
    this.userChange.emit(this.userToModify);
  }

  userGroupChange(selectedIndex: number): void {
    this.userForm.form.markAsTouched();
    const groupName = this.userGroupNames[selectedIndex];
    if (selectedIndex === 0) {
      this.userToModify.groupId = null;
    } else {
      this.userToModify.groupId = this.getGroupId(groupName);
    }
    this.userChange.emit(this.userToModify);
  }

  // this only should be used for email, firstname, lastname fields for now
  // special handling of validation
  userValueChange(forceValidation = false): void {
    this.userChange.emit(this.userToModify);

    // email field alreaedy will validate on model change
    // which triggers its validateUserChange.  No double tap needed.
    if (forceValidation === true) {
      this.validateUserChange();
    }
  }

  validateUserChange(): void {
    if (this.userToModify.email?.trim() != null && this.userToModify.firstName.trim() != null && this.userToModify.lastName.trim() != null) {
      this.validateUser.emit(this.userToModify);
    }
  }
}
