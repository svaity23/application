import { AttachmentEntry } from './asset-attachment-entry.model';
import { FileMetadataTag } from './file-metadata-tag.model';
import { Metadata } from './entities/metadata.model';

export interface AssetAttachment {
  accountName: string;
  assetBlob: string;
  assetDescription: string;
  assetId: string;
  containerName: string;
  metadata: Metadata[];
  fileMetadataTags?: FileMetadataTag[] | [];
  results: AttachmentEntry[];
  statusCode: number;
}

/*
{
    "messageType": "THUMBNAIL_READY",
    "assetId": "95d19ff1-2372-4965-8734-c08fbf948001",
    "statusCode": 206,
    "containerName": "assets",
    "assetBlob": "95d19ff1-2372-4965-8734-c08fbf948001.pdf",
    "accountName": "5189526f642f449fb0185f50",
    "assetDescription": "test",
    "metadataInfo": [
          {
            "id": "51ADB787-92CF-47C3-A1A5-778687AF3E01",
            "assetId": "1626D8DB-AA90-4B46-985A-7248A4AB8EEC",
            "metadataFieldId": "58190BBB-5964-4710-8DF1-025F9472F8A2",
            "value": "Marcel Stoica"
          },
          {
            "id": "B343C377-B38F-4E5E-ABC2-70C2B5B2051D",
            "assetId": "1626D8DB-AA90-4B46-985A-7248A4AB8EEC",
            "metadataFieldId": "4960B3F8-DF04-4A7A-9623-D711041A8E09",
            "value": "Wed Jun 10 2020"
          }
        ],
        "results": [
        {
            "name": "web",
            "statusCode": 200,
            "containerName": "web",
            "blobName": "95d19ff1-2372-4965-8734-c08fbf948001.png"
        },
        {
            "name": "thumb",
            "statusCode": 200,
            "containerName": "thumbnail",
            "blobName": "95d19ff1-2372-4965-8734-c08fbf948001.png"
        },
        {
            "name": "meta",
            "statusCode": 501,
            "containerName": null,
            "blobName": null
        },
        {
            "name": "low-res",
            "statusCode": 200,
            "containerName": "low-resolution",
            "blobName": "95d19ff1-2372-4965-8734-c08fbf948001.jpg"
        }
    ],
}

*/
