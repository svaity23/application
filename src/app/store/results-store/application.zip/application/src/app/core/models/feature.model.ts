export interface Feature {
    key: string;
}
