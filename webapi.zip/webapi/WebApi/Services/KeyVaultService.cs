﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using Azure.Security.KeyVault.Secrets;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using WebApi.Common.Constants;

namespace WebApi.Services
{
    public class KeyVaultService
    {
        private readonly IConfiguration _configuration;
        private readonly SecretClient _secretClient;
        private readonly ILogger<KeyVaultService> _logger;
        private Dictionary<string, string> _secrets;
        private Dictionary<string, X509Certificate2> _certificates;

        public KeyVaultService(IConfiguration configuration, SecretClient secretClient, ILogger<KeyVaultService> logger)
        {
            _configuration = configuration;
            _secretClient = secretClient;
            _logger = logger;

            InitializeKeyVaultSecrets();
            InitializeKeyVaultCertificates();
        }

        private void InitializeKeyVaultSecrets()
        {
            _logger.LogDebug("WebApi KeyVaultService: Initializing KeyVault Secret Client");

            _secrets = new Dictionary<string, string>();
            try
            {
                _secrets.Add(KeyVaultSecretKey.BlobStorageKey, GetSecretFromKeyVault(_configuration[KeyVaultSecretKey.BlobStorageKey]));
                _secrets.Add(KeyVaultSecretKey.GoogleRecaptchaV2, GetSecretFromKeyVault(_configuration[KeyVaultSecretKey.GoogleRecaptchaV2]));
                _secrets.Add(KeyVaultSecretKey.HubspotClientSecret, GetSecretFromKeyVault(_configuration[KeyVaultSecretKey.HubspotClientSecret]));
                _secrets.Add(KeyVaultSecretKey.SlackClientSecret, GetSecretFromKeyVault(_configuration[KeyVaultSecretKey.SlackClientSecret]));
                _secrets.Add(KeyVaultSecretKey.CanvaClientSecret, GetSecretFromKeyVault(_configuration[KeyVaultSecretKey.CanvaClientSecret]));

                _logger.LogDebug("WebApi KeyVaultService: Initialized Secrets");

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "WebApi KeyVaultService: Failed Initializing Secrets");
            }
        }

        private void InitializeKeyVaultCertificates()
        {
            _logger.LogDebug("WebApi KeyVaultService: Initializing KeyVault Certificates");

            _certificates = new Dictionary<string, X509Certificate2>();

            try
            {
                _certificates.Add(KeyVaultSecretKey.IdTokenAdb2cCert, GetCertificateFromKeyVault(_configuration[KeyVaultSecretKey.IdTokenAdb2cCert]));

                _logger.LogDebug("WebApi KeyVaultService: Initialized Certificates");

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "WebApi KeyVaultService: Failed Initializing Certificates");
            }
        }

        private string GetSecretFromKeyVault(string key)
        {
            var secret = _secretClient.GetSecret(key);
            string value = secret.Value.Value;

            if (string.IsNullOrWhiteSpace(value))
            {
                _logger.LogError(new InvalidOperationException($"Cannot fetch key={key} from Key Vaults"), "WebApi KeyVaultService: Failed loading secret.");
            }

            return value ?? "";
        }

        private X509Certificate2 GetCertificateFromKeyVault(string key)
        {
            //Certificate Client only get the public part of the certificate.  
            //Therefore, we use the SecretClient to get the certificate's private half as well. 
            //The Private Key is necessary to sign the JWT. 
            string encodedCert = GetSecretFromKeyVault(key);
            if (string.IsNullOrWhiteSpace(encodedCert))
            {
                _logger.LogError(new InvalidOperationException($"Cannot fetch certificate={key} from Key Vaults"), "WebApi KeyVaultService: Failed loading certificate.");
                return null;
            }
            return new X509Certificate2(Convert.FromBase64String(encodedCert));
        }

        public string GetSecret(string key)
        {
            return  _secrets[key] ?? "";
        }

        public X509Certificate2 GetCertificate(string key)
        {
            return _certificates[key] ?? null;
        }
    }
}
