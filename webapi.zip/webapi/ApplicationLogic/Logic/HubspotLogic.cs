﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Threading.Tasks;

namespace ApplicationLogic.Logic
{
    public class HubspotLogic
    {
        public ILogger<HubspotLogic> Logger { get; set; }
        private readonly HubspotFinder _finder;

        public HubspotLogic(damContext context)
        {
            _finder = new HubspotFinder(context);
            Logger = NullLogger<HubspotLogic>.Instance;
        }

        public async Task<string> GetHubspotAssets(Guid accountId, Guid userId, string jsonParams)
        {
            return await _finder.GetHubspotAssets(accountId, userId, jsonParams);
        }

        public async Task<string> UpsertHubspotAssetsAsync(Guid accountId, Guid userId, Guid sessionId, string jsonParams)
        {
            return await _finder.UpsertHubspotAssetsAsync(accountId, userId, sessionId, jsonParams);
        }

        public async Task<string> DeleteHubspotAssetsAsync(Guid accountId, Guid userId, Guid sessionId, string jsonParams)
        {
            return await _finder.DeleteHubspotAssetsAsync(accountId, userId, sessionId, jsonParams);
        }

        public async Task<string> GetHubspotSyncErrorsAsync(Guid accountId)
        {
            return await _finder.GetHubspotSyncErrorsAsync(accountId);
        }

        public async Task<string> SyncAllAsync(Guid accountId)
        {
            return await _finder.SyncAllAsync(accountId);
        }

        public async Task<string> ResyncCollectionAsync(Guid accountId, Guid userId, Guid sessionId, Guid? collectionId)
        {
            return await _finder.ResyncCollectionAsync(accountId, userId, sessionId, collectionId);
        }

        public async Task<string> StopSyncCollectionAsync(Guid accountId, Guid userId, Guid sessionId, Guid? collectionId)
        {
            return await _finder.StopSyncCollectionAsync(accountId, userId, sessionId, collectionId);
        }
    }
}
