import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { BaseDataService } from './base-data.service';

import { AssetDownloadRequest } from '../models/asset-download-request.model';
import { SignalRSource } from '../enums/signal-r-source.enum';

export interface DownloadDataServiceInterface {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  downloadAssets(assetDownloadRequests: Array<AssetDownloadRequest>): Observable<any>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  downloadFile(fileUrl: string): Observable<any>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  downloadFromContainer(containerName: string): Observable<any>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  downloadFromLightbox(accountId: string, assetDownloadRequests: Array<AssetDownloadRequest>): Observable<any>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  downloadSharedAssets(assetDownloadRequests: Array<AssetDownloadRequest>, daysValid: number): Observable<any>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  queueAssetDownload(assetRequests: AssetDownloadRequest[], source: SignalRSource, conversionType?: number): Observable<any>;
}

@Injectable({ providedIn: 'root' })
export class DownloadDataService extends BaseDataService implements DownloadDataServiceInterface {

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private iDownload: any;

  downloadAndSave(downloadKey: string, _fileName: string): void {
    // Filesaver used _fileName but we can refactor this out if we really
    // dont care for it.  Leaving as a reminder that we do get back
    // fileName from the download request for single and multi file
    const streamUrl = `${this.downloadApiUrl}/download/` + downloadKey;
    this.iframeDownload(streamUrl);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  downloadAssets(assetDownloadRequests: Array<AssetDownloadRequest>): Observable<any> {
    const url = `${this.downloadApiUrl}/download/assets`;
    return this.createApiPost({ url, data: assetDownloadRequests });
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  downloadFile(fileUrl: string): Observable<any> {
    return this.createApiGet({ url: fileUrl, options: { reportProgress: true, observe: 'events', responseType: 'blob' } });
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  downloadFromContainer(subFolderId: string): Observable<any> {
    const url = `${this.downloadApiUrl}/download/conversions/${subFolderId}`;
    return this.createApiPost({ url });
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  downloadFromLightbox(accountId: string, assetDownloadRequests: Array<AssetDownloadRequest>): Observable<any> {
    const request = {
      accountId,
      assetDownloadRequests
    }
    const url = `${this.downloadApiUrl}/download/lightbox`;

    // Lightboxes are public. We must generate an anon post request.
    return this.createAnonApiPost({ url, data: request });
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  downloadSharedAssets(assetDownloadRequests: Array<AssetDownloadRequest>, daysValid: number): Observable<any> {
    const request = {
      assetDownloadRequests,
      daysValid
    }
    const url = `${this.downloadApiUrl}/download/shared`;

    return this.createApiPost({ url, data: request });
  }

  // TODO: change name of this. getDownloadEndpointUrl?
  getDownloadUrl(key: string): string {
    const url = `${this.downloadApiUrl}/download/${key}`;
    return url;
  }

  // TODO: Potential cleanup. The naming of the endpoint is confusing.
  // Maybe change and move to asset data service as queue or conversion verb.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  queueAssetDownload(assetRequests: AssetDownloadRequest[], source: SignalRSource, conversionType?: number): Observable<any> {
    const request = {
      conversionType,
      // signalRConnectionId, // This will get attached via the signal-r.interceptor.
      assets: assetRequests,
      source
    };

    const url = `${this.webApiUrl}/assets/download`;
    return this.createApiPost({ url, data: request });
  }

  private iframeDownload(url: string): void {
    if (this.iDownload) {
      this.iDownload.src = url;
    } else {
      this.iDownload = document.createElement('iframe');
      this.iDownload.src = url;
      this.iDownload.style = 'position: absolute; width:0; height:0; border:0;';
      document.body.appendChild(this.iDownload);
    }
  }
}
