﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.Logic;
using ApplicationLogic.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApi.Dtos;
using WebApi.Dtos.Setting;
using WebApi.Extensions;

namespace WebApi.Services
{
    public class IntegrationService
    {
        private readonly ILogger<IntegrationService> _logger;
        private readonly IntegrationLogic _integrationLogic;
        private readonly JsonSerializer _jsonSerializer;
        private readonly ServiceBusService _serviceBusService;

        public IntegrationService(ILogger<IntegrationService> logger, damContext context, ServiceBusService serviceBusService)
        {
            _logger = logger;
            _integrationLogic = new IntegrationLogic(context);
            _logger.LogInformation("IntegrationService initialized");
            _jsonSerializer = JsonSerializer.Create(new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() });
            _serviceBusService = serviceBusService;
        }


        public async Task<List<IntegrationDto>> GetMarcomIntegrations(Guid accountId)
        {
            string resultJson = await _integrationLogic.GetMarcomIntegrations(accountId);
            var integrations = JsonConvert.DeserializeObject<List<IntegrationDto>>(resultJson);
            return integrations;
        }       

        public async Task SyncWithMarcomPortal(Guid accountId, Guid userId, IntegrationDto integration, string signalRId, string signalRSource, Guid? assetIdParam = null)
        {
            //Send Message to the DistributedMarketing container. 
            string token = integration.Token;
            
            string assetId = assetIdParam?.ToString();
            string integrationId = integration.Id.ToString();
            object message = new
            {
                Action = "MARCOM_PORTAL_LIBRARY_INTEGRATION",
                Token = token,
                AccountId = accountId,
                AssetId = assetId, //This is not a required value and will only be passsed in the modify asset scenario.
                IntegrationId = integrationId,
                UserId = userId,
                IntegrationStatus = integration.Status,
                SignalRConnectionId = signalRId,
                SignalRSource = signalRSource
            };
            await _serviceBusService.SignalDistributedMarketing(message);
        }

        public async Task<UpsertResponse<IntegrationDto>> UpsertIntegrationAsync(Guid accountId, Guid userId, IntegrationDto integrationDto)
        {
            var jsonInput = integrationDto.ToJsonString();
            //TODO:  this passes the signalR data into the stored proc which is not needed.  remove uneeneded params from jsonInput. 
            string resultJson = await _integrationLogic.UpsertIntegrationAsync(accountId, jsonInput);

            //Start Sync with MarcomPortal.  Insert a row into the integration table. 
            UpsertResponse<IntegrationDto> result = JsonConvert.DeserializeObject<UpsertResponse<IntegrationDto>>(resultJson);
            if (integrationDto.Key == "marcom-library" && result.Entity != null)
            {
                await SyncWithMarcomPortal(accountId, userId, result.Entity, integrationDto.SignalRConnectionId, integrationDto.SignalRSource);
            }
            return result;            
        }

    }
}
