﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SignalRHub.Messages
{
    public class SaveErrorDTO
    {
        public string Id { get; set; }
        public List<string> Errors;
    }
}
