﻿using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Threading.Tasks;

namespace ApplicationLogic.Logic
{
    public class GroupLogic
    {
        private readonly GroupFinder _finder;
        private readonly NullLogger<GroupLogic> _logger;

        public GroupLogic(damContext context)
        {
            _finder = new GroupFinder(context);
            _logger = NullLogger<GroupLogic>.Instance;
        }

        public async Task<string> GetAllGroupsAsync(Guid accountId, Guid userId)
        {
            return await _finder.GetAllGroupAsync(accountId, userId);
        }

        public async Task<string> DeleteGroupAsync(Guid accountId, Guid userId, string jsonGroups)
        {
            return await _finder.DeleteGroupAsync(accountId, userId, jsonGroups);
        }

        public async Task<string> SaveGroupAsync(Guid accountId, Guid userId, string jsonNewGroup)
        {
            return await _finder.SaveGroupAsync(accountId, userId, jsonNewGroup);
        }

    }
}
