﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using ApplicationLogic.DomainModel.Finders;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace ApplicationLogic.Logic
{
    public class RoleLogic
    {
        public ILogger<RoleLogic> Logger { get; set; }

        private readonly RoleFinder _finder;

        public RoleLogic(damContext context)
        {
            _finder = new RoleFinder(context);
            Logger = NullLogger<RoleLogic>.Instance;            
        }

        public async IAsyncEnumerable<Role> GetAccountRolesAsync(Guid accountId)
        {
            Logger.LogInformation($"[Logic] Getting roles for account = {accountId}");

            var results = _finder.GetByAccountIdAsync(accountId);
            await foreach (var result in results)
            {
                yield return result;
            }
        }

        public async Task<Role> GetByKey(string key)
        {
            return await _finder.GetByKey(key);
        }

        public async Task<Role> FindByIdAsync(Guid id)
        {
            return await _finder.FindByIdAsync(id);
        }
     
    }
}
