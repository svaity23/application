
export interface TagFieldValue {
    id: string;
    value: string;
}

/*
tags (to support type ahead)
              - accountId
              - value: {"tag1", "tag2", "tag3", "tag1", "tag2", "tag3", "tag1", "tag2", "tag3", "tag1", "tag2", "tag3"}

*/
