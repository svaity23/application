﻿using ApplicationLogic.DomainModel;
using ApplicationLogic.DomainModel.Context;
using Marcom.Azure.ServiceBus;
using Marcom.Azure.ServiceBus.Config;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Dtos;

namespace WebApi.Services
{
    public class AdminService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<AdminService> _logger;        
        private readonly IBusServiceFactory _busServiceFactory;
        private readonly AccountService _accountService;
        private readonly AssetService _assetService;
        private readonly damContext _context;

        public AdminService(IConfiguration configuration, damContext context, ILogger<AdminService> logger, AccountService accountService, IBusServiceFactory busServiceFactory, AssetService assetService)
        {
            _assetService = assetService;
            _configuration = configuration;
            _logger = logger;
            _busServiceFactory = busServiceFactory;
            _accountService = accountService;
            _context = context;
        }

        public async Task DeleteOldStorage()
        {
            var busService = _busServiceFactory.CreateBusSendService(
                _configuration["AssetConsolidationServiceBus:Endpoint"],
                _configuration["AssetConsolidationServiceBus:TopicName"],
                new ServiceBusSendSettings
                {
                    ComputerName = _configuration["COMPUTERNAME"],
                    Environment = _configuration["DotnetEnvironment"],
                    TargetMachines = _configuration.Get<TargetMachineConfig>().TargetMachines
                });

            var accounts = await _accountService.GetAllAccountsAsync(true);

            var storageAccountName = GetStorageAccountName();
            foreach (var account in accounts)
            {                
                // Only process accounts that still have an old storage account name stored in DB
                if (account.StorageAccountName != storageAccountName)
                {
                    var message = new
                    {
                        AccountId = account.Id,
                        MessageType = "BULK_STORAGE_DELETE"
                    };

                    await busService.SendAsync(message);
                }
            }
        }

        private string GetStorageAccountName()
        {
            return _configuration["BlobStorage:StorageAccountName"];
        }

        public async Task<Tuple<int, int>> ProcessAssetsAsync(List<Asset> assets)
        {
            DateTime minDate = new DateTime(2021, 7, 1, 0, 0, 0);
            DateTime maxDate = new DateTime(2021, 7, 1, 23, 59, 59);

            var assetsToProcess = assets.Where(a => a.Modified < maxDate && a.Modified > minDate);

            int successCount = 0;
            int errorCount = 0;

            var options = new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver()
            };

            foreach (var assetToProcess in assetsToProcess)
            {
                try
                {
                    object attachmentObj = JsonConvert.DeserializeObject<object>(assetToProcess.Attachment, options);
                    var dynamicAttachment = (dynamic)attachmentObj;

                    foreach (var property in dynamicAttachment)
                    {
                        var propName = property.Name;
                        if (propName == "results")
                        {
                            var results = property.Value;

                            foreach (var result in results)
                            {
                                var name = result.name;
                                if (name == "low-res")
                                {
                                    var blobName = result.blobName.ToString();
                                    result.blobName = blobName.Replace(".png", ".jpg");
                                    var newAttachmentJson = JsonConvert.SerializeObject(dynamicAttachment);
                                    assetToProcess.Attachment = newAttachmentJson;
                                    _context.Update(assetToProcess);
                                    await _context.SaveChangesAsync();

                                    successCount++;
                                }
                            }
                        }
                    }
                }
                catch(Exception ex)
                {
                    _logger.LogError("error processing assetId: " + assetToProcess.Id, ex);
                    errorCount++;
                }
            }

            return new Tuple<int, int>(successCount, errorCount);
        }
    }
}
