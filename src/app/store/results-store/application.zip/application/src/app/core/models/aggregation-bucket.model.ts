export interface AggregationBucket {
  count: number;
  name: string;
}
