﻿using ApplicationLogic.Models;
using System.Text.Json.Serialization;
using WebApi.Dtos.Setting;

namespace WebApi.Dtos
{
    public class ActivateAssetsForFinishUploadResponseDto
    {
        [JsonPropertyName("updates")]
        public UpdateEntityResponse[] Updates { get; set; }

        [JsonPropertyName("integrationSettings")]
        public AreaSettingDto[] IntegrationSettings { get; set; }
    }
}
