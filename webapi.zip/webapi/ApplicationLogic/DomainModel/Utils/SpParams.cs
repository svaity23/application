﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;

namespace ApplicationLogic.DomainModel.Utils
{
    public class SpParams
    {
        private const string JsonInputParam         = "@jsonInput";
        private const string AccountIdParam         = "@accountId";
        private const string UserIdParam            = "@userId";
        private const string SessionIdParam         = "@sessionId";
        private const string AssetIdParam           = "@assetId";
        private const string EmailParam             = "@email";
        private const string IncludeInactiveParam   = "@includeInactive";

        List<SqlParameter> parameters = new List<SqlParameter>();

        public SpParams WithAccountId(Guid? accountId)
        {
            SqlParameter param;
            if (accountId != null)
            {
                param = new SqlParameter(AccountIdParam, SqlDbType.UniqueIdentifier)
                {
                    Value = accountId
                };
            }
            else
            {
                param = new SqlParameter(AccountIdParam, SqlDbType.UniqueIdentifier)
                {
                    Value = DBNull.Value
                };
            }

            parameters.Add(param);
            return this;
        }

        public SpParams WithEmail(string Email)
        {
            SqlParameter param = new SqlParameter(EmailParam, SqlDbType.NVarChar)
            {
                Value = Email
            };
            parameters.Add(param);
            return this;
        }

        public SpParams WithUserId(Guid? userId)
        {
            SqlParameter param;
            if (userId != null)
            {
                param = new SqlParameter(UserIdParam, SqlDbType.UniqueIdentifier)
                {
                    Value = userId
                };
            }
            else
            {
                param = new SqlParameter(UserIdParam, SqlDbType.UniqueIdentifier)
                {
                    Value = DBNull.Value
                };
            }
            parameters.Add(param);
            return this;
        }
        public SpParams WithSessionId(Guid? sessionId)
        {
            SqlParameter param;
            if (sessionId != null)
            {
                param = new SqlParameter(SessionIdParam, SqlDbType.UniqueIdentifier)
                {
                    Value = sessionId
                };
            }
            else
            {
                param = new SqlParameter(SessionIdParam, SqlDbType.UniqueIdentifier)
                {
                    Value = DBNull.Value
                };
            }
            parameters.Add(param);
            return this;
        }

        public SpParams WithAssetId(Guid? assetId)
        {
            SqlParameter param;
            if (assetId != null)
            {
                param = new SqlParameter(AssetIdParam, SqlDbType.UniqueIdentifier)
                {
                    Value = assetId
                };
            }
            else
            {
                param = new SqlParameter(AssetIdParam, SqlDbType.UniqueIdentifier)
                {
                    Value = DBNull.Value
                };
            }
            parameters.Add(param);
            return this;
        }

        public SpParams WithJson(string json)
        {
            SqlParameter param = new SqlParameter(JsonInputParam, SqlDbType.NVarChar)
            {
                Value = json
            };
            parameters.Add(param);
            return this;
        }

        public SpParams WithString(string paramName, string value)
        {
            SqlParameter param = new SqlParameter($"@{paramName}", SqlDbType.NVarChar)
            {
                Value = value
            };
            parameters.Add(param);
            return this;
        }

        public SpParams WithBigInt(string paramName, long? value)
        {
            SqlParameter param = new SqlParameter($"@{paramName}", SqlDbType.BigInt)
            {
                Value = value
            };
            parameters.Add(param);
            return this;
        }

        public SpParams WithDateTime2(string paramName, DateTime? value)
        {
            SqlParameter param = new SqlParameter($"@{paramName}", SqlDbType.DateTime2)
            {
                Value = value
            };
            parameters.Add(param);
            return this;
        }
        public SpParams WithGuid(string paramName, Guid value)
        {
            SqlParameter param = new SqlParameter($"@{paramName}", SqlDbType.UniqueIdentifier)
            {
                Value = value
            };
            parameters.Add(param);
            return this;
        }


        internal SpParams WithIncludeInactive(bool includeInactive)
        {
            SqlParameter param = new SqlParameter(IncludeInactiveParam, SqlDbType.Bit)
            {
                Value = includeInactive
            };
            parameters.Add(param);
            return this;
        }

        public List<SqlParameter> Build()
        {
            return this.parameters;
        }
    }
}
