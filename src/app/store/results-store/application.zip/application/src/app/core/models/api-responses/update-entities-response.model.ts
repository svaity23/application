import { UpdateEntityResponse } from './update-entity-response.model';

export interface UpdateEntitiesResponse {
    updates: UpdateEntityResponse[]
}
