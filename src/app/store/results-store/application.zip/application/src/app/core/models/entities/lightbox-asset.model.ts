import { AssetAttachment } from '../asset-attachment.model';
import { AssetViewState } from '@app/core/models/view-states/asset-view-state.model';
import { FileGroupType, FileType } from '@app/core/enums';

// todo: Many of these properties can and should be removed. The WebApi and stored proc should also reflect the property changes.
// tslint:disable-next-line: interface-name
export interface LightboxAsset {
    accountId?: string;
    active?: boolean;
    attachment?: AssetAttachment;
    created: string; // this never gets converted to date when we map from webApi
    description: string;
    error: string[]; // todo: not sure if thi will remain since sp not return
    fileExtension: FileType; // will be a field in the table soon?
    fileGroup: FileGroupType;
    fileName: string;
    fileSize: number;
    id: string;
    mediaType?: string;
    modified?: string; // this never gets converted to date when we map from webApi
    name: string;
    uri?: string;
    viewState: AssetViewState;
}
